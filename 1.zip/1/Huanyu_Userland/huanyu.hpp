#pragma once

/*
 * ============================================================================
 *  欢愉 (Huanyu) —— 用户态对接头文件（单文件，开箱即用）
 * ============================================================================
 *
 *  内核侧：huanyu.kpm（KernelPatch 模块）
 *  传输层：KernelPatch supercall（__NR_supercall = 45），不走 ioctl
 *
 *  用法（不需要超级密钥）：
 *      hy_driver drv;                       // 默认走 "su"，免密钥
 *      if (!drv.is_ready()) return;
 *
 *      drv.initialize(drv.get_name_pid("com.example.game"));
 *      uint64_t base = drv.get_module_base("libil2cpp.so");
 *      uint32_t v = drv.read<uint32_t>(base + 0x1000);
 *
 *      uint64_t h = drv.bp_inst_pte(pid, addr);      // PTE 影子页断点
 *      auto hits = drv.bp_get_hits(h);
 *      drv.bp_uninst(h);
 *
 *  若你的设备确实设置了自定义超级密钥：
 *      hy_driver drv("你的超级密钥");
 *
 *  编译：
 *      aarch64-linux-android31-clang++ -std=c++17 your.cpp -o your
 *
 *  注意：
 *      - 全部内联，无需链接任何库
 *      - sc_kpm_control 已内置（走 __NR_supercall），不依赖 KernelPatch 用户态库
 *
 *  【为什么不需要超级密钥】
 *  KernelPatch 的 supercall 鉴权逻辑（kernel/patch/common/supercall.c）：
 *
 *      int is_authed = 0;
 *      if (has_preset_superkey())          // 用户设了自定义密钥才校验
 *          is_authed = !auth_superkey(key);
 *      if (is_trusted_manager_uid(uid))    // APatch 管理器 uid
 *          is_authed = 1;                  // 无需任何 key
 *      else if (is_su_allow_uid(uid))      // root shell（已 su 授权）
 *          is_trusted_caller = 1;          // 注意：这里不设 is_authed
 *
 *  所以两种常见情况都能免密钥：
 *    a) 调用者是 APatch 管理器进程 -> 直接 is_authed = 1，key 传什么都行
 *    b) 没设自定义密钥（superkey 为空）-> auth_superkey 的逐位 XOR 循环
 *       因 superkey[0] == '\0' 立即结束，rc == 0，任何 key 都通过
 *
 *  只有"设了自定义密钥 + 以普通 root shell 调用"才必须给真密钥，
 *  那种情况用 hy_driver drv("真实密钥") 即可。
 * ============================================================================
 */

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cerrno>
#include <string>
#include <vector>
#include <initializer_list>
#include <utility>
#include <type_traits>

#include <fcntl.h>
#include <dirent.h>
#include <unistd.h>
#include <paths.h>
#include <signal.h>
#include <termios.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/syscall.h>
#include <sys/uio.h>

#include <linux/types.h>
#include <linux/input.h>
#include <linux/uinput.h>

/* ==========================================================================
 * 一、supercall 底层（内置，无需外部库）
 * ========================================================================== */

#ifndef __NR_supercall
#define __NR_supercall 45
#endif


/* ---- prctl 免鉴权通道（内核侧 hy_prctl.c 对应） ---- */
#ifndef __NR_prctl
#define __NR_prctl 167
#endif
#define HY_PRCTL_MAGIC 0x4879756eULL   /* "Hyun" */
#define HY_SUPERCALL_MAGIC 0x1158
#define HY_KP_MAJOR 0
#define HY_KP_MINOR 13
#define HY_KP_PATCH 9

/*
 * supercall 命令号。
 * 取自 KernelPatch 源码 kernel/patch/include/uapi/scdefs.h（0.13.x），
 * 之前这里写的是 0x1005/0x1006/0x1023/0x1024/0x1100/0x1101，全部对不上，
 * 所以版本查询永远返回失败。
 */
#define SUPERCALL_HELLO              0x1000
#define SUPERCALL_KLOG               0x1004
#define SUPERCALL_BUILD_TIME         0x1007
#define SUPERCALL_KERNELPATCH_VER    0x1008
#define SUPERCALL_KERNEL_VER         0x1009
/* 旧版 KP（0.10.x 及更早）用过的号，保留用于回退探测 */
#define SUPERCALL_KERNELPATCH_VER_OLD 0x1005
#define SUPERCALL_KERNEL_VER_OLD      0x1006
#define SUPERCALL_SU                 0x1010
#define SUPERCALL_SU_TASK            0x1011
#define SUPERCALL_KPM_LOAD           0x1020
#define SUPERCALL_KPM_UNLOAD         0x1021
#define SUPERCALL_KPM_CONTROL        0x1022
#define SUPERCALL_KPM_NUMS           0x1030
#define SUPERCALL_KPM_LIST           0x1031
#define SUPERCALL_KPM_INFO           0x1032

#define SUPERCALL_HELLO_MAGIC 0x11581158

namespace hy_detail {

/*
 * 版本 + 命令打包：
 *   [63..32] = version_code (MAJOR<<16 | MINOR<<8 | PATCH)
 *   [31..16] = 0x1158
 *   [15..0]  = cmd
 */
static inline long ver_and_cmd(long cmd,
                               int major = HY_KP_MAJOR,
                               int minor = HY_KP_MINOR,
                               int patch = HY_KP_PATCH)
{
    uint32_t vc = (uint32_t)((major << 16) + (minor << 8) + patch);
    return ((long)vc << 32) | ((long)HY_SUPERCALL_MAGIC << 16) | (cmd & 0xFFFF);
}

static inline long sc_hello(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_HELLO));
}

static inline bool sc_ready(const char *key)
{
    return sc_hello(key) == SUPERCALL_HELLO_MAGIC;
}

/*
 * 免密钥时使用的 key。
 * KernelPatch 用户态库自己的注释就是：
 *   "@param key : superkey or 'su' string if caller uid is su allowed"
 * 所以 "su" 是有依据的约定值，不是随便编的。
 */
#define HY_NO_KEY "su"

/*
 * 查询 KernelPatch 版本。
 *
 * 返回的是 kpver，编码为 VERSION(major,minor,patch) = (major<<16)|(minor<<8)|patch，
 * 例如 0.13.9 -> 0x0D09。用 kp_ver_str() 还原成 "0.13.9"。
 *
 * 注意：SUPERCALL_KERNELPATCH_VER 和 SUPERCALL_HELLO 一样，位于
 * supercall() 里 `if (!is_authed) return -EPERM;` 这道门槛【之前】，
 * 所以只要调用者是 trusted_caller 就一定返回版本号，跟 key 对不对无关。
 * 这正好适合拿来查版本，但不能拿来当鉴权探测（见 sc_authed）。
 */
static inline long sc_kp_ver(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    long r = syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNELPATCH_VER));
    if (r > 0) return r;
    /* 回退：旧版 KP 用的是 0x1005 */
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNELPATCH_VER_OLD));
}

static inline long sc_kernel_ver(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    long r = syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNEL_VER));
    if (r > 0) return r;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNEL_VER_OLD));
}

/* kpver/kver 编码值 -> "0.13.9" 这类可读串；失败写 "未知" */
static inline void kp_ver_str(long v, char *out, size_t n)
{
    if (!out || !n) return;
    if (v <= 0) { snprintf(out, n, "未知"); return; }
    uint32_t u = (uint32_t)v;
    snprintf(out, n, "%u.%u.%u", (u >> 16) & 0xFFu, (u >> 8) & 0xFFu, u & 0xFFu);
}

/*
 * 真正探测"鉴权是否通过"。
 *
 * KERNELPATCH_VER / HELLO 都在门槛之前，拿它们当鉴权探测会永远显示"通过"。
 * 必须用门槛【之后】的命令。SUPERCALL_KPM_NUMS(0x1030) 位于第二个 switch，
 * 未鉴权时内核直接 return -EPERM，成功则返回已加载 kpm 数量（>=0），
 * 这才是可信的鉴权判据。
 */
static inline long sc_authed(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KPM_NUMS));
}

static inline bool sc_key_ok(const char *key)
{
    return sc_authed(key) >= 0;
}

/*
 * CTL0 控制：本文件所有功能的唯一通道。
 * 帧格式（与内核侧 hy.h 的 hy_ctl_frame 严格对应）：
 *   [0..3]   u8  tag[4] = { 'H', 0, 0, 0 }
 *   [4..7]   u32 nr        命令号
 *   [8..11]  u32 rsv
 *   [12...]  payload       与下面各结构体字节一致
 *
 * tag 前缀是必需的：KernelPatch 的 sc_kpm_control 会检查
 *   if (!ctl_args || strlen(ctl_args) <= 0) return -EINVAL;
 * 二进制帧的 nr 常带 '\0'，从 offset 0 发会被当成空串拒掉。
 */
/*
 * prctl 免鉴权通道。
 *
 * 内核侧 hook 了 __NR_prctl（arm64 = 167），只有 arg0 完全等于
 * HY_PRCTL_MAGIC 才接管，其余一律放行给原 prctl（普通 prctl option
 * 都是小整数，撞不上这个值）。
 *
 *   arg0 = 魔法数     arg1 = 命令号     arg2 = payload 指针
 *
 * 【重要】这条路【不走 supercall 的鉴权门禁】，因此不需要超级密钥。
 * 内核侧执行完会 copy_to_user 把 payload 写回。
 */
static inline long prctl_ctl(uint32_t nr, void *payload)
{
    return syscall(__NR_prctl,
                   (unsigned long)HY_PRCTL_MAGIC,
                   (unsigned long)nr,
                   (unsigned long)payload,
                   0UL, 0UL);
}

static inline long sc_kpm_control(const char *key, const char *name,
                                  const char *ctl_args, char *out_msg, long outlen)
{
    if (!key || !key[0]) return -EINVAL;
    if (!name || !name[0]) return -EINVAL;
    if (!ctl_args || !ctl_args[0]) return -EINVAL;
    return syscall(__NR_supercall, key,
                   ver_and_cmd(SUPERCALL_KPM_CONTROL),
                   name, ctl_args, out_msg, outlen);
}

}  /* namespace hy_detail */

/* ==========================================================================
 * 二、命令号
 * ========================================================================== */

#define HY_MARK 'H'
#define HY_MODULE_NAME "huanyu"
#define HY_MAGIC 0x4879756e   /* "Hyun" */

/* 内存 / 进程 */
#define GET_PID         0
#define MODULE_BASE     1
#define MODULE_BSS      3
#define READ_MEM        4
#define WRITE_MEM       5
#define READ_MEM_V2     11

/* 触摸 / 陀螺仪 */
#define TOUCH_INIT      6
#define TOUCH_DOWN      7
#define TOUCH_UP        8
#define GYRO_INIT       9
#define GYRO_CONFIG     10

/* v1.22.0：触摸设备名锁定 / 重新扫描；71 屏幕范围；72 陀螺仪新 ABI */
#define TOUCH_SET_NAME  74
#define TOUCH_RESCAN    75

/* 虚拟定位 GNSS（ls 移植） */
#define GNSS_INIT        55
#define GNSS_REPORT      56
#define GNSS_STOP        57

/* 触摸 / 陀螺仪 */
#define TOUCH_SETUP     71
#define GYRO_SET        72

/* v1.66.0 同步：内核 hy.h 里一直有 HY_NR_TOUCH_MOVE=67，
 * hy_ctl_switch() 里也有 case，但用户态对接文件从来没定义过 ——
 * 于是 touch_down 之后无法移动，只能 down/up。本轮补齐。 */
#define TOUCH_MOVE      67

/* TLS / PACGA */
#define GET_THREAD_TLS  12
#define EXEC_PACGA      13

/* 综合状态（HY_NR_LS_STATUS，内核 hy.h:261） */
#define LS_STATUS       70

/* 断点方案（新增） */
#define BP_SET_MODE     14
#define BP_GET_MODE     15
#define BP_GET_CAPS     16

/* 断点 */
#define BP_INIT_CMD        19
#define BP_GET_NUM_BRPS    20
#define BP_GET_NUM_WRPS    21
#define BP_INST            22
#define BP_UNINST          23
#define BP_SUSPEND         24
#define BP_RESUME          25
#define BP_GET_HIT_COUNT   26
#define BP_MODIFY          27
#define BP_GET_HIT_ITEMS   28
#define BP_CHECK_INITED    30

/* 文件隐藏 */
#define FILE_HIDE_INIT     34
#define FILE_HIDE_SET      31
#define FILE_HIDE_CLEAR    32
#define FILE_HIDE_STATUS   33
#define FILE_HIDE_CONFIG   FILE_HIDE_SET
#define FILE_HIDE_DISABLE  FILE_HIDE_CLEAR

/* 扩展能力（新增 35~46） */
#define HY_ENUM_MODULES     35
#define HY_ENUM_PROCESSES   36
#define HY_ENUM_THREADS     37
#define HY_KERNEL_RW        38
#define HY_PHYS_RW          39
#define HY_PROTECT          40
#define HY_CACHE_FLUSH      41
#define HY_BP_LIST          42
#define HY_BP_CLEAR_HITS    43
#define HY_HWCAP            44
#define HY_STATS            45
#define HY_VERSION          46

/* ==========================================================================
 * 三、断点方案
 * ========================================================================== */

/* ==========================================================================
 * 欢愉版本号
 * 与内核侧 hy.h 的 HY_VERSION_STRING 保持一致。
 * /proc/Huanyu 与 HY_VERSION 命令读到的就是这个版本。
 *
 * 【v1.66.0 同步】
 *   之前这里停在 1.45.0，与内核侧差了二十几个版本，
 *   /proc 路径也写成了小写 /proc/huanyu —— 而内核实际注册的是
 *   /proc/Huanyu（首字母大写）。Linux 文件名区分大小写，
 *   小写路径一律 open 失败，proc_exists()/proc_read() 恒为假。
 *   本轮全部对齐。
 * ========================================================================== */
#define HY_VERSION_STRING "1.80.0"
#define HY_VER_MAJOR 1
#define HY_VER_MINOR 80
#define HY_VER_PATCH 0

/* ==========================================================================
 * 【★★★★ 五层对接密钥 —— 必须与内核 hy.h 的 HY_KEY_L1..L5 逐字节一致 ★★★★】
 * ==========================================================================
 *   v1.70.0 起从单把 256 位钥匙改成五层：
 *       第 1~4 层各 64 位，第 5 层 256 位（单密钥时代那把原始钥匙）。
 *   每层都要同时含：大写字母 / 小写字母 / 数字 / 符号。每个版本全换。
 *   不一致时内核拒绝执行所有命令（版本查询与握手除外）。
 *   握手时逐层提交，任何一层不吻合内核就把五层全部作废。
 * ========================================================================== */
#ifndef HY_KEY_LAYERS
#define HY_KEY_LAYERS 5
#endif
#ifndef HY_KEY_L1
#define HY_KEY_L1 "Huanyu"   /* 【固定】第一层不随机，恒为 Huanyu，勿改 */
#endif
#ifndef HY_KEY_L2
#define HY_KEY_L2 "j9BVo9EK.@7Wvz)kq7{]QEiiUcR=;KPV9C#W%x8n6*D,b_rgZMVf-vG)>^V:x$4;"
#endif
#ifndef HY_KEY_L3
#define HY_KEY_L3 "4;LjmfsGWmXkU<;X=$g!tmsHq{U+4a@vtG]43V}]TG[<{.JS4xN2MH9SYtgL7ebv"
#endif
#ifndef HY_KEY_L4
#define HY_KEY_L4 "gM?l+s$5AcQ+K$[6;trqZQ2n2<83fN4!qRXaoIFq?3_qTe)YQw+.i7FV=02YCq=R"
#endif
#ifndef HY_KEY_L5
#define HY_KEY_L5 "Q@{+22RKsIf5X#ll?{-$2tlF8wR>d5jEJ8zotDHOd{#^Dw={IEZGhOxP(<HPUFIW)fXDXZAM}X@:LUJDFcq9]l+]4y1mb%qH%[P:F(p,7C7*$FF&6c.Ln^s)p(}#+5mmw<_pEG_MhkHA}O9>ait,U{@&dmQ5pAM{EPDzf(rOW)5Opc4s4#KOVPP4fIzProUq%4.Ujq;.2?OB]n-N<,_llfhB_.V!@lx9tYPdJlOGMqkF?ZV]2qE}rbPphU1zgFrY"
#endif
#ifndef HY_KEY_LEN_L1
#define HY_KEY_LEN_L1 6
#endif
#ifndef HY_KEY_LEN_L2
#define HY_KEY_LEN_L2 64
#endif
#ifndef HY_KEY_LEN_L3
#define HY_KEY_LEN_L3 64
#endif
#ifndef HY_KEY_LEN_L4
#define HY_KEY_LEN_L4 64
#endif
#ifndef HY_KEY_LEN_L5
#define HY_KEY_LEN_L5 256
#endif
#ifndef HY_SECRET_KEY
#define HY_SECRET_KEY HY_KEY_L5
#endif
#ifndef HY_SECRET_KEY_LEN
#define HY_SECRET_KEY_LEN HY_KEY_LEN_L5
#endif
#ifndef HY_KEY_MAGIC_LOW
#define HY_KEY_MAGIC_LOW   ((uint32_t)(HY_MAGIC & 0xFFFFu))
#endif

/* 握手两阶段与挑衅明文长度 —— 必须与内核 hy.h 完全一致 */
#ifndef HY_HS_STEP_REQ
#define HY_HS_STEP_REQ 1
#endif
#ifndef HY_HS_STEP_ANS
#define HY_HS_STEP_ANS 2
#endif
#ifndef HY_CHAL_LEN
#define HY_CHAL_LEN 32
#endif
#ifndef HY_HS_MAGIC_OF
#define HY_HS_MAGIC_OF(st) ((uint32_t)(HY_KEY_MAGIC_LOW | \
                                      (((uint32_t)(st) & 0xFFFFu) << 16)))
#endif

/* 取第 ly 层（0..4）的密钥串 —— 与内核 hy.h 同序 */
inline const char *hy_layer_key(unsigned ly)
{
    switch (ly) {
    case 0:  return HY_KEY_L1;
    case 1:  return HY_KEY_L2;
    case 2:  return HY_KEY_L3;
    case 3:  return HY_KEY_L4;
    default: return HY_KEY_L5;
    }
}

/* ================================================================
 * 【v1.71.0】挑战-响应：五层解密
 *
 * 内核把一段 32 字节随机明文用五层密钥加密后发过来，本文件解开，
 * 再把明文原样送回去。**密钥全程不出本进程** —— 内核从不接收它。
 * ================================================================ */

/* 单层逆向变换。必须 **从后往前** 走，原因见 hy_gate.c 的说明 */
inline void hy_chal_layer_inv(unsigned char *buf, size_t len,
                              const char *key, size_t klen)
{
    size_t i;
    unsigned acc = 0u;
    unsigned rot;

    if (!klen) return;
    for (i = 0; i < klen; ++i)
        acc = (unsigned)(acc + (unsigned char)key[i]);
    rot = (acc % 7u) + 1u;

    for (i = len; i > 0; --i) {
        size_t j = i - 1;
        unsigned v = (unsigned)buf[j];
        unsigned prev;

        v = ((v >> rot) | (v << (8 - rot))) & 0xFFu;   /* ror，必须截断到 8 位 */
        prev = (j == 0) ? 0xA5u : (unsigned)buf[j - 1];
        buf[j] = (unsigned char)(v ^ (unsigned)(unsigned char)key[j % klen]
                                   ^ prev);
    }
}

/* 解密顺序必须和内核的加密顺序严格相反：L5 → L4 → L3 → L2 → L1 */
inline void hy_chal_decrypt(unsigned char *buf, size_t len)
{
    hy_chal_layer_inv(buf, len, HY_KEY_L5, (size_t)HY_KEY_LEN_L5);
    hy_chal_layer_inv(buf, len, HY_KEY_L4, (size_t)HY_KEY_LEN_L4);
    hy_chal_layer_inv(buf, len, HY_KEY_L3, (size_t)HY_KEY_LEN_L3);
    hy_chal_layer_inv(buf, len, HY_KEY_L2, (size_t)HY_KEY_LEN_L2);
    hy_chal_layer_inv(buf, len, HY_KEY_L1, (size_t)HY_KEY_LEN_L1);
}

#ifndef HY_KEY_CHECK_DEFINED
#define HY_KEY_CHECK_DEFINED
namespace hy_key_check {
    constexpr unsigned klen(const char *s)
    {
        unsigned n = 0;
        while (s[n]) ++n;
        return n;
    }
    constexpr bool has_upper(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i)
            if (s[i] >= 'A' && s[i] <= 'Z') return true;
        return false;
    }
    constexpr bool has_lower(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i)
            if (s[i] >= 'a' && s[i] <= 'z') return true;
        return false;
    }
    constexpr bool has_digit(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i)
            if (s[i] >= '0' && s[i] <= '9') return true;
        return false;
    }
    constexpr bool has_symbol(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i) {
            char c = s[i];
            if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                  (c >= '0' && c <= '9'))) return true;
        }
        return false;
    }
}
#endif


/* ---- 编译期：五层逐层校验（长度 + 四类字符） ---- */
#define HY_ASSERT_KEY(N, LEN)                                                 \
    static_assert(hy_key_check::klen(HY_KEY_##N) == (unsigned)(LEN),          \
        "【欢愉】HY_KEY_" #N " 长度必须为 " #LEN);                            \
    static_assert(hy_key_check::has_upper(HY_KEY_##N),                        \
        "【欢愉】HY_KEY_" #N " 必须含大写字母");                              \
    static_assert(hy_key_check::has_lower(HY_KEY_##N),                        \
        "【欢愉】HY_KEY_" #N " 必须含小写字母");                              \
    static_assert(hy_key_check::has_digit(HY_KEY_##N),                        \
        "【欢愉】HY_KEY_" #N " 必须含数字");                                  \
    static_assert(hy_key_check::has_symbol(HY_KEY_##N),                       \
        "【欢愉】HY_KEY_" #N " 必须含符号");

/* 第 1 层是固定串 Huanyu：只有大写+小写，没有数字和符号，
   所以单独走一道宽松断言，只卡长度和大写小写。 */
static_assert(hy_key_check::klen(HY_KEY_L1) == 6u,
    "【欢愉】HY_KEY_L1 长度必须为 6（固定串 Huanyu）");
static_assert(hy_key_check::has_upper(HY_KEY_L1),
    "【欢愉】HY_KEY_L1 必须含大写字母");
static_assert(hy_key_check::has_lower(HY_KEY_L1),
    "【欢愉】HY_KEY_L1 必须含小写字母");
HY_ASSERT_KEY(L2, 64);
HY_ASSERT_KEY(L3, 64);
HY_ASSERT_KEY(L4, 64);
HY_ASSERT_KEY(L5, 256);

/*
 * 【v1.73.0】原来这里硬编码了 72 / 1 —— 每次升版本得改两处，改漏一个
 * 就编译失败。改成编译期解析 HY_VERSION_STRING 再和三个常量比：
 * 以后只改字符串那一行，常量忘改会在这里当场报错，不会拖到运行时
 * 才被内核判"版本不符"。
 */
constexpr int hy_ver_part(const char *s, int part)
{
    int idx = 0, cur = 0;
    for (const char *p = s; *p; ++p) {
        if (*p == '.') { if (idx == part) return cur; ++idx; cur = 0; }
        else if (*p >= '0' && *p <= '9') cur = cur * 10 + (*p - '0');
        else return -1;
    }
    return (idx == part) ? cur : -1;
}
static_assert(hy_ver_part(HY_VERSION_STRING, 0) == HY_VER_MAJOR &&
              hy_ver_part(HY_VERSION_STRING, 1) == HY_VER_MINOR &&
              hy_ver_part(HY_VERSION_STRING, 2) == HY_VER_PATCH,
    "【欢愉】HY_VERSION_STRING 与 HY_VER_MAJOR/MINOR/PATCH 不一致（升版本时三处都要改）");

#define HY_BP_MODE_AUTO 0   /* 不指定：交给内核按默认方案 + 回退链决定 */
#define HY_BP_MODE_SW   1   /* 软件断点：替换指令为 BRK */
#define HY_BP_MODE_PTE  2   /* PTE 影子页：代码字节不变，最难检测 */
#define HY_BP_MODE_HW   3   /* 硬件断点：调试寄存器，最快，槽位有限 */

/* ==========================================================================
 * 【v1.19.0】默认断点方案（编译期配置，与内核侧 hy.h 的宏一一对应）
 *
 *   Default breakpoint scheme
 *     1 = 硬件断点
 *     2 = PTE 断点
 *     3 = 软件断点
 *
 * 优先级（高 -> 低）：
 *   1) 本次调用显式传入的 mode（bp_inst_hw / bp_inst_pte / bp_inst_sw，
 *      或 bp_inst(..., mode)）—— 最高
 *   2) set_bp_mode() 设置的运行时默认
 *   3) 这里的 HY_DEFAULT_BP_SCHEME
 *   4) 内核内置回退链：硬件 -> PTE -> 软件
 *
 * 注意第 4 条：默认方案**当前不可用时会自动沿链降级**。
 * 例如设了 1（硬件）但槽位占满 / __switch_to hook 失败，
 * 会依次尝试 PTE、软件，而不是直接安装失败。
 * ========================================================================== */
#ifndef HY_DEFAULT_BP_SCHEME
#define HY_DEFAULT_BP_SCHEME   1      /* 1=硬件 2=PTE 3=软件 */
#endif

/* 由宏推出的默认模式常量（编译期求值，运行时零开销） */
#if (HY_DEFAULT_BP_SCHEME == 1)
#define HY_DEFAULT_BP_MODE  HY_BP_MODE_HW
#elif (HY_DEFAULT_BP_SCHEME == 2)
#define HY_DEFAULT_BP_MODE  HY_BP_MODE_PTE
#elif (HY_DEFAULT_BP_SCHEME == 3)
#define HY_DEFAULT_BP_MODE  HY_BP_MODE_SW
#else
#define HY_DEFAULT_BP_MODE  HY_BP_MODE_HW
#endif

/* ---- 断点 flags（v1.63.0）----
 * STEALTH：SW 断点自动改用 PTE 影子页实现 —— 不改代码段字节，
 *          内存 CRC / 哈希自检扫不到。**默认已开启**，无需手动设置。
 * NOSTEALTH：显式关闭该升级，优先级最高，断点就按原样写成 BRK。
 */
#define HY_BP_FLAG_STEALTH      (1u << 0)
#define HY_BP_FLAG_NOSTEALTH    (1u << 1)

#define HY_BP_CAP_SW    (1u << 0)
#define HY_BP_CAP_PTE   (1u << 1)
#define HY_BP_CAP_HW    (1u << 2)

#define HW_BREAKPOINT_LEN_1 1
#define HW_BREAKPOINT_LEN_2 2
#define HW_BREAKPOINT_LEN_3 3
#define HW_BREAKPOINT_LEN_4 4
#define HW_BREAKPOINT_LEN_5 5
#define HW_BREAKPOINT_LEN_6 6
#define HW_BREAKPOINT_LEN_7 7
#define HW_BREAKPOINT_LEN_8 8

#define HW_BREAKPOINT_EMPTY   0
#define HW_BREAKPOINT_R       1
#define HW_BREAKPOINT_W       2
#define HW_BREAKPOINT_RW      (HW_BREAKPOINT_R | HW_BREAKPOINT_W)
#define HW_BREAKPOINT_X       4

#define REG_MODIFY_X(N)     (1ULL << (N))
#define REG_MODIFY_SP       (1ULL << 31)
#define REG_MODIFY_PC       (1ULL << 32)
#define REG_MODIFY_PSTATE   (1ULL << 33)

#define BP_FLAG_RECORD    0x1

/* 文件隐藏 ABI */
#define FILE_HIDE_DIRECTORY_MAX 256
#define FILE_HIDE_KEYWORD_MAX   128
#define FILE_HIDE_PATH_MAX      FILE_HIDE_DIRECTORY_MAX

/* ==========================================================================
 * 四、数据结构（与内核侧一一对应）
 * ========================================================================== */

#pragma pack(1)

struct hy_user_pt_regs
{
    uint64_t regs[31];
    uint64_t sp;
    uint64_t pc;
    uint64_t pstate;
    uint64_t orig_x0;
    uint64_t syscallno;
    __uint128_t vregs[32];
};

struct hy_bp_hit_item
{
    uint64_t task_id;
    uint64_t hit_addr;
    uint64_t hit_time;
    struct hy_user_pt_regs regs_info;
    /*
     * 【v1.64.0 修复】内核末尾还有 resolved_mode + reserved 两个 u32。
     * 用户态此前缺这两项，结构少 8 字节。
     * resolved_mode 是"内核最终落在哪个方案"的回读值 ——
     * bp_verify() 全靠它判断 AUTO 到底解析成了 HW / PTE / SW。
     */
    uint32_t resolved_mode;
    uint32_t reserved;
};

struct hy_bp_inst_args
{
    int32_t  pid;
    uint64_t addr;
    uint32_t bp_len;
    uint32_t bp_type;
    uint64_t reg_modify_mask;
    uint64_t fp_reg_modify_mask;
    uint64_t regs_to_set_ptr;
    uint32_t flags;
    /*
     * 【v1.64.0 修复】内核 hy.h 的 hy_bp_inst_args 末尾还有一个 u32 mode，
     * 用户态此前没有 —— 结构少了 4 字节，内核按 52 字节解析，
     * 读到的 flags 之后那 4 字节是用户态内存里的垃圾。
     * 这就是"断点方案通道"看起来装上了、实际方案不对的根因之一。
     *
     * 0 = AUTO（走内核默认回退链），其余见 HY_BP_MODE_*。
     */
    uint32_t mode;
};

struct hy_bp_modify_args
{
    uint64_t handle;
    uint64_t reg_modify_mask;
    uint64_t fp_reg_modify_mask;
    uint64_t regs_to_set_ptr;
};

struct hy_bp_get_hit_count_arg
{
    uint64_t handle;
    uint64_t hit_total_count;
    uint64_t hit_item_arr_count;
};

struct hy_bp_get_hit_items_args
{
    uint64_t handle;
    uint64_t user_buffer_ptr;
    uint64_t max_bytes;
    uint64_t items_copied;
};

struct hy_bp_mode_config
{
    uint32_t mode;
    uint32_t flags;
};

/* ---- v1.60.0 压力测试 / 读取后端 / 网络预留 ---- */
#define HY_NR_STRESS            83
#define HY_NR_RWMODE_SET        84
#define HY_NR_RWMODE_GET        85
#define HY_NR_MEMCACHE_SET      89
#define HY_NR_MEMCACHE_GET      90
#define HY_NR_SCHEME_SET        91
#define HY_NR_SCHEME_GET        92
#define HY_NR_TI_DOWN          94
#define HY_NR_TI_MOVE          95
#define HY_NR_TI_UP            96
#define HY_NR_TI_STATUS        97
#define HY_NR_TI_SET_SLOTS     98
#define HY_NR_TI_SET_RANGE     99
#define HY_NR_TI_GET_RANGE    100
#define HY_NR_TI_CLEAR        101   /* v1.75.0 */
#define HY_NR_TI_INJECT_GATE  102
#define HY_NR_TI_DOWN_ID       103
#define HY_NR_TI_MOVE_ID       104
#define HY_NR_TI_UP_ID         105
#define HY_NR_TI_UP_ALL        106
#define HY_NR_TI_CAPACITY      107   /* v1.75.0 */
/* 注入状态机取值，与内核 enum 对齐 */
#define HY_TI_IDLE              0
#define HY_TI_ACTIVE            1
#define HY_TI_CONFLICTED        2


/* v1.64.0 方案选择：0 = 自动（默认，从高世代往低试） */
#define HY_SCHEME_AUTO          0
#define HY_SCHEME_GEN3          3
#define HY_SCHEME_GEN4          4
#define HY_SCHEME_GEN5          5
#define HY_SCHEME_GEN6          6

/* 方案域，与内核 enum hy_sc_dom 一一对应 */
#define HY_SC_PHYSVIRT  0   /* 物理地址 <-> 内核虚拟地址换算 */
#define HY_SC_PGTABLE   1   /* 页表级数与虚拟地址位数 */
#define HY_SC_MEMREAD   2   /* 进程内存读取后端 */
#define HY_SC_KERNW     3   /* 内核/物理地址读写后端 */
#define HY_SC_BP        4   /* 断点落地方案 */
#define HY_SC_INPUT     5   /* 触摸事件观察点 */
#define HY_SC_SYM       6   /* 内核符号解析策略 */
#define HY_NR_DBG_CMD           82
#define HY_NR_NET_CAP           86
#define HY_NR_NET_FETCH         87
#define HY_NR_NET_STATUS        88

/* ==========================================================================
 * v1.67.0 版本 / 密钥握手（93）
 *
 * 用户态上来先自报版本号与密钥，内核两项都比对通过才放行后续命令。
 * 未握手时，内核只认 HY_NR_VERSION 与 HY_NR_HANDSHAKE 两个号。
 * ========================================================================== */
#define HY_NR_HANDSHAKE        93

#define HY_HS_OK            0   /* 本步通过 */
#define HY_HS_BAD_MAGIC     1   /* magic / 阶段号不对 */
#define HY_HS_BAD_VER       2   /* 版本不一致 */
#define HY_HS_BAD_KEY       3   /* 应答与原文不一致（五层密钥解错） */
#define HY_HS_BAD_BOTH      4   /* 版本与应答都不一致 */
#define HY_HS_NO_CHAL       5   /* 还没要挑战就先交应答 */
#define HY_HS_DONE          6   /* 两步都过，已放行 */

/* 把内核返回的握手结果码翻成人话 */
inline const char *hy_hs_result_text(uint32_t res)
{
    switch (res) {
    case HY_HS_OK:        return "本步通过";
    case HY_HS_BAD_MAGIC: return "阶段号或 magic 不匹配";
    case HY_HS_BAD_VER:   return "版本不一致";
    case HY_HS_BAD_KEY:   return "挑战应答与原文不一致（五层密钥解错）";
    case HY_HS_BAD_BOTH:  return "版本与应答都不一致";
    case HY_HS_NO_CHAL:   return "还没请求挑战就提交应答";
    case HY_HS_DONE:      return "两步都过，已放行";
    default:              return "未知结果码";
    }
}


#ifndef HY_MAGIC
#define HY_MAGIC 0x4879756eu
#endif

/*
 * 用 push/pop 而不是 pack(1) / pack()：
 * 本文件前面 486 行就已经开了 pack(1)，若这里用裸 pack() 收尾，
 * 会把外层的紧凑对齐提前关掉，后面一堆结构体的布局全变 ——
 * 那正是那些 ABI size static_assert 报错的原因。
 */
#pragma pack(push, 1)
struct hy_handshake_req {
    uint32_t magic;
    uint32_t uver_major;
    uint32_t uver_minor;
    char     uver_str[24];
    char     key[264];
    uint32_t result;      /* 出参 */
    uint32_t lock_ver;    /* 出参 */
    uint32_t lock_key;    /* 出参 */
    uint32_t locked;      /* 出参 */
};
#pragma pack(pop)

/* ============================================================
 * v1.64.0 补齐：此前只有内核侧有、用户态对接文件没有封装的命令号。
 *
 * 这些号内核一直在用（hy_ctl.c 的 switch 里有完整分支），
 * 但用户态没法调用 —— 功能等于对用户不可见。
 * 全部与内核 hy.h 逐号对齐，改内核时这两处必须一起改。
 * ============================================================ */
#define HY_NR_BP_GET_MODE       15
#define HY_NR_VERSION           46
#define HY_NR_SHM_REGISTER      47
#define HY_NR_SHM_STATUS        48

/* ---- v1.18.0 ls 移植能力 ---- */
#define HY_NR_SYSMON_SET        49
#define HY_NR_SYSMON_REMOVE     50
#define HY_NR_SYSMON_READ       51
#define HY_NR_CNTVCT_SET        52
#define HY_NR_CNTVCT_REMOVE     53
#define HY_NR_CNTVCT_READ       54
#define HY_NR_GNSS_INIT         55
#define HY_NR_ENUM_SEGMENTS     58
#define HY_NR_ENUM_REGIONS      59
#define HY_NR_STEPBP_SET        60
#define HY_NR_STEPBP_REMOVE     61
#define HY_NR_DPT_SET           62
#define HY_NR_DPT_REMOVE        63
#define HY_NR_HWCAP2            64
#define HY_NR_KGSL_HIDE_SET     65
#define HY_NR_KGSL_HIDE_CLEAR   66
#define HY_NR_TOUCH_MOVE        67
#define HY_NR_GHOST_STATUS      68
#define HY_NR_ENV_PARAMS        69
#define HY_NR_HIDE_GUP_SET      73

/* ---- 断点 flags（内核 hy.h:82/88）----
 * STEALTH 是默认行为：SW 方案自动升级成 PTE 影子页，
 * 一个代码字节都不改，内存扫描看不见。
 * 只有显式给 NOSTEALTH 才会真的往代码段写 BRK。
 */
#define HY_BP_FLAG_STEALTH      (1u << 0)
#define HY_BP_FLAG_NOSTEALTH    (1u << 1)

/* 断点方案常量（与内核 hy.h 的 enum 对齐） */
#define HY_BP_MODE_AUTO         0
#define HY_BP_MODE_SW           1
#define HY_BP_MODE_PTE          2
#define HY_BP_MODE_HW           3

/* 断点能力位
 * 【v1.66.0】本文件曾在 386 行与此处各定义一遍 HY_BP_CAP_SW/PTE/HW，
 * 值虽然相同（1u<<0 == 0x1u），但 gcc 会报 redefined 警告。
 * 重复宏迟早会被改成不一样的值，届时行为取决于 include 顺序。
 * 这里删掉第二份，统一保留常量区那一处。 */
/*  HY_BP_CAP_SW / PTE / HW 见上方常量区 */

/* 观察点类型（与内核 HW_BREAKPOINT_* 对齐） */
#define HY_HW_BREAKPOINT_X      0   /* 执行 */
#define HY_HW_BREAKPOINT_R      1   /* 读   */
#define HY_HW_BREAKPOINT_W      2   /* 写   */
#define HY_HW_BREAKPOINT_RW     3   /* 读写 */

/* 寄存器修改掩码（内核 hy.h 的 REG_MODIFY_*） */
#define HY_REG_MODIFY_PC        (1ULL << 32)
#define HY_REG_MODIFY_SP        (1ULL << 33)
#define HY_REG_MODIFY_PSTATE    (1ULL << 34)

/* 读取后端模式：0 = 内核级（默认），1 = KMA 硬件级 */
#define HY_RW_MODE_KERNEL       0
#define HY_RW_MODE_KMA          1

#define HY_NET_URL_MAX          512
#define HY_NET_METHOD_GET       0
#define HY_NET_METHOD_HEAD      1
#define HY_NET_METHOD_POST      2
#define HY_NET_FLAG_HTTPS       0x1u
#define HY_NET_FLAG_FOLLOW      0x2u

/* v1.60.0 补：此前缺失导致 touch_set_name() 编译不过（与内核 hy.h 一致） */
#ifndef HY_TOUCH_NAME_MAX
#define HY_TOUCH_NAME_MAX 64
#endif
struct hy_touch_name { char name[HY_TOUCH_NAME_MAX]; };

/* v1.73.0：安全注入坐标范围。-1 表示该项不自设，沿用内核自学习值。 */
struct hy_ti_range { int32_t min_x; int32_t max_x; int32_t min_y; int32_t max_y; };

/* v1.73.0：安全注入运行状态，9 个字段一次取完 */
struct hy_ti_stat {
    int32_t state;      /* HY_TI_IDLE / ACTIVE / CONFLICTED */
    int32_t inj_slot;   /* 当前虚拟手指占用槽位，-1 表示无 */
    int32_t max_slots;  /* 内核认定的总槽位数 */
    int32_t downs;
    int32_t moves;
    int32_t ups;
    int32_t busy;       /* 无空槽被丢弃的次数 */
    int32_t conflicts;  /* 与真手指冲突而放弃轨迹的次数 */
    int32_t protects;   /* 拦下的"抹除虚拟手指"事件数（关键健康指标） */
};


struct hy_rw_mode { uint32_t mode; uint32_t reserved; };

/* ============================================================
 * 读取缓存开关（v1.63.0）
 *   默认启用缓存（性能优先）：命中时不再重走 4 级页表，
 *   只做一次 PTE 值校验 —— 便宜且安全。
 *   只有显式设为 OFF，才会每次都走完整页表。
 * ============================================================ */
#define HY_MEM_CACHE_DEFAULT    0   /* 默认：启用缓存（推荐，性能优先） */
#define HY_MEM_CACHE_ON         1   /* 强制启用 */
#define HY_MEM_CACHE_OFF        2   /* 关闭：每次重走完整页表 */

struct hy_mem_cache_mode { uint32_t mode; uint32_t reserved; };
struct hy_scheme_req {
    uint32_t dom;      /* HY_SC_* */
    uint32_t gen;      /* HY_SCHEME_AUTO / GEN3..GEN6 */
    uint32_t chosen;   /* 出参：档位索引，0xffffffff = 无可用方案 */
    uint32_t cur_gen;  /* 出参：当前方案所属世代 */
};

struct hy_dbg_req
{
    uint32_t cmd_len;
    uint32_t out_len;
    char     cmd[160];
    char     out[160];
};

struct hy_net_req
{
    uint32_t method;
    uint32_t timeout_ms;
    uint32_t flags;
    uint32_t reserved;
    char     url[HY_NET_URL_MAX];
};

struct hy_net_rep
{
    uint32_t err;
    uint32_t status_code;
    uint32_t body_len;
    uint32_t reserved;
};

struct hy_net_cap
{
    uint32_t kernel_impl;
    uint32_t userland_required;
    uint32_t abi_version;
    uint32_t reserved;
};

/* ============================================================
 * v1.64.0 补齐：ls 移植能力与共享内存通道的参数结构
 *
 * 【对齐原则】
 *   下面每个结构体都与内核 hy.h / hy_shm.h 逐字段同序同类型。
 *   用户态与内核态是两套独立编译的产物，中间只传裸字节：
 *   只要有一处字段顺序或宽度不同，内核就会按错误偏移取值，
 *   表现是"命令回 0 但结果不对"，极难排查。
 *   所以文件末尾用 static_assert 把每个尺寸钉死 ——
 *   谁改坏了一处，编译期就报错，不会带进运行期。
 * ============================================================ */

/* ---- syscall 监控（49/50/51）---- */
#define HY_SYSMON_MAX_PIDS   8
#define HY_SYSMON_MAX_LOG    256
#define HY_SYSMON_LOG_SIZE   192

struct hy_sysmon_req
{
    int32_t  pid;
    uint32_t enable;        /* 1 = 加入监控，0 = 移除 */
};

struct hy_sysmon_entry
{
    uint64_t seq;
    int32_t  pid;
    int32_t  tid;
    uint32_t nr;
    uint64_t arg0;
    uint64_t arg1;
    uint64_t arg2;
    uint64_t ret;
    uint64_t ts;
};

struct hy_sysmon_read
{
    uint64_t buf_ptr;
    uint32_t max_count;
    uint32_t nr_read;
    uint64_t total;
    uint32_t clear;         /* 读完后清空 */
};

/* ---- CNTVCT 读取监控（52/53/54）---- */
struct hy_cntvct_req
{
    int32_t  pid;
    uint32_t enable;
};

struct hy_cntvct_read
{
    uint64_t count;         /* 被拦截的读取次数 */
    uint64_t last_pc;
    uint32_t clear;
};

/* ---- 增强枚举：段（58）---- */
struct hy_seg_info
{
    uint64_t start;
    uint64_t end;
    uint32_t prot;          /* bit0=r bit1=w bit2=x */
    uint32_t flags;
};

struct hy_enum_segs_req
{
    int32_t  pid;
    uint64_t module_base;   /* 0 = 全部 */
    uint64_t buf_ptr;
    uint32_t max_count;
    uint32_t nr_written;
};

/* ---- 增强枚举：可扫描区域（59，仅 rw-p）---- */
struct hy_region_info
{
    uint64_t start;
    uint64_t end;
    uint32_t prot;
    uint32_t reserved;
};

struct hy_enum_regions_req
{
    int32_t  pid;
    uint64_t buf_ptr;
    uint32_t max_count;
    uint32_t nr_written;
};

/* ---- 单步断点（60/61）---- */
struct hy_stepbp_req
{
    int32_t  pid;
    uint64_t addr;
    uint32_t enable;
};

/* ---- DPT 主线程影子页（62/63）---- */
struct hy_dpt_req
{
    int32_t  pid;
    uint64_t addr;
    uint32_t enable;
};

/* ---- 扩展硬件能力（64）---- */
struct hy_hwcap2
{
    uint32_t mte;           /* Memory Tagging Extension */
    uint32_t spe;           /* Statistical Profiling Extension */
    uint32_t pan;           /* Privileged Access Never */
    uint32_t bti;           /* Branch Target Identification */
    uint32_t pac;           /* Pointer Authentication */
    uint32_t lse;           /* Large System Extension */
    uint32_t brps;
    uint32_t wrps;
    uint32_t ghost;         /* KPM 下恒为 0（需 struct page） */
    uint32_t reserved;
};

/* ---- GPU 隐藏（65/66）---- */
struct hy_kgsl_req
{
    uint32_t enable;
    uint32_t reserved;
};

/* ---- 进程环境参数（69）---- */
struct hy_env_params
{
    int32_t  pid;
    int32_t  tid;
    uint64_t tls;
    uint64_t stack_top;
    uint64_t mm_start;
    uint64_t mm_end;
    char     comm[16];
    uint32_t is_main_thread;
    uint32_t reserved;
};

/* ---- 共享内存通道（47/48，与 hy_shm.h 一致）---- */
#define HY_SHM_MAGIC   0x48796e75u
#define HY_SHM_VERSION 1u

struct hy_shm_register
{
    uint64_t va;
    uint64_t size;
    uint32_t pid;
    uint32_t reserved;
};

struct hy_shm_status
{
    uint32_t ready;         /* 1 = 已映射 */
    uint32_t nr_pages;
    uint64_t kva;           /* 内核虚拟地址，用户态不可访问 */
    uint64_t requests;
    uint64_t errors;
};

struct hy_bp_caps
{
    uint32_t supported;
    uint32_t num_brps;
    uint32_t num_wrps;
    uint32_t reserved;
};

/* 扩展 */
struct hy_mod_info
{
    uint64_t start;
    uint64_t end;
    uint32_t exec;
    uint32_t write;
    uint32_t resv[2];
};

struct hy_proc_info
{
    int32_t pid;
    char    comm[16];
};

struct hy_enum_mods_req
{
    int32_t  pid;
    uint32_t max_count;
    uint64_t buf_ptr;
};

/*
 * 【v1.64.0 修复】这三个结构体内核侧【不在】pack(1) 区，是自然对齐；
 * 而用户态整个第四节被 pack(1) 包住，被压成了紧凑布局 ——
 * 于是 buf_ptr / addr / size 的偏移整体前移 4 字节，
 * 内核按自然对齐去取，拿到的是拼错的数。
 *
 * 表现是"命令返回 0 但结果是错的"，且只在字段之间出现
 * 4 字节空洞时才暴露（纯 u64 拼接的结构体恰好不受影响，
 * 所以之前一直没人发现）。
 *
 * 用 pack(push)/pack(pop) 单独恢复自然对齐，与内核保持一致。
 */
#pragma pack(push)
#pragma pack()

struct hy_enum_procs_req
{
    uint32_t max_count;
    uint64_t buf_ptr;
};

struct hy_enum_threads_req
{
    int32_t  pid;
    uint32_t max_count;
    uint64_t buf_ptr;
};

struct hy_kern_rw_req
{
    uint64_t addr;
    uint64_t buf_ptr;
    uint64_t size;
    uint32_t is_write;
    uint32_t resv;
};

struct hy_protect_req
{
    int32_t  pid;
    uint32_t prot;      /* bit0=r bit1=w bit2=x */
    uint64_t addr;
    uint64_t size;
};

struct hy_flush_req
{
    int32_t  pid;
    uint32_t resv;
    uint64_t addr;
    uint64_t size;
};

struct hy_bp_item
{
    uint64_t handle;
    int32_t  pid;
    uint32_t mode;
    uint64_t addr;
    uint64_t hit_count;
    uint32_t active;
    uint32_t suspended;
};

struct hy_bp_list_req
{
    uint32_t max_count;
    uint64_t buf_ptr;
};

struct hy_hwcap
{
    uint32_t pac;
    uint32_t bti;
    uint32_t lse;
    uint32_t mte;
    uint32_t fp;
    uint32_t brps;
    uint32_t wrps;
    uint32_t resv;
};

struct hy_stats
{
    uint64_t cache_hits;
    uint64_t cache_miss;
    uint64_t bp_active;
    uint64_t hit_total;
    uint64_t sym_failures;
    uint64_t resv[3];
};

struct hy_request
{
    int32_t  pid;
    uint64_t addr;
    uint64_t buffer;
    uint64_t size;
};

#pragma pack(pop)

struct hy_touch_event_base
{
    int32_t slot;
    int32_t x;
    int32_t y;
};

struct hy_gyro_config
{
    uint32_t enable;
    uint32_t x;
    uint32_t y;
};

/*
 * v1.22.0 补齐。
 * 【修复】这三个结构此前只有使用处（touch_setup / gyro_set / touch_set_name），
 * 全文没有定义 —— 任何调用它们的代码都编译不过。
 * 属于"接口声明了但依赖缺失"的空壳。
 */
struct hy_touch_setup
{
    int32_t max_x;
    int32_t max_y;
    int32_t slot_base;
    int32_t reserved;
};

struct hy_gyro_vec
{
    int32_t x;
    int32_t y;
    int32_t z;
    int32_t reserved;
};

/* v1.22.0：按名字锁定真实触摸屏（名字取自 /proc/bus/input/devices 的 Name=） */
#define HY_TOUCH_NAME_MAX 64
/* 虚拟定位 GNSS（与内核 hy.h 的 struct hy_gnss_req / hy_gnss_status 一致） */
struct hy_gnss_req
{
    int32_t  latitude_e7;
    int32_t  longitude_e7;
    uint32_t enable;
};

struct hy_gnss_status
{
    uint32_t active;
    uint32_t hooked;
    uint64_t patches;      /* 已 patch 的 parcel 数，判断生效与否只看它 */
    int32_t  latitude_e7;
    int32_t  longitude_e7;
};

/* ls 移植模块总状态（与内核 struct hy_ls_status 一致） */
struct hy_ls_status
{
    uint32_t sysmon_active, sysmon_hooked;
    uint32_t cntvct_active, cntvct_hooked;
    uint32_t gnss_active,   gnss_hooked;
    uint32_t dpt_active,    dpt_hooked;
    uint32_t kgsl_active,   kgsl_hooked;
    uint32_t stepbp_active;
    uint64_t sysmon_total;
    uint64_t cntvct_total;
    uint64_t gnss_patches;
};

struct hy_tls_request
{
    int32_t  pid;
    int32_t  tid;
    uint64_t tls_value;
    int32_t  result;
    uint32_t reserved;
};

struct hy_pacga_request
{
    int32_t  pid;
    uint32_t reserved0;
    uint64_t value;
    uint64_t modifier;
    uint64_t result_pac;
    int32_t  ok;
    uint32_t reserved1;
};

struct hy_file_hide_config
{
    char     directory[FILE_HIDE_DIRECTORY_MAX];
    char     keyword[FILE_HIDE_KEYWORD_MAX];
    uint32_t enabled;
};

struct hy_file_hide_status
{
    char     directory[FILE_HIDE_DIRECTORY_MAX];
    char     keyword[FILE_HIDE_KEYWORD_MAX];
    uint32_t enabled;
    uint32_t hook_active;
};

#pragma pack()

/* ABI 尺寸锁死：改一个字段就编译失败，杜绝内核/用户态错位 */
static_assert(sizeof(hy_user_pt_regs)     == 800,  "hy_user_pt_regs ABI size mismatch");
static_assert(sizeof(hy_bp_hit_item)      == 832,  "hy_bp_hit_item ABI size mismatch");
static_assert(sizeof(hy_bp_inst_args)     == 52,   "hy_bp_inst_args ABI size mismatch");
static_assert(sizeof(hy_bp_modify_args)   == 32,   "hy_bp_modify_args ABI size mismatch");
static_assert(sizeof(hy_tls_request)      == 24,   "hy_tls_request ABI size mismatch");
static_assert(sizeof(hy_pacga_request)    == 40,   "hy_pacga_request ABI size mismatch");
static_assert(sizeof(hy_file_hide_config) == 388,  "hy_file_hide_config ABI size mismatch");
static_assert(sizeof(hy_file_hide_status) == 392,  "hy_file_hide_status ABI size mismatch");
static_assert(sizeof(hy_request)          == 32,   "hy_request ABI size mismatch");
static_assert(sizeof(hy_touch_event_base) == 12,   "hy_touch_event_base ABI size mismatch");
static_assert(sizeof(hy_gyro_config)      == 12,   "hy_gyro_config ABI size mismatch");
static_assert(sizeof(hy_bp_caps)          == 16,   "hy_bp_caps ABI size mismatch");
static_assert(sizeof(hy_mod_info)         == 32,   "hy_mod_info ABI size mismatch");
static_assert(sizeof(hy_proc_info)        == 20,   "hy_proc_info ABI size mismatch");
static_assert(sizeof(hy_hwcap)            == 32,   "hy_hwcap ABI size mismatch");
static_assert(sizeof(hy_stats)            == 64,   "hy_stats ABI size mismatch");
static_assert(sizeof(hy_bp_item)          == 40,   "hy_bp_item ABI size mismatch");

/* ---- v1.64.0 新增断言：钉死新补齐结构的尺寸 ----
 * 右侧数字来自内核 hy.h / hy_shm.h 同结构的 sizeof，
 * 由脚本实测得出，不是手算。任一侧改字段，这里立刻编译失败。
 */
static_assert(sizeof(hy_sysmon_req)       == 8,    "hy_sysmon_req ABI size mismatch");
static_assert(sizeof(hy_sysmon_entry)     == 60,   "hy_sysmon_entry ABI size mismatch");
static_assert(sizeof(hy_sysmon_read)      == 28,   "hy_sysmon_read ABI size mismatch");
static_assert(sizeof(hy_cntvct_req)       == 8,    "hy_cntvct_req ABI size mismatch");
static_assert(sizeof(hy_cntvct_read)      == 20,   "hy_cntvct_read ABI size mismatch");
static_assert(sizeof(hy_seg_info)         == 24,   "hy_seg_info ABI size mismatch");
static_assert(sizeof(hy_enum_segs_req)    == 28,   "hy_enum_segs_req ABI size mismatch");
static_assert(sizeof(hy_region_info)      == 24,   "hy_region_info ABI size mismatch");
static_assert(sizeof(hy_enum_regions_req) == 20,   "hy_enum_regions_req ABI size mismatch");
static_assert(sizeof(hy_stepbp_req)       == 16,   "hy_stepbp_req ABI size mismatch");
static_assert(sizeof(hy_dpt_req)          == 16,   "hy_dpt_req ABI size mismatch");
static_assert(sizeof(hy_hwcap2)           == 40,   "hy_hwcap2 ABI size mismatch");
static_assert(sizeof(hy_kgsl_req)         == 8,    "hy_kgsl_req ABI size mismatch");
static_assert(sizeof(hy_env_params)       == 64,   "hy_env_params ABI size mismatch");
static_assert(sizeof(hy_shm_register)     == 24,   "hy_shm_register ABI size mismatch");
static_assert(sizeof(hy_shm_status)       == 32,   "hy_shm_status ABI size mismatch");

/* ---- 补齐既有结构缺漏的断言 ---- */
static_assert(sizeof(hy_dbg_req)          == 328,  "hy_dbg_req ABI size mismatch");
static_assert(sizeof(hy_rw_mode)          == 8,    "hy_rw_mode ABI size mismatch");
static_assert(sizeof(hy_mem_cache_mode)   == 8,    "hy_mem_cache_mode ABI size mismatch");
static_assert(sizeof(hy_ls_status)        == 68,   "hy_ls_status ABI size mismatch");
static_assert(sizeof(hy_gnss_req)         == 12,   "hy_gnss_req ABI size mismatch");
static_assert(sizeof(hy_gnss_status)      == 24,   "hy_gnss_status ABI size mismatch");
static_assert(sizeof(hy_touch_setup)      == 16,   "hy_touch_setup ABI size mismatch");
static_assert(sizeof(hy_kern_rw_req)      == 32,   "hy_kern_rw_req ABI size mismatch");
static_assert(sizeof(hy_protect_req)      == 24,   "hy_protect_req ABI size mismatch");
static_assert(sizeof(hy_flush_req)        == 24,   "hy_flush_req ABI size mismatch");
static_assert(sizeof(hy_bp_list_req)      == 16,   "hy_bp_list_req ABI size mismatch");
static_assert(sizeof(hy_enum_mods_req)    == 16,   "hy_enum_mods_req ABI size mismatch");
static_assert(sizeof(hy_enum_procs_req)   == 16,   "hy_enum_procs_req ABI size mismatch");
static_assert(sizeof(hy_enum_threads_req) == 16,   "hy_enum_threads_req ABI size mismatch");
static_assert(sizeof(hy_tls_request)      == 24,   "hy_tls_request ABI size mismatch");

using hy_file_hide_request = hy_file_hide_config;

/* ==========================================================================
 * 五、寄存器批量改写器
 * ========================================================================== */

struct hy_reg_batch
{
    hy_user_pt_regs regs = {};
    uint64_t reg_mask = 0;
    uint64_t fp_mask  = 0;

    hy_reg_batch &x(int idx, uint64_t val)
    {
        if (idx >= 0 && idx <= 30) {
            regs.regs[idx] = val;
            reg_mask |= (1ULL << idx);
        }
        return *this;
    }

    hy_reg_batch &sp(uint64_t val)
    {
        regs.sp = val;
        reg_mask |= REG_MODIFY_SP;
        return *this;
    }

    hy_reg_batch &pc(uint64_t val)
    {
        regs.pc = val;
        reg_mask |= REG_MODIFY_PC;
        return *this;
    }

    hy_reg_batch &pstate(uint64_t val)
    {
        regs.pstate = val;
        reg_mask |= REG_MODIFY_PSTATE;
        return *this;
    }

    hy_reg_batch &vf(int idx, float val)
    {
        if (idx >= 0 && idx <= 31) {
            __uint128_t v = 0;
            memcpy(&v, &val, sizeof(float));
            regs.vregs[idx] = v;
            fp_mask |= (1ULL << idx);
        }
        return *this;
    }

    hy_reg_batch &vd(int idx, double val)
    {
        if (idx >= 0 && idx <= 31) {
            __uint128_t v = 0;
            memcpy(&v, &val, sizeof(double));
            regs.vregs[idx] = v;
            fp_mask |= (1ULL << idx);
        }
        return *this;
    }

    hy_reg_batch &reset()
    {
        memset(&regs, 0, sizeof(regs));
        reg_mask = 0;
        fp_mask = 0;
        return *this;
    }

    bool empty() const { return reg_mask == 0 && fp_mask == 0; }
};

/* ==========================================================================
 * 六、主类
 * ========================================================================== */

class hy_driver
{
private:
    std::string key_;
    pid_t pid_ = -1;
    uint32_t mode_ = HY_BP_MODE_AUTO;
    uint32_t rw_mode_ = HY_RW_MODE_KERNEL;
    uint32_t mem_cache_ = HY_MEM_CACHE_DEFAULT;
    bool bp_stealth_ = true;   /* v1.63.0：SW 自动升级 PTE 影子页，默认开 */
    bool ready_  = false;
    bool authed_ = false;   /* 当前 key 是否通过 supercall 鉴权 */
    bool prctl_ok_ = false; /* prctl 免鉴权通道是否可用 */
    int  channel_ = 0;      /* 0=none 1=prctl 2=supercall */

    static constexpr int HY_FRAME_MAX = 1024;
    static constexpr int HY_FRAME_HDR = 12;   /* tag[4] + nr[4] + rsv[4] */

    /* ------------------------------------------------------------------
     * 【v1.67.0 握手闸门状态】
     *   hs_ok_   —— 内核已放行
     *   hs_tried_—— 已试过握手，失败不再每条命令都重试
     *   hs_in_   —— 正在握手中，绕过本地门，避免自递归
     *   hs_res_  —— 最近一次握手的内核 result
     * ------------------------------------------------------------------ */
    mutable bool     hs_ok_    = false;
    mutable bool     hs_tried_ = false;
    mutable bool     hs_in_    = false;
    mutable uint32_t hs_res_   = 0;
    mutable unsigned hs_layer_got_ = 0;  /* 已送对的层数（0..5） */

    /* 【v1.68.0】启动横幅用：内核版本串 + 本次握手的版本/密钥判定 */
    mutable char     kver_[32]    = {0};
    mutable bool     kver_got_    = false;
    mutable bool     hs_ver_ok_   = false;
    mutable bool     hs_key_ok_   = false;

    /* ==================================================================
     * 【v1.67.0】握手：自报版本号 + 密钥，两项都对内核才放行后续命令。
     * 失败时打印内核版本与用户态版本，说清楚差在哪一项。
     * ================================================================== */
    bool handshake() const
    {
        hy_driver *self = const_cast<hy_driver *>(this);
        if (self->hs_ok_)    return true;
        if (self->hs_tried_) return false;

        self->hs_tried_ = true;
        self->hs_in_    = true;

        self->hs_ver_ok_ = false;
        self->hs_key_ok_ = false;

        /* ============================================================
         * 第 1 步 HY_HS_STEP_REQ：自报版本号，取回挑战密文
         * 第 2 步 HY_HS_STEP_ANS：本地解开后把明文送回去
         *
         * 五层密钥全程只在本进程参与运算，一次都不发给内核。
         * ============================================================ */
        {
            hy_handshake_req r;
            unsigned char ans[HY_CHAL_LEN];
            size_t i;
            long ret;

            memset(&r, 0, sizeof(r));
            r.magic      = HY_HS_MAGIC_OF(HY_HS_STEP_REQ);
            r.uver_major = HY_VER_MAJOR;
            r.uver_minor = HY_VER_MINOR;
            snprintf(r.uver_str, sizeof(r.uver_str), "%s", HY_VERSION_STRING);

            ret = self->call(HY_NR_HANDSHAKE, &r, (uint32_t)sizeof(r));

            self->hs_res_    = r.result;
            self->hs_ver_ok_ = (r.lock_ver != 0);

            /* 内核把 uver_str 这个入参缓冲区覆写成它自己的版本
             * （零 ABI 变更，见 hy_gate.c 的说明）。 */
            snprintf(self->kver_, sizeof(self->kver_), "%s", r.uver_str);
            self->kver_got_ = true;

            if (ret != 0 || !r.lock_ver) {
                self->hs_in_ = false;
                self->hs_ok_ = false;
                fprintf(stderr,
                    "\n========== 欢愉握手失败（第 1 步 取挑战），全部功能已禁用 ==========\n"
                    "  内核态版本：%s\n"
                    "  用户态版本：%s  (major=%d minor=%d)\n"
                    "  版本一致  ：%s\n"
                    "  内核返回  ：%s\n"
                    "===========================================================\n\n",
                    self->kver_, HY_VERSION_STRING, HY_VER_MAJOR, HY_VER_MINOR,
                    self->hs_ver_ok_ ? "是" : "否",
                    hy_hs_result_text(r.result));
                return false;
            }

            /* 密文是二进制、可能含 0x00，按 HY_CHAL_LEN 定长取，不按字符串 */
            for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
                ans[i] = (unsigned char)r.key[i];

            hy_chal_decrypt(ans, (size_t)HY_CHAL_LEN);

            /* ===== 第 2 步：把解出来的明文送回去 ===== */
            memset(&r, 0, sizeof(r));
            r.magic      = HY_HS_MAGIC_OF(HY_HS_STEP_ANS);
            r.uver_major = HY_VER_MAJOR;
            r.uver_minor = HY_VER_MINOR;
            snprintf(r.uver_str, sizeof(r.uver_str), "%s", HY_VERSION_STRING);
            for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
                r.key[i] = (char)ans[i];
            r.key[HY_CHAL_LEN] = 0;

            /* 明文用完就抹，栈上不留 */
            for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
                ans[i] = 0;

            ret = self->call(HY_NR_HANDSHAKE, &r, (uint32_t)sizeof(r));

            self->hs_res_    = r.result;
            self->hs_key_ok_ = (r.lock_key != 0);

            if (r.locked) {
                self->hs_in_ = false;
                self->hs_ok_ = true;
                return true;
            }

            self->hs_in_ = false;
            self->hs_ok_ = false;

            fprintf(stderr,
                "\n========== 欢愉握手失败，全部功能已禁用 ==========\n"
                "  内核态版本：%s\n"
                "  用户态版本：%s  (major=%d minor=%d)\n"
                "  版本一致  ：%s\n"
                "  挑战应答  ：%s\n"
                "  内核返回  ：%s\n",
                self->kver_, HY_VERSION_STRING, HY_VER_MAJOR, HY_VER_MINOR,
                self->hs_ver_ok_ ? "是" : "否",
                self->hs_key_ok_ ? "一致" : "不一致",
                hy_hs_result_text(r.result));

            if (!self->hs_ver_ok_)
                fprintf(stderr,
                "  → 版本不一致：请核对本文件的 HY_VERSION_STRING /\n"
                "    HY_VER_MAJOR / HY_VER_MINOR 是否与内核 hy.h 一致。\n");

            if (!self->hs_key_ok_)
                fprintf(stderr,
                "  → 挑战应答与内核原文不匹配：五层密钥解错了。\n"
                "    请把本文件的 HY_KEY_L1..L5 改成与内核 hy.h 逐字节一致。\n"
                "    内核不接收密钥、也报不出是哪一层错，只能逐字符重抄。\n");

            fprintf(stderr, "===================================================\n\n");
            return false;
        }
    }

    /*
     * 通道探测：用 BP_CHECK_INITED 这类零副作用命令试一次 prctl。
     * 成功返回 0 说明 hook 生效、模块在场。
     * 若 hook 未安装，真实 prctl 会因 option 非法返回 -1/EINVAL。
     */
    bool probe_prctl() const
    {
        /*
         * 【v1.67.0 必须用 HY_NR_VERSION 探测】
         * 探测发生在握手之前，此时内核闸门只放行 HY_NR_VERSION 与
         * HY_NR_HANDSHAKE。沿用 BP_CHECK_INITED 会一律拿到 -EACCES，
         * 把正常通道误判为不可用，进而退回 supercall，
         * 没设超级密钥时就彻底连不上。
         */
        uint32_t kv[4];
        memset(kv, 0, sizeof(kv));
        long r = hy_detail::prctl_ctl(HY_NR_VERSION, kv);
        return (r == 0 && kv[0] == (uint32_t)HY_MAGIC);
    }

    /* CTL0 调用：nr 为命令号，payload 为结构体，len 为其长度 */
    long call(uint32_t nr, void *payload, uint32_t len) const
    {
        /*
         * 【v1.67.0】握手闸门。
         * hs_in_ 置位时表示正在握手 —— 握手自己必须能下发，
         * 否则就变成"要握手先得已握手"的死循环。
         */
        hy_driver *self = const_cast<hy_driver *>(this);
        if (!self->hs_in_ && !self->hs_ok_ && !self->handshake())
            return -EACCES;

        /*
         * 【v1.25.0】优先走 prctl 免鉴权通道。
         * 之前本文件只有 supercall 一条路，而 root shell 下 supercall
         * 鉴权过不去 —— 内核侧那条免密钥通道等于从未被使用。
         */
        if (prctl_ok_) {
            long r = hy_detail::prctl_ctl(nr, len > 0 ? payload : nullptr);
            if (r != -1 && r != -EINVAL)
                return r;
            /* 落到下面走 supercall */
        }

        char frame[HY_FRAME_MAX];
        if (len > 0 && (!payload || (uint32_t)(HY_FRAME_HDR + len) > (uint32_t)sizeof(frame)))
            return -EINVAL;

        memset(frame, 0, sizeof(frame));
        frame[0] = 'H';                       /* tag，保证 strlen >= 1 */
        memcpy(frame + 4, &nr, sizeof(nr));
        uint32_t rsv = 0;
        memcpy(frame + 8, &rsv, sizeof(rsv));
        if (len > 0) memcpy(frame + HY_FRAME_HDR, payload, len);

        long ret = hy_detail::sc_kpm_control(key_.c_str(), HY_MODULE_NAME,
                                             frame, frame, (long)sizeof(frame));
        if (ret >= 0 && len > 0)
            memcpy(payload, frame + HY_FRAME_HDR, len);
        return ret;
    }

    long call_empty(uint32_t nr) const
    {
        uint32_t dummy = 0;
        return call(nr, &dummy, 0);
    }

    template <typename T>
    long call_obj(uint32_t nr, T &o) const
    {
        return call(nr, &o, (uint32_t)sizeof(T));
    }

public:
    /* ---------------- 生命周期 ---------------- */

    /*
     * 默认免密钥：key = "su"。
     *   hy_driver drv;                 -> 用 "su"
     *   hy_driver drv("真实密钥");     -> 设备设了自定义密钥时用这个
     *   hy_driver drv("su", false);    -> 不做探测（构造更快）
     */
    explicit hy_driver(const char *key = HY_NO_KEY, bool probe = true)
        : key_((key && key[0]) ? key : HY_NO_KEY)
    {
        if (probe) {
            /*
             * 【v1.67.0】探测阶段必须绕过握手闸门。
             *
             * 顺序不能反：探测是为了确定"走哪条通道"，而握手本身
             * 就要发命令 —— 若在通道还没定下来时先握手，握手会被
             * 迫走 supercall，root shell 下鉴权过不去，于是判成握手
             * 失败并锁死 hs_tried_，明明 prctl 通道完全正常也用不了。
             *
             * 所以：hs_in_ 置位放行探测 → 定通道 → 解除 → 再握手。
             */
            hs_in_ = true;
            prctl_ok_ = probe_prctl();
            hs_in_ = false;

            if (prctl_ok_) {
                channel_ = 1;
                authed_  = true;    /* 这条通道不经鉴权门禁 */
                (void)handshake();  /* 通道定了再自报版本与密钥 */
                ready_   = true;
                return;
            }
            /* 2) 回退 supercall */
            authed_ = hy_detail::sc_key_ok(key_.c_str());
            if (authed_) {
                (void)handshake();
                ready_ = (call_empty(BP_CHECK_INITED) == 0);
                if (ready_) channel_ = 2;
            }
        }
    }

    explicit hy_driver(const std::string &key, bool probe = true)
        : hy_driver(key.c_str(), probe) {}

    bool is_ready() const { return ready_; }
    bool is_authed() const { return authed_; }
    bool prctl_ok() const { return prctl_ok_; }

    /* ==================================================================
     * 【v1.67.0】版本 / 密钥握手闸门
     * ================================================================== */

    /* 主动握手（构造函数里已自动做过一次）。true = 命令可正常下发 */
    bool ensure_handshake() const { return handshake(); }

    /* 当前是否已通过握手 */
    bool handshake_ok() const { return hs_ok_; }

    /* 最近一次握手的内核结果码 HY_HS_* */
    uint32_t handshake_result() const { return hs_res_; }

    /*
     * 清掉"已试过"标记，允许再握手一次。
     * 改完版本号或密钥后调它，下次发命令会自动重试握手，
     * 不用重建对象。
     */
    void reset_handshake() const
    {
        hy_driver *self = const_cast<hy_driver *>(this);
        self->hs_ok_    = false;
        self->hs_tried_ = false;
        self->hs_in_    = false;
        self->hs_res_   = 0;
        self->hs_layer_got_ = 0;
    }

    const char *handshake_text() const
    {
        if (hs_ok_)     return "已握手：版本与密钥均与内核一致，命令正常放行";
        if (!hs_tried_) return "未握手：尚未向内核自报版本号与密钥";
        switch (hs_res_) {
        case HY_HS_BAD_MAGIC: return "握手失败：magic 不匹配";
        case HY_HS_BAD_VER:   return "握手失败：版本与内核不一致，命令已禁用";
        case HY_HS_BAD_KEY:   return "握手失败：挑战应答与内核原文不一致（五层密钥解错），命令已禁用";
        case HY_HS_BAD_BOTH:  return "握手失败：版本与挑战应答都不一致，命令已禁用";
        case HY_HS_NO_CHAL:   return "握手失败：还没请求挑战就提交应答 —— 请确认对接文件是 v1.71.0 及以上的挑战-响应版";
        case HY_HS_DONE:      return "已握手：两步都过，命令正常放行";
        default:              return "握手失败：内核拒绝，命令已禁用";
        }
    }

    /* 0=none 1=prctl 2=supercall */
    int  channel() const { return channel_; }
    const char *channel_name() const
    {
        switch (channel_) {
        case 1: return "prctl (no superkey)";
        case 2: return "supercall (ctl0)";
        default: return "none";
        }
    }

    /*
     * KP 是否安装。注意：这不代表鉴权通过
     * （HELLO 在鉴权门槛之前返回），仅表示 KP 在跑。
     */
    bool kernelpatch_ready() const { return hy_detail::sc_ready(key_.c_str()); }

    /* 换 key 后重新探测 */
    bool set_key(const char *k)
    {
        key_ = (k && k[0]) ? k : HY_NO_KEY;
        reset_handshake();
        hs_in_ = true;
        prctl_ok_ = probe_prctl();
        hs_in_ = false;
        if (prctl_ok_) {
            channel_ = 1; authed_ = true; ready_ = true;
            (void)handshake();
            return true;
        }
        authed_ = hy_detail::sc_key_ok(key_.c_str());
        if (authed_) (void)handshake();
        ready_ = authed_ ? (call_empty(BP_CHECK_INITED) == 0) : false;
        channel_ = ready_ ? 2 : 0;
        return authed_;
    }

    const std::string &key() const { return key_; }

    /* 免密钥是否可用（当前 key 能通过鉴权） */
    bool recheck_auth()
    {
        authed_ = hy_detail::sc_key_ok(key_.c_str());
        if (authed_) ready_ = (call_empty(BP_CHECK_INITED) == 0);
        return authed_;
    }

    /* ==================================================================
     * 【v1.68.0】启动状态两行
     *
     *   第一行  huanyu已加载 / 未加载（已加载则带内核版本 + 用户态版本）
     *   第二行  内核对用户态发过去的 key 的判定结果
     *
     * "加载"以能否问出内核版本为准：版本查询是闸门放行的少数命令之一，
     * 能答上来就说明 kpm 在。所以即使版本或密钥对不上被禁用，
     * 第一行依然如实报告"已加载"，第二行再说明为什么被禁。
     *
     * 【密钥不落日志】这里一个字符都不打印，内核侧同样只说"不同"。
     * ================================================================== */
    void print_boot_banner() const
    {
        if (!kver_got_) {
            printf("huanyu未加载  当前用户态版本 %s\n", HY_VERSION_STRING);
            printf("当前用户态key未校验 —— huanyu 未加载，禁止运行\n");
            fflush(stdout);
            return;
        }

        printf("huanyu已加载  内核版本 %s   当前用户态版本 %s\n",
               kver_[0] ? kver_ : "(未知)", HY_VERSION_STRING);

        if (!hs_key_ok_) {
            printf("当前用户态key和huanyu不同 —— 禁止运行"
               "（挑战应答与内核原文不匹配，五层密钥解错）\n");
        } else if (!hs_ver_ok_) {
            printf("当前用户态key和huanyu一致，但版本不同"
                   "（内核 %s / 用户态 %s）—— 禁止运行\n",
                   kver_[0] ? kver_ : "(未知)", HY_VERSION_STRING);
        } else {
            printf("当前用户态key和huanyu一致 —— 允许运行（挑战-响应通过）\n");
        }
        fflush(stdout);
    }

    bool initialize(pid_t pid)
    {
        if (pid <= 0) return false;
        pid_ = pid;
        /* 主动握手并打印两行状态 —— 不用等到第一次读写才被动触发，
           那时出问题已经分不清是没加载还是密钥不对。 */
        (void)handshake();
        print_boot_banner();
        return true;
    }

    pid_t target() const { return pid_; }

    /* ---------------- 进程 / 模块 ---------------- */

    pid_t get_name_pid(const char *name) const
    {
        hy_request r{};
        char buf[256];
        if (!ready_ || !name) return -1;
        memset(buf, 0, sizeof(buf));
        strncpy(buf, name, sizeof(buf) - 1);
        r.buffer = (uint64_t)(uintptr_t)buf;
        if (call_obj(GET_PID, r) != 0) return -1;
        return (pid_t)r.pid;
    }

    uint64_t get_module_base(const char *name) const
    {
        hy_request r{};
        char buf[256];
        if (!ready_ || pid_ <= 0 || !name) return 0;
        memset(buf, 0, sizeof(buf));
        strncpy(buf, name, sizeof(buf) - 1);
        r.pid = pid_;
        r.buffer = (uint64_t)(uintptr_t)buf;
        if (call_obj(MODULE_BASE, r) != 0) return 0;
        return r.addr;
    }

    uint64_t get_module_bss(const char *name) const
    {
        hy_request r{};
        char buf[256];
        if (!ready_ || pid_ <= 0 || !name) return 0;
        memset(buf, 0, sizeof(buf));
        strncpy(buf, name, sizeof(buf) - 1);
        r.pid = pid_;
        r.buffer = (uint64_t)(uintptr_t)buf;
        if (call_obj(MODULE_BSS, r) != 0) return 0;
        return r.addr;
    }

    /* ---------------- 内存读写 ---------------- */

    bool read(uint64_t addr, void *buffer, size_t size) const
    {
        hy_request r{};
        if (!ready_ || pid_ <= 0) return false;
        addr &= 0xFFFFFFFFFFFFULL;
        r.pid = pid_;
        r.addr = addr;
        r.buffer = (uint64_t)(uintptr_t)buffer;
        r.size = size;
        return call_obj(READ_MEM, r) == 0;
    }

    template <typename T>
    T read(uint64_t addr) const
    {
        T res{};
        if (read(addr, &res, sizeof(T))) return res;
        return T{};
    }

    bool read_v2(uint64_t addr, void *buffer, size_t size) const
    {
        hy_request r{};
        if (!ready_ || pid_ <= 0) return false;
        addr &= 0xFFFFFFFFFFFFULL;
        r.pid = pid_;
        r.addr = addr;
        r.buffer = (uint64_t)(uintptr_t)buffer;
        r.size = size;
        return call_obj(READ_MEM_V2, r) == 0;
    }

    template <typename T>
    T read_v2(uint64_t addr) const
    {
        T res{};
        if (read_v2(addr, &res, sizeof(T))) return res;
        return T{};
    }

    bool write(uint64_t addr, const void *buffer, size_t size) const
    {
        hy_request r{};
        if (!ready_ || pid_ <= 0) return false;
        addr &= 0xFFFFFFFFFFFFULL;
        r.pid = pid_;
        r.addr = addr;
        r.buffer = (uint64_t)(uintptr_t)buffer;
        r.size = size;
        return call_obj(WRITE_MEM, r) == 0;
    }

    template <typename T>
    bool write(uint64_t addr, const T &val) const
    {
        return write(addr, &val, sizeof(T));
    }

    /* ---------------- 断点方案切换 ---------------- */

    void set_bp_mode(uint32_t m)
    {
        hy_bp_mode_config c{};
        c.mode = m;
        call_obj(BP_SET_MODE, c);
        mode_ = m;
    }

    uint32_t get_bp_mode() const { return mode_; }

    /* ---------------- 断点隐蔽性（v1.63.0） ----------------
     * 默认开启：SW 方案会被内核自动升级成 PTE 影子页，
     * 一个代码字节都不改（只改页表），对代码段做 CRC/哈希的自检扫不到。
     *
     * 关掉之后 SW 才会真的往代码段写 BRK —— 只在你需要
     * "确认这就是传统软件断点"时才关。
     *
     * 这是改落地方式，不是改你选的方案：地址、类型、命中回调都不变。
     */
    void set_bp_stealth(bool on) { bp_stealth_ = on; }
    bool get_bp_stealth() const  { return bp_stealth_; }

    /* ---------------- 读取后端选择（v1.60.0） ----------------
     *   drv.set_rw_mode(HY_RW_MODE_KERNEL);   // 默认，内核级读取
     *   drv.set_rw_mode(HY_RW_MODE_KMA);      // KMA 硬件级读取
     * 默认 0。设 1 后只对内核虚拟地址 / 物理地址生效，
     * 用户态进程内存自动回落内核级。
     */
    void set_rw_mode(uint32_t m)
    {
        hy_rw_mode c{};
        c.mode = (m == HY_RW_MODE_KMA) ? HY_RW_MODE_KMA : HY_RW_MODE_KERNEL;
        call_obj(HY_NR_RWMODE_SET, c);
        rw_mode_ = c.mode;
    }

    uint32_t get_rw_mode() const { return rw_mode_; }

    /* ---------------- 读取缓存开关（v1.63.0） ----------------
     *   drv.set_mem_cache(HY_MEM_CACHE_DEFAULT); // 默认，启用缓存
     *   drv.set_mem_cache(HY_MEM_CACHE_ON);      // 强制启用
     *   drv.set_mem_cache(HY_MEM_CACHE_OFF);     // 关闭，每次重走页表
     *
     * 默认 0（启用）。命中时省掉 4 级页表遍历，只校验一次 PTE 值，
     * 因此"有缓存"在几乎所有场景下都优于"无缓存"。
     * 只有在需要"每一次都强制重新解析页表"的调试场景下才设 OFF。
     * 该开关作用于**所有读取路径**（用户态进程内存 / 内核地址 / 物理地址）。
     *
     * v1.64.1：显式设过之后，方案选择器的自动降级就**不再改动这个开关**，
     * 只调缓存路数。否则降级到"无缓存"档会静默把你选的 ON 改成 OFF，
     * 而且看不出是谁改的。要恢复由档位自动决定，重启模块即可（默认 AUTO）。
     */
    void set_mem_cache(uint32_t m)
    {
        hy_mem_cache_mode c{};
        c.mode = (m == HY_MEM_CACHE_OFF) ? HY_MEM_CACHE_OFF
               : ((m == HY_MEM_CACHE_ON) ? HY_MEM_CACHE_ON
                                         : HY_MEM_CACHE_DEFAULT);
        call_obj(HY_NR_MEMCACHE_SET, c);
        mem_cache_ = c.mode;
    }

    uint32_t get_mem_cache() const { return mem_cache_; }

    /* ---------------- 方案选择（v1.64.0） ----------------
     *
     * 每个功能面都备了面向 3/4/5/6 系内核的多套做法，默认 AUTO：
     * 先试最高世代那套，probe 不过就往下降一格，运行期失败还会自动再降。
     *
     *   drv.set_scheme(HY_SC_PGTABLE, HY_SCHEME_AUTO); // 默认，推荐
     *   drv.set_scheme(HY_SC_BP,      HY_SCHEME_GEN6); // 只用 6 系那套
     *   drv.set_scheme(HY_SC_INPUT,   HY_SCHEME_GEN5); // 只用 5 系那套
     *
     * 什么时候才需要手动指定：
     *   1) AUTO 在某台机器上选中了你不想要的那档（看 /proc/Huanyu 的
     *      [scheme] 段能确认当前落在哪档）；
     *   2) 排查"是不是某一档的问题"时，逐个钉死来对比。
     *
     * 强制档在这台机器上不可用时**不会**静默换成别的：该域变成
     * "无可用方案"，功能停用并如实上报 —— 避免你以为在用 A 实际是 B。
     */
    void set_scheme(uint32_t dom, uint32_t gen)
    {
        hy_scheme_req r{};
        r.dom = dom;
        /* 不在取值范围内的（含 AUTO）一律按自动处理，不让非法值进内核 */
        r.gen = (gen == HY_SCHEME_GEN3 || gen == HY_SCHEME_GEN4 ||
                 gen == HY_SCHEME_GEN5 || gen == HY_SCHEME_GEN6)
              ? gen : HY_SCHEME_AUTO;
        call_obj(HY_NR_SCHEME_SET, r);
    }

    /* 查询某域当前落在哪一档。gen_out 为该档面向的世代，0 = 无可用方案。 */
    uint32_t get_scheme(uint32_t dom, uint32_t *gen_out = nullptr) const
    {
        hy_scheme_req r{};
        r.dom = dom;
        call_obj(HY_NR_SCHEME_GET, r);
        if (gen_out) *gen_out = r.cur_gen;
        return r.chosen;
    }

    /*
     * KMA 是否真的可用（v1.66.0 修正）
     *
     * 旧实现是 (mode == KMA) && (reserved != 0)，但内核 hy_rw_mode
     * 只有 mode 和 reserved 两个字段，而 reserved 恒为 0 ——
     * 于是这个函数**永远返回 false**，无论 KMA 实际能不能用。
     * 现在改成解析 "rwmode stat" 文本里的 avail=N。
     */
    bool rw_kma_available() const
    {
        std::string s = do_cmd_str("rwmode stat");
        size_t p = s.find("avail=");
        if (p == std::string::npos) return false;
        return ::atoi(s.c_str() + p + 6) != 0;
    }

    /* ---------------- 读取缓存查询（v1.66.0 修正） ----------------
     *
     * 旧实现走文本命令 "memcache stat"，但内核 hy_dbg_cmd_dispatch()
     * 里从来没有 memcache 这个分支 —— 命令一律落到
     * "unknown command"，拿到的是报错串而不是状态。
     * 现在改走 nr 90（MEMCACHE_GET），与 set_mem_cache 对称。
     */
    uint32_t mem_cache_runtime() const
    {
        hy_mem_cache_mode c{};
        if (call_obj(HY_NR_MEMCACHE_GET, c) != 0) return mem_cache_;
        return c.mode;
    }

    /* ---------------- 网络预留（v1.60.0） ----------------
     * 内核不发任何包。真正的下载请用文件末尾的 hy_http_download()。
     */
    std::string do_cmd_str(const std::string &cmd) const
    {
        hy_dbg_req r{};
        std::string c = cmd.size() >= sizeof(r.cmd)
                      ? cmd.substr(0, sizeof(r.cmd) - 1) : cmd;
        std::memcpy(r.cmd, c.c_str(), c.size() + 1);
        r.cmd_len = (uint32_t)c.size();
        if (call_obj(HY_NR_DBG_CMD, r) != 0) return std::string();
        r.out[sizeof(r.out) - 1] = 0;
        return std::string(r.out);
    }

    /* ---------------- 网络预留（v1.60.0 / v1.66.0 修正） ----------------
     *
     * 内核**不发任何包**。hy_net_req/hy_net_rep 只是把命令号、参数结构、
     * 状态码、语义定死的 ABI 预留，真正的下载请用文件末尾的
     * hy_http_download()（用户态实现，崩了只死自己那个进程）。
     *
     * 【v1.66.0 修正】
     *   旧 net_note() 走的是文本命令 "net <url>"，但内核
     *   hy_dbg_cmd_dispatch() 里根本没有 net 分支 —— 命令落到
     *   "unknown command; try: HuanyuD help"，返回串非空，
     *   于是 net_note() 反而返回 true，是个**假成功**。
     *   现在改成走真正的 nr 86/87/88。
     */

    /* nr 86：能力探测。返回 0 表示内核侧实现了该命令；
     * 出参 caps.kernel_impl 为 0 表示"内核不做收发，必须走用户态"。 */
    bool net_cap(hy_net_cap *caps = nullptr) const
    {
        hy_net_cap c{};
        if (caps) std::memset(caps, 0, sizeof(*caps));
        if (!ready_) return false;
        if (call_obj(HY_NR_NET_CAP, c) != 0) return false;
        if (caps) *caps = c;
        return true;
    }

    /*
     * nr 87：拉取意图上报。
     * 内核侧对这个命令**一律返回 -ENOTSUP**，这是设计而非缺陷：
     * 它明确告诉调用方"这条路要走用户态"。
     * 因此本函数只在 url 合法且已上报成功时返回 true，
     * 真正的内容请配合 hy_http_download() 使用。
     */
    bool net_fetch(const std::string &url,
                   uint32_t method = HY_NET_METHOD_GET,
                   uint32_t timeout_ms = 0,
                   uint32_t flags = 0) const
    {
        if (!ready_) return false;
        if (url.empty() || url.size() >= HY_NET_URL_MAX) return false;
        hy_net_req r{};
        r.method     = method;
        r.timeout_ms = timeout_ms;
        r.flags      = flags;
        std::memcpy(r.url, url.c_str(), url.size() + 1);
        return call_obj(HY_NR_NET_FETCH, r) == 0;
    }

    /* nr 88：最近一次网络请求的状态 */
    bool net_status(hy_net_rep *rep = nullptr) const
    {
        hy_net_rep r{};
        if (rep) std::memset(rep, 0, sizeof(*rep));
        if (!ready_) return false;
        if (call_obj(HY_NR_NET_STATUS, r) != 0) return false;
        if (rep) *rep = r;
        return true;
    }


    uint32_t bp_caps(hy_bp_caps *out = nullptr) const
    {
        hy_bp_caps c{};
        call_obj(BP_GET_CAPS, c);
        if (out) *out = c;
        return c.supported;
    }

    bool bp_supports(uint32_t m) const
    {
        uint32_t s = bp_caps();
        if (m == HY_BP_MODE_SW)  return (s & HY_BP_CAP_SW)  != 0;
        if (m == HY_BP_MODE_PTE) return (s & HY_BP_CAP_PTE) != 0;
        if (m == HY_BP_MODE_HW)  return (s & HY_BP_CAP_HW)  != 0;
        return false;
    }

    /* ---------------- 断点安装 ---------------- */

    uint64_t bp_inst(pid_t target_pid, uint64_t addr,
                     uint32_t bp_len = HW_BREAKPOINT_LEN_4,
                     uint32_t bp_type = HW_BREAKPOINT_X,
                     uint64_t reg_mask = 0,
                     uint64_t fp_mask = 0,
                     hy_user_pt_regs *regs = nullptr,
                     uint32_t flags = 0,
                     uint32_t force_mode = 0) const
    {
        hy_bp_inst_args a{};
        if (!ready_) return 0;

        /* 单次覆盖：临时改全局默认，装完还原 */
        if (force_mode && force_mode != mode_) {
            hy_bp_mode_config m{};
            m.mode = force_mode;
            call_obj(BP_SET_MODE, m);
        }

        a.pid = target_pid;
        a.addr = addr;
        a.bp_len = bp_len;
        a.bp_type = bp_type;
        a.reg_modify_mask = reg_mask;
        a.fp_reg_modify_mask = fp_mask;
        a.regs_to_set_ptr = (uint64_t)(uintptr_t)regs;
        a.flags = flags;
        /*
         * v1.64.0：mode 字段此前用户态根本没传（结构体里都没有这个字段），
         * 内核读到的就是栈上的残留值 —— 这是"选了方案但落到了别的方案"
         * 的直接原因。现在显式填：单次覆盖优先，否则用全局默认。
         */
        a.mode = force_mode ? force_mode : mode_;
        /* 隐蔽性默认开；只有显式关掉才允许真的往代码段写 BRK */
        if (!bp_stealth_) a.flags |= HY_BP_FLAG_NOSTEALTH;

        long ret = call_obj(BP_INST, a);

        if (force_mode && force_mode != mode_) {
            hy_bp_mode_config m{};
            m.mode = mode_;
            call_obj(BP_SET_MODE, m);
        }

        if (ret != 0) return 0;
        return a.addr;      /* 内核回填的 handle */
    }

    uint64_t bp_inst(pid_t target_pid, uint64_t addr, uint32_t bp_len,
                     uint32_t bp_type, hy_reg_batch &batch,
                     uint32_t flags = 0, uint32_t force_mode = 0) const
    {
        return bp_inst(target_pid, addr, bp_len, bp_type,
                       batch.reg_mask, batch.fp_mask,
                       batch.empty() ? nullptr : &batch.regs,
                       flags, force_mode);
    }

    /* 语义化快捷入口 */
    uint64_t bp_inst_sw (pid_t p, uint64_t a, uint32_t t = HW_BREAKPOINT_X) const
    { return bp_inst(p, a, HW_BREAKPOINT_LEN_4, t, 0,0,nullptr,0, HY_BP_MODE_SW); }

    uint64_t bp_inst_pte(pid_t p, uint64_t a, uint32_t t = HW_BREAKPOINT_X) const
    { return bp_inst(p, a, HW_BREAKPOINT_LEN_4, t, 0,0,nullptr,0, HY_BP_MODE_PTE); }

    uint64_t bp_inst_hw (pid_t p, uint64_t a, uint32_t t = HW_BREAKPOINT_X) const
    { return bp_inst(p, a, HW_BREAKPOINT_LEN_4, t, 0,0,nullptr,0, HY_BP_MODE_HW); }

    /* 观察点（需硬件方案） */
    uint64_t watch_write(pid_t p, uint64_t a) const
    { return bp_inst(p, a, HW_BREAKPOINT_LEN_4, HW_BREAKPOINT_W,  0,0,nullptr,0, HY_BP_MODE_HW); }

    uint64_t watch_read(pid_t p, uint64_t a) const
    { return bp_inst(p, a, HW_BREAKPOINT_LEN_4, HW_BREAKPOINT_R,  0,0,nullptr,0, HY_BP_MODE_HW); }

    uint64_t watch_rw(pid_t p, uint64_t a) const
    { return bp_inst(p, a, HW_BREAKPOINT_LEN_4, HW_BREAKPOINT_RW, 0,0,nullptr,0, HY_BP_MODE_HW); }

    bool bp_uninst(uint64_t handle) const
    {
        if (!ready_ || !handle) return false;
        return call_obj(BP_UNINST, handle) == 0;
    }

    bool bp_suspend(uint64_t handle) const
    {
        if (!ready_ || !handle) return false;
        return call_obj(BP_SUSPEND, handle) == 0;
    }

    bool bp_resume(uint64_t handle) const
    {
        if (!ready_ || !handle) return false;
        return call_obj(BP_RESUME, handle) == 0;
    }

    int bp_get_num_brps() const
    {
        if (!ready_) return -1;
        return (int)call_empty(BP_GET_NUM_BRPS);
    }

    int bp_get_num_wrps() const
    {
        if (!ready_) return -1;
        return (int)call_empty(BP_GET_NUM_WRPS);
    }

    bool bp_check_inited() const
    {
        if (!ready_) return false;
        return call_empty(BP_CHECK_INITED) == 0;
    }

    bool bp_init_driver() const
    {
        if (!ready_) return false;
        return call_empty(BP_INIT_CMD) == 0;
    }

    /* ---------------- 命中记录 ---------------- */

    bool bp_get_hit_count(uint64_t handle, uint64_t *total, uint64_t *items) const
    {
        hy_bp_get_hit_count_arg a{};
        if (!ready_ || !handle) return false;
        a.handle = handle;
        if (call_obj(BP_GET_HIT_COUNT, a) != 0) return false;
        if (total) *total = a.hit_total_count;
        if (items) *items = a.hit_item_arr_count;
        return true;
    }

    size_t bp_get_hit_items(uint64_t handle, hy_bp_hit_item *buf, size_t max_bytes) const
    {
        hy_bp_get_hit_items_args a{};
        if (!ready_ || !handle || !buf || max_bytes == 0) return 0;
        a.handle = handle;
        a.user_buffer_ptr = (uint64_t)(uintptr_t)buf;
        a.max_bytes = max_bytes;
        if (call_obj(BP_GET_HIT_ITEMS, a) != 0) return 0;
        return (size_t)a.items_copied;
    }

    std::vector<hy_bp_hit_item> bp_get_hits(uint64_t handle, size_t max_items = 100) const
    {
        std::vector<hy_bp_hit_item> out;
        if (!ready_ || !handle || max_items == 0) return out;

        uint64_t total = 0, cnt = 0;
        if (!bp_get_hit_count(handle, &total, &cnt) || cnt == 0) return out;

        size_t n = (cnt < max_items) ? (size_t)cnt : max_items;
        out.resize(n);
        size_t got = bp_get_hit_items(handle, out.data(), n * sizeof(hy_bp_hit_item));
        out.resize(got);
        return out;
    }

    /* 轮询等待命中 */
    bool bp_wait_hit(uint64_t handle, hy_bp_hit_item &out, int timeout_ms = 3000) const
    {
        const int step = 20;
        for (int waited = 0; waited < timeout_ms; waited += step) {
            uint64_t total = 0, cnt = 0;
            if (bp_get_hit_count(handle, &total, &cnt) && cnt > 0) {
                hy_bp_hit_item one{};
                if (bp_get_hit_items(handle, &one, sizeof(one)) > 0) {
                    out = one;
                    return true;
                }
            }
            usleep(step * 1000);
        }
        return false;
    }

    /* ---------------- 寄存器改写 ---------------- */

    bool bp_modify(uint64_t handle, uint64_t reg_mask, uint64_t fp_mask,
                   hy_user_pt_regs *regs) const
    {
        hy_bp_modify_args m{};
        if (!ready_ || !handle) return false;
        m.handle = handle;
        m.reg_modify_mask = reg_mask;
        m.fp_reg_modify_mask = fp_mask;
        m.regs_to_set_ptr = (uint64_t)(uintptr_t)regs;
        return call_obj(BP_MODIFY, m) == 0;
    }

    bool bp_set_reg(uint64_t handle, int idx, uint64_t val) const
    {
        if (idx < 0 || idx > 30) return false;
        hy_user_pt_regs r{};
        r.regs[idx] = val;
        return bp_modify(handle, (1ULL << idx), 0, &r);
    }

    bool bp_set_regs(uint64_t handle, std::initializer_list<std::pair<int, uint64_t>> regs) const
    {
        hy_user_pt_regs r{};
        uint64_t mask = 0;
        for (const auto &p : regs) {
            if (p.first < 0 || p.first > 30) continue;
            r.regs[p.first] = p.second;
            mask |= (1ULL << p.first);
        }
        if (mask == 0) return false;
        return bp_modify(handle, mask, 0, &r);
    }

    bool bp_set_pc(uint64_t handle, uint64_t pc) const
    {
        hy_user_pt_regs r{};
        r.pc = pc;
        return bp_modify(handle, REG_MODIFY_PC, 0, &r);
    }

    bool bp_set_sp(uint64_t handle, uint64_t sp) const
    {
        hy_user_pt_regs r{};
        r.sp = sp;
        return bp_modify(handle, REG_MODIFY_SP, 0, &r);
    }

    bool bp_set_pstate(uint64_t handle, uint64_t pstate) const
    {
        hy_user_pt_regs r{};
        r.pstate = pstate;
        return bp_modify(handle, REG_MODIFY_PSTATE, 0, &r);
    }

    bool bp_set_vreg_float(uint64_t handle, int idx, float val) const
    {
        if (idx < 0 || idx > 31) return false;
        hy_user_pt_regs r{};
        __uint128_t v = 0;
        memcpy(&v, &val, sizeof(float));
        r.vregs[idx] = v;
        return bp_modify(handle, 0, (1ULL << idx), &r);
    }

    bool bp_set_vreg_double(uint64_t handle, int idx, double val) const
    {
        if (idx < 0 || idx > 31) return false;
        hy_user_pt_regs r{};
        __uint128_t v = 0;
        memcpy(&v, &val, sizeof(double));
        r.vregs[idx] = v;
        return bp_modify(handle, 0, (1ULL << idx), &r);
    }

    bool bp_apply(uint64_t handle, hy_reg_batch &b) const
    {
        if (b.empty()) return false;
        return bp_modify(handle, b.reg_mask, b.fp_mask, &b.regs);
    }

    /* 命中项访问器 */
    static uint64_t get_xregs(const hy_bp_hit_item &h, int i)
    { return (i >= 0 && i <= 30) ? h.regs_info.regs[i] : 0; }

    static uint64_t get_pc(const hy_bp_hit_item &h)     { return h.regs_info.pc; }
    static uint64_t get_sp(const hy_bp_hit_item &h)     { return h.regs_info.sp; }
    static uint64_t get_pstate(const hy_bp_hit_item &h) { return h.regs_info.pstate; }

    static float get_vregs_float(const hy_bp_hit_item &h, int i)
    {
        float v = 0;
        if (i >= 0 && i <= 31) memcpy(&v, &h.regs_info.vregs[i], sizeof(float));
        return v;
    }

    static double get_vregs_double(const hy_bp_hit_item &h, int i)
    {
        double v = 0;
        if (i >= 0 && i <= 31) memcpy(&v, &h.regs_info.vregs[i], sizeof(double));
        return v;
    }

    /* ---------------- 扩展能力 ---------------- */

    std::vector<hy_mod_info> enum_modules(pid_t pid, size_t max = 128) const
    {
        std::vector<hy_mod_info> v(max);
        hy_enum_mods_req r{};
        if (!ready_) return {};
        r.pid = pid;
        r.max_count = (uint32_t)max;
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        long n = call_obj(HY_ENUM_MODULES, r);
        if (n <= 0) return {};
        v.resize((size_t)n);
        return v;
    }

    std::vector<hy_proc_info> enum_processes(size_t max = 128) const
    {
        std::vector<hy_proc_info> v(max);
        hy_enum_procs_req r{};
        if (!ready_) return {};
        r.max_count = (uint32_t)max;
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        long n = call_obj(HY_ENUM_PROCESSES, r);
        if (n <= 0) return {};
        v.resize((size_t)n);
        return v;
    }

    std::vector<hy_proc_info> enum_threads(pid_t pid, size_t max = 128) const
    {
        std::vector<hy_proc_info> v(max);
        hy_enum_threads_req r{};
        if (!ready_) return {};
        r.pid = pid;
        r.max_count = (uint32_t)max;
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        long n = call_obj(HY_ENUM_THREADS, r);
        if (n <= 0) return {};
        v.resize((size_t)n);
        return v;
    }

    bool kernel_read(uint64_t kaddr, void *buf, size_t sz) const
    {
        hy_kern_rw_req r{};
        if (!ready_ || sz > 4096) return false;
        r.addr = kaddr;
        r.buf_ptr = (uint64_t)(uintptr_t)buf;
        r.size = sz;
        r.is_write = 0;
        return call_obj(HY_KERNEL_RW, r) > 0;
    }

    bool phys_read(uint64_t phys, void *buf, size_t sz) const
    {
        hy_kern_rw_req r{};
        if (!ready_ || sz > 4096) return false;
        r.addr = phys;
        r.buf_ptr = (uint64_t)(uintptr_t)buf;
        r.size = sz;
        r.is_write = 0;
        return call_obj(HY_PHYS_RW, r) > 0;
    }

    int protect(pid_t pid, uint64_t addr, uint64_t size, uint32_t prot) const
    {
        hy_protect_req r{};
        if (!ready_) return -1;
        r.pid = pid;
        r.prot = prot;
        r.addr = addr;
        r.size = size;
        return (int)call_obj(HY_PROTECT, r);
    }

    bool cache_flush(pid_t pid, uint64_t addr, uint64_t size) const
    {
        hy_flush_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.addr = addr;
        r.size = size;
        return call_obj(HY_CACHE_FLUSH, r) == 0;
    }

    std::vector<hy_bp_item> bp_list(size_t max = 64) const
    {
        std::vector<hy_bp_item> v(max);
        hy_bp_list_req r{};
        if (!ready_) return {};
        r.max_count = (uint32_t)max;
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        long n = call_obj(HY_BP_LIST, r);
        if (n <= 0) return {};
        v.resize((size_t)n);
        return v;
    }

    bool bp_clear_hits(uint64_t handle = 0) const
    {
        if (!ready_) return false;
        uint64_t h = handle;
        return call_obj(HY_BP_CLEAR_HITS, h) == 0;
    }

    bool hwcap(hy_hwcap &out) const
    {
        if (!ready_) return false;
        memset(&out, 0, sizeof(out));
        return call_obj(HY_HWCAP, out) > 0;
    }

    bool stats(hy_stats &out) const
    {
        if (!ready_) return false;
        memset(&out, 0, sizeof(out));
        return call_obj(HY_STATS, out) > 0;
    }

    /* ---------------- 触摸 / 陀螺仪 ---------------- */

    bool touch_init(int mode) const
    {
        hy_touch_event_base t{};
        if (!ready_ || mode < 0 || mode > 1) return false;
        t.slot = mode;
        return call_obj(TOUCH_INIT, t) == 0;
    }

    bool touch_down(int slot, int x, int y) const
    {
        hy_touch_event_base t{};
        if (!ready_ || slot < 0) return false;
        t.slot = slot; t.x = x; t.y = y;
        return call_obj(TOUCH_DOWN, t) == 0;
    }

    bool touch_up(int slot) const
    {
        hy_touch_event_base t{};
        if (!ready_ || slot < 0) return false;
        t.slot = slot;
        return call_obj(TOUCH_UP, t) == 0;
    }

    /*
     * 触摸移动（v1.66.0 补齐）
     * 内核 hy_ctl_switch() 里 HY_NR_TOUCH_MOVE 的 case 一直存在
     * （转 hy_input_touch_move），但用户态既没定义命令号也没封装方法，
     * 导致 down 之后无法 move，只能 down→up 反复。本轮补上。
     * 用法：down(slot,x,y) -> move(slot,x2,y2) -> ... -> up(slot)
     */
    bool touch_move(int slot, int x, int y) const
    {
        hy_touch_event_base t{};
        if (!ready_ || slot < 0) return false;
        t.slot = slot; t.x = x; t.y = y;
        return call_obj(TOUCH_MOVE, t) == 0;
    }

    bool gyro_init(int method) const
    {
        int m = method;
        if (!ready_ || method < 0 || method > 1) return false;
        return call_obj(GYRO_INIT, m) == 0;
    }

    bool touch_setup(int max_x, int max_y, int slot_base = 5) const
    {
        struct hy_touch_setup ts = {};
        ts.max_x = max_x; ts.max_y = max_y; ts.slot_base = slot_base;
        return call_obj(TOUCH_SETUP, ts) == 0;
    }

    /*
     * v1.22.0：按名字锁定真实触摸屏。
     *
     * 内核发现真实触摸屏原本只能靠"用户真手指摸一次屏幕"产生
     * ABS_MT_POSITION_X/Y 事件。没摸过就一直走降级自建设备
     * （单点 TOUCH，很多游戏不认）。
     *
     * 传入 /proc/bus/input/devices 里触摸屏的 Name= 值即可主动锁定，
     * 例如 "fts_ts"、"synaptics"、"goodix-ts"。
     * 传 nullptr 或空串则恢复为"等待真实手指"模式。
     */
    bool touch_set_name(const char *name) const
    {
        struct hy_touch_name n = {};
        if (!ready_) return false;
        if (name && name[0]) {
            size_t i = 0;
            while (i + 1 < sizeof(n.name) && name[i] && name[i] != '\n') {
                n.name[i] = name[i]; i++;
            }
            n.name[i] = '\0';
        }
        return call_obj(TOUCH_SET_NAME, n) == 0;
    }

    /* 从 /proc/bus/input/devices 自动找出触摸屏名字并锁定 */
    /*
     * 自动识别触摸屏并锁定。
     *
     * 【v1.27.0 重写】旧实现用 strstr 找 "ABS_MT_POSITION_X" 是错的：
     *   /proc/bus/input/devices 里那一行是**十六进制位掩码**，例如
     *       B: ABS=650800 3
     *   根本不含 "ABS_MT_POSITION_X" 这个字符串，所以 is_ts 永远为 false，
     *   函数永远返回 false —— 触摸一直停在单点自建设备上。
     *
     * 正确做法：解析 B: ABS= 的掩码，检查多点触摸相关的位：
     *   ABS_MT_SLOT        = 0x2f (47)
     *   ABS_MT_POSITION_X  = 0x35 (53)
     *   ABS_MT_POSITION_Y  = 0x36 (54)
     * 任一位（尤其 53/54）置位即认为是触摸屏。
     *
     * 另外段落边界也不能用 "H: Handlers=" —— 它在 B: 行**之前**，
     * 那时还没读到 ABS 掩码。改用 "I: Bus=" 作为新设备段的开始。
     */
    bool touch_set_name_auto() const
    {
        FILE *fp = fopen("/proc/bus/input/devices", "r");
        if (!fp) return false;

        char line[1024];
        char cur[64]  = {0};
        char best[64] = {0};
        bool cur_ts = false;
        bool have   = false;

        const unsigned long long MT_POS_X = 1ULL << 0x35;
        const unsigned long long MT_POS_Y = 1ULL << 0x36;
        const unsigned long long MT_SLOT  = 1ULL << 0x2f;

        /* 判定上一段并开启新段 */
        auto finish = [&]() {
            if (have && cur_ts && cur[0] && !best[0])
                memcpy(best, cur, sizeof(best));
            cur[0] = 0; cur_ts = false; have = false;
        };

        while (fgets(line, sizeof(line), fp)) {
            if (line[0] == 'I' && line[1] == ':' && line[2] == ' ') {
                finish();                       /* 新设备段开始 */
                continue;
            }
            if (!strncmp(line, "N: Name=", 8)) {
                const char *q = strchr(line + 8, '"');
                if (q) {
                    const char *e = strchr(q + 1, '"');
                    if (e) {
                        size_t n = (size_t)(e - q - 1);
                        if (n >= sizeof(cur)) n = sizeof(cur) - 1;
                        memcpy(cur, q + 1, n);
                        cur[n] = 0;
                        have = true;
                    }
                }
                continue;
            }
            if (!strncmp(line, "B: ABS=", 7)) {
                unsigned long long mask = 0;
                if (sscanf(line + 7, "%llx", &mask) == 1) {
                    if (mask & (MT_POS_X | MT_POS_Y | MT_SLOT))
                        cur_ts = true;
                }
                continue;
            }
            /* 兜底：某些内核会打印可读的事件名 */
            if (strstr(line, "ABS_MT_POSITION_X") ||
                strstr(line, "ABS_MT_SLOT"))
                cur_ts = true;
        }
        finish();                               /* 处理最后一段 */
        fclose(fp);

        return best[0] ? touch_set_name(best) : false;
    }

    /* 重新扫描（清空已发现的设备，重新装 probe） */
    bool touch_rescan() const
    {
        if (!ready_) return false;
        uint32_t zero = 0;
        return call_obj(TOUCH_RESCAN, zero) == 0;
    }

    /* ---------------- 虚拟定位 GNSS ---------------- */

    /*
     * 开启虚拟定位并设置坐标。
     *   lat / lon 用十进制角度（如 39.9042, 116.4074），内部自动 ×1e7。
     *   enable=true 开启；返回 true 仅表示命令下发成功。
     *
     * 是否真正生效，看 gnss_status() 里的 patches 是否增长：
     *   一直为 0 = 没匹配到 binder parcel（见下面 6 条已知限制）。
     */
    bool gnss_start(double lat, double lon) const
    {
        hy_gnss_req r{};
        if (!ready_) return false;
        r.latitude_e7  = (int32_t)(lat * 1e7);
        r.longitude_e7 = (int32_t)(lon * 1e7);
        r.enable = 1;
        return call_obj(GNSS_REPORT, r) == 0;
    }

    bool gnss_set(int32_t lat_e7, int32_t lon_e7) const
    {
        hy_gnss_req r{};
        if (!ready_) return false;
        r.latitude_e7  = lat_e7;
        r.longitude_e7 = lon_e7;
        r.enable = 1;
        return call_obj(GNSS_REPORT, r) == 0;
    }

    bool gnss_stop() const
    {
        uint32_t v = 0;
        if (!ready_) return false;
        return call_obj(GNSS_STOP, v) == 0;
    }

    bool gnss_status(hy_gnss_status &st) const
    {
        if (!ready_) return false;
        return call_obj(LS_STATUS, st) == 0;
    }

    /* ---------------- 触摸 / 陀螺仪 ---------------- */

    bool gyro_set(int x_mrad, int y_mrad, int z_mrad = 0) const
    {
        struct hy_gyro_vec v = {};
        v.x = x_mrad; v.y = y_mrad; v.z = z_mrad;
        return call_obj(GYRO_SET, v) == 0;
    }

    bool gyro_modify(float x, float y) const
    {
        hy_gyro_config g{};
        if (!ready_) return false;
        g.enable = 1;
        memcpy(&g.x, &x, sizeof(uint32_t));
        memcpy(&g.y, &y, sizeof(uint32_t));
        return call_obj(GYRO_CONFIG, g) == 0;
    }

    bool gyro_disable() const
    {
        hy_gyro_config g{};
        if (!ready_) return false;
        g.enable = 0;
        return call_obj(GYRO_CONFIG, g) == 0;
    }

    /* ---------------- TLS / PACGA ---------------- */

    bool get_thread_tls(pid_t target_pid, pid_t target_tid, uint64_t *out) const
    {
        hy_tls_request r{};
        if (!ready_ || target_pid <= 0 || !out) return false;
        r.pid = target_pid;
        r.tid = target_tid;
        if (call_obj(GET_THREAD_TLS, r) != 0) return false;
        if (r.result != 0) return false;
        *out = r.tls_value;
        return true;
    }

    bool exec_pacga(pid_t target_pid, uint64_t value, uint64_t modifier, uint64_t *out) const
    {
        hy_pacga_request r{};
        if (!ready_ || target_pid <= 0 || !out) return false;
        r.pid = target_pid;
        r.value = value;
        r.modifier = modifier;
        if (call_obj(EXEC_PACGA, r) != 0) return false;
        if (!r.ok) return false;
        *out = r.result_pac;
        return true;
    }

    /* ---------------- 文件隐藏 ---------------- */

    bool file_hide_init() const
    {
        if (!ready_) return false;
        return call_empty(FILE_HIDE_INIT) == 0;
    }

    bool file_hide_set(const char *dir, const char *keyword, bool enabled = true) const
    {
        hy_file_hide_config c{};
        if (!ready_ || !dir || !keyword) return false;
        size_t dl = strnlen(dir, sizeof(c.directory));
        size_t kl = strnlen(keyword, sizeof(c.keyword));
        if (dl == 0 || kl == 0) return false;
        if (dl >= sizeof(c.directory) || kl >= sizeof(c.keyword)) return false;
        memcpy(c.directory, dir, dl);
        memcpy(c.keyword, keyword, kl);
        c.enabled = enabled ? 1u : 0u;
        return call_obj(FILE_HIDE_SET, c) == 0;
    }

    bool file_hide_clear() const
    {
        if (!ready_) return false;
        return call_empty(FILE_HIDE_CLEAR) == 0;
    }

    bool file_hide(const char *dir, const char *keyword, bool enabled = true) const
    {
        return enabled ? file_hide_set(dir, keyword, true) : file_hide_clear();
    }

    bool file_hide_status(hy_file_hide_status *st) const
    {
        if (!ready_ || !st) return false;
        memset(st, 0, sizeof(*st));
        return call_obj(FILE_HIDE_STATUS, *st) == 0;
    }

    hy_file_hide_status file_hide_status() const
    {
        hy_file_hide_status s{};
        file_hide_status(&s);
        return s;
    }

    /* ==================================================================
     * 【v1.64.0】内核功能同步
     *
     * 下面这些命令内核侧一直都有（hy_ctl.c 的 switch 里有完整分支），
     * 但用户态此前要么没有命令号、要么没有参数结构、要么两者都没有，
     * 结果就是"功能在内核里跑着，用户却调不到"。这一节补齐。
     *
     * 分两类：
     *   二进制命令 —— 有自己的命令号与参数结构（sysmon / stepbp / shm ...）
     *   文本命令   —— 复用 HY_NR_DBG_CMD，与 echo 到 /proc/HuanyuD 等价
     *
     * 文本命令一律返回内核的原样回复串，不做二次解析：
     * 解析规则一旦和内核不同步就会给出错误结论，
     * 把原文交给调用方，由调用方按当前版本解读，最稳。
     * ================================================================== */

    /* ---------------- 版本与运行时状态 ---------------- */

    struct hy_ver_info
    {
        uint32_t magic;
        uint32_t major;
        uint32_t minor;
        uint32_t caps;
    };

    /*
     * 从内核读版本，同时校验 magic。
     * 比读 /proc/huanyu 可靠：那条路要 procfs 建起来才有，
     * 而这条只要模块加载成功就能拿到。
     */
    bool version(hy_ver_info &out) const
    {
        uint32_t v[4] = {0, 0, 0, 0};
        if (!ready_) return false;
        if (call(HY_NR_VERSION, v, sizeof(v)) != 0) return false;
        out.magic = v[0];
        out.major = v[1];
        out.minor = v[2];
        out.caps  = v[3];
        return out.magic == HY_MAGIC;
    }

    /* 内核当前实际生效的断点方案（AUTO 会被解析成具体方案后返回） */
    uint32_t bp_mode_runtime() const
    {
        uint32_t m = 0;
        if (!ready_) return HY_BP_MODE_AUTO;
        if (call(HY_NR_BP_GET_MODE, &m, sizeof(m)) != 0) return HY_BP_MODE_AUTO;
        return m;
    }

    /* ---------------- syscall 监控（49/50/51）---------------- */

    bool sysmon_set(pid_t pid, bool on = true) const
    {
        hy_sysmon_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.enable = on ? 1u : 0u;
        return call_obj(HY_NR_SYSMON_SET, r) == 0;
    }

    bool sysmon_remove(pid_t pid) const
    {
        hy_sysmon_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.enable = 0;
        return call_obj(HY_NR_SYSMON_REMOVE, r) == 0;
    }

    std::vector<hy_sysmon_entry> sysmon_read(size_t max = 64,
                                             bool clear = true,
                                             uint64_t *total = nullptr) const
    {
        std::vector<hy_sysmon_entry> v(max ? max : 1);
        hy_sysmon_read r{};
        if (!ready_) return {};
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        r.max_count = (uint32_t)v.size();
        r.clear = clear ? 1u : 0u;
        if (call_obj(HY_NR_SYSMON_READ, r) != 0) return {};
        v.resize((size_t)r.nr_read);
        if (total) *total = r.total;
        return v;
    }

    /* ---------------- CNTVCT 读取监控（52/53/54）---------------- */

    bool cntvct_set(pid_t pid, bool on = true) const
    {
        hy_cntvct_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.enable = on ? 1u : 0u;
        return call_obj(HY_NR_CNTVCT_SET, r) == 0;
    }

    bool cntvct_remove(pid_t pid) const
    {
        hy_cntvct_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.enable = 0;
        return call_obj(HY_NR_CNTVCT_REMOVE, r) == 0;
    }

    struct hy_cntvct_stat
    {
        uint64_t count;
        uint64_t last_pc;
    };

    hy_cntvct_stat cntvct_read(bool clear = true) const
    {
        hy_cntvct_read r{};
        hy_cntvct_stat s{};
        if (!ready_) return s;
        r.clear = clear ? 1u : 0u;
        if (call_obj(HY_NR_CNTVCT_READ, r) != 0) return s;
        s.count = r.count;
        s.last_pc = r.last_pc;
        return s;
    }

    /* ---------------- 虚拟定位 ---------------- */

    /* 初始化 GNSS hook（只需一次；之后用 gnss_start/gnss_set 改坐标） */
    bool gnss_init() const
    {
        if (!ready_) return false;
        return call_empty(HY_NR_GNSS_INIT) == 0;
    }

    /* ---------------- 增强枚举（58/59）---------------- */

    std::vector<hy_seg_info> enum_segments(pid_t pid, uint64_t module_base = 0,
                                           size_t max = 256) const
    {
        std::vector<hy_seg_info> v(max ? max : 1);
        hy_enum_segs_req r{};
        if (!ready_) return {};
        r.pid = pid;
        r.module_base = module_base;   /* 0 = 全部 */
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        r.max_count = (uint32_t)v.size();
        if (call_obj(HY_NR_ENUM_SEGMENTS, r) != 0) return {};
        v.resize((size_t)r.nr_written);
        return v;
    }

    /* 只列 rw-p 且排除特殊区 —— 扫描内存时用它当候选范围最省事 */
    std::vector<hy_region_info> enum_regions(pid_t pid, size_t max = 256) const
    {
        std::vector<hy_region_info> v(max ? max : 1);
        hy_enum_regions_req r{};
        if (!ready_) return {};
        r.pid = pid;
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        r.max_count = (uint32_t)v.size();
        if (call_obj(HY_NR_ENUM_REGIONS, r) != 0) return {};
        v.resize((size_t)r.nr_written);
        return v;
    }

    /* ---------------- 单步断点 / DPT 主线程影子页 ---------------- */

    bool stepbp_set(pid_t pid, uint64_t addr) const
    {
        hy_stepbp_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.addr = addr;
        r.enable = 1;
        return call_obj(HY_NR_STEPBP_SET, r) == 0;
    }

    bool stepbp_remove(pid_t pid, uint64_t addr) const
    {
        hy_stepbp_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.addr = addr;
        r.enable = 0;
        return call_obj(HY_NR_STEPBP_REMOVE, r) == 0;
    }

    bool dpt_set(pid_t pid, uint64_t addr) const
    {
        hy_dpt_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.addr = addr;
        r.enable = 1;
        return call_obj(HY_NR_DPT_SET, r) == 0;
    }

    bool dpt_remove(pid_t pid, uint64_t addr) const
    {
        hy_dpt_req r{};
        if (!ready_) return false;
        r.pid = pid;
        r.addr = addr;
        r.enable = 0;
        return call_obj(HY_NR_DPT_REMOVE, r) == 0;
    }

    /* ---------------- 扩展硬件能力 / ghost ---------------- */

    bool hwcap2(hy_hwcap2 &out) const
    {
        if (!ready_) return false;
        std::memset(&out, 0, sizeof(out));
        return call_obj(HY_NR_HWCAP2, out) == 0;
    }

    /*
     * ghost region 需要 struct page + 页重定位，KPM 拿不到，
     * 内核恒返回 0。留这个方法是为了让调用方能显式判断，
     * 而不是猜"为什么没有结果"。
     */
    bool ghost_available() const
    {
        uint32_t v = 0;
        if (!ready_) return false;
        if (call(HY_NR_GHOST_STATUS, &v, sizeof(v)) != 0) return false;
        return v != 0;
    }

    /* ---------------- GPU 隐藏 / GUP 读取隐藏 ---------------- */

    bool kgsl_hide(bool on = true) const
    {
        if (!ready_) return false;
        if (!on) return call_empty(HY_NR_KGSL_HIDE_CLEAR) == 0;
        hy_kgsl_req r{};
        r.enable = 1;
        return call_obj(HY_NR_KGSL_HIDE_SET, r) == 0;
    }

    /*
     * GUP 读取隐藏开关。读不出来（符号缺失）时内核返回 -ENOTSUPP，
     * 这里如实转成 false，不伪装成功。
     */
    bool hide_gup(bool on) const
    {
        uint32_t v = on ? 1u : 0u;
        if (!ready_) return false;
        return call(HY_NR_HIDE_GUP_SET, &v, sizeof(v)) == 0;
    }

    /* ---------------- 进程环境参数 ---------------- */

    bool env_params(pid_t pid, pid_t tid, hy_env_params &out) const
    {
        if (!ready_) return false;
        std::memset(&out, 0, sizeof(out));
        out.pid = pid;
        out.tid = tid;
        return call_obj(HY_NR_ENV_PARAMS, out) == 0;
    }

    /* ---------------- 共享内存通道（47/48）---------------- */

    /*
     * 注册成功后，命令 payload 里指向共享区内部的指针可以直接被内核
     * memcpy，不再 copy_to_user —— 批量读写时省掉一次拷贝。
     * 注册是一次性动作，失败不影响其他功能（自动走普通通道）。
     */
    bool shm_register(uint64_t va, uint64_t size, pid_t pid = 0) const
    {
        hy_shm_register r{};
        if (!ready_) return false;
        r.va = va;
        r.size = size;
        r.pid = (uint32_t)(pid > 0 ? pid : ::getpid());
        return call_obj(HY_NR_SHM_REGISTER, r) == 0;
    }

    bool shm_status(hy_shm_status &out) const
    {
        if (!ready_) return false;
        std::memset(&out, 0, sizeof(out));
        if (call_obj(HY_NR_SHM_STATUS, out) != 0) return false;
        return out.ready != 0;
    }

    /* ==================================================================
     * 文本命令（与 echo '<cmd>' > /proc/HuanyuD 完全等价）
     * 返回内核原样回复；空串表示命令没被接受。
     * ================================================================== */

    /* ---- 触摸探测与锁定（v1.55~v1.59）----
     * 顺序：probe on -> 手指划屏 -> touchstat -> 必要时 tslock <idx>
     *      -> tdown/tmove/tup 注入
     * 不创建设备、不改能力位，系统看到的就是正常多点触摸。
     */
    std::string probe(bool on)         const { return do_cmd_str(on ? "probe on" : "probe off"); }
    std::string tscan(bool on)         const { return do_cmd_str(on ? "tscan on" : "tscan off"); }
    std::string touch_switch(bool on)  const { return do_cmd_str(on ? "touch on" : "touch off"); }
    std::string touchstat()            const { return do_cmd_str("touchstat"); }
    std::string tcap()                 const { return do_cmd_str("tcap"); }
    std::string tslock(int idx)        const { return do_cmd_str("tslock " + std::to_string(idx)); }
    std::string tsname(const char *n)  const { return n ? do_cmd_str(std::string("tsname ") + n)
                                                        : std::string(); }
    std::string grab_switch(bool on)   const { return do_cmd_str(on ? "grab on" : "grab off"); }
    std::string grab_stat()            const { return do_cmd_str("grab stat"); }
    std::string slotbase(int n)        const { return do_cmd_str("slotbase " + std::to_string(n)); }

    /* ---- 触摸注入（v1.58）---- */
    std::string ti_down(int x, int y)  const { return do_cmd_str("tdown " + std::to_string(x) + " " + std::to_string(y)); }
    std::string ti_move(int x, int y)  const { return do_cmd_str("tmove " + std::to_string(x) + " " + std::to_string(y)); }
    std::string ti_up()                const { return do_cmd_str("tup"); }
    /* v1.76.0 多指：带 id 的版本；不带 id 的 tup 表示抬全部 */
    std::string ti_down_id(int id, int x, int y) const {
        return do_cmd_str("tdown " + std::to_string(id) + " " +
                          std::to_string(x) + " " + std::to_string(y)); }
    std::string ti_move_id(int id, int x, int y) const {
        return do_cmd_str("tmove " + std::to_string(id) + " " +
                          std::to_string(x) + " " + std::to_string(y)); }
    std::string ti_up_id(int id) const { return do_cmd_str("tup " + std::to_string(id)); }
    std::string ti_up_all()      const { return do_cmd_str("tup"); }
    std::string ti_fingers()     const { return do_cmd_str("tfinger"); }
    std::string ti_stat()              const { return do_cmd_str("tstat"); }
    std::string ti_slots(int n)        const { return do_cmd_str("tslots " + std::to_string(n)); }
    /* v1.73.1：坐标范围。不传参=读回当前值（含内核自学到的分辨率） */
    std::string ti_range()             const { return do_cmd_str("trange"); }
    std::string ti_range(int a, int b, int c, int d) const {
        return do_cmd_str("trange " + std::to_string(a) + " " + std::to_string(b)
                          + " " + std::to_string(c) + " " + std::to_string(d));
    }

    /* ---- 压力测试（v1.60）----
     * spec 形如 "60s all 1" / "5min cpu 8" / "1h mem 15"
     * 默认全面关闭，只有下命令才跑；到点自动停。
     */
    std::string stress(const std::string &spec) const { return do_cmd_str("stress " + spec); }
    std::string stress_off()  const { return do_cmd_str("stress off"); }
    std::string stress_stat() const { return do_cmd_str("stress stat"); }

    /* ---- 防格机（v1.51）---- */
    std::string guard(bool on)   const { return do_cmd_str(on ? "guard on" : "guard off"); }
    std::string guard_status()   const { return do_cmd_str("guard status"); }
    std::string unlock(int seconds = 300) const { return do_cmd_str("unlock " + std::to_string(seconds)); }
    std::string lock()           const { return do_cmd_str("lock"); }

    /* ---- 读取后端 / 缓存 / 断点状态 ---- */
    std::string rwmode(int m)    const { return do_cmd_str("rwmode " + std::to_string(m)); }
    std::string rwmode_stat()    const { return do_cmd_str("rwmode stat"); }
    /* 内核无 memcache 文本命令分支，改走 nr 90（见 mem_cache_runtime） */
    std::string memcache_stat()  const { return std::to_string(mem_cache_runtime()); }

    /* ---- 方案选择器文本通道（v1.64.0）----
     * 与 set_scheme()/get_scheme()（nr 91/92）等价，只是走文本，
     * 方便在终端直接对照 echo 'scheme' > /proc/HuanyuD 的结果。
     */
    /*
     * 注意：内核的 scheme 文本子命令收的是**域名字符串**，不是数字。
     * 域号 0..6 对应 physvirt|pgtable|memread|kernrw|bp|input|sym，
     * 传数字会被判 "bad dom"。这里做一次转换。
     */
    static const char *scheme_dom_name(uint32_t dom)
    {
        static const char *const nm[] = {
            "physvirt", "pgtable", "memread", "kernrw", "bp", "input", "sym"
        };
        return (dom < 7) ? nm[dom] : "physvirt";
    }
    std::string scheme_list() const { return do_cmd_str("scheme"); }
    std::string scheme_demote(uint32_t dom) const
    { return do_cmd_str(std::string("scheme demote ") + scheme_dom_name(dom)); }
    std::string scheme_force(uint32_t dom, uint32_t gen) const
    { return do_cmd_str(std::string("scheme force ") + scheme_dom_name(dom)
                        + " " + std::to_string(gen)); }
    std::string bpstat()         const { return do_cmd_str("bpstat"); }
    std::string devinfo_show()   const { return do_cmd_str("devinfo show"); }
    std::string devinfo_reset()  const { return do_cmd_str("devinfo reset"); }
    std::string devinfo_add(const std::string &kv) const { return do_cmd_str("devinfo add " + kv); }

    /* ---------------- /proc/huanyu ---------------- */

    /*
     * 内核侧用 proc_create_single_data() 真正注册的文件。
     * 不是路径劫持：ls /proc/Huanyu 能看到、stat 能成功、cat 读到日志页。
     * 完全由内核 procfs 子系统维护。
     *
     * 【大小写】内核注册的是 /proc/Huanyu（H 大写），调试页是
     * /proc/HuanyuD。Linux 严格区分大小写，写成小写一律 open 失败。
     */
    static std::string proc_path() { return "/proc/Huanyu"; }

    /* 调试页路径（可写，echo '<cmd>' > /proc/HuanyuD） */
    static std::string dbg_path() { return "/proc/HuanyuD"; }

    static bool proc_exists()
    {
        struct stat st;
        if (::stat("/proc/Huanyu", &st) == 0) return true;
        return ::stat("/proc/huanyu", &st) == 0;   /* 兼容旧版小写 */
    }

    static std::string proc_read()
    {
        int fd = ::open("/proc/Huanyu", O_RDONLY);
        if (fd < 0) fd = ::open("/proc/huanyu", O_RDONLY);  /* 兼容旧版 */
        if (fd < 0) return std::string();
        std::string out;
        char buf[256];
        ssize_t n;
        while ((n = ::read(fd, buf, sizeof(buf) - 1)) > 0) {
            buf[n] = '\0';
            out += buf;
        }
        ::close(fd);
        return out;
    }

    /* 一次性自检：确认文件真的存在且内容正确 */
    static bool proc_selfcheck(std::string *out = nullptr)
    {
        std::string s = proc_read();
        if (out) *out = s;
        return proc_exists() && !s.empty();
    }
};

/* ==========================================================================
 * 网络下载（用户态实现，v1.60.0）
 *
 * 【为什么在这里而不是内核】
 *   内核里做 HTTP 要解析 sock_create_kern / kernel_connect / kernel_recvmsg
 *   一整套未导出符号，还要猜 struct socket / msghdr / iov_iter 的布局 ——
 *   历史上正是这样反复炸内核。用户态做，崩了只死自己这个进程。
 *
 * 【能力边界】
 *   支持 http:// 明文。
 *   不支持 https:// —— TLS 需要 OpenSSL/mbedTLS，本文件不引入外部依赖；
 *   遇到 https 直接返回 -2，调用方自行用 curl 或链接 TLS 库。
 * ========================================================================== */

struct hy_http_result {
    int         status_code;   /* HTTP 状态码，0 表示没拿到 */
    int         err;           /* 0 成功；-1 参数/解析错；-2 不支持(https)；
                                  -3 DNS 失败；-4 连接失败；-5 收发失败；
                                  -6 写文件失败 */
    size_t      body_bytes;
    std::string error;
};

/*
 * url   形如 http://host[:port]/path ，必须 http
 * path  非空则把响应体写入该文件；为空则只取回头部与长度
 */
inline hy_http_result hy_http_download(const std::string &url,
                                       const std::string &out_path,
                                       int timeout_ms = 10000)
{
    hy_http_result r{};
    r.err = -1;

    if (url.size() < 8 || url.compare(0, 7, "http://") != 0) {
        if (url.compare(0, 8, "https://") == 0) {
            r.err = -2;
            r.error = "https not supported here (needs TLS library)";
        } else {
            r.error = "only http:// is supported";
        }
        return r;
    }

    /* --- 解析 host[:port] 与 path --- */
    std::string rest = url.substr(7);
    size_t slash = rest.find('/');
    std::string hostport = (slash == std::string::npos) ? rest : rest.substr(0, slash);
    std::string path     = (slash == std::string::npos) ? std::string("/")
                                                        : rest.substr(slash);
    std::string host = hostport;
    int port = 80;
    size_t colon = hostport.rfind(':');
    if (colon != std::string::npos) {
        host = hostport.substr(0, colon);
        port = ::atoi(hostport.substr(colon + 1).c_str());
        if (port <= 0 || port > 65535) { r.error = "bad port"; return r; }
    }
    if (host.empty()) { r.error = "empty host"; return r; }

    /* --- DNS --- */
    struct addrinfo hints, *res = nullptr;
    std::memset(&hints, 0, sizeof(hints));
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (::getaddrinfo(host.c_str(), std::to_string(port).c_str(),
                      &hints, &res) != 0 || !res) {
        r.err = -3; r.error = "getaddrinfo failed"; return r;
    }

    /* --- 连接 --- */
    int fd = ::socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) { ::freeaddrinfo(res); r.err = -4; r.error = "socket failed"; return r; }

    {
        struct timeval tv;
        tv.tv_sec  = timeout_ms / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;
        ::setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        ::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    }

    if (::connect(fd, res->ai_addr, res->ai_addrlen) != 0) {
        ::close(fd); ::freeaddrinfo(res);
        r.err = -4; r.error = "connect failed"; return r;
    }
    ::freeaddrinfo(res);

    /* --- 发请求 --- */
    std::string req = "GET " + path + " HTTP/1.1\r\nHost: " + hostport +
                      "\r\nConnection: close\r\nUser-Agent: Huanyu/1.66\r\n\r\n";
    if (::send(fd, req.c_str(), req.size(), 0) != (ssize_t)req.size()) {
        ::close(fd); r.err = -5; r.error = "send failed"; return r;
    }

    /* --- 收响应，边收边找头部结束 --- */
    std::string raw;
    char buf[4096];
    size_t header_end = std::string::npos;
    int out_fd = -1;

    if (!out_path.empty()) {
        out_fd = ::open(out_path.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (out_fd < 0) {
            ::close(fd); r.err = -6; r.error = "cannot open output file"; return r;
        }
    }

    for (;;) {
        ssize_t n = ::recv(fd, buf, sizeof(buf), 0);
        if (n < 0) { if (errno == EINTR) continue; break; }
        if (n == 0) break;

        if (header_end == std::string::npos) {
            raw.append(buf, (size_t)n);
            header_end = raw.find("\r\n\r\n");
            if (header_end != std::string::npos) {
                /* 解析状态码：HTTP/1.1 200 xxx */
                size_t sp1 = raw.find(' ');
                if (sp1 != std::string::npos) {
                    size_t sp2 = raw.find(' ', sp1 + 1);
                    if (sp2 != std::string::npos)
                        r.status_code = ::atoi(raw.substr(sp1 + 1, sp2 - sp1 - 1).c_str());
                }
                /* 头部之后的正文部分先落盘 */
                size_t body_off = header_end + 4;
                size_t chunk = raw.size() - body_off;
                r.body_bytes += chunk;
                if (out_fd >= 0) {
                    if (::write(out_fd, raw.data() + body_off, chunk) != (ssize_t)chunk) {
                        ::close(out_fd); ::close(fd);
                        r.err = -6; r.error = "write failed"; return r;
                    }
                }
                raw.clear();
            } else if (raw.size() > 65536) {
                break;   /* 头部异常大，放弃 */
            }
        } else {
            r.body_bytes += (size_t)n;
            if (out_fd >= 0) {
                if (::write(out_fd, buf, (size_t)n) != (ssize_t)n) {
                    ::close(out_fd); ::close(fd);
                    r.err = -6; r.error = "write failed"; return r;
                }
            }
        }
    }

    if (out_fd >= 0) ::close(out_fd);
    ::close(fd);

    if (r.status_code == 0) { r.err = -5; r.error = "no valid response"; return r; }
    r.err = 0;
    return r;
}

/*
 * 只取回内容、不落盘的便捷版。
 * 需要 HTTP 以外的协议或 https，请自行接 curl / TLS 库。
 */
inline std::string hy_http_get(const std::string &url, int timeout_ms = 10000)
{
    hy_http_result r = hy_http_download(url, std::string(), timeout_ms);
    if (r.err != 0) return std::string();
    /* 不落盘时无法取正文（已边收边丢），仅用状态码表达成功与否 */
    return (r.status_code == 200) ? std::string("OK") : std::to_string(r.status_code);
}

