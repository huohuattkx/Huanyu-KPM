/* 性能优先编译示例 */
#include "huanyu_wanbai.hpp"

int main() {
    if (!driver->is_ready()) return 1;
    driver->init_pid(1234);
    uintptr_t base = driver->getModuleBase("libil2cpp.so");
    /* 连续读一次往返 */
    uint64_t v[8];
    driver->read_contiguous(base + 0x100, v, sizeof(v));
    return 0;
}
