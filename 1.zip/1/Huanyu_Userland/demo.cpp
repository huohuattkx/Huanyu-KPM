/*
 * 欢愉 (Huanyu) —— 完整使用示例
 *
 * 编译（Android arm64）：
 *   aarch64-linux-android31-clang++ -std=c++17 demo.cpp -o demo
 *
 * 前置：APatch 中已加载 huanyu.kpm
 */
#include "huanyu.hpp"
#include <thread>
#include <chrono>

static const char *PKG      = "com.example.game";

static void show_caps(const hy_driver &d)
{
    hy_bp_caps cap{};
    d.bp_caps(&cap);
    printf("[能力] 断点 SW=%d PTE=%d HW=%d (brps=%d wrps=%d)\n",
           !!(cap.supported & HY_BP_CAP_SW),
           !!(cap.supported & HY_BP_CAP_PTE),
           !!(cap.supported & HY_BP_CAP_HW),
           cap.num_brps, cap.num_wrps);

    hy_hwcap hw{};
    if (d.hwcap(hw))
        printf("[CPU ] PAC=%d BTI=%d LSE=%d MTE=%d FP=%d\n",
               hw.pac, hw.bti, hw.lse, hw.mte, hw.fp);

    hy_stats st{};
    if (d.stats(st))
        printf("[统计] 缓存命中=%llu 未命中=%llu 活跃断点=%llu 总命中=%llu 符号缺失=%llu\n",
               (unsigned long long)st.cache_hits,
               (unsigned long long)st.cache_miss,
               (unsigned long long)st.bp_active,
               (unsigned long long)st.hit_total,
               (unsigned long long)st.sym_failures);
}

static void show_proc()
{
    /*
     * /proc/huanyu —— 内核用 proc_create_single_data 真正注册的文件。
     * 用 stat 验证它真的存在（路径劫持的方案过不了这一关）。
     */
    struct stat st;
    bool exists = (::stat("/proc/huanyu", &st) == 0);

    printf("[proc] stat /proc/huanyu : %s", exists ? "存在" : "不存在");
    if (exists)
        printf(" (mode=%o size=%lld)", st.st_mode & 07777, (long long)st.st_size);
    printf("\n");

    std::string s = hy_driver::proc_read();
    printf("[proc] cat  /proc/huanyu : \"%s\"\n", s.c_str());

    if (exists && !s.empty())
        printf("[proc] 自检通过：文件真实存在且可读\n");
    else
        printf("[proc] 自检失败：模块未加载，或 proc_create 未成功\n");
}

static void show_enum(const hy_driver &d, pid_t pid)
{
    auto procs = d.enum_processes(32);
    printf("[进程] 共 %zu 个，前 5: ", procs.size());
    for (size_t i = 0; i < procs.size() && i < 5; i++)
        printf("%d(%s) ", procs[i].pid, procs[i].comm);
    printf("\n");

    auto mods = d.enum_modules(pid, 64);
    printf("[内存区] %zu 段，前 5:\n", mods.size());
    for (size_t i = 0; i < mods.size() && i < 5; i++)
        printf("   %llx-%llx exec=%d write=%d\n",
               (unsigned long long)mods[i].start,
               (unsigned long long)mods[i].end,
               mods[i].exec, mods[i].write);
}

static void demo_breakpoints(const hy_driver &d, pid_t pid, uint64_t addr)
{
    /* ---- 三种方案各装一个 ---- */
    uint64_t h_sw  = d.bp_inst_sw (pid, addr);
    uint64_t h_pte = d.bp_inst_pte(pid, addr + 4);
    uint64_t h_hw  = d.bp_inst_hw (pid, addr + 8);
    uint64_t h_w   = d.watch_write(pid, addr + 16);
    printf("[断点] SW=%llx PTE=%llx HW=%llx 写观察=%llx\n",
           (unsigned long long)h_sw, (unsigned long long)h_pte,
           (unsigned long long)h_hw, (unsigned long long)h_w);

    /* ---- 列出全部 ---- */
    auto list = d.bp_list(32);
    printf("[列表] %zu 个:\n", list.size());
    for (auto &it : list)
        printf("   handle=%llx pid=%d mode=%d addr=%llx hits=%llu active=%d\n",
               (unsigned long long)it.handle, it.pid, it.mode,
               (unsigned long long)it.addr,
               (unsigned long long)it.hit_count, it.active);

    /* ---- 等命中并读寄存器 ---- */
    hy_bp_hit_item hit{};
    if (d.bp_wait_hit(h_sw, hit, 3000)) {
        printf("[命中] PC=%llx X0=%llx SP=%llx\n",
               (unsigned long long)hy_driver::get_pc(hit),
               (unsigned long long)hy_driver::get_xregs(hit, 0),
               (unsigned long long)hy_driver::get_sp(hit));

        /* 改 X0 与 PC */
        d.bp_set_reg(h_sw, 0, 0x1);
        d.bp_set_pc(h_sw, hy_driver::get_pc(hit) + 4);

        /* 批量改 */
        hy_reg_batch b;
        b.x(1, 0x1234).x(2, 0x5678).pc(hy_driver::get_pc(hit));
        d.bp_apply(h_sw, b);

        /* 浮点 */
        d.bp_set_vreg_float(h_sw, 0, 3.14f);
    } else {
        printf("[命中] 3 秒内未命中（正常，取决于目标是否执行到该地址）\n");
    }

    /* ---- 卸载：务必成对，避免模块退出时残留 ---- */
    d.bp_uninst(h_sw);
    d.bp_uninst(h_pte);
    d.bp_uninst(h_hw);
    d.bp_uninst(h_w);
    printf("[清理] 全部断点已卸载\n");
}

int main()
{
    /* 不需要超级密钥 */
    hy_driver drv;

    if (!drv.kernelpatch_ready()) {
        printf("KernelPatch 未安装（或未以 su/管理器身份运行）\n");
        return 1;
    }
    printf("KernelPatch 就绪\n");

    if (!drv.is_authed()) {
        printf("鉴权未通过。若设备设置了自定义超级密钥，请改用：\n");
        printf("    hy_driver drv(\"你的超级密钥\");\n");
        return 1;
    }
    printf("鉴权通过（免密钥）\n");

    if (!drv.is_ready()) {
        printf("欢愉模块未加载\n");
        return 1;
    }
    printf("驱动对接成功\n");

    show_caps(drv);
    show_proc();

    pid_t pid = drv.get_name_pid(PKG);
    if (pid <= 0) {
        printf("未找到进程 %s\n", PKG);
        return 1;
    }
    printf("目标 PID = %d\n", pid);
    drv.initialize(pid);

    show_enum(drv, pid);

    /* 内存读写 */
    uint64_t base = drv.get_module_base("libil2cpp.so");
    printf("[模块] libil2cpp.so base = %llx\n", (unsigned long long)base);
    if (base) {
        uint32_t v = drv.read<uint32_t>(base + 0x1000);
        printf("[读取] base+0x1000 = %08x\n", v);
        drv.write<uint32_t>(base + 0x1000, 0xDEADBEEF);
        printf("[写入] 已写入 0xDEADBEEF\n");
    }

    /* TLS / PACGA */
    uint64_t tls = 0;
    if (drv.get_thread_tls(pid, pid, &tls))
        printf("[TLS ] %llx\n", (unsigned long long)tls);

    uint64_t pac = 0;
    if (drv.exec_pacga(pid, 0x1122334455667788ULL, 0x0, &pac))
        printf("[PACGA] %llx\n", (unsigned long long)pac);

    demo_breakpoints(drv, pid, base ? base + 0x2000 : 0x70001000);

    return 0;
}
