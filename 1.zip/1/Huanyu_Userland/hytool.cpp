/*
 * hytool —— 欢愉虚拟手指无交互测试器（纯命令行，无 UI）
 *
 * 定位：驱动层正确性验证工具。不内置任何游戏逻辑、目标选择、
 *       路径规划或定时策略 —— 那些由调用方决定。
 *
 * 编译：
 *   aarch64-linux-android31-clang++ -std=c++17 -O2 hytool.cpp -o hytool -lm -lpthread
 *   （Termux：clang++ -std=c++17 -O2 hytool.cpp -o hytool -lm -lpthread）
 *   需与 huanyu_wanbai.hpp 同目录。
 *
 * ── 命令 ────────────────────────────────────────────────
 *   hytool info
 *        链路/版本/槽位容量/坐标范围/注入闸门/统计
 *
 *   hytool setup
 *        下发面板坐标范围与槽位数（按实测值：20351x44351 / 10）
 *
 *   hytool click <x> <y> [hold_ms]
 *        单点按下-停留-抬起
 *
 *   hytool slide <x0> <y0> <x1> <y1> [ms] [hz]
 *        匀速直线滑动（一次 down，全程 move，结束才 up）
 *
 *   hytool circle [n] [sec] [hz]
 *        n 根手指同时画圈。n=3 时圆心在屏幕 25%/50%/75% 高度，
 *        起始相位各错开 120° —— 三根若黏在一起动，说明槽位串了。
 *
 *   hytool jitter [sec] [hz]
 *        只统计不下发：测实际帧间隔抖动，回答"是不是抽搐"。
 *
 *   hytool up       抬起全部（含强制清除）
 *   hytool stat     注入状态
 *
 * ── 全局参数 ────────────────────────────────────────────
 *   --px        坐标按【屏幕像素】解释，自动乘倍率转面板坐标
 *   --panel W H 手动指定面板尺寸（默认 20351 44351）
 *   --scr  W H  屏幕像素（默认 1080 2354，配合 --px 算倍率）
 *
 * ── 不断触的三条 ────────────────────────────────────────
 *   1) 一次 down 对应全程 move，中途绝不抬手
 *      （TRACKING_ID 按下时分配一次即长期有效）
 *   2) 绝对时间累加 clock_nanosleep(TIMER_ABSTIME)，
 *      不用 usleep —— 后者每帧误差累积，几百帧后采样就歪
 *   3) 匀速小步长，每帧只走一点点
 */
#include "huanyu_wanbai.hpp"

#include <cmath>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <pthread.h>
#include <unistd.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* 实测值：getevent -lp /dev/input/event7 */
static int g_panel_w = 20351;
static int g_panel_h = 44351;
static int g_scr_w   = 1080;
static int g_scr_h   = 2354;
static int g_use_px  = 0;      /* 1 = 入参是屏幕像素 */

static volatile sig_atomic_t g_run = 1;
static void on_stop(int) { g_run = 0; }

/* ── 看门狗：主线程卡住时的最后兜底 ───────────────────── */
static c_driver   *g_drv      = nullptr;
static int         g_wd_limit = 0;      /* 秒，0=不启用 */
static time_t      g_t0       = 0;

static void *wd_thread(void *)
{
    if (!g_wd_limit) return nullptr;
    while (g_run) {
        sleep(1);
        if (!g_run) break;
        if ((int)(time(nullptr) - g_t0) > g_wd_limit) {
            fprintf(stderr, "\n[看门狗] 超时，强制抬手退出\n");
            if (g_drv) { g_drv->ti_up_all(); g_drv->ti_clear(); }
            _exit(2);
        }
    }
    return nullptr;
}

static void start_watchdog(int sec)
{
    g_wd_limit = sec;
    g_t0       = time(nullptr);
    pthread_t t;
    pthread_create(&t, nullptr, wd_thread, nullptr);
    pthread_detach(t);
}

/* ── 坐标换算 ─────────────────────────────────────────── */
static int to_panel_x(int v)
{
    if (!g_use_px) return v;
    return (int)((double)v * g_panel_w / g_scr_w);
}
static int to_panel_y(int v)
{
    if (!g_use_px) return v;
    return (int)((double)v * g_panel_h / g_scr_h);
}

/* ── 绝对时间节拍器：不累积误差 ───────────────────────── */
struct pacer {
    struct timespec next;
    long            period_ns;

    void start(long hz)
    {
        period_ns = 1000000000L / (hz > 0 ? hz : 120);
        clock_gettime(CLOCK_MONOTONIC, &next);
    }
    void wait()
    {
        next.tv_nsec += period_ns;
        while (next.tv_nsec >= 1000000000L) {
            next.tv_nsec -= 1000000000L;
            next.tv_sec  += 1;
        }
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, nullptr);
    }
};

/* ── 收尾：连抬两次，防最后一帧被竞态吃掉 ─────────────── */
static void cleanup()
{
    if (!g_drv) return;
    g_drv->ti_up_all();
    usleep(100000);
    g_drv->ti_up_all();
    g_drv->ti_clear();
}

/* ================= 子命令 ================= */

static int cmd_info(c_driver &d, int argc, char **argv)
{
    (void)argc; (void)argv;
    int cap = 0, act = 0, tot = 0;
    d.ti_capacity(&cap, &act, &tot);

    int mnx = 0, mxx = 0, mny = 0, mxy = 0;
    d.ti_get_range(&mnx, &mxx, &mny, &mxy);

    hy_ti_stat st{};
    d.ti_status(&st);

    printf("链路      : %s\n", d.handshake_ok() ? "OK" : "失败");
    printf("握手返回值: 0x%x  %s\n", d.handshake_result(), d.handshake_text());
    printf("槽位容量  : cap=%d active=%d total=%d\n", cap, act, tot);
    printf("坐标范围  : %d..%d x %d..%d\n", mnx, mxx, mny, mxy);
    printf("注入闸门  : %s\n", d.ti_inject_gate_query() ? "开" : "关");
    printf("注入状态  : state=%d slot=%d/%d d=%d m=%d u=%d busy=%d conf=%d protect=%d\n",
           st.state, st.inj_slot, st.max_slots,
           st.downs, st.moves, st.ups, st.busy, st.conflicts, st.protects);
    printf("\nprotect>0 说明\"注入后被物理驱动抹除\"的防护在生效。\n");
    if (cap > tot)
        printf("[警告] cap(%d) > total(%d)，槽位口径不一致\n", cap, tot);
    return 0;
}

static int cmd_setup(c_driver &d, int argc, char **argv)
{
    (void)argc; (void)argv;
    printf("下发 range 0 %d 0 %d ...\n", g_panel_w, g_panel_h);
    if (!d.ti_set_range(0, g_panel_w, 0, g_panel_h)) {
        printf("  失败\n"); return 1;
    }
    printf("下发 slots 10 ...\n");
    if (!d.ti_set_slots(10)) { printf("  失败\n"); return 1; }

    int mnx, mxx, mny, mxy;
    d.ti_get_range(&mnx, &mxx, &mny, &mxy);
    printf("回读: %d..%d x %d..%d\n", mnx, mxx, mny, mxy);
    if (mxx != g_panel_w || mxy != g_panel_h)
        printf("[警告] 回读与下发不一致，内核可能被自学习覆盖\n");
    return 0;
}

static int cmd_click(c_driver &d, int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "用法: click <x> <y> [hold_ms]\n"); return 1; }
    int x = to_panel_x(atoi(argv[0]));
    int y = to_panel_y(atoi(argv[1]));
    int hold = (argc > 2) ? atoi(argv[2]) : 80;

    printf("click (%d,%d) hold=%dms\n", x, y, hold);
    if (!d.ti_down_id(0, x, y)) { printf("  down 失败\n"); return 1; }
    usleep((useconds_t)hold * 1000);
    d.ti_up_id(0);
    cleanup();
    return 0;
}

static int cmd_slide(c_driver &d, int argc, char **argv)
{
    if (argc < 4) {
        fprintf(stderr, "用法: slide <x0> <y0> <x1> <y1> [ms] [hz]\n"); return 1;
    }
    int x0 = to_panel_x(atoi(argv[0])), y0 = to_panel_y(atoi(argv[1]));
    int x1 = to_panel_x(atoi(argv[2])), y1 = to_panel_y(atoi(argv[3]));
    int ms = (argc > 4) ? atoi(argv[4]) : 1000;
    int hz = (argc > 5) ? atoi(argv[5]) : 120;

    int frames = ms * hz / 1000;
    if (frames < 2) frames = 2;

    printf("slide (%d,%d)->(%d,%d) %dms @%dHz = %d帧\n", x0, y0, x1, y1, ms, hz, frames);

    start_watchdog(ms / 1000 + 8);
    pacer p; p.start(hz);

    if (!d.ti_down_id(0, x0, y0)) { printf("  down 失败\n"); return 1; }
    for (int i = 1; i <= frames && g_run; i++) {
        int x = x0 + (x1 - x0) * i / frames;
        int y = y0 + (y1 - y0) * i / frames;
        d.ti_move_id(0, x, y);
        p.wait();
    }
    cleanup();
    printf("完成\n");
    return 0;
}

/*
 * n 指画圈。
 * 每根手指一次 down，之后全部并发 move（同一帧内依次下发），
 * 结束才统一抬 —— 这就是"不断触"的标准形态。
 */
static int cmd_circle(c_driver &d, int argc, char **argv)
{
    int n   = (argc > 0) ? atoi(argv[0]) : 1;
    int sec = (argc > 1) ? atoi(argv[1]) : 20;
    int hz  = (argc > 2) ? atoi(argv[2]) : 120;

    if (n < 1) n = 1;
    if (n > 8) n = 8;
    if (sec < 1) sec = 1;

    int cap = 0, act = 0, tot = 0;
    d.ti_capacity(&cap, &act, &tot);
    if (n > cap) {
        printf("[警告] 请求 %d 根，当前容量仅 %d，降到 %d\n", n, cap, cap);
        n = cap;
        if (n < 1) return 1;
    }

    int R = (int)(g_panel_w * 0.18);          /* 半径：屏宽 18% */
    int frames = sec * hz;

    printf("circle: %d 指 / %d 秒 / %dHz / 半径 %d / 共 %d 帧\n",
           n, sec, hz, R, frames);

    start_watchdog(sec + 8);
    pacer p; p.start(hz);

    for (int i = 0; i < n; i++) {
        /* 圆心纵向分布：单指放正中；多指按 1/(n+1) 均分 */
        double frac = (n == 1) ? 0.5 : (double)(i + 1) / (n + 1);
        int cx = (int)(g_panel_w * 0.5);
        int cy = (int)(g_panel_h * frac);
        double ph = (double)i * 2.0 * M_PI / n;   /* 相位错开 */
        int x = cx + (int)(R * cos(ph));
        int y = cy + (int)(R * sin(ph));
        if (!d.ti_down_id(i, x, y)) {
            printf("  down id=%d 失败\n", i);
            cleanup();
            return 1;
        }
    }

    for (int f = 1; f <= frames && g_run; f++) {
        for (int i = 0; i < n; i++) {
            double frac = (n == 1) ? 0.5 : (double)(i + 1) / (n + 1);
            int cx = (int)(g_panel_w * 0.5);
            int cy = (int)(g_panel_h * frac);
            double sp = 1.0 + 0.15 * i;
            double a  = (double)i * 2.0 * M_PI / n
                      + sp * (double)f / hz * 2.0 * M_PI / 2.0;  /* 2秒一圈 */
            d.ti_move_id(i, cx + (int)(R * cos(a)), cy + (int)(R * sin(a)));
        }
        p.wait();
        if (f % (hz * 5) == 0) printf("  ...%d/%d 帧\n", f, frames);
    }

    cleanup();
    printf("完成，已抬手\n");
    return 0;
}

/* 只统计不下发：回答"喂得匀不匀" */
static int cmd_jitter(c_driver &d, int argc, char **argv)
{
    (void)d;
    int sec = (argc > 0) ? atoi(argv[0]) : 10;
    int hz  = (argc > 1) ? atoi(argv[1]) : 120;

    long period_ns = 1000000000L / (hz > 0 ? hz : 120);
    long frames    = (long)sec * (hz > 0 ? hz : 120);
    double target_ms = period_ns / 1e6;

    printf("jitter: %d 秒 @%dHz，目标帧间隔 %.3f ms（纯计时统计，不下发事件）\n",
           sec, hz, target_ms);

    struct timespec prev, cur;
    double mn = 1e9, mx = 0, sum = 0;
    long over1 = 0, over2 = 0;

    pacer p; p.start(hz);
    clock_gettime(CLOCK_MONOTONIC, &prev);

    for (long i = 1; i <= frames && g_run; i++) {
        p.wait();
        clock_gettime(CLOCK_MONOTONIC, &cur);
        double dt = (cur.tv_sec - prev.tv_sec) * 1000.0
                  + (cur.tv_nsec - prev.tv_nsec) / 1e6;
        prev = cur;
        if (dt < mn) mn = dt;
        if (dt > mx) mx = dt;
        sum += dt;
        if (dt > target_ms * 2) over1++;
        if (dt > target_ms * 4) over2++;
    }

    double avg = sum / (double)(frames > 0 ? frames : 1);
    printf("\n  最小 %.3f ms   平均 %.3f ms   最大 %.3f ms\n", mn, avg, mx);
    printf("  抖动峰峰 %.3f ms  (%.1f%% of 目标)\n", mx - mn, (mx - mn) / target_ms * 100);
    printf("  超 2 倍帧 %ld 次   超 4 倍帧 %ld 次\n", over1, over2);
    printf("\n  判定：抖动 < 30%% 基本顺滑；> 100%% 会明显抽搐，\n");
    printf("        多半是调用进程被调度挤掉，不是内核丢事件。\n");
    return 0;
}

static void usage(const char *me)
{
    printf(
    "hytool —— 欢愉虚拟手指无交互测试器\n\n"
    "用法: %s [全局参数] <命令> [参数]\n\n"
    "命令:\n"
    "  info                         链路/容量/范围/统计\n"
    "  setup                        下发面板范围与槽位数\n"
    "  click  <x> <y> [ms]          单点点击\n"
    "  slide  <x0> <y0> <x1> <y1> [ms] [hz]   匀速直线滑动\n"
    "  circle [n] [sec] [hz]        n 指同时画圈（默认 1/20s/120Hz）\n"
    "  jitter [sec] [hz]            仅统计帧间隔抖动\n"
    "  up                           抬起全部并清除\n"
    "  stat                         注入状态\n\n"
    "全局参数:\n"
    "  --px          坐标按屏幕像素解释（自动转面板坐标）\n"
    "  --panel W H   面板尺寸（默认 %d %d）\n"
    "  --scr   W H   屏幕像素（默认 %d %d，配合 --px）\n\n"
    "例:\n"
    "  %s info\n"
    "  %s setup\n"
    "  %s --px circle 1 20 120\n"
    "  %s --px circle 3 20 120\n"
    "  %s jitter 10 120\n",
    me, g_panel_w, g_panel_h, g_scr_w, g_scr_h, me, me, me, me, me);
}

int main(int argc, char **argv)
{
    signal(SIGINT,  on_stop);
    signal(SIGTERM, on_stop);

    /* 解析全局参数 */
    int i = 1;
    while (i < argc && argv[i][0] == '-') {
        if (!strcmp(argv[i], "--px"))    { g_use_px = 1; i++; }
        else if (!strcmp(argv[i], "--panel") && i + 2 < argc) {
            g_panel_w = atoi(argv[i+1]); g_panel_h = atoi(argv[i+2]); i += 3;
        }
        else if (!strcmp(argv[i], "--scr") && i + 2 < argc) {
            g_scr_w = atoi(argv[i+1]); g_scr_h = atoi(argv[i+2]); i += 3;
        }
        else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            usage(argv[0]); return 0;
        }
        else { fprintf(stderr, "未知参数 %s\n", argv[i]); usage(argv[0]); return 1; }
    }

    if (i >= argc) { usage(argv[0]); return 1; }

    const char *cmd = argv[i];
    char **ca = argv + i + 1;
    int    cn = argc - i - 1;

    /* up / stat 不需要画圆，但都要链路 */
    c_driver drv;
    g_drv = &drv;

    if (!drv.handshake_ok()) {
        fprintf(stderr, "[-] 握手失败：%s\n", drv.handshake_text());
        return 1;
    }

    if      (!strcmp(cmd, "info"))   return cmd_info(drv, cn, ca);
    else if (!strcmp(cmd, "setup"))  return cmd_setup(drv, cn, ca);
    else if (!strcmp(cmd, "click"))  return cmd_click(drv, cn, ca);
    else if (!strcmp(cmd, "slide"))  return cmd_slide(drv, cn, ca);
    else if (!strcmp(cmd, "circle")) return cmd_circle(drv, cn, ca);
    else if (!strcmp(cmd, "jitter")) { (void)cn; return cmd_jitter(drv, cn, ca); }
    else if (!strcmp(cmd, "up"))     { cleanup(); printf("已抬手并清除\n"); return 0; }
    else if (!strcmp(cmd, "stat"))   return cmd_info(drv, cn, ca);

    fprintf(stderr, "未知命令 %s\n", cmd);
    usage(argv[0]);
    return 1;
}
