/* ls 移植功能使用示例 */
#include "huanyu_wanbai.hpp"

int main() {
    if (!driver->is_ready()) { printf("未连接\n"); return 1; }

    int pid = driver->GetPid((char*)"com.example.game");
    driver->init_pid(pid);

    /* 综合状态：一眼看清哪些能用 */
    hy_ls_status st = driver->ls_status();
    printf("sysmon: active=%u hooked=%u total=%llu\n",
           st.sysmon_active, st.sysmon_hooked,
           (unsigned long long)st.sysmon_total);
    printf("cntvct: active=%u hooked=%u total=%llu\n",
           st.cntvct_active, st.cntvct_hooked,
           (unsigned long long)st.cntvct_total);
    printf("gnss  : active=%u hooked=%u patches=%llu\n",
           st.gnss_active, st.gnss_hooked,
           (unsigned long long)st.gnss_patches);
    printf("dpt   : active=%u hooked=%u\n", st.dpt_active, st.dpt_hooked);

    /* syscall 监控 */
    driver->sysmon_set(pid, true);
    auto recs = driver->sysmon_read(64);
    for (auto &r : recs) printf("  nr=%u arg0=%llx ret=%lld\n",
                                r.nr, (unsigned long long)r.arg0, (long long)r.ret);
    driver->sysmon_remove(pid);

    /* CNTVCT 监控 */
    driver->cntvct_set(pid, true);
    printf("cntvct reads=%llu\n", (unsigned long long)driver->cntvct_read(true));
    driver->cntvct_remove(pid);

    /* 虚拟定位：北京 */
    driver->gnss_set_deg(39.9042, 116.4074);

    /* 增强枚举 */
    auto segs = driver->enum_segments(pid);
    printf("segments=%zu\n", segs.size());
    auto regs = driver->enum_regions(pid);
    printf("regions =%zu\n", regs.size());

    /* 扩展能力 */
    auto c = driver->hwcap2();
    printf("MTE=%u SPE=%u BTI=%u PAC=%u LSE=%u brps=%u wrps=%u ghost=%u\n",
           c.mte, c.spe, c.bti, c.pac, c.lse, c.brps, c.wrps, c.ghost);

    /* 触摸移动 */
    driver->touch_move(0, 500, 800);
    return 0;
}
