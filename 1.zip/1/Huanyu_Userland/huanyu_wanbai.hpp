/* ==========================================================================
 * 欢愉版本号
 * 与内核侧 hy.h 的 HY_VERSION_STRING 保持一致。
 * /proc/Huanyu 与 HY_VERSION 命令读到的就是这个版本。
 *
 * 【v1.66.0 同步】之前停在 1.46.0，与内核侧差二十几个版本。
 * 注意 proc 路径是 /proc/Huanyu（H 大写），内核实际注册的也是这个。
 * ========================================================================== */
#define HY_VERSION_STRING "1.80.0"
#define HY_VER_MAJOR 1
#define HY_VER_MINOR 80
#define HY_VER_PATCH 0

/* ==========================================================================
 * 【★★★★ 五层对接密钥 —— 必须与内核 hy.h 的 HY_KEY_L1..L5 逐字节一致 ★★★★】
 * ==========================================================================
 *   v1.70.0 起从单把 256 位钥匙改成五层：
 *       第 1~4 层各 64 位，第 5 层 256 位（单密钥时代那把原始钥匙）。
 *
 *   每层都要同时含：大写字母 / 小写字母 / 数字 / 符号。每个版本全换。
 *   不一致时内核拒绝执行所有命令（版本查询与握手除外）。
 *
 *   握手时本文件会 **逐层** 提交，任何一层不吻合，内核就把五层全部作废，
 *   必须从头再送一遍 —— 少送、错送、只蒙对几层都不放行。
 *
 *   本文件会在编译期和运行时各校验一次格式，格式错会直接报错，
 *   免得拿着一把非法钥匙去握手、白跑一趟还查不出原因。
 * ========================================================================== */
#ifndef HY_KEY_LAYERS
#define HY_KEY_LAYERS 5
#endif
#ifndef HY_KEY_L1
#define HY_KEY_L1 "Huanyu"   /* 【固定】第一层不随机，恒为 Huanyu，勿改 */
#endif
#ifndef HY_KEY_L2
#define HY_KEY_L2 "j9BVo9EK.@7Wvz)kq7{]QEiiUcR=;KPV9C#W%x8n6*D,b_rgZMVf-vG)>^V:x$4;"
#endif
#ifndef HY_KEY_L3
#define HY_KEY_L3 "4;LjmfsGWmXkU<;X=$g!tmsHq{U+4a@vtG]43V}]TG[<{.JS4xN2MH9SYtgL7ebv"
#endif
#ifndef HY_KEY_L4
#define HY_KEY_L4 "gM?l+s$5AcQ+K$[6;trqZQ2n2<83fN4!qRXaoIFq?3_qTe)YQw+.i7FV=02YCq=R"
#endif
#ifndef HY_KEY_L5
#define HY_KEY_L5 "Q@{+22RKsIf5X#ll?{-$2tlF8wR>d5jEJ8zotDHOd{#^Dw={IEZGhOxP(<HPUFIW)fXDXZAM}X@:LUJDFcq9]l+]4y1mb%qH%[P:F(p,7C7*$FF&6c.Ln^s)p(}#+5mmw<_pEG_MhkHA}O9>ait,U{@&dmQ5pAM{EPDzf(rOW)5Opc4s4#KOVPP4fIzProUq%4.Ujq;.2?OB]n-N<,_llfhB_.V!@lx9tYPdJlOGMqkF?ZV]2qE}rbPphU1zgFrY"
#endif
#ifndef HY_KEY_LEN_L1
#define HY_KEY_LEN_L1 6
#endif
#ifndef HY_KEY_LEN_L2
#define HY_KEY_LEN_L2 64
#endif
#ifndef HY_KEY_LEN_L3
#define HY_KEY_LEN_L3 64
#endif
#ifndef HY_KEY_LEN_L4
#define HY_KEY_LEN_L4 64
#endif
#ifndef HY_KEY_LEN_L5
#define HY_KEY_LEN_L5 256
#endif

/* 兼容旧名：单密钥时代的名字指向第 5 层 */
#ifndef HY_SECRET_KEY
#define HY_SECRET_KEY HY_KEY_L5
#endif
#ifndef HY_SECRET_KEY_LEN
#define HY_SECRET_KEY_LEN HY_KEY_LEN_L5
#endif

/*
 * 层号编码：塞进 magic 的高 16 位，低 16 位保留 HY_MAGIC 的低半段。
 * 必须与内核 hy.h 的 HY_HS_MAGIC_OF 完全一致，否则内核解不出层号。
 */
#ifndef HY_KEY_MAGIC_LOW
#define HY_KEY_MAGIC_LOW   ((uint32_t)(HY_MAGIC & 0xFFFFu))
#endif

/* 握手两阶段与挑衅明文长度 —— 必须与内核 hy.h 完全一致 */
#ifndef HY_HS_STEP_REQ
#define HY_HS_STEP_REQ 1
#endif
#ifndef HY_HS_STEP_ANS
#define HY_HS_STEP_ANS 2
#endif
#ifndef HY_CHAL_LEN
#define HY_CHAL_LEN 32
#endif
#ifndef HY_HS_MAGIC_OF
#define HY_HS_MAGIC_OF(st) ((uint32_t)(HY_KEY_MAGIC_LOW | \
                                      (((uint32_t)(st) & 0xFFFFu) << 16)))
#endif
/* ==========================================================================
 * 【编译期密钥格式校验】
 *
 * 放在类外面而不是类里面：类内 static_assert 调用本类的
 * static constexpr 成员函数会撞上"定义尚未完整"，编译不过。
 *
 * 全部用最朴素的循环，不碰 <cstring>，也不碰 lambda ——
 * 这个文件要能在各种编译环境下开箱即用。
 * ========================================================================== */
#ifndef HY_KEY_CHECK_DEFINED
#define HY_KEY_CHECK_DEFINED
namespace hy_key_check {
    constexpr unsigned klen(const char *s)
    {
        unsigned n = 0;
        while (s[n]) ++n;
        return n;
    }
    constexpr bool has_upper(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i)
            if (s[i] >= 'A' && s[i] <= 'Z') return true;
        return false;
    }
    constexpr bool has_lower(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i)
            if (s[i] >= 'a' && s[i] <= 'z') return true;
        return false;
    }
    constexpr bool has_digit(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i)
            if (s[i] >= '0' && s[i] <= '9') return true;
        return false;
    }
    constexpr bool has_symbol(const char *s)
    {
        for (unsigned i = 0; s[i]; ++i) {
            char c = s[i];
            if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                  (c >= '0' && c <= '9'))) return true;
        }
        return false;
    }
}
#endif


/* ---- 编译期：五层逐层校验（长度 + 四类字符） ---- */
#define HY_ASSERT_KEY(N, LEN)                                                 \
    static_assert(hy_key_check::klen(HY_KEY_##N) == (unsigned)(LEN),          \
        "【欢愉】HY_KEY_" #N " 长度必须为 " #LEN " —— 内核侧同名字就是这样"); \
    static_assert(hy_key_check::has_upper(HY_KEY_##N),                        \
        "【欢愉】HY_KEY_" #N " 必须含大写字母");                              \
    static_assert(hy_key_check::has_lower(HY_KEY_##N),                        \
        "【欢愉】HY_KEY_" #N " 必须含小写字母");                              \
    static_assert(hy_key_check::has_digit(HY_KEY_##N),                        \
        "【欢愉】HY_KEY_" #N " 必须含数字");                                  \
    static_assert(hy_key_check::has_symbol(HY_KEY_##N),                       \
        "【欢愉】HY_KEY_" #N " 必须含符号");

/* 第 1 层是固定串 Huanyu：只有大写+小写，没有数字和符号，
   所以单独走一道宽松断言，只卡长度和大写小写。 */
static_assert(hy_key_check::klen(HY_KEY_L1) == 6u,
    "【欢愉】HY_KEY_L1 长度必须为 6（固定串 Huanyu）");
static_assert(hy_key_check::has_upper(HY_KEY_L1),
    "【欢愉】HY_KEY_L1 必须含大写字母");
static_assert(hy_key_check::has_lower(HY_KEY_L1),
    "【欢愉】HY_KEY_L1 必须含小写字母");
HY_ASSERT_KEY(L2, 64);
HY_ASSERT_KEY(L3, 64);
HY_ASSERT_KEY(L4, 64);
HY_ASSERT_KEY(L5, 256);

/*
 * 【v1.73.0】原来这里硬编码了 72 / 1 —— 每次升版本得改两处，改漏一个
 * 就编译失败。改成编译期解析 HY_VERSION_STRING 再和三个常量比：
 * 以后只改字符串那一行，常量忘改会在这里当场报错，不会拖到运行时
 * 才被内核判"版本不符"。
 */
constexpr int hy_ver_part(const char *s, int part)
{
    int idx = 0, cur = 0;
    for (const char *p = s; *p; ++p) {
        if (*p == '.') { if (idx == part) return cur; ++idx; cur = 0; }
        else if (*p >= '0' && *p <= '9') cur = cur * 10 + (*p - '0');
        else return -1;
    }
    return (idx == part) ? cur : -1;
}
static_assert(hy_ver_part(HY_VERSION_STRING, 0) == HY_VER_MAJOR &&
              hy_ver_part(HY_VERSION_STRING, 1) == HY_VER_MINOR &&
              hy_ver_part(HY_VERSION_STRING, 2) == HY_VER_PATCH,
    "【欢愉】HY_VERSION_STRING 与 HY_VER_MAJOR/MINOR/PATCH 不一致（升版本时三处都要改）");

#ifndef WANBAI_H
#define WANBAI_H
/*
 * ============================================================================
 *  欢愉 (Huanyu) 驱动对接头 —— 万白 (WANBAI) 兼容层
 * ============================================================================
 *
 *  直接对接欢愉内核模块（huanyu.kpm），走 prctl / supercall / 共享内存
 *  三条通道，不经过 /dev 节点，不做目录扫描。
 *
 *  【典型用法】
 *          c_driver drv;
 *          driver->initialize(pid);
 *          driver->GetPid("com.xxx");
 *          driver->getModuleBase("libil2cpp.so");
 *          int v = driver->read<int>(addr);
 *          driver->write<int>(addr, 123);
 *
 *  【免超级密钥】
 *      c_driver drv;           即可，不需要传任何密钥
 *      c_driver drv("密钥");    只在设置了自定义超级密钥 + 普通 root shell 时需要
 *
 *  【v1.67.0 握手闸门 —— 必读】
 *      本文件与内核 kpm 必须 **版本号一致 + 密钥一致**，否则内核
 *      拒绝执行除版本查询与握手以外的所有命令。
 *
 *      两者都在本文件顶部「用户可改区」上方的常量区：
 *          HY_VERSION_STRING / HY_VER_MAJOR / HY_VER_MINOR
 *          HY_SECRET_KEY
 *      改了内核 hy.h 里的任何一个，这里必须跟着改。
 *
 *      握手由本文件在第一次下发命令时自动完成，调用方无需干预；
 *      失败时会在 stderr 打印双方版本号与密钥核对提示。
 *      想手动掌握时机就调 driver->handshake()，返回 true 才可用。
 *
 *  编译：aarch64-linux-android31-clang++ -std=c++17 your.cpp -o your
 * ============================================================================
 */

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cerrno>
#include <string>
#include <vector>
#include <initializer_list>
#include <utility>

#include <dirent.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <pthread.h>

/* v1.60.0 网络下载（用户态）所需 */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <sys/prctl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/utsname.h>

#include <linux/types.h>
#include <linux/input.h>
#include <linux/uinput.h>

/* ==========================================================================
 * 【★★ 用户可改区 ★★】—— 整套文件里你唯一需要动的地方
 * ==========================================================================
 *
 *   HY_USER_BP_SCHEME —— 断点方案。改这一个数字即可，其余全部自动。
 *
 *     值   宏名                    含义                     内核实现
 *     ---  ----------------------  -----------------------  ------------------
 *      0   HY_BP_SCHEME_DEFAULT    遵循模块默认（★默认★）   交给内核自己挑
 *      1   HY_BP_SCHEME_HW_EXEC    硬件执行断点              DBGBCR/BRK 寄存器
 *      2   HY_BP_SCHEME_PTE        PTE 影子页断点            复制目标页改权限
 *      3   HY_BP_SCHEME_SW         软件断点                  把指令改成 BRK
 *      4   HY_BP_SCHEME_STEP       单步断点                  独立 STEPBP 命令
 *      5   HY_BP_SCHEME_WATCH_R    硬件读观察点              DBGWCR
 *      6   HY_BP_SCHEME_WATCH_W    硬件写观察点              DBGWCR
 *      7   HY_BP_SCHEME_WATCH_RW   硬件读写观察点            DBGWCR
 *      8   HY_BP_SCHEME_DPT        DPT 主线程影子页          独立 DPT 命令
 *
 *   ── 怎么选 ────────────────────────────────────────────────────────────
 *   · 不确定就留 0。内核按「编译期默认 → 硬件 → PTE → 软件」自己挑最稳的。
 *   · 1/5/6/7 用 ARM64 硬件断点寄存器，速度最快、最不容易被反调试扫到，
 *     但数量有限：执行断点占 brps，观察点占 wrps。
 *     你机器上的数目见 /proc/Huanyu 的 [breakpoint] 段（hw slots: brps=6 wrps=4）。
 *     用满会失败，此时改用 2。
 *   · 2 (PTE) 不受硬件槽位限制（影子页池已扩到 256），不改代码字节，
 *     代价是页粒度 —— 同一页内任何地址访问都会命中，且要多占一份物理页。
 *   · 3 (SW) 最通用，但直接改代码段，完整性校验 / 反调试一扫就发现。
 *   · 4 (STEP) 逐条指令走，很慢，只适合短距离精读。
 *   · 8 (DPT) 给主线程挂影子页，适合盯主线程的单点。
 *
 *   ── 一次只上一个方案 ──────────────────────────────────────────────────
 *   HY_USER_BP_STRICT = 1 时，候选链里**只有你指定的那一个方案**，
 *   内核不会再追加默认方案、也不会走「硬件->PTE->软件」回退链。
 *   推荐保持 1：多方案叠加在同一地址上会互相打架（影子页 + 硬件槽 +
 *   软件 BRK 同时生效），表现为装成功但命中异常，个别内核上直接崩。
 *   置 1 后若该方案不可用会**直接失败**，不会悄悄降级成别的方案 ——
 *   是成是败你能明确知道。
 *
 *   两种改法（等价，挑一个）：
 *     (a) 直接改下面的数字
 *     (b) 编译时覆盖： -DHY_USER_BP_SCHEME=2
 *     运行时也能改：   drv.set_bp_scheme(HY_BP_SCHEME_PTE);
 * ========================================================================== */
#ifndef HY_USER_BP_SCHEME
#define HY_USER_BP_SCHEME   0    /* ←←← 改这里：0=默认 1=硬件 2=PTE 3=软件 4=单步 5/6/7=观察点 8=DPT */
#endif

#ifndef HY_USER_BP_STRICT
#define HY_USER_BP_STRICT   1    /* 1=只用上面那一个方案，不叠加、不回退（推荐） */
#endif

#ifndef HY_USER_BP_LEN
#define HY_USER_BP_LEN      4    /* 断点长度（字节）：HW 观察点常用 4；执行断点恒 4 */
#endif

/* ==========================================================================
 * 一、supercall 底层（内置，不依赖 KernelPatch 用户态库）
 * ========================================================================== */

#ifndef __NR_supercall
#define __NR_supercall 45
#endif

#define HY_SUPERCALL_MAGIC 0x1158
#define HY_KP_MAJOR 0
#define HY_KP_MINOR 13
#define HY_KP_PATCH 9

/*
 * supercall 命令号。取自 KernelPatch 源码
 * kernel/patch/include/uapi/scdefs.h（0.13.x）。
 * 之前写的是 0x1005 / 0x1006，对不上真实内核，所以版本查询永远失败。
 */
#define SUPERCALL_HELLO              0x1000
#define SUPERCALL_KLOG               0x1004
#define SUPERCALL_BUILD_TIME         0x1007
#define SUPERCALL_KERNELPATCH_VER    0x1008
#define SUPERCALL_KERNEL_VER         0x1009
/* 旧版 KP（0.10.x 及更早）用过的号，保留用于回退探测 */
#define SUPERCALL_KERNELPATCH_VER_OLD 0x1005
#define SUPERCALL_KERNEL_VER_OLD      0x1006
#define SUPERCALL_KPM_LOAD           0x1020
#define SUPERCALL_KPM_UNLOAD         0x1021
#define SUPERCALL_KPM_CONTROL        0x1022
#define SUPERCALL_KPM_NUMS           0x1030
#define SUPERCALL_KPM_LIST           0x1031
#define SUPERCALL_KPM_INFO           0x1032
#define SUPERCALL_HELLO_MAGIC        0x11581158

/* 免密钥默认 key（定义在 namespace 之外：宏不受命名空间限制） */
#define HUANYU_NO_KEY "su"

namespace hy_detail {

static inline long ver_and_cmd(long cmd,
                               int major = HY_KP_MAJOR,
                               int minor = HY_KP_MINOR,
                               int patch = HY_KP_PATCH)
{
    uint32_t vc = (uint32_t)((major << 16) + (minor << 8) + patch);
    return ((long)vc << 32) | ((long)HY_SUPERCALL_MAGIC << 16) | (cmd & 0xFFFF);
}

static inline long sc_hello(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_HELLO));
}

static inline bool sc_ready(const char *key)
{
    return sc_hello(key) == SUPERCALL_HELLO_MAGIC;
}

/*
 * 查询 KernelPatch 版本。
 * 返回 kpver，编码为 VERSION(major,minor,patch) = (major<<16)|(minor<<8)|patch，
 * 例如 0.13.9 -> 0x0D09。用 kp_ver_str() 还原成 "0.13.9"。
 *
 * 注意：KERNELPATCH_VER 和 HELLO 一样，位于 supercall() 里
 *   if (!is_authed) return -EPERM;
 * 这道门槛【之前】，只要调用者是 trusted_caller 就一定返回版本号，
 * 与 key 对不对无关 —— 适合查版本，不能当鉴权探测（见 sc_authed）。
 */
static inline long sc_kp_ver(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    long r = syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNELPATCH_VER));
    if (r > 0) return r;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNELPATCH_VER_OLD));
}

static inline long sc_kernel_ver(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    long r = syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNEL_VER));
    if (r > 0) return r;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KERNEL_VER_OLD));
}

/* kpver / kver 编码值 -> "0.13.9"；失败写 "未知" */
static inline void kp_ver_str(long v, char *out, size_t n)
{
    if (!out || !n) return;
    if (v <= 0) { snprintf(out, n, "未知"); return; }
    uint32_t u = (uint32_t)v;
    snprintf(out, n, "%u.%u.%u", (u >> 16) & 0xFFu, (u >> 8) & 0xFFu, u & 0xFFu);
}

/*
 * 真正探测"鉴权是否通过"。
 * KERNELPATCH_VER / HELLO 都在门槛之前，拿它们当鉴权探测会永远显示"通过"。
 * SUPERCALL_KPM_NUMS(0x1030) 位于门槛之后的第二个 switch：
 * 未鉴权时内核直接 return -EPERM，成功则返回已加载 kpm 数量（>=0）。
 */
static inline long sc_authed(const char *key)
{
    if (!key || !key[0]) return -EINVAL;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KPM_NUMS));
}

static inline bool sc_key_ok(const char *key) { return sc_authed(key) >= 0; }

static inline long sc_kpm_control(const char *key, const char *name,
                                  const char *ctl_args, char *out_msg, long outlen)
{
    if (!key || !key[0]) return -EINVAL;
    if (!name || !name[0]) return -EINVAL;
    if (!ctl_args || !ctl_args[0]) return -EINVAL;
    return syscall(__NR_supercall, key, ver_and_cmd(SUPERCALL_KPM_CONTROL),
                   name, ctl_args, out_msg, outlen);
}

/*
 * prctl 免鉴权通道。
 * 内核侧 hook 了 prctl，用魔法数识别自己的调用，直接执行命令。
 * 与 supercall 完全独立，不需要 superkey。
 */
#define HY_PRCTL_MAGIC 0x4879756eULL   /* "Hyun" */

static inline long hy_prctl(unsigned int nr, void *payload)
{
    return syscall(__NR_prctl, HY_PRCTL_MAGIC,
                   (unsigned long)nr, (unsigned long)payload, 0UL, 0UL);
}

}   /* namespace hy_detail */

/* ==========================================================================
 * 二、命令号
 * ========================================================================== */

#define HY_MODULE_NAME "huanyu"

#define HY_NR_GET_PID          0
#define HY_NR_MODULE_BASE      1
#define HY_NR_MODULE_BSS       3
#define HY_NR_READ_MEM         4
#define HY_NR_WRITE_MEM        5
#define HY_NR_READ_MEM_V2      11

#define HY_NR_TOUCH_INIT       6
#define HY_NR_TOUCH_DOWN       7
#define HY_NR_TOUCH_UP         8
#define HY_NR_GYRO_INIT        9
#define HY_NR_GYRO_CONFIG      10

#define HY_NR_GET_THREAD_TLS   12
#define HY_NR_EXEC_PACGA       13

#define HY_NR_BP_SET_MODE      14
#define HY_NR_BP_GET_MODE      15
#define HY_NR_BP_GET_CAPS      16

#define HY_NR_BP_INIT          19
#define HY_NR_BP_NUM_BRPS      20
#define HY_NR_BP_NUM_WRPS      21
#define HY_NR_BP_INST          22
#define HY_NR_BP_UNINST        23
#define HY_NR_BP_SUSPEND       24
#define HY_NR_BP_RESUME        25
#define HY_NR_BP_HIT_COUNT     26
#define HY_NR_BP_MODIFY        27
#define HY_NR_BP_HIT_ITEMS     28
#define HY_NR_BP_CHECK_INITED  30

#define HY_NR_FILE_HIDE_INIT   34
#define HY_NR_FILE_HIDE_SET    31
#define HY_NR_FILE_HIDE_CLEAR  32
#define HY_NR_FILE_HIDE_STATUS 33

#define HY_NR_ENUM_MODULES     35
#define HY_NR_ENUM_PROCESSES   36
#define HY_NR_ENUM_THREADS     37
#define HY_NR_KERNEL_RW        38
#define HY_NR_PHYS_RW          39
#define HY_NR_PROTECT          40
#define HY_NR_CACHE_FLUSH      41
#define HY_NR_BP_LIST          42
#define HY_NR_BP_CLEAR_HITS    43
#define HY_NR_HWCAP            44
#define HY_NR_STATS            45
#define HY_NR_VERSION          46
#define HY_NR_SHM_REGISTER     47
#define HY_NR_SHM_STATUS       48

/* ---- v1.18.0：移植 lsdriver 能力 ---- */
/* syscall 监控 */
#define HY_NR_SYSMON_SET       49
#define HY_NR_SYSMON_REMOVE    50
#define HY_NR_SYSMON_READ      51
/* CNTVCT 读取监控 */
#define HY_NR_CNTVCT_SET       52
#define HY_NR_CNTVCT_REMOVE    53
#define HY_NR_CNTVCT_READ      54
/* 虚拟定位 GNSS */
#define HY_NR_GNSS_INIT        55
#define HY_NR_GNSS_REPORT      56
#define HY_NR_GNSS_STOP        57
/* 增强枚举 */
#define HY_NR_ENUM_SEGMENTS    58
#define HY_NR_ENUM_REGIONS     59
/* 单步断点 */
#define HY_NR_STEPBP_SET       60
#define HY_NR_STEPBP_REMOVE    61
/* DPT 主线程影子页 */
#define HY_NR_DPT_SET          62
#define HY_NR_DPT_REMOVE       63
/* 扩展能力 / GPU 隐藏 / 触摸移动 / ghost / 环境 / 综合状态 */
#define HY_NR_HWCAP2           64
#define HY_NR_KGSL_HIDE_SET    65
#define HY_NR_KGSL_HIDE_CLEAR  66
#define HY_NR_TOUCH_MOVE       67
#define HY_NR_TOUCH_SETUP      71
#define HY_NR_GYRO_SET         72
#define HY_NR_GHOST_STATUS     68
#define HY_NR_ENV_PARAMS       69
#define HY_NR_LS_STATUS        70
/* ---- v1.60.0 压力测试 / 读取后端 / 网络预留 ---- */
#define HY_NR_DBG_CMD          82
#define HY_NR_STRESS            83
#define HY_NR_RWMODE_SET        84
#define HY_NR_RWMODE_GET        85
#define HY_NR_MEMCACHE_SET      89
#define HY_NR_MEMCACHE_GET      90
#define HY_NR_NET_CAP           86
#define HY_NR_NET_FETCH         87
#define HY_NR_NET_STATUS        88
/* v1.66.0 补齐：内核有 HY_NR_HIDE_GUP_SET=73，用户态缺定义 */
#define HY_NR_HIDE_GUP_SET      73

/* 读取后端模式（与内核 hy.h 的 HY_RW_MODE_* 对齐）
 *   0 = 内核级读取（默认，与不加这个功能时行为完全一致）
 *   1 = KMA 硬件级读取
 *   仅对内核虚拟地址 / 物理地址生效；
 *   用户态进程内存不适用，内核会自动回落到内核级。 */
#define HY_RW_MODE_KERNEL       0
#define HY_RW_MODE_KMA          1

/* 网络预留：内核侧不发任何包，收发必须由用户态完成。
 * 这些号的意义是"接口先定死"，以后不会因为 ABI 变动返工。 */
#define HY_NET_URL_MAX          512
#define HY_NET_METHOD_GET       0
#define HY_NET_METHOD_HEAD      1
#define HY_NET_METHOD_POST      2
#define HY_NET_FLAG_HTTPS       0x1u
#define HY_NET_FLAG_FOLLOW      0x2u


/* 断点方案（内核内部编号，用户一般不用直接碰，走下面的 HY_BP_SCHEME_*） */
#define HY_BP_MODE_AUTO 0
#define HY_BP_MODE_SW   1
#define HY_BP_MODE_PTE  2
#define HY_BP_MODE_HW   3

/* ==========================================================================
 * 【用户断点方案】—— 这是给用户直接用的，和上面的内核编号不是一套。
 *
 *   方案值            含义                      内核 mode   额外动作
 *   ----------------  ------------------------  ----------  ------------------
 *   DEFAULT    = 0    遵循模块默认（推荐/默认）   AUTO        走内置回退链
 *   HW_EXEC    = 1    硬件执行断点               HW          type=X
 *   PTE        = 2    PTE 影子页                 PTE         无
 *   SW         = 3    软件断点（改写指令）       SW          无
 *   STEP       = 4    单步断点                   —           走 STEPBP 命令
 *   WATCH_R    = 5    硬件读观察点               HW          type=R
 *   WATCH_W    = 6    硬件写观察点               HW          type=W
 *   WATCH_RW   = 7    硬件读写观察点             HW          type=RW
 *   DPT        = 8    DPT 主线程影子页           —           走 DPT 命令
 *
 *   说明：
 *   - 0 是默认值：不覆盖模块默认，内核按「编译期默认 → 回退链」自己选。
 *     想让欢愉自动挑最稳的方案就用 0。
 *   - 1/5/6/7 都靠 ARM64 硬件断点寄存器（DBGBCR/DBGWCR），数量有限，
 *     你机器上是 brps=6 wrps=4（见 /proc/Huanyu 的 [breakpoint] 段）。
 *     其中执行断点占 brps，观察点占 wrps，用满会失败。
 *   - 2 (PTE) 不占硬件寄存器，数量只受影子页池限制（已扩到 256），
 *     但要把目标页复制一份再改权限，对被调试进程的内存布局有影响。
 *   - 3 (SW) 直接改写指令，最通用也最容易被反调试扫到。
 *   - 4 (STEP) 是独立命令，不经过 mode 字段。
 *   - 8 (DPT) 给主线程挂影子页，也是独立命令。
 *
 *   用法：
 *     c_driver drv;
 *     drv.set_bp_scheme(HY_BP_SCHEME_PTE);   // 之后所有断点都走 PTE
 *     uint64_t h = drv.bp_inst(pid, addr);   // 自动按上面的方案走
 *     drv.set_bp_scheme(HY_BP_SCHEME_DEFAULT); // 还原
 * ========================================================================== */
#define HY_BP_SCHEME_DEFAULT   0   /* 遵循模块默认（本枚举的默认值） */
#define HY_BP_SCHEME_HW_EXEC   1   /* 硬件执行断点 */
#define HY_BP_SCHEME_PTE       2   /* PTE 影子页断点 */
#define HY_BP_SCHEME_SW        3   /* 软件断点 */
#define HY_BP_SCHEME_STEP      4   /* 单步断点 */
#define HY_BP_SCHEME_WATCH_R   5   /* 硬件读观察点 */
#define HY_BP_SCHEME_WATCH_W   6   /* 硬件写观察点 */
#define HY_BP_SCHEME_WATCH_RW  7   /* 硬件读写观察点 */
#define HY_BP_SCHEME_DPT       8   /* DPT 主线程影子页 */
#define HY_BP_SCHEME_MAX       9

#define HY_BP_CAP_SW  (1u << 0)
#define HY_BP_CAP_PTE (1u << 1)
#define HY_BP_CAP_HW  (1u << 2)

/* hy_bp_inst_args.flags 位 */
#define HY_BP_FLAG_RECORD 0x1    /* 记录命中上下文（寄存器等） */
#define HY_BP_FLAG_STRICT 0x2    /* 单方案严格模式：只装指定方案，不叠加不回退 */

#define HW_BREAKPOINT_LEN_1 1
#define HW_BREAKPOINT_LEN_2 2
#define HW_BREAKPOINT_LEN_3 3
#define HW_BREAKPOINT_LEN_4 4
#define HW_BREAKPOINT_LEN_5 5
#define HW_BREAKPOINT_LEN_6 6
#define HW_BREAKPOINT_LEN_7 7
#define HW_BREAKPOINT_LEN_8 8

#define HW_BREAKPOINT_EMPTY 0
#define HW_BREAKPOINT_R     1
#define HW_BREAKPOINT_W     2
#define HW_BREAKPOINT_RW    (HW_BREAKPOINT_R | HW_BREAKPOINT_W)
#define HW_BREAKPOINT_X     4

#define REG_MODIFY_X(N)   (1ULL << (N))
#define REG_MODIFY_SP     (1ULL << 31)
#define REG_MODIFY_PC     (1ULL << 32)
#define REG_MODIFY_PSTATE (1ULL << 33)
#define BP_FLAG_RECORD    0x1

/* ==========================================================================
 * 三、数据结构
 * ========================================================================== */

#pragma pack(1)

struct hy_request {
    int32_t  pid;
    uint64_t addr;
    uint64_t buffer;
    uint64_t size;
};

struct hy_user_pt_regs {
    uint64_t regs[31];
    uint64_t sp;
    uint64_t pc;
    uint64_t pstate;
    uint64_t orig_x0;
    uint64_t syscallno;
    __uint128_t vregs[32];
};

struct hy_bp_hit_item {
    uint64_t task_id;
    uint64_t hit_addr;
    uint64_t hit_time;
    struct hy_user_pt_regs regs_info;
    uint32_t resolved_mode;   /* 内核实际落到哪个方案：1=SW 2=PTE 3=HW */
    uint32_t reserved;
};

struct hy_bp_inst_args {
    int32_t  pid;
    uint64_t addr;
    uint32_t bp_len;
    uint32_t bp_type;
    uint64_t reg_modify_mask;
    uint64_t fp_reg_modify_mask;
    uint64_t regs_to_set_ptr;
    uint32_t flags;
    uint32_t mode;            /* 本次显式指定方案：0=AUTO 1=SW 2=PTE 3=HW */
};

struct hy_bp_modify_args {
    uint64_t handle;
    uint64_t reg_modify_mask;
    uint64_t fp_reg_modify_mask;
    uint64_t regs_to_set_ptr;
};

struct hy_bp_hit_count_arg {
    uint64_t handle;
    uint64_t hit_total_count;
    uint64_t hit_item_arr_count;
};

struct hy_bp_hit_items_args {
    uint64_t handle;
    uint64_t user_buffer_ptr;
    uint64_t max_bytes;
    uint64_t items_copied;
};

struct hy_bp_mode_config { uint32_t mode; uint32_t flags; };
/* v1.60.0 统一文本命令通道（/proc/HuanyuD 与 supercall 共用同一套解析） */
struct hy_dbg_req {
    uint32_t cmd_len;
    uint32_t out_len;
    char     cmd[160];
    char     out[160];
};

/* v1.60.0 读取后端选择 */
struct hy_rw_mode { uint32_t mode; uint32_t reserved; };

/* ============================================================
 * 读取缓存开关（v1.63.0）
 *   默认启用缓存（性能优先）。命中时省掉 4 级页表遍历，
 *   只做一次 PTE 值校验。只有显式设 OFF 才每次走完整页表。
 * ============================================================ */
#define HY_MEM_CACHE_DEFAULT    0   /* 默认：启用缓存（推荐，性能优先） */
#define HY_MEM_CACHE_ON         1   /* 强制启用 */
#define HY_MEM_CACHE_OFF        2   /* 关闭：每次重走完整页表 */

struct hy_mem_cache_mode { uint32_t mode; uint32_t reserved; };

/* ---- 断点 flags（v1.63.0）----
 * STEALTH：SW 断点自动改用 PTE 影子页实现 —— 不改代码段字节，
 *          内存 CRC / 哈希自检扫不到。**默认已开启**，无需手动设置。
 * NOSTEALTH：显式关闭该升级，优先级最高，断点就按原样写成 BRK。
 */
#define HY_BP_FLAG_STEALTH      (1u << 0)
#define HY_BP_FLAG_NOSTEALTH    (1u << 1)

/* v1.60.0 网络访问预留（内核只登记意图，收发在用户态） */
struct hy_net_req {
    uint32_t method;      /* HY_NET_METHOD_* */
    uint32_t timeout_ms;  /* 0 = 用默认 10s */
    uint32_t flags;       /* HY_NET_FLAG_* */
    uint32_t reserved;
    char     url[HY_NET_URL_MAX];
};
struct hy_net_rep {
    uint32_t err;         /* 0 成功 */
    uint32_t status_code; /* HTTP 状态码 */
    uint32_t body_len;
    uint32_t reserved;
};
struct hy_net_cap {
    uint32_t kernel_impl;       /* 0 = 内核不做收发 */
    uint32_t userland_required; /* 1 = 必须用户态 */
    uint32_t abi_version;
    uint32_t reserved;
};

/* ---- v1.64.0 方案选择（91 设置 / 92 查询）----
 * 与断点方案同一个套路：默认 0（自动），可显式指定世代。
 * 作用域：0=physvirt 1=pgtable 2=memread 3=kernrw 4=bp 5=input 6=sym
 */
#define HY_NR_SCHEME_SET        91
#define HY_NR_SCHEME_GET        92
#define HY_NR_TI_DOWN          94
#define HY_NR_TI_MOVE          95
#define HY_NR_TI_UP            96
#define HY_NR_TI_STATUS        97
#define HY_NR_TI_SET_SLOTS     98
#define HY_NR_TI_SET_RANGE     99
#define HY_NR_TI_GET_RANGE    100
#define HY_NR_TI_CLEAR        101   /* v1.75.0 强制清除残留手指 */
#define HY_NR_TI_INJECT_GATE  102   /* v1.75.0 注入总闸 */
/* v1.76.0 多指：带手指 id 的 down/move/up + 容量查询 */
#define HY_NR_TI_DOWN_ID       103
#define HY_NR_TI_MOVE_ID       104
#define HY_NR_TI_UP_ID         105
#define HY_NR_TI_UP_ALL        106
#define HY_NR_TI_CAPACITY      107
/* 注入状态机取值，与内核 enum 对齐 */
#define HY_TI_IDLE              0
#define HY_TI_ACTIVE            1
#define HY_TI_CONFLICTED        2

#define HY_SCHEME_AUTO  0
#define HY_SCHEME_GEN3  3
#define HY_SCHEME_GEN4  4
#define HY_SCHEME_GEN5  5
#define HY_SCHEME_GEN6  6
#define HY_SC_PHYSVIRT 0
#define HY_SC_PGTABLE  1
#define HY_SC_MEMREAD  2
#define HY_SC_KERNW    3
#define HY_SC_BP       4
#define HY_SC_INPUT    5
#define HY_SC_SYM      6

/* ---- v1.67.0 版本 / 密钥握手（93）----
 *
 * 用户态上来先自报版本号与密钥，内核两项都比对通过才放行后续命令。
 * 这是唯一一个"未握手也能下发"的功能命令。
 */
#define HY_NR_HANDSHAKE        93

/* 与内核 hy.h 的 HY_MAGIC 对齐（"Hyun"） */
#ifndef HY_MAGIC
#define HY_MAGIC 0x4879756eu
#endif

#define HY_HS_OK            0   /* 本步通过 */
#define HY_HS_BAD_MAGIC     1   /* magic / 阶段号不对 */
#define HY_HS_BAD_VER       2   /* 版本不一致 */
#define HY_HS_BAD_KEY       3   /* 应答与原文不一致（五层密钥解错） */
#define HY_HS_BAD_BOTH      4   /* 版本与应答都不一致 */
#define HY_HS_NO_CHAL       5   /* 还没要挑战就先交应答 */
#define HY_HS_DONE          6   /* 两步都过，已放行 */

/* push/pop 而非 pack(1)/pack()：避免提前关掉外层的紧凑对齐 */
#pragma pack(push, 1)
struct hy_handshake_req {
    uint32_t magic;
    uint32_t uver_major;
    uint32_t uver_minor;
    char     uver_str[24];
    char     key[264];
    uint32_t result;      /* 出参 */
    uint32_t lock_ver;    /* 出参 */
    uint32_t lock_key;    /* 出参 */
    uint32_t locked;      /* 出参 */
};
#pragma pack(pop)

struct hy_scheme_req {
    uint32_t dom;      /* HY_SC_* */
    uint32_t gen;      /* HY_SCHEME_AUTO / GEN3..GEN6 */
    uint32_t chosen;   /* 出参：档位索引，-1 = 无可用方案 */
    uint32_t cur_gen;  /* 出参：该档所属世代 */
};

struct hy_bp_caps { uint32_t supported; uint32_t num_brps; uint32_t num_wrps; uint32_t reserved; };

struct hy_mod_info {
    uint64_t start; uint64_t end;
    uint32_t exec;  uint32_t write; uint32_t resv[2];
};

struct hy_proc_info { int32_t pid; char comm[16]; };

struct hy_enum_req { int32_t pid; uint32_t max_count; uint64_t buf_ptr; };

struct hy_kern_rw_req {
    uint64_t addr; uint64_t buf_ptr; uint64_t size;
    uint32_t is_write; uint32_t resv;
};

struct hy_protect_req {
    int32_t pid; uint32_t prot; uint64_t addr; uint64_t size;
};

struct hy_flush_req { int32_t pid; uint32_t resv; uint64_t addr; uint64_t size; };

struct hy_bp_item {
    uint64_t handle; int32_t pid; uint32_t mode;
    uint64_t addr; uint64_t hit_count; uint32_t active; uint32_t suspended;
};

struct hy_bp_list_req { uint32_t max_count; uint64_t buf_ptr; };

struct hy_hwcap {
    uint32_t pac, bti, lse, mte, fp, brps, wrps, resv;
};

struct hy_stats {
    uint64_t cache_hits, cache_miss, bp_active, hit_total, sym_failures, resv[3];
};

struct hy_touch_event_base { int32_t slot; int32_t x; int32_t y; };
struct hy_touch_setup { int32_t max_x; int32_t max_y; int32_t slot_base; int32_t reserved; };
struct hy_gyro_vec { int32_t x; int32_t y; int32_t z; int32_t reserved; };
/* v1.22.0 */
#define HY_TOUCH_NAME_MAX 64
struct hy_touch_name { char name[HY_TOUCH_NAME_MAX]; };

/* v1.73.0：安全注入坐标范围。-1 表示该项不自设，沿用内核自学习值。 */
struct hy_ti_range { int32_t min_x; int32_t max_x; int32_t min_y; int32_t max_y; };

/* v1.73.0：安全注入运行状态，9 个字段一次取完 */
struct hy_ti_stat {
    int32_t state;      /* HY_TI_IDLE / ACTIVE / CONFLICTED */
    int32_t inj_slot;   /* 当前虚拟手指占用槽位，-1 表示无 */
    int32_t max_slots;  /* 内核认定的总槽位数 */
    int32_t downs;
    int32_t moves;
    int32_t ups;
    int32_t busy;       /* 无空槽被丢弃的次数 */
    int32_t conflicts;  /* 与真手指冲突而放弃轨迹的次数 */
    int32_t protects;   /* 拦下的"抹除虚拟手指"事件数（关键健康指标） */
};

/* v1.76.0：指定手指 id 的 down/move/up */
struct hy_ti_finger_op {
    int32_t id;         /* 手指编号 0..15 */
    int32_t x;
    int32_t y;
};

/* v1.76.0：容量查询。capacity = 总槽位 - 真手指占用，动态变化 */
struct hy_ti_cap {
    int32_t capacity;   /* 当前还能再按几根 */
    int32_t active;     /* 已按着的虚拟手指数 */
    int32_t real;       /* 真手指占用槽位数 */
    int32_t total_slots;
};

#define TOUCH_SET_NAME 74
#define TOUCH_RESCAN   75
#define TOUCH_SETUP    71
#define GYRO_SET       72

struct hy_gyro_config { uint32_t enable; uint32_t x; uint32_t y; };

struct hy_tls_request {
    int32_t pid; int32_t tid; uint64_t tls_value; int32_t result; uint32_t reserved;
};

struct hy_pacga_request {
    int32_t pid; uint32_t reserved0; uint64_t value;
    uint64_t modifier; uint64_t result_pac; int32_t ok; uint32_t reserved1;
};

struct hy_file_hide_config {
    char directory[256]; char keyword[128]; uint32_t enabled;
};

struct hy_file_hide_status {
    char directory[256]; char keyword[128]; uint32_t enabled; uint32_t hook_active;
};

#pragma pack()

static_assert(sizeof(hy_request)          == 28,   "hy_request ABI mismatch");
static_assert(sizeof(hy_bp_hit_item)      == 832,  "hy_bp_hit_item ABI mismatch");
static_assert(sizeof(hy_bp_inst_args)     == 52,   "hy_bp_inst_args ABI mismatch");
static_assert(sizeof(hy_tls_request)      == 24,   "hy_tls_request ABI mismatch");
static_assert(sizeof(hy_pacga_request)    == 40,   "hy_pacga_request ABI mismatch");
static_assert(sizeof(hy_file_hide_config) == 388,  "hy_file_hide_config ABI mismatch");

/* 兼容原 wanbai 头文件里的类型名 */
typedef struct _COPY_MEMORY {
    pid_t pid; uintptr_t addr; void *buffer; size_t size;
} COPY_MEMORY, *PCOPY_MEMORY;

typedef struct _MODULE_BASE {
    pid_t pid; char *name; uintptr_t base;
} MODULE_BASE, *PMODULE_BASE;

struct mem_operation {
    pid_t target_pid; uint64_t addr; void *buffer; uint64_t size;
};

enum OPERATIONS {
    OP_READ_MEM = 0x801, OP_WRITE_MEM = 0x802, OP_MODULE_BASE = 0x803,
    PROC_OP_READ_MEM = 0xC01, PROC_OP_WRITE_MEM = 0xC02, PROC_OP_MODULE_BASE = 0xC03,
};


/* ==========================================================================
 * 共享内存通道（lsdriver 风格）
 *   用户态 mmap 一块内存 -> 注册给内核 -> 内核 GUP + vmap
 *   之后命令提交与数据回传全部是纯内存读写，零系统调用、零拷贝
 * ========================================================================== */

/* ls 同款固定虚拟地址 */
#define HY_DRIVER_VERSION "1.18.0"

#define HY_SHM_FIXED_VA 0x2025827000ULL

/* 目标进程名：内核线程按此扫描。默认 "Huanyu"。 */
#define HY_SHM_DEFAULT_NAME "Huanyu"

#define HY_SHM_MAGIC   0x48796e75u
#define HY_SHM_VERSION 1u
#define HY_SHM_PAYLOAD (128u * 1024u)
#define HY_SHM_SIZE    (sizeof(hy_shm_obj))

#define HY_SHM_IDLE 0u
#define HY_SHM_REQ  1u
#define HY_SHM_BUSY 2u
#define HY_SHM_F_READY (1u << 0)

#pragma pack(1)

struct hy_shm_obj {
    volatile uint32_t magic;
    volatile uint32_t version;
    volatile uint32_t state;
    volatile uint32_t seq;
    volatile uint32_t ack;
    volatile int32_t  ret;
    volatile uint32_t nr;
    volatile uint32_t len;
    volatile uint32_t flags;
    volatile uint32_t reserved0;
    volatile uint64_t shm_va;
    volatile uint64_t shm_size;
    volatile uint64_t requests;
    volatile uint64_t errors;
    uint8_t payload[HY_SHM_PAYLOAD];
};


/* ---- v1.18.0 ls 移植结构体（与内核侧 hy.h 严格一致）---- */
#pragma pack()   /* 恢复默认对齐：内核侧 struct 是自然对齐，不是 pack(1) */

struct hy_sysmon_req { int32_t pid; uint32_t enable; };

struct hy_sysmon_entry {
    uint64_t seq;
    int32_t  pid;
    int32_t  tid;
    uint32_t nr;
    uint64_t arg0, arg1, arg2, ret, ts;
};

struct hy_sysmon_read {
    uint64_t buf_ptr;
    uint32_t max_count;
    uint32_t nr_read;
    uint64_t total;
    uint32_t clear;
};

struct hy_cntvct_req  { int32_t pid; uint32_t enable; };
struct hy_cntvct_read { uint64_t count; uint64_t last_pc; uint32_t clear; };

struct hy_gnss_req {
    int32_t  latitude_e7;
    int32_t  longitude_e7;
    uint32_t enable;
};

struct hy_gnss_status {
    uint32_t active;
    uint32_t hooked;
    uint64_t patches;
    int32_t  latitude_e7;
    int32_t  longitude_e7;
};

struct hy_seg_info { uint64_t start, end; uint32_t prot, flags; };
struct hy_enum_segs_req {
    int32_t  pid;
    uint64_t module_base;
    uint64_t buf_ptr;
    uint32_t max_count;
    uint32_t nr_written;
};

struct hy_region_info { uint64_t start, end; uint32_t prot, reserved; };
struct hy_enum_regions_req {
    int32_t  pid;
    uint64_t buf_ptr;
    uint32_t max_count;
    uint32_t nr_written;
};

struct hy_stepbp_req { int32_t pid; uint64_t addr; uint32_t enable; };
struct hy_dpt_req    { int32_t pid; uint64_t addr; uint32_t enable; };

struct hy_hwcap2 {
    uint32_t mte, spe, pan, bti, pac, lse, brps, wrps, ghost, reserved;
};

struct hy_kgsl_req { uint32_t enable, reserved; };

struct hy_env_params {
    int32_t  pid;
    int32_t  tid;
    uint64_t tls;
    uint64_t stack_top;
    uint64_t mm_start;
    uint64_t mm_end;
    char     comm[16];
    uint32_t is_main_thread;
    uint32_t reserved;
};

struct hy_ls_status {
    uint32_t sysmon_active, sysmon_hooked;
    uint32_t cntvct_active, cntvct_hooked;
    uint32_t gnss_active,   gnss_hooked;
    uint32_t dpt_active,    dpt_hooked;
    uint32_t kgsl_active,   kgsl_hooked;
    uint32_t stepbp_active;
    uint64_t sysmon_total;
    uint64_t cntvct_total;
    uint64_t gnss_patches;
};

static_assert(sizeof(struct hy_sysmon_entry) == 64, "hy_sysmon_entry ABI");
static_assert(sizeof(struct hy_seg_info)    == 24, "hy_seg_info ABI");
static_assert(sizeof(struct hy_region_info) == 24, "hy_region_info ABI");
static_assert(sizeof(struct hy_gnss_req)    == 12, "hy_gnss_req ABI");
static_assert(sizeof(struct hy_ls_status)   == 72, "hy_ls_status ABI");
static_assert(sizeof(struct hy_env_params)  == 64, "hy_env_params ABI");

#pragma pack(1)   /* 回到文件原本的对齐设定 */

struct hy_shm_register {
    uint64_t va;
    uint64_t size;
    uint32_t pid;
    uint32_t reserved;
};

struct hy_shm_status {
    uint32_t ready;
    uint32_t nr_pages;
    uint64_t kva;
    uint64_t requests;
    uint64_t errors;
};

#pragma pack()

static_assert(sizeof(hy_shm_register) == 24, "hy_shm_register ABI mismatch");

/* ==========================================================================
 * 主类
 * ========================================================================== */

/* ==========================================================================
 * 【链路体检报告】
 * 原来只有一个 bool + 一行 printf，出问题完全看不出是哪一环断了。
 * 现在把 prctl / supercall / shm 三条通道、鉴权、模块版本、
 * KernelPatch 版本、内核版本全部单独探测，逐项给结论和建议。
 * ========================================================================== */
struct hy_link_report {
    /* 三条通道 */
    bool   prctl_ok      = false;
    long   prctl_ret     = 0;
    int    prctl_errno   = 0;

    bool   sc_ok         = false;      /* supercall 能打通 */
    bool   sc_authed     = false;      /* 且密钥正确（过了鉴权门槛） */
    long   sc_ret        = 0;
    int    sc_errno      = 0;

    bool   shm_ok        = false;

    /* 环境 */
    bool   kp_present    = false;      /* KernelPatch 在不在 */
    long   kp_ver        = 0;          /* KernelPatch 版本（编码值） */
    long   kern_ver      = 0;          /* 内核版本（编码值） */
    char   mod_version[32]{0};         /* 欢愉模块版本字符串 */

    /* 结论 */
    bool   linked        = false;      /* 最终是否连通 */
    int    verdict       = 0;          /* 0=正常，<0 为失败原因 */
    char   reason[192]{0};             /* 人话结论 */
    char   advice[192]{0};             /* 该怎么做 */
};

/* 结论码 */
#define HY_LINK_OK              0
#define HY_LINK_NO_KP          -1    /* KernelPatch 都不在 */
#define HY_LINK_NO_MODULE      -2    /* 模块没加载 */
#define HY_LINK_NO_CHANNEL     -3    /* 两条通道都不通 */
#define HY_LINK_BAD_KEY        -4    /* 密钥不对 */

class c_driver {
private:
    std::string key_;
    pid_t  pid_ = 0;
    int    fd_  = -1;          /* 保留字段：欢愉不用文件描述符，恒为 -1 */
    bool   initialized_ = false;
    bool   authed_      = false;   /* supercall 鉴权是否通过 */
    bool   prctl_ok_    = false;   /* prctl 免鉴权通道是否可用 */

    /* 共享内存通道 */
    struct hy_shm_obj *shm_ = nullptr;
    void  *shm_mem_ = nullptr;
    size_t shm_len_ = 0;
    bool   shm_ok_  = false;

    /* 守护进程模式 */
    int    daemon_fd_ = -1;
    uint32_t shm_seq_ = 0;

    /* 【v1.68.0】启动横幅用：内核侧版本串 + 本次握手判定结果。
       握手成功/失败都会填，供 print_boot_banner() 打印那两行状态。 */
    mutable char     kver_[32] = {0};      /* 内核版本，"1.67.0" 或 "(未知)" */
    mutable bool     kver_got_ = false;    /* 内核版本是否问到了 */
    mutable bool     hs_ver_ok_ = false;   /* 本次握手：版本是否一致 */
    mutable bool     hs_key_ok_ = false;   /* 本次握手：密钥是否一致 */
    /* 【v1.72.1】横幅兜底：握手没跑（例如本文件版本常量自相矛盾而提前
       返回）时，kver_got_ 会一直是 false，横幅就会打印"huanyu未加载"，
       与体检里从 /proc/Huanyu 读到的模块版本自相矛盾。这里独立再取一次
       模块版本，专供横幅第一行判"在不在"。 */
    mutable char     modver_[32] = {0};
    mutable bool     modver_got_ = false;

    /* 当前运行时默认断点方案（mutable：const 方法里也要能记） */
    mutable uint32_t bp_mode_ = 0;   /* 内核编号：0=AUTO 1=SW 2=PTE 3=HW */
    mutable uint32_t rw_mode_ = HY_RW_MODE_KERNEL;  /* 0=内核级(默认) 1=KMA */
    mutable uint32_t mem_cache_ = HY_MEM_CACHE_DEFAULT; /* 0/1=启用 2=关闭 */

    /* 【用户断点方案】—— 由文件顶部的 HY_USER_BP_SCHEME 初始化 */
    mutable uint32_t bp_scheme_ = (uint32_t)HY_USER_BP_SCHEME;
    mutable bool     bp_strict_ = (HY_USER_BP_STRICT != 0);
    mutable uint32_t bp_len_    = (uint32_t)HY_USER_BP_LEN;
    mutable int      bp_last_err_ = 0;   /* 最近一次断点操作的错误码 */

    static constexpr int HY_FRAME_MAX = 1024;
    static constexpr int HY_FRAME_HDR = 12;   /* tag[4] + nr[4] + rsv[4] */

    /* ------------------------------------------------------------------
     * 【v1.67.0 握手闸门状态】
     *   hs_ok_   —— 内核已放行，可以正常下发命令
     *   hs_tried_—— 已尝试过握手，失败不再无限重试（否则每条命令都试一次）
     *   hs_in_   —— 正在握手过程中，绕过本地门，避免自递归
     *   hs_res_  —— 最近一次握手的内核返回 result
     * ------------------------------------------------------------------ */
    mutable bool hs_ok_    = false;
    mutable bool hs_tried_ = false;
    mutable bool hs_in_    = false;
    mutable uint32_t hs_res_ = 0;
    mutable unsigned hs_layer_got_ = 0;  /* 已送对的层数（0..5） */

    /* ==================================================================
     * 密钥格式自检
     *
     * 校验放在用户态而不是内核态：这把钥匙是用户自己的，
     * 由用户态自己核对、自己提示，内核那边一个字符都不透露。
     *
     * 编译期用 static_assert 卡死长度；运行期再查一遍字符集，
     * 免得有人把宏改成一串纯字母还能编译过、然后到内核才发现不一致。
     * ================================================================== */
    /* 运行期复核一遍格式（编译期那道在文件顶部，见 HY_ASSERT_KEY） */

    /* 取第 ly 层（0..4）的密钥串与其应有长度 */
    static const char *layer_key(unsigned ly)
    {
        switch (ly) {
        case 0:  return HY_KEY_L1;
        case 1:  return HY_KEY_L2;
        case 2:  return HY_KEY_L3;
        case 3:  return HY_KEY_L4;
        default: return HY_KEY_L5;
        }
    }
    static size_t layer_len(unsigned ly)
    {
        switch (ly) {
        case 0:  return HY_KEY_LEN_L1;
        case 1:  return HY_KEY_LEN_L2;
        case 2:  return HY_KEY_LEN_L3;
        case 3:  return HY_KEY_LEN_L4;
        default: return HY_KEY_LEN_L5;
        }
    }
    /* ================================================================
     * 【v1.71.0】挑战-响应：五层解密
     *
     * 内核把一段 32 字节随机明文用五层密钥加密后发过来，本文件解开，
     * 再把明文原样送回去。**密钥全程不出本进程** —— 内核从不接收它。
     *
     * 这三个函数必须与 hy_gate.c 里的 chal_layer_fwd / chal_encrypt
     * 逐字节对应，任何一处写错，解出来的就是错的，握手必然失败。
     * ================================================================ */

    /* 单层逆向变换。必须 **从后往前** 走，原因见 hy_gate.c 的说明 */
    static void chal_layer_inv(unsigned char *buf, size_t len,
                               const char *key, size_t klen)
    {
        size_t i;
        unsigned acc = 0u;
        unsigned rot;

        if (!klen) return;
        for (i = 0; i < klen; ++i)
            acc = (unsigned)(acc + (unsigned char)key[i]);
        rot = (acc % 7u) + 1u;

        for (i = len; i > 0; --i) {
            size_t j = i - 1;
            unsigned v = (unsigned)buf[j];
            unsigned prev;

            v = ((v >> rot) | (v << (8 - rot))) & 0xFFu;   /* ror，必须截断到 8 位 */
            prev = (j == 0) ? 0xA5u : (unsigned)buf[j - 1];
            buf[j] = (unsigned char)(v ^ (unsigned)(unsigned char)key[j % klen]
                                       ^ prev);
        }
    }

    /* 解密顺序必须和内核的加密顺序严格相反：L5 → L4 → L3 → L2 → L1 */
    static void chal_decrypt(unsigned char *buf, size_t len)
    {
        chal_layer_inv(buf, len, HY_KEY_L5, (size_t)HY_KEY_LEN_L5);
        chal_layer_inv(buf, len, HY_KEY_L4, (size_t)HY_KEY_LEN_L4);
        chal_layer_inv(buf, len, HY_KEY_L3, (size_t)HY_KEY_LEN_L3);
        chal_layer_inv(buf, len, HY_KEY_L2, (size_t)HY_KEY_LEN_L2);
        chal_layer_inv(buf, len, HY_KEY_L1, (size_t)HY_KEY_LEN_L1);
    }

    /* 把内核返回的握手结果码翻成人话 */
    static const char *hs_result_text(uint32_t res)
    {
        switch (res) {
        case HY_HS_OK:        return "本步通过";
        case HY_HS_BAD_MAGIC: return "阶段号或 magic 不匹配";
        case HY_HS_BAD_VER:   return "版本不一致";
        case HY_HS_BAD_KEY:   return "挑战应答与原文不一致（五层密钥解错）";
        case HY_HS_BAD_BOTH:  return "版本与应答都不一致";
        case HY_HS_NO_CHAL:   return "还没请求挑战就提交应答";
        case HY_HS_DONE:      return "两步都过，已放行";
        default:              return "未知结果码";
        }
    }

    static bool one_has_upper(const char *p)
    {
        for (; *p; ++p) if (*p >= 'A' && *p <= 'Z') return true;
        return false;
    }
    static bool one_has_lower(const char *p)
    {
        for (; *p; ++p) if (*p >= 'a' && *p <= 'z') return true;
        return false;
    }
    static bool one_has_digit(const char *p)
    {
        for (; *p; ++p) if (*p >= '0' && *p <= '9') return true;
        return false;
    }
    static bool one_has_symbol(const char *p)
    {
        for (; *p; ++p) {
            char c = *p;
            if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                  (c >= '0' && c <= '9'))) return true;
        }
        return false;
    }

    /*
     * 逐层格式自检。
     * 返回 0 表示五层全合格；返回 n(>=1) 表示第 n 层不合格，
     * why 会说明是长度还是字符集的问题。
     */
    static unsigned key_layers_check(const char **why)
    {
        unsigned ly;
        for (ly = 0; ly < (unsigned)HY_KEY_LAYERS; ++ly) {
            const char *k = layer_key(ly);
            if (strlen(k) != layer_len(ly))                 { *why = "长度不对";   return ly + 1u; }
            if (!one_has_upper(k))                          { *why = "缺少大写字母"; return ly + 1u; }
            if (!one_has_lower(k))                          { *why = "缺少小写字母"; return ly + 1u; }
            /* 第 1 层是固定串 Huanyu，只有字母 —— 不参与数字/符号这两条 */
            if (ly == 0) continue;
            if (!one_has_digit(k))                          { *why = "缺少数字";   return ly + 1u; }
            if (!one_has_symbol(k))                         { *why = "缺少符号";   return ly + 1u; }
        }
        *why = "";
        return 0;
    }

    /* 兼容旧调用点：都指向第 5 层（单密钥时代的那把） */
    static bool key_len_ok()    { return strlen(HY_KEY_L5) == (size_t)HY_KEY_LEN_L5; }
    static bool key_has_upper() { return one_has_upper(HY_KEY_L5); }
    static bool key_has_lower() { return one_has_lower(HY_KEY_L5); }
    static bool key_has_digit() { return one_has_digit(HY_KEY_L5); }
    static bool key_has_symbol(){ return one_has_symbol(HY_KEY_L5); }

    /* 密钥格式出问题时的完整提示：只打印用户态这一侧出问题的那一层 */
    static void key_report(const char *why, unsigned ly = 0)
    {
        if (ly == 0) {
            fprintf(stderr,
                "\n==== 欢愉对接密钥错误 ====\n"
                "  原因：%s\n"
                "  要求：第 1~4 层各 64 位、第 5 层 256 位，"
                "每层都要同时含大写字母 / 小写字母 / 数字 / 符号\n"
                "  请改成合法密钥，并与内核 hy.h 的 HY_KEY_L1..L5 逐字节一致。\n"
                "==========================\n\n", why);
            return;
        }
        fprintf(stderr,
            "\n==== 欢愉对接密钥错误（第 %u 层）====\n"
            "  原因：%s\n"
            "  要求：本层 %zu 位，且同时含大写字母 / 小写字母 / 数字 / 符号\n"
            "  当前用户态第 %u 层：%s\n"
            "  当前用户态长度：%zu\n"
            "  请改成合法密钥，并与内核 hy.h 的 HY_KEY_L%u 逐字节一致。\n"
            "==================================\n\n",
            ly, why, layer_len(ly - 1u), ly, layer_key(ly - 1u),
            strlen(layer_key(ly - 1u)), ly);
    }

    /* ==================================================================
     * 【v1.67.0】握手：自报版本号 + 密钥，内核两项都对才放行后续命令。
     *
     * 走 prctl / supercall 基础通道，**不走共享内存**：
     * shm 通道自身要先靠 HY_NR_SHM_REGISTER 建立，而那个命令在未握手时
     * 同样被内核拦着 —— 用 shm 发握手会形成死锁。
     * ================================================================== */
    bool handshake() const
    {
        c_driver *self = const_cast<c_driver *>(this);
        if (self->hs_ok_)    return true;
        if (self->hs_tried_) return false;

        /* 先在本地把五层格式核一遍，格式不对就不必去内核白跑 */
        {
            const char *why = "";
            unsigned bad = key_layers_check(&why);
            if (bad) {
                key_report(why, bad);
                self->hs_tried_ = true;
                return false;
            }
        }

        self->hs_tried_ = true;
        self->hs_in_    = true;

        /* 三个版本常量是否自洽（本文件独有的一道自检） */
        {
            char want[32];
            if (!version_consistent(want, sizeof(want))) {
                fprintf(stderr,
                    "\n========== 欢愉：本文件版本常量自相矛盾 ==========\n"
                    "  HY_VERSION_STRING = %s\n"
                    "  HY_VER_MAJOR.MINOR.PATCH 推导出来应是 = %s\n"
                    "  两者不等，内核会按字符串比对并拒绝握手。\n"
                    "  请把三处改成同一个版本（当前内核：见 dmesg | grep huanyu）。\n"
                    "===================================================\n\n",
                    HY_VERSION_STRING, want);
                self->hs_in_  = false;
                self->hs_res_ = HY_HS_BAD_VER;
                return false;
            }
        }

        self->hs_ver_ok_ = 0;
        self->hs_key_ok_ = 0;

        /* ============================================================
         * 第 1 步 HY_HS_STEP_REQ：自报版本号，取回挑战密文
         * 第 2 步 HY_HS_STEP_ANS：本地解开后把明文送回去
         *
         * 五层密钥全程只在本进程参与运算，一次都不发给内核。
         * ============================================================ */
        {
            hy_handshake_req r;
            unsigned char ans[HY_CHAL_LEN];
            size_t i;
            long ret;

            memset(&r, 0, sizeof(r));
            r.magic      = HY_HS_MAGIC_OF(HY_HS_STEP_REQ);
            r.uver_major = HY_VER_MAJOR;
            r.uver_minor = HY_VER_MINOR;
            snprintf(r.uver_str, sizeof(r.uver_str), "%s", HY_VERSION_STRING);

            if (self->prctl_ok_)
                ret = hy_detail::hy_prctl(HY_NR_HANDSHAKE, &r);
            else
                ret = self->call(HY_NR_HANDSHAKE, &r, (uint32_t)sizeof(r));

            /* 【必须在这里落地，不能漏】
             * 内核把 uver_str 这个入参缓冲区覆写成它自己的版本（零 ABI
             * 变更，见 hy_gate.c 说明）。漏掉这三行的后果不是"少显示一
             * 个版本号"，而是启动横幅与失败诊断全部失真：
             *   - kver_got_ 恒 false → 横幅第一行永远打印"huanyu未加载"，
             *     哪怕模块好好地在（体检里能从 /proc/Huanyu 读到版本）；
             *   - hs_ver_ok_ 恒 false → 横幅第二行走错分支，握手明明成功
             *     也会打印"版本不同 —— 禁止运行"；
             *   - 下面两条失败诊断里的"内核态版本"打印出来是空串。
             * kver_got_ 只在调用本身成功时才置位：通道都没回应，就谈不
             * 上"问到了版本"，此时按未加载处理才是如实上报。
             */
            self->hs_ver_ok_ = (r.lock_ver != 0);
            snprintf(self->kver_, sizeof(self->kver_), "%s", r.uver_str);
            self->kver_got_  = (ret == 0);

            if (ret != 0 || !r.lock_ver) {
                self->hs_in_ = false;
                self->hs_ok_ = false;
                self->hs_key_ok_ = 0;
                fprintf(stderr,
                    "\n========== 欢愉握手失败（取挑战失败）==========\n"
                    "  内核态版本：%s  用户态版本：%s\n"
                    "==============================================\n\n",
                    self->kver_, HY_VERSION_STRING);
                return false;
            }

            /* 密文是二进制、可能含 0x00，按 HY_CHAL_LEN 定长取，不按字符串 */
            for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
                ans[i] = (unsigned char)r.key[i];

            chal_decrypt(ans, (size_t)HY_CHAL_LEN);

            /* ===== 第 2 步 HY_HS_STEP_ANS：把解出来的明文送回去 ===== */
            memset(&r, 0, sizeof(r));
            r.magic      = HY_HS_MAGIC_OF(HY_HS_STEP_ANS);
            r.uver_major = HY_VER_MAJOR;
            r.uver_minor = HY_VER_MINOR;
            snprintf(r.uver_str, sizeof(r.uver_str), "%s", HY_VERSION_STRING);
            for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
                r.key[i] = (char)ans[i];
            r.key[HY_CHAL_LEN] = 0;

            /* 明文用完就抹，栈上不留 */
            for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
                ans[i] = 0;

            if (self->prctl_ok_)
                ret = hy_detail::hy_prctl(HY_NR_HANDSHAKE, &r);
            else
                ret = self->call(HY_NR_HANDSHAKE, &r, (uint32_t)sizeof(r));

            self->hs_res_    = r.result;
            self->hs_key_ok_ = (r.lock_key != 0);

            if (r.locked) {
                self->hs_in_  = false;
                self->hs_ok_  = true;
                return true;
            }

            self->hs_in_ = false;
            self->hs_ok_ = false;

            fprintf(stderr,
                "\n========== 欢愉握手失败，全部功能已禁用 ==========\n"
                "  内核态版本：%s\n"
                "  用户态版本：%s  (major=%d minor=%d)\n"
                "  版本一致  ：%s\n"
                "  挑战应答  ：%s\n"
                "  内核返回  ：%s\n",
                self->kver_, HY_VERSION_STRING, HY_VER_MAJOR, HY_VER_MINOR,
                self->hs_ver_ok_ ? "是" : "否",
                self->hs_key_ok_ ? "一致" : "不一致",
                hs_result_text(r.result));

            if (!self->hs_ver_ok_)
                fprintf(stderr,
                "  → 版本不一致：请把本文件的 HY_VERSION_STRING /\n"
                "    HY_VER_MAJOR / HY_VER_MINOR 改成与内核 hy.h 一致。\n");

            if (!self->hs_key_ok_) {
                fprintf(stderr,
                "  → 挑战应答与内核原文不匹配：五层密钥解错了。\n"
                "    请把本文件的 HY_KEY_L1..L5 改成与内核 hy.h 逐字节一致。\n"
                "    内核不接收密钥、也报不出是哪一层错，只能由本文件自查：\n");
                {
                    const char *why = "";
                    unsigned bad = key_layers_check(&why);
                    if (bad) key_report(why, bad);
                    else fprintf(stderr,
                        "    本文件五层格式自检通过（长度/字符集都对），\n"
                        "    所以是 **内容** 与内核不一致，请逐字符重新抄一遍。\n");
                }
            }

            fprintf(stderr,
                "  内核侧日志同样会记录本次失败（dmesg | grep huanyu）。\n"
                "===================================================\n\n");
            return false;
        }
    }

    /* 命令通道：优先 prctl（免鉴权），失败则回退 supercall */

    long do_cmd(uint32_t nr, void *payload, uint32_t len) const
    {
        c_driver *self = const_cast<c_driver *>(this);
        if (!self->hs_in_ && !self->hs_ok_ && !self->handshake())
            return -EACCES;
        if (prctl_ok_) return hy_detail::hy_prctl(nr, payload);
        return call(nr, payload, len);
    }

    long do_cmd_empty(uint32_t nr) const
    {
        if (prctl_ok_) return hy_detail::hy_prctl(nr, NULL);
        char frame[64];
        memset(frame, 0, sizeof(frame));
        frame[0] = 'H';
        memcpy(frame + 4, &nr, sizeof(nr));
        return hy_detail::sc_kpm_control(key_.c_str(), HY_MODULE_NAME,
                                         frame, frame, (long)sizeof(frame));
    }

    long call(uint32_t nr, void *payload, uint32_t len) const
    {
        c_driver *self = const_cast<c_driver *>(this);
        if (!self->hs_in_ && !self->hs_ok_ && !self->handshake())
            return -EACCES;

        if (len > 0 && (!payload || (uint32_t)(HY_FRAME_HDR + len) > (uint32_t)HY_FRAME_MAX))
            return -EINVAL;

        char frame[HY_FRAME_MAX];
        memset(frame, 0, sizeof(frame));
        frame[0] = 'H';                     /* tag，保证 strlen >= 1 */
        memcpy(frame + 4, &nr, sizeof(nr));
        uint32_t rsv = 0;
        memcpy(frame + 8, &rsv, sizeof(rsv));
        if (len > 0) memcpy(frame + HY_FRAME_HDR, payload, len);

        long ret = hy_detail::sc_kpm_control(key_.c_str(), HY_MODULE_NAME,
                                             frame, frame, (long)sizeof(frame));
        if (ret >= 0 && len > 0)
            memcpy(payload, frame + HY_FRAME_HDR, len);
        return ret;
    }

    long call_empty(uint32_t nr) const
    {
        char frame[64];
        memset(frame, 0, sizeof(frame));
        frame[0] = 'H';
        memcpy(frame + 4, &nr, sizeof(nr));
        return hy_detail::sc_kpm_control(key_.c_str(), HY_MODULE_NAME,
                                         frame, frame, (long)sizeof(frame));
    }

    template <typename T>
    long call_obj(uint32_t nr, T &o) const { return call(nr, &o, (uint32_t)sizeof(T)); }

    template <typename T>
    long do_cmd_obj(uint32_t nr, T &o) const
    {
        c_driver *self = const_cast<c_driver *>(this);
        if (!self->hs_in_ && !self->hs_ok_ && !self->handshake())
            return -EACCES;

        /*
         * 通道优先级：共享内存 > prctl > supercall
         * 共享内存最快（零 syscall、零拷贝），但需要已建立映射。
         */
        if (daemon_fd_ >= 0) return self->daemon_cmd_obj(nr, o);
        if (shm_ok_ && sizeof(T) <= HY_SHM_PAYLOAD)
            return self->shm_cmd_obj(nr, o);
        if (prctl_ok_) return hy_detail::hy_prctl(nr, &o);
        return call_obj(nr, o);
    }

    /* 文本命令通道：与 echo '<cmd>' > /proc/HuanyuD 完全等价 */
    std::string do_cmd_str(const std::string &cmd) const
    {
        hy_dbg_req r{};
        std::string c = cmd.size() >= sizeof(r.cmd)
                      ? cmd.substr(0, sizeof(r.cmd) - 1) : cmd;
        std::memcpy(r.cmd, c.c_str(), c.size() + 1);
        r.cmd_len = (uint32_t)c.size();

        if (do_cmd_obj(HY_NR_DBG_CMD, r) != 0) return std::string();

        r.out[sizeof(r.out) - 1] = 0;
        return std::string(r.out);
    }

    /*
     * 兜底：解析 /proc/pid/maps。
     *
     * 【性能优化 v1.17.0】原来每次调 getModuleBase 都要
     * fopen + 逐行扫描整个 maps（大进程可达数千行）+ fclose。
     * 而模块基址在一次会话里是**不变的**，反复解析纯属浪费。
     * 现在缓存 (pid, 名字) -> base，命中直接返回。
     */
    struct base_cache_ent {
        int       pid;
        char      name[128];
        uintptr_t base;
    };
    mutable base_cache_ent base_cache_[8] = {};
    mutable int base_cache_n_ = 0;

    uintptr_t base_cached(const char *name) const
    {
        for (int i = 0; i < base_cache_n_; i++) {
            if (base_cache_[i].pid == pid_ &&
                strncmp(base_cache_[i].name, name, sizeof(base_cache_[i].name)) == 0)
                return base_cache_[i].base;
        }
        return 0;
    }

    void base_store(const char *name, uintptr_t base) const
    {
        int slot;
        if (base_cache_n_ < 8) {
            slot = base_cache_n_++;
        } else {
            slot = 7;                       /* 满了就覆盖最后一个（简单 LRU 近似） */
            for (int i = 0; i < 7; i++) base_cache_[i] = base_cache_[i + 1];
        }
        base_cache_[slot].pid = pid_;
        snprintf(base_cache_[slot].name, sizeof(base_cache_[slot].name), "%s", name);
        base_cache_[slot].base = base;
    }

    uintptr_t base_via_maps(const char *name) const
    {
        uintptr_t cached;

        if (pid_ <= 0 || !name) return 0;

        cached = base_cached(name);
        if (cached) return cached;

        {
            char path[256];
            snprintf(path, sizeof(path), "/proc/%d/maps", pid_);
            FILE *fp = fopen(path, "r");
            if (!fp) return 0;

            char line[512];
            uintptr_t base = 0;
            size_t nlen = strlen(name);

            while (fgets(line, sizeof(line), fp)) {
                char *p = strstr(line, name);
                if (!p) continue;
                /* r-xp 才是可执行段；只认文件名部分（行尾） */
                if (strncmp(p + nlen, ".so", 3) != 0 && p[nlen] != '\n' && p[nlen] != '\0') {
                    /* 可能是路径的一部分（如 /lib/xx.so），继续看是否行尾 */
                    if (p[nlen] != ' ') continue;
                }
                if (!strstr(line, "r-xp")) continue;
                {
                    unsigned long long s = 0;
                    if (sscanf(line, "%llx-", &s) == 1) { base = (uintptr_t)s; break; }
                }
            }
            fclose(fp);
            if (base) base_store(name, base);
            return base;
        }
    }

    /* pid 变了要清缓存 */
    void base_cache_clear() const { base_cache_n_ = 0; }

public:

    /* ======================================================================
     * 【v1.67.0】版本 / 密钥握手闸门
     * ----------------------------------------------------------------------
     *  内核要求：用户态的版本号与密钥必须和内核 hy.h 完全一致，
     *  否则拒绝执行除版本查询与握手以外的所有命令。
     *
     *  构造函数里已经自动握手过一次。这里再暴露出来，是想让你能
     *  自己挑时机、也能自己查结果 —— 用不用随意。
     * ====================================================================== */

    /* 主动握手。已握手过直接返回 true；失败会打印双方版本号。 */
    bool ensure_handshake() const { return handshake(); }

    /* 当前是否已通过握手 */
    bool handshake_ok() const { return hs_ok_; }

    /* 最近一次握手的内核结果码（HY_HS_*） */
    uint32_t handshake_result() const { return hs_res_; }

    /*
     * 清掉"已试过"标记，允许再握手一次。
     * 改完版本号或密钥后调它，下次发命令会自动重试，不用重建对象。
     */
    void reset_handshake() const
    {
        c_driver *self = const_cast<c_driver *>(this);
        self->hs_ok_    = false;
        self->hs_tried_ = false;
        self->hs_in_    = false;
        self->hs_res_   = 0;
        self->hs_layer_got_ = 0;
    }

    /*
     * 【本文件比 huanyu.hpp 多一道自检】
     * HY_VERSION_STRING 与 HY_VER_MAJOR / HY_VER_MINOR 是三个独立的手写
     * 常量，改了一个忘改另外两个，编译照样过（三者之间没有编译期约束）。
     * 内核比对用的是字符串，而 /proc 与 HY_NR_VERSION 显示的是 major/minor
     * —— 两者不一致时会出现"看上去版本对、实际握手被拒"的怪现象。
     * 所以在握手前先把三者对一遍。
     */
    bool version_consistent(char *want, size_t cap) const
    {
        char built[32];
        snprintf(built, sizeof(built), "%u.%u.%u",
                 (unsigned)HY_VER_MAJOR, (unsigned)HY_VER_MINOR,
                 (unsigned)HY_VER_PATCH);
        if (want && cap)
            snprintf(want, cap, "%s", built);
        return strcmp(built, HY_VERSION_STRING) == 0;
    }

    /* 一行人话说明当前闸门状态 */
    const char *handshake_text() const
    {
        if (hs_ok_)    return "已握手：挑战-响应通过，版本与密钥均与内核一致，命令正常放行";
        if (!hs_tried_) return "未握手：尚未向内核自报版本号并完成挑战-响应";
        switch (hs_res_) {
        case HY_HS_BAD_MAGIC: return "握手失败：magic 不匹配";
        case HY_HS_BAD_VER:   return "握手失败：版本与内核不一致，命令已禁用";
        case HY_HS_BAD_KEY:   return "握手失败：挑战应答与内核原文不一致（五层密钥解错），命令已禁用";
        case HY_HS_BAD_BOTH:  return "握手失败：版本与挑战应答都不一致，命令已禁用";
        case HY_HS_NO_CHAL:   return "握手失败：还没请求挑战就提交应答 —— 请确认对接文件是 v1.71.0 及以上的挑战-响应版";
        case HY_HS_DONE:      return "已握手：两步都过，命令正常放行";
        default:              return "握手失败：内核拒绝，命令已禁用";
        }
    }

    /* ==================================================================
     * 【v1.18.0】lsdriver 能力移植
     * ================================================================== */

    /* ---- syscall 监控 ---- */

    /* 加入/移除监控目标（ls 原版上限也是 8 个进程） */
    bool sysmon_set(int pid, bool enable = true)
    {
        hy_sysmon_req r{};
        r.pid = pid;
        r.enable = enable ? 1u : 0u;
        return do_cmd_obj(HY_NR_SYSMON_SET, r) == 0;
    }

    bool sysmon_remove(int pid)
    {
        hy_sysmon_req r{};
        r.pid = pid;
        r.enable = 0;
        return do_cmd_obj(HY_NR_SYSMON_REMOVE, r) == 0;
    }

    /*
     * 读取 syscall 记录。
     * 每条记录含：序号、pid、syscall 号、前 3 个参数、返回值。
     */
    std::vector<hy_sysmon_entry> sysmon_read(size_t max_items = 128,
                                             bool clear = false)
    {
        std::vector<hy_sysmon_entry> out;
        if (!initialized_ || max_items == 0) return out;

        out.resize(max_items);
        hy_sysmon_read r{};
        r.buf_ptr  = (uint64_t)(uintptr_t)out.data();
        r.max_count = (uint32_t)max_items;
        r.clear    = clear ? 1u : 0u;

        if (do_cmd_obj(HY_NR_SYSMON_READ, r) != 0) { out.clear(); return out; }
        out.resize(r.nr_read);
        return out;
    }

    /* ---- CNTVCT 读取监控 ---- */

    /*
     * 监控目标进程读取 CNTVCT_EL0。
     *
     * 原理：切到目标进程时清除 CNTKCTL_EL1.EL0VCTEN，
     * 使 EL0 读 CNTVCT 陷入内核，由内核已有的模拟函数兜底，
     * 因此被监控进程的行为不变，只是每次读取都被计数。
     *
     * 注意：若内核没有 cntvct_read_handler，内核侧会拒绝启用
     * （否则目标进程读 CNTVCT 会 SIGILL 崩溃）。
     */
    bool cntvct_set(int pid, bool enable = true)
    {
        hy_cntvct_req r{};
        r.pid = pid;
        r.enable = enable ? 1u : 0u;
        return do_cmd_obj(HY_NR_CNTVCT_SET, r) == 0;
    }

    bool cntvct_remove(int pid)
    {
        hy_cntvct_req r{};
        r.pid = pid;
        r.enable = 0;
        return do_cmd_obj(HY_NR_CNTVCT_REMOVE, r) == 0;
    }

    /* 返回被拦截的读取次数 */
    uint64_t cntvct_read(bool clear = false)
    {
        hy_cntvct_read r{};
        r.clear = clear ? 1u : 0u;
        if (do_cmd_obj(HY_NR_CNTVCT_READ, r) != 0) return 0;
        return r.count;
    }

    /* ---- 虚拟定位 GNSS ---- */

    /*
     * 设置虚拟坐标。单位是 e7（度 × 1e7）。
     *   纬度 39.9042 度 -> 399042000
     *   经度 116.4074 度 -> 1164074000
     *
     * 原理：hook ioctl，拦截 BINDER_WRITE_READ，
     * 在 Parcel 里按 Location.writeToParcel() 的布局
     * 定位 latitude/longitude 两个 double 并改写。
     * 与 ls 原版同款。
     */
    bool gnss_set(int32_t lat_e7, int32_t lon_e7)
    {
        hy_gnss_req r{};
        r.latitude_e7  = lat_e7;
        r.longitude_e7 = lon_e7;
        r.enable = 1;
        return do_cmd_obj(HY_NR_GNSS_REPORT, r) == 0;
    }

    /* 度 -> e7 的小工具 */
    static int32_t deg_to_e7(double deg)
    {
        return (int32_t)(deg * 10000000.0);
    }

    bool gnss_set_deg(double lat, double lon)
    {
        return gnss_set(deg_to_e7(lat), deg_to_e7(lon));
    }

    bool gnss_stop()
    {
        hy_gnss_req r{};
        r.enable = 0;
        return do_cmd_obj(HY_NR_GNSS_STOP, r) == 0;
    }

    hy_gnss_status gnss_status()
    {
        hy_gnss_status st{};
        do_cmd_obj(HY_NR_GNSS_REPORT, st);
        return st;
    }

    /* ---- 增强枚举 ---- */

    std::vector<hy_seg_info> enum_segments(int pid, uint64_t module_base = 0,
                                           size_t max_items = 512)
    {
        std::vector<hy_seg_info> out;
        if (!initialized_ || max_items == 0) return out;
        out.resize(max_items);
        hy_enum_segs_req r{};
        r.pid = pid;
        r.module_base = module_base;
        r.buf_ptr = (uint64_t)(uintptr_t)out.data();
        r.max_count = (uint32_t)max_items;
        if (do_cmd_obj(HY_NR_ENUM_SEGMENTS, r) != 0) { out.clear(); return out; }
        out.resize(r.nr_written);
        return out;
    }

    /*
     * 可扫描区域： rw-p 且排除过小/过大的段。
     * 对应 ls 的 regions（用于内存扫描改数值）。
     */
    std::vector<hy_region_info> enum_regions(int pid, size_t max_items = 4096)
    {
        std::vector<hy_region_info> out;
        if (!initialized_ || max_items == 0) return out;
        out.resize(max_items);
        hy_enum_regions_req r{};
        r.pid = pid;
        r.buf_ptr = (uint64_t)(uintptr_t)out.data();
        r.max_count = (uint32_t)max_items;
        if (do_cmd_obj(HY_NR_ENUM_REGIONS, r) != 0) { out.clear(); return out; }
        out.resize(r.nr_written);
        return out;
    }

    /* ---- 单步断点 ---- */
    bool stepbp_set(int pid, uint64_t addr)
    {
        hy_stepbp_req r{};
        r.pid = pid; r.addr = addr; r.enable = 1;
        return do_cmd_obj(HY_NR_STEPBP_SET, r) == 0;
    }

    bool stepbp_remove(int pid, uint64_t addr)
    {
        hy_stepbp_req r{};
        r.pid = pid; r.addr = addr; r.enable = 0;
        return do_cmd_obj(HY_NR_STEPBP_REMOVE, r) == 0;
    }

    /* ---- DPT 主线程影子页 ---- */

    /*
     * 只有主线程命中断点，其他线程不受影响。
     *
     * 说明：ls 原版是给主线程建**私有影子 PGD**（换页表）；
     * 欢愉是 KPM，拿不到 struct page / mmu_notifier，
     * 改用等价实现——在上下文切换时切 PTE。
     * 对外行为一致，机制不同。
     */
    bool dpt_set(int pid, uint64_t addr)
    {
        hy_dpt_req r{};
        r.pid = pid; r.addr = addr; r.enable = 1;
        return do_cmd_obj(HY_NR_DPT_SET, r) == 0;
    }

    bool dpt_remove(int pid, uint64_t addr)
    {
        hy_dpt_req r{};
        r.pid = pid; r.addr = addr; r.enable = 0;
        return do_cmd_obj(HY_NR_DPT_REMOVE, r) == 0;
    }

    /* ---- 扩展能力 ---- */
    hy_hwcap2 hwcap2()
    {
        hy_hwcap2 c{};
        do_cmd_obj(HY_NR_HWCAP2, c);
        return c;
    }

    /* ---- GPU 隐藏 ---- */
    bool kgsl_hide(bool enable = true)
    {
        hy_kgsl_req r{};
        r.enable = enable ? 1u : 0u;
        return do_cmd_obj(enable ? HY_NR_KGSL_HIDE_SET : HY_NR_KGSL_HIDE_CLEAR, r) == 0;
    }

    /* ---- 触摸移动（补齐 ls 的 touch_move）---- */
    bool touch_move(int slot, int x, int y)
    {
        if (!initialized_) return false;
        hy_touch_event_base t{};
        t.slot = slot; t.x = x; t.y = y;
        return do_cmd_obj(HY_NR_TOUCH_MOVE, t) == 0;
    }

    /* 触摸配置：屏幕分辨率 + 虚拟手指起始槽位。
       必须先调用它，否则自建设备默认按 1080x2400 上报坐标。 */
    bool touch_setup(int max_x, int max_y, int slot_base = 5) const
    {
        struct hy_touch_setup ts = {};
        ts.max_x = max_x;
        ts.max_y = max_y;
        ts.slot_base = slot_base;
        return do_cmd_obj(HY_NR_TOUCH_SETUP, ts) == 0;
    }

    /* 陀螺仪（新 ABI）：mrad/s，走 sendto hook 改写 ASensorEvent */
    bool gyro_set(int x_mrad, int y_mrad, int z_mrad = 0) const
    {
        struct hy_gyro_vec v = {};
        v.x = x_mrad;
        v.y = y_mrad;
        v.z = z_mrad;
        return do_cmd_obj(HY_NR_GYRO_SET, v) == 0;
    }

    /* ---- 进程环境参数 ---- */
    hy_env_params env_params(int pid)
    {
        hy_env_params ep{};
        ep.pid = pid;
        do_cmd_obj(HY_NR_ENV_PARAMS, ep);
        return ep;
    }

    /* ---- 综合状态：一眼看清所有 ls 移植功能 ---- */
    hy_ls_status ls_status()
    {
        hy_ls_status st{};
        do_cmd_obj(HY_NR_LS_STATUS, st);
        return st;
    }

    /* ---------------- 生命周期 ---------------- */

    /*
     * 免密钥构造。
     *   c_driver drv;              默认
     *   c_driver drv("真实密钥");   设了自定义超级密钥时用
     *   c_driver drv("su", false); 不探测
     */
    explicit c_driver(const char *key = HUANYU_NO_KEY, bool probe = true)
        : key_((key && key[0]) ? key : HUANYU_NO_KEY)
    {
        if (!probe) { initialized_ = true; return; }

        hy_link_report rep = probe_link();
        prctl_ok_ = rep.prctl_ok;
        authed_   = rep.sc_authed;

        /*
         * 【v1.67.0】握手必须排在一切功能命令之前。
         * 原先这里直接发 HY_NR_BP_CHECK_INITED，而那个命令在未握手时
         * 会被内核闸门拦掉（返回 -EACCES），于是明明链路正常
         * 却判定初始化失败。现在先握手，握手结果一并打印。
         */
        if (rep.prctl_ok) {
            (void)handshake();
            initialized_ = true;
            print_boot_banner();
            print_link_report(rep);
            return;
        }
        if (rep.sc_ok && rep.sc_authed) {
            if (handshake()) {
                long rc = do_cmd_empty(HY_NR_BP_CHECK_INITED);
                if (rc == 0) {
                    initialized_ = true;
                    print_boot_banner();
                    print_link_report(rep);
                    return;
                }
            }
        }
        print_boot_banner();
        print_link_report(rep);
    }

    /* ==================================================================
     * 【v1.68.0】启动状态两行
     *
     *   第一行  huanyu已加载 / 未加载
     *           已加载就在后面带上内核版本号与当前用户态版本号。
     *   第二行  内核对用户态发过去的 key 的判定结果。
     *
     * 判定"加载"用"能不能问出内核版本"：版本查询是闸门放行的少数命令
     * 之一，能答上来就说明 kpm 在、也接得上；答不上来就是没加载。
     * 这样即使版本或密钥对不上被禁用了，第一行依然如实报告"已加载"。
     *
     * 【密钥不落日志】这里一个字符都不打印。内核侧同样只说"不同"，
     * 原因见 hy_gate.c：dmesg / pstore 整机可读，那把钥匙一旦写进去
     * 就等于公开。要看自己这侧的钥匙，用 key_report()。
     * ================================================================== */
    /* 只读一次 /proc/Huanyu 的 version 行，用来独立判断"模块在不在"。
       握手通道走不通时它是唯一可信的旁证，避免横幅与体检互相打脸。 */
    void probe_modver() const
    {
        FILE *f = fopen("/proc/Huanyu", "rb");
        if (!f) f = fopen("/proc/huanyu", "rb");
        if (!f) return;
        char line[512];
        while (fgets(line, sizeof(line), f)) {
            if (strncmp(line, "version", 7)) continue;
            const char *c = strchr(line, ':');
            if (!c) continue;
            c++;
            while (*c == ' ' || *c == '\t') c++;
            size_t n = 0;
            while (c[n] && c[n] != '\n' && c[n] != ' ' && c[n] != '\r' && n < 31) n++;
            if (!n) continue;
            memcpy(modver_, c, n);
            modver_[n] = 0;
            modver_got_ = true;
            break;
        }
        fclose(f);
    }

    void print_boot_banner() const
    {
        if (!kver_got_) {
            probe_modver();
            if (modver_got_) {
                printf("huanyu已加载  内核版本 %s   当前用户态版本 %s\n",
                       modver_, HY_VERSION_STRING);
                printf("当前用户态key未校验 —— 握手未发起或版本不符，禁止运行\n");
                fflush(stdout);
                return;
            }
            printf("huanyu未加载  当前用户态版本 %s\n", HY_VERSION_STRING);
            printf("当前用户态key未校验 —— huanyu 未加载，禁止运行\n");
            fflush(stdout);
            return;
        }

        printf("huanyu已加载  内核版本 %s   当前用户态版本 %s\n",
               kver_[0] ? kver_ : "(未知)", HY_VERSION_STRING);

        if (!hs_key_ok_) {
            printf("当前用户态key和huanyu不同 —— 禁止运行"
               "（挑战应答与内核原文不匹配，五层密钥解错）\n");
        } else if (!hs_ver_ok_) {
            printf("当前用户态key和huanyu一致，但版本不同"
                   "（内核 %s / 用户态 %s）—— 禁止运行\n",
                   kver_[0] ? kver_ : "(未知)", HY_VERSION_STRING);
        } else {
            printf("当前用户态key和huanyu一致 —— 允许运行（挑战-响应通过）\n");
        }
        fflush(stdout);
    }

    /* ======================================================================
     * 【链路体检】逐项探测三条通道与环境，不依赖任何一次探测的结果
     * ====================================================================== */
    hy_link_report probe_link() const
    {
        hy_link_report r{};

        /* ---- 1. KernelPatch 在不在 + 版本号 ----
         * KERNELPATCH_VER(0x1008) 在鉴权门槛之前，只要 trusted_caller 就返回
         * kpver，与 key 对不对无关 —— 正好用来查版本。
         */
        errno = 0;
        r.kp_ver = hy_detail::sc_kp_ver(key_.c_str());
        r.sc_errno = errno;
        r.kp_present = (r.kp_ver > 0);
        r.sc_ok      = r.kp_present;
        /* 必须记下真实返回值：否则体检里会打出 "ret=0 errno=1" 这种自相矛盾
           的一行（0 看着像成功，实际是没赋值的初值）。*/
        r.sc_ret = r.kp_ver;

        /* ---- 1b. 鉴权单独判 ----
         * KPM_NUMS(0x1030) 位于门槛之后的第二个 switch：未鉴权则内核直接
         * return -EPERM，成功返回已加载 kpm 数量（>=0）。
         */
        errno = 0;
        long kpm_nums = hy_detail::sc_authed(key_.c_str());
        (void)kpm_nums;
        r.sc_authed = (kpm_nums >= 0);
        if (!r.kp_present && r.sc_authed) r.kp_present = true;

        /* ---- 2. 内核版本 ---- */
        errno = 0;
        r.kern_ver = hy_detail::sc_kernel_ver(key_.c_str());

        /* ---- 3. prctl 免密钥通道 ----
         * 【v1.67.0 必须用 HY_NR_VERSION 探测】
         * 探测发生在握手之前，此时内核闸门只放行 HY_NR_VERSION 与
         * HY_NR_HANDSHAKE 两个号。若沿用 BP_CHECK_INITED，内核一律
         * 返回 -EACCES，探测会把一条完全正常的 prctl 通道误判为不可用，
         * 进而退回 supercall —— 没设超级密钥时就彻底连不上。
         */
        errno = 0;
        uint32_t kv[4];
        memset(kv, 0, sizeof(kv));
        long pr = hy_detail::hy_prctl(HY_NR_VERSION, kv);
        r.prctl_ret   = pr;
        r.prctl_errno = errno;
        r.prctl_ok    = (pr == 0 && kv[0] == HY_MAGIC);

        /* prctl 能返回 0 且带回 HY_MAGIC，只可能是 KernelPatch 的 hook 拦
           下了这个号——这本身就是"KP 在"的铁证。上面第 1 步只看 supercall
           鉴权，设备没设超级密钥时会把它误判成"KP 不在"，于是报告里出现
           "KernelPatch 不在"和"结论已连通"并存的矛盾。这里补上推断。*/
        if (r.prctl_ok && !r.kp_present) {
            r.kp_present = true;
            r.kp_ver     = 0;   /* 版本未知：不走 supercall 问不出来 */
        }

        /* ---- 4. 共享内存通道 ---- */
        r.shm_ok = (shm_mem_ != nullptr) && shm_ok_;

        /* ---- 5. 模块版本（读 /proc/Huanyu 尾部 version 行） ---- */
        {
            FILE *f = fopen("/proc/Huanyu", "rb");
            if (!f) f = fopen("/proc/huanyu", "rb");
            if (f) {
                char line[512];
                while (fgets(line, sizeof(line), f)) {
                    if (!strncmp(line, "version", 7)) {
                        const char *c = strchr(line, ':');
                        if (c) {
                            c++;
                            while (*c == ' ' || *c == '\t') c++;
                            size_t n = 0;
                            while (c[n] && c[n] != '\n' && c[n] != ' ' && n < 31) n++;
                            memcpy(r.mod_version, c, n);
                            r.mod_version[n] = 0;
                        }
                    }
                }
                fclose(f);
            } else {
                snprintf(r.mod_version, sizeof(r.mod_version), "(procfs 不可读)");
            }
        }

        /* ---- 6. 下结论 ---- */
        if (r.prctl_ok || (r.sc_ok && r.sc_authed)) {
            r.linked  = true;
            r.verdict = HY_LINK_OK;
            snprintf(r.reason, sizeof(r.reason), "已连通（%s）",
                     r.prctl_ok ? "prctl 免密钥通道" : "supercall 通道");
            snprintf(r.advice, sizeof(r.advice), "无需额外操作");
            return r;
        }

        if (!r.kp_present) {
            long hello = hy_detail::sc_hello(key_.c_str());
            if (hello == SUPERCALL_HELLO_MAGIC) {
                r.verdict = HY_LINK_BAD_KEY;
                snprintf(r.reason, sizeof(r.reason),
                         "KernelPatch 在，但密钥 \"%s\" 过不了鉴权门槛", key_.c_str());
                snprintf(r.advice, sizeof(r.advice),
                         "设备设了自定义超级密钥：c_driver drv(\"你的真实密钥\");");
            } else {
                r.verdict = HY_LINK_NO_KP;
                snprintf(r.reason, sizeof(r.reason),
                         "KernelPatch / APatch 未生效（HELLO 也不通）");
                snprintf(r.advice, sizeof(r.advice),
                         "先确认 KP 已刷入并成功 patch 了 boot 镜像");
            }
            return r;
        }

        if (r.prctl_errno == EINVAL) {
            r.verdict = HY_LINK_NO_MODULE;
            snprintf(r.reason, sizeof(r.reason),
                     "欢愉模块未加载（prctl 返回 EINVAL，hook 未生效）");
            snprintf(r.advice, sizeof(r.advice),
                     "用 APatch/KP 管理器加载 huanyu_*.kpm 后再试");
            return r;
        }

        r.verdict = HY_LINK_NO_CHANNEL;
        snprintf(r.reason, sizeof(r.reason),
                 "两条通道都不通：prctl(ret=%ld errno=%d) supercall(ret=%ld)",
                 r.prctl_ret, r.prctl_errno, r.sc_ret);
        snprintf(r.advice, sizeof(r.advice),
                 "检查 SELinux 是否为 permissive，以及 KPM 是否加载成功");
        return r;
    }

    /* 打印体检报告 */
    static void print_link_report(const hy_link_report &r)
    {
        printf("========== 欢愉链路体检 ==========\n");
        printf(" [通道] prctl    : %s", r.prctl_ok ? "可用（免密钥）" : "不可用");
        printf("   (ret=%ld errno=%d%s%s)\n", r.prctl_ret, r.prctl_errno,
               r.prctl_errno ? " " : "", r.prctl_errno ? strerror(r.prctl_errno) : "");
        printf(" [通道] supercall: %s", r.sc_authed ? "可用（鉴权通过）"
                                     : (r.sc_ok ? "通但鉴权失败" : "不可用"));
        printf("   (ret=%ld errno=%d)\n", r.sc_ret, r.sc_errno);
        if (!r.sc_authed && r.prctl_ok)
            printf("          ↳ 免密钥通道已通，supercall 不可用不影响使用"
                   "（未设自定义超级密钥时的正常现象）\n");
        printf(" [通道] shm      : %s\n", r.shm_ok ? "已建立" : "未建立（可选）");
        printf(" [环境] KernelPatch : %s", r.kp_present ? "在" : "不在");
        if (r.kp_present) {
            char vs[32] = {0};
            hy_detail::kp_ver_str(r.kp_ver, vs, sizeof(vs));
            printf("  ver=%s", vs);
            if (!r.kp_ver) printf("  (版本未知，由 prctl 通道可证)");
        }
        printf("\n");
        printf(" [环境] 内核版本     : %s\n",
               r.kern_ver > 0 ? format_kver(r.kern_ver).c_str() : "未知");
        printf(" [环境] 欢愉模块     : %s\n", r.mod_version);
        printf(" ------------------------------------\n");
        if (r.linked) {
            printf(" [结论] %s  —— %s\n", r.reason, r.advice);
        } else {
            printf(" [结论] 未连通 (code=%d)\n", r.verdict);
            printf("         原因 : %s\n", r.reason);
            printf("         建议 : %s\n", r.advice);
        }
        printf("==================================\n");
    }

    /* 内核版本编码 -> 字符串 */
    static std::string format_kver(long v)
    {
        if (v <= 0) return std::string("未知");
        char b[64];
        snprintf(b, sizeof(b), "%lu.%lu.%lu (0x%08lx)",
                 (unsigned long)((v >> 16) & 0xff),
                 (unsigned long)((v >> 8) & 0xff),
                 (unsigned long)(v & 0xff),
                 (unsigned long)v);
        return std::string(b);
    }

    /* 对外：随时体检一次 */
    hy_link_report link_report() const { return probe_link(); }
    void           link_dump()   const { print_link_report(probe_link()); }


    explicit c_driver(const std::string &key, bool probe = true)
        : c_driver(key.c_str(), probe) {}

    ~c_driver() = default;

    bool is_ready()      const { return initialized_; }
    bool is_authed()     const { return authed_; }
    bool kernelpatch_ready() const { return hy_detail::sc_ready(key_.c_str()); }
    int  get_fd()        const { return fd_; }

    bool set_key(const char *k)
    {
        key_ = (k && k[0]) ? k : HUANYU_NO_KEY;
        authed_ = hy_detail::sc_key_ok(key_.c_str());
        initialized_ = authed_ && (do_cmd_empty(HY_NR_BP_CHECK_INITED) == 0);
        return authed_;
    }

    /* ---------------- 共享内存通道 ---------------- */

    /*
     * 建立共享区。成功返回 true。
     * 必须在 initialize() 之前或之后都可以，但建议尽早。
     */
    bool shm_init()
    {
        if (shm_mem_) return shm_ok_;

        size_t len = HY_SHM_SIZE;
        long ps = sysconf(_SC_PAGESIZE);
        if (ps > 0) len = ((len + (size_t)ps - 1) / (size_t)ps) * (size_t)ps;

        /*
         * 【ls 同款：固定地址】
         * 必须 mmap 到 HY_SHM_FIXED_VA (0x2025827000)，
         * 内核的连接线程扫描到目标进程名后直接 GUP 这个地址。
         * 不用发任何注册命令 —— 靠地址 + 进程名握手。
         */
        void *want = (void *)(uintptr_t)HY_SHM_FIXED_VA;
        void *p = mmap(want, len, PROT_READ | PROT_WRITE,
                       MAP_SHARED | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
        if (p == MAP_FAILED || !p) {
            printf("[-] 欢愉 shm: mmap 失败\n");
            return false;
        }
        if ((uintptr_t)p != HY_SHM_FIXED_VA) {
            printf("[-] 欢愉 shm: 地址不符 got=%p want=0x%llx\n",
                   p, (unsigned long long)HY_SHM_FIXED_VA);
            munmap(p, len);
            shm_mem_ = nullptr;
            return false;
        }

        shm_mem_ = p;
        shm_len_ = len;
        shm_ = (struct hy_shm_obj *)p;

        memset(p, 0, len);
        shm_->magic   = HY_SHM_MAGIC;
        shm_->version = HY_SHM_VERSION;
        shm_->shm_va  = (uint64_t)(uintptr_t)p;
        shm_->shm_size = (uint64_t)len;
        shm_->state   = HY_SHM_IDLE;

        /*
         * 【不发任何命令，纯等内核来连】
         * 内核的连接线程（hy_shmc）每 2 秒扫一次进程名，
         * 命中就 GUP 这个固定地址并写 flags |= READY。
         * 这里只等握手完成。
         *
         * 前提是：本进程的名字必须能被内核匹配到。
         * 见 shm_set_host_name()。
         */
        for (int i = 0; i < 6000; i++) {          /* 最多等 6 秒 */
            if (shm_->flags & HY_SHM_F_READY) { shm_ok_ = true; break; }
            usleep(1000);
        }

        if (!shm_ok_) {
            printf("[-] 欢愉 shm: 内核未连接（超时 6s）\n");
            printf("[-]   内核靠扫描固定地址 + magic 匹配来连，不依赖进程名。\n");
            printf("[-]   排查：dmesg | grep shm\n");
            return false;
        }

        printf("[+] 欢愉 shm 通道就绪 (固定地址 0x%llx, %zu KB)\n",
               (unsigned long long)HY_SHM_FIXED_VA, len / 1024);
        return true;

        (void)0;
    }

    bool shm_ready() const { return shm_ok_; }

    /* 通过共享内存提交一条命令。payload 大小 <= HY_SHM_PAYLOAD */
    long shm_cmd(uint32_t nr, void *payload, uint32_t len)
    {
        if (!shm_ok_ || !shm_) return -ENODEV;
        if (len > HY_SHM_PAYLOAD) return -EINVAL;

        /* 等上一轮完成 */
        for (int i = 0; i < 5000; i++) {
            if (shm_->state == HY_SHM_IDLE) break;
            if (i > 100) usleep(100);
        }
        if (shm_->state != HY_SHM_IDLE) return -EBUSY;

        if (len > 0 && payload) memcpy(shm_->payload, payload, len);

        uint32_t seq = ++shm_seq_;
        shm_->nr   = nr;
        shm_->len  = len;
        shm_->ret  = 0;
        shm_->ack  = 0;
        shm_->seq  = seq;
        shm_->state = HY_SHM_REQ;

        /* 等内核完成 */
        for (int i = 0; i < 20000; i++) {
            if (shm_->ack == seq && shm_->state == HY_SHM_IDLE) break;
            if (i > 2000) usleep(100);
        }

        if (shm_->ack != seq) return -ETIMEDOUT;

        if (len > 0 && payload) memcpy(payload, shm_->payload, len);
        return shm_->ret;
    }

    template <typename T>
    long shm_cmd_obj(uint32_t nr, T &o) { return shm_cmd(nr, &o, (uint32_t)sizeof(T)); }



    /* ==========================================================================
     * 守护进程模式（与 lsdriver 的 "LS" 进程同款）
     *
     *   游戏 so --(unix socket)--> huanyu_daemon --(共享内存)--> 内核
     *
     *   daemon 会把自己改名 "Huanyu"，内核按名字扫到它（ls 同款），
     *   GUP + vmap 固定地址完成握手。
     *
     *   游戏侧不需要 mmap 固定地址 —— 避免与游戏自身内存布局冲突。
     * ========================================================================== */

    bool daemon_connect(const char *sock_path = "/data/local/tmp/.huanyu_daemon_sock")
    {
        if (daemon_fd_ >= 0) return true;

        int fd = socket(AF_UNIX, SOCK_STREAM, 0);
        if (fd < 0) return false;

        struct sockaddr_un addr;
        memset(&addr, 0, sizeof(addr));
        addr.sun_family = AF_UNIX;
        strncpy(addr.sun_path, sock_path, sizeof(addr.sun_path) - 1);

        if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
            close(fd);
            return false;
        }

        daemon_fd_ = fd;
        printf("[+] 欢愉：已连接守护进程 %s\n", sock_path);
        return true;
    }

    /* 通过 daemon 提交命令 */
    long daemon_cmd(uint32_t nr, void *payload, uint32_t len)
    {
        if (daemon_fd_ < 0) return -ENODEV;
        if (len > HY_SHM_PAYLOAD) return -EINVAL;

        uint32_t hdr[2] = { nr, len };

        if (send(daemon_fd_, hdr, sizeof(hdr), 0) < 0) return -EIO;
        if (len > 0 && send(daemon_fd_, payload, len, 0) < 0) return -EIO;

        int32_t ret = 0;
        if (recv(daemon_fd_, &ret, sizeof(ret), MSG_WAITALL) != (ssize_t)sizeof(ret))
            return -EIO;

        if (len > 0) {
            uint32_t back_len = 0;
            if (recv(daemon_fd_, &back_len, sizeof(back_len), MSG_WAITALL)
                    != (ssize_t)sizeof(back_len))
                return -EIO;
            if (back_len == len &&
                recv(daemon_fd_, payload, len, MSG_WAITALL) != (ssize_t)len)
                return -EIO;
        }

        return ret;
    }

    template <typename T>
    long daemon_cmd_obj(uint32_t nr, T &o) { return daemon_cmd(nr, &o, (uint32_t)sizeof(T)); }

    /* ---------------- 原接口：初始化 ---------------- */

    void initialize(pid_t target_pid)
    {
        pid_ = target_pid;
        if (target_pid > 0) initialized_ = initialized_ || authed_;
    }

    int init_pid(pid_t target_pid) { pid_ = target_pid; return (int)target_pid; }

    /* ---------------- 原接口：PID ---------------- */

    pid_t GetPid(char *name)
    {
        if (!name) return -1;

        /* 优先走内核 */
        if (authed_) {
            hy_request r{};
            char buf[256];
            memset(buf, 0, sizeof(buf));
            strncpy(buf, name, sizeof(buf) - 1);
            r.buffer = (uint64_t)(uintptr_t)buf;
            if (do_cmd_obj(HY_NR_GET_PID, r) == 0 && r.pid > 0)
                return (pid_t)r.pid;
        }

        /* 兜底 pidof */
        char cmd[256] = "pidof ";
        strncat(cmd, name, sizeof(cmd) - strlen(cmd) - 1);
        FILE *fp = popen(cmd, "r");
        if (!fp) return -1;
        int p = -1;
        if (fscanf(fp, "%d", &p) != 1) p = -1;
        pclose(fp);
        return (pid_t)p;
    }

    pid_t get_name_pid(const char *name) { return GetPid((char *)name); }

    /* v1.22.0：按名字锁定真实触摸屏（/proc/bus/input/devices 的 Name= 字段） */
    bool touch_set_name(const char *name)
    {
        hy_touch_name n = {};
        if (!initialized_ || !name) return false;
        size_t i = 0;
        while (i + 1 < sizeof(n.name) && name[i] && name[i] != '\n') {
            n.name[i] = name[i]; i++;
        }
        n.name[i] = '\0';
        return do_cmd_obj(TOUCH_SET_NAME, n) == 0;
    }
    bool touch_rescan()
    {
        uint32_t zero = 0;
        return initialized_ && do_cmd_obj(TOUCH_RESCAN, zero) == 0;
    }
    /* 自动从 /proc/bus/input/devices 找出触摸屏名字并锁定 */
    bool touch_set_name_auto()
    {
        FILE *fp = fopen("/proc/bus/input/devices", "r");
        if (!fp) return false;
        char line[512], cur[64] = {0}, best[64] = {0};
        bool is_ts = false;
        while (fgets(line, sizeof(line), fp)) {
            if (!strncmp(line, "N: Name=", 8)) {
                const char *q = strchr(line + 8, '"');
                if (q) {
                    const char *e = strchr(q + 1, '"');
                    if (e) {
                        size_t n = (size_t)(e - q - 1);
                        if (n >= sizeof(cur)) n = sizeof(cur) - 1;
                        memcpy(cur, q + 1, n); cur[n] = '\0';
                    }
                }
                is_ts = false;
            } else if (strstr(line, "ABS_MT_POSITION_X") || strstr(line, "ABS_MT_SLOT")) {
                is_ts = true;
            } else if (!strncmp(line, "H: Handlers=", 12)) {
                if (is_ts && cur[0]) { strcpy(best, cur); break; }
                cur[0] = '\0';
            }
        }
        fclose(fp);
        return best[0] ? touch_set_name(best) : false;
    }


    /* ================= v1.73.0 secure touch inject =================
     *
     * 复用真实触摸屏、只用空闲槽位注入 —— 不新建 /dev/input 节点、
     * 不改设备能力位、绝不抢占真手指的槽位。
     * 之前这套只在内核里，用户态根本调不到，这里一次补齐。
     */

    /* 按下。x/y 为设备原始坐标。返回 0 成功；-EBUSY 表示无空闲槽位 */
    bool ti_down(int x, int y) const
    {
        struct hy_touch_event_base t{};
        t.slot = 0; t.x = x; t.y = y;
        return do_cmd_obj(HY_NR_TI_DOWN, t) == 0;
    }

    /* 移动：沿用同一个槽位，只更新坐标 */
    bool ti_move(int x, int y) const
    {
        struct hy_touch_event_base t{};
        t.slot = 0; t.x = x; t.y = y;
        return do_cmd_obj(HY_NR_TI_MOVE, t) == 0;
    }

    /* 抬起。真手指还在时不发 BTN_TOUCH=0，不会打断真实触摸 */
    bool ti_up() const { return do_cmd(HY_NR_TI_UP, nullptr, 0) == 0; }

    /* -------- v1.76.0：多指 --------
     *
     * 旧版只有一根手指（第二次 down 直接 -EBUSY）。现在每根手指有独立
     * 编号，容量由内核按 "总槽位 - 真手指占用" 动态算：
     *   0 根真手指 -> 10 根虚拟；5 根真手指 -> 5 根；6 根 -> 4 根。
     * 真手指落下时若超额，内核会自动释放多余的虚拟手指让位。
     *
     * 典型用法（多指同时压枪/连点）：
     *   ti_down_id(0, x0, y0);
     *   ti_down_id(1, x1, y1);
     *   ti_move_id(0, x0b, y0b);
     *   ti_up_id(0); ti_up_id(1);
     */

    /* 按下指定手指。id 已按着则等价于 move（幂等） */
    bool ti_down_id(int id, int x, int y) const
    {
        struct hy_ti_finger_op o{};
        o.id = id; o.x = x; o.y = y;
        return do_cmd_obj(HY_NR_TI_DOWN_ID, o) == 0;
    }

    /* 移动指定手指 */
    bool ti_move_id(int id, int x, int y) const
    {
        struct hy_ti_finger_op o{};
        o.id = id; o.x = x; o.y = y;
        return do_cmd_obj(HY_NR_TI_MOVE_ID, o) == 0;
    }

    /* 抬起指定手指 */
    bool ti_up_id(int id) const
    {
        struct hy_ti_finger_op o{};
        o.id = id; o.x = 0; o.y = 0;
        return do_cmd_obj(HY_NR_TI_UP_ID, o) == 0;
    }

    /* 抬起全部虚拟手指 */
    bool ti_up_all() const { return do_cmd(HY_NR_TI_UP_ALL, nullptr, 0) == 0; }

    /* 容量查询：cap=还能再按几根，active=已按着几根 */
    bool ti_capacity(int *cap, int *active = nullptr, int *total = nullptr) const
    {
        struct hy_ti_cap c{};
        if (do_cmd_obj(HY_NR_TI_CAPACITY, c) != 0) return false;
        if (cap)    *cap    = c.capacity;
        if (active) *active = c.active;
        if (total)  *total  = c.total_slots;
        return true;
    }

    /* 便捷入口：已按下则移动，否则按下。滑动场景用这个最省事 */
    bool ti_tap_or_drag(int x, int y) const
    {
        struct hy_ti_stat st{};
        ti_status(&st);
        if (st.state == HY_TI_ACTIVE) return ti_move(x, y);
        return ti_down(x, y);
    }

    /* 状态查询。st->protects 大于 0 说明"注入后手指被抹掉"的防护在生效 */
    bool ti_status(struct hy_ti_stat *st) const
    {
        if (!st) return false;
        struct hy_ti_stat tmp{};
        bool ok = do_cmd_obj(HY_NR_TI_STATUS, tmp) == 0;
        *st = tmp;
        return ok;
    }

    /* 手动设定总槽位数。自学习不可靠时用它纠正（比如驱动只用 slot 0） */
    bool ti_set_slots(int n) const
    {
        struct hy_ti_range r{};
        r.min_x = n; r.max_x = -1; r.min_y = -1; r.max_y = -1;
        return do_cmd_obj(HY_NR_TI_SET_SLOTS, r) == 0;
    }

    /* 显式设定坐标范围。不设的话内核默认 1080x2400 + 自学习，
     * 屏幕不是这个尺寸时必须调它，否则坐标会被钳到错的边界。 */
    bool ti_set_range(int min_x, int max_x, int min_y, int max_y) const
    {
        struct hy_ti_range r{};
        r.min_x = min_x; r.max_x = max_x; r.min_y = min_y; r.max_y = max_y;
        return do_cmd_obj(HY_NR_TI_SET_RANGE, r) == 0;
    }

    /* 读回内核当前认定的坐标范围（v1.73.1）。
     * 诊断用：想知道内核从物理驱动自学到了什么分辨率，或者自己设的值
     * 有没有真的落进去。之前只能设不能读，对不对全靠猜。 */
    bool ti_get_range(int *min_x, int *max_x, int *min_y, int *max_y) const
    {
        struct hy_ti_range r{};
        bool ok = do_cmd_obj(HY_NR_TI_GET_RANGE, r) == 0;
        if (min_x) *min_x = r.min_x;
        if (max_x) *max_x = r.max_x;
        if (min_y) *min_y = r.min_y;
        if (max_y) *max_y = r.max_y;
        return ok;
    }

    /* ---------------- v1.75.0 新增 ---------------- */

    /*
     * 强制清除残留手指。
     *
     * ti_up() 靠位图判断 keep 才决定要不要发 BTN_TOUCH=0，位图一旦有
     * 残留（比如此前为学坐标摸过屏）就不发，上层收不到"触摸结束"信号，
     * 屏幕上的圆点就永久留着。本接口不看 keep，无条件发完整抬起序列并
     * 清空位图 —— 卡住的手指用它收拾残局。
     *
     * 不受注入总闸限制：它就是应急用的，闸门关着时照样能调。
     */
    bool ti_clear() const { return do_cmd(HY_NR_TI_CLEAR, nullptr, 0) == 0; }

    /*
     * 注入总闸。on=true 放行按下/移动/抬起，on=false 一律拒绝。
     *
     * 触摸探测是只读的、默认开且无害；但"生成手指"必须显式调用。这道
     * 闸门再兜一层：关掉后连用户态调用也不放行，确保没有任何自动生成
     * 手指的路径。关闭时内核会顺带做一次强制清除。
     *
     * 仅查询：传 query=true，返回当前闸门状态。
     */
    bool ti_inject_gate(bool on) const
    {
        struct hy_ti_range r{};
        r.min_x = on ? 1 : 0; r.max_x = -1; r.min_y = -1; r.max_y = -1;
        return do_cmd_obj(HY_NR_TI_INJECT_GATE, r) >= 0;
    }
    bool ti_inject_gate_query() const
    {
        struct hy_ti_range r{};
        r.min_x = 2; r.max_x = -1; r.min_y = -1; r.max_y = -1;
        return do_cmd_obj(HY_NR_TI_INJECT_GATE, r) == 1;
    }

    /* ---------------- 原接口：模块基址 ---------------- */

    uintptr_t getModuleBase(const char *name)
    {
        if (!name) return 0;

        /*
         * 先用 maps 精确匹配。
         * 内核的 MODULE_BASE 拿不到 VMA 映射文件名（KP 未导出 dentry/path），
         * 只能返回"第一个可执行段"，对 so 名不精确 —— 所以放在兜底位。
         */
        if (pid_ > 0) {
            uintptr_t b = base_via_maps(name);
            if (b) return b;
        }

        if (authed_ && pid_ > 0) {
            hy_request r{};
            char buf[256];
            memset(buf, 0, sizeof(buf));
            strncpy(buf, name, sizeof(buf) - 1);
            r.pid = pid_;
            r.buffer = (uint64_t)(uintptr_t)buf;
            if (do_cmd_obj(HY_NR_MODULE_BASE, r) == 0) return (uintptr_t)r.addr;
        }
        return 0;
    }

    uintptr_t get_module_base(char *name) { return getModuleBase(name); }

    uintptr_t getModuleBss(const char *name)
    {
        if (!authed_ || pid_ <= 0 || !name) return 0;
        hy_request r{};
        char buf[256];
        memset(buf, 0, sizeof(buf));
        strncpy(buf, name, sizeof(buf) - 1);
        r.pid = pid_;
        r.buffer = (uint64_t)(uintptr_t)buf;
        if (do_cmd_obj(HY_NR_MODULE_BSS, r) != 0) return 0;
        return (uintptr_t)r.addr;
    }

    /* ---------------- 原接口：读写 ---------------- */

    bool read(uintptr_t addr, void *buffer, size_t size)
    {
        if (!initialized_ || pid_ <= 0 || !buffer || size == 0) return false;
        hy_request r{};
        r.pid    = pid_;
        r.addr   = addr & 0xFFFFFFFFFFFFULL;
        r.buffer = (uint64_t)(uintptr_t)buffer;
        r.size   = size;
        return do_cmd_obj(HY_NR_READ_MEM, r) == 0;
    }

    template <typename T>
    T read(uintptr_t addr)
    {
        T res{};
        if (read(addr, &res, sizeof(T))) return res;
        return T{};
    }

    /*
     * 【性能优化 v1.17.0】批量连续读。
     * 读 N 个字段原本要发 N 次命令（N 次完整往返）。
     * 若这些字段在目标进程里连续（结构体成员通常如此），
     * 一次读完，往返次数从 N 降到 1 —— 这是最实在的提速。
     *
     *   uint64_t v[8];
     *   driver->read_contiguous(base + 0x100, v, sizeof(v));
     */
    bool read_contiguous(uintptr_t addr, void *dst, size_t n)
    {
        return read(addr, dst, (uint32_t)n);
    }

    /* 同类：批量连续写 */
    bool write_contiguous(uintptr_t addr, const void *src, size_t n)
    {
        void *tmp = malloc(n);
        if (!tmp) return false;
        memcpy(tmp, src, n);
        bool ok = write(addr, tmp, (uint32_t)n);
        free(tmp);
        return ok;
    }

    /* 一次往返读一个结构体 */
    template <typename T>
    T read_struct(uintptr_t addr)
    {
        T res{};
        read_contiguous(addr, &res, sizeof(T));
        return res;
    }

    bool read_v2(uintptr_t addr, void *buffer, size_t size)
    {
        if (!initialized_ || pid_ <= 0 || !buffer || size == 0) return false;
        hy_request r{};
        r.pid    = pid_;
        r.addr   = addr & 0xFFFFFFFFFFFFULL;
        r.buffer = (uint64_t)(uintptr_t)buffer;
        r.size   = size;
        return do_cmd_obj(HY_NR_READ_MEM_V2, r) == 0;
    }

    template <typename T>
    T read_v2(uintptr_t addr)
    {
        T res{};
        if (read_v2(addr, &res, sizeof(T))) return res;
        return T{};
    }

    bool write(uintptr_t addr, void *buffer, size_t size)
    {
        if (!initialized_ || pid_ <= 0 || !buffer || size == 0) return false;
        hy_request r{};
        r.pid    = pid_;
        r.addr   = addr & 0xFFFFFFFFFFFFULL;
        r.buffer = (uint64_t)(uintptr_t)buffer;
        r.size   = size;
        return do_cmd_obj(HY_NR_WRITE_MEM, r) == 0;
    }

    template <typename T>
    bool write(uintptr_t addr, T value)
    {
        return write(addr, &value, sizeof(T));
    }

    /* 兼容原 WriteAddress（原实现直接写 /proc/pid/mem，这里改走欢愉） */
    template <class T>
    T WriteAddress(long int addr, T value)
    {
        write((uintptr_t)addr, &value, sizeof(T));
        return T{};
    }

    /* ================= 欢愉：断点 =================
     *
     * 方案由文件顶部 HY_USER_BP_SCHEME 决定，也可运行时改。
     * 全部走 hy_bp_inst_args.mode 的「本次显式指定」通道 ——
     * 不去动内核的全局运行时默认，因此不会污染后续断点。
     * ================================================= */

    /* 方案名（写日志用） */
    static const char *bp_scheme_name(uint32_t scheme)
    {
        switch (scheme) {
        case HY_BP_SCHEME_DEFAULT:  return "DEFAULT(遵循模块默认)";
        case HY_BP_SCHEME_HW_EXEC:  return "HW_EXEC(硬件执行断点)";
        case HY_BP_SCHEME_PTE:      return "PTE(影子页)";
        case HY_BP_SCHEME_SW:       return "SW(软件断点)";
        case HY_BP_SCHEME_STEP:     return "STEP(单步)";
        case HY_BP_SCHEME_WATCH_R:  return "WATCH_R(硬件读观察点)";
        case HY_BP_SCHEME_WATCH_W:  return "WATCH_W(硬件写观察点)";
        case HY_BP_SCHEME_WATCH_RW: return "WATCH_RW(硬件读写观察点)";
        case HY_BP_SCHEME_DPT:      return "DPT(主线程影子页)";
        default:                    return "UNKNOWN";
        }
    }

    /* 内核 mode 编号 -> 名字 */
    static const char *bp_mode_name(uint32_t mode)
    {
        switch (mode) {
        case HY_BP_MODE_AUTO: return "AUTO";
        case HY_BP_MODE_SW:   return "SW";
        case HY_BP_MODE_PTE:  return "PTE";
        case HY_BP_MODE_HW:   return "HW";
        default:              return "?";
        }
    }

    /*
     * 方案 -> 内核参数。
     * 返回 false 表示该方案不走 BP_INST（STEP / DPT 是独立命令）。
     */
    static bool bp_scheme_to_mode(uint32_t scheme, uint32_t *mode, uint32_t *type)
    {
        uint32_t m = HY_BP_MODE_AUTO, t = HW_BREAKPOINT_X;
        switch (scheme) {
        case HY_BP_SCHEME_DEFAULT:  m = HY_BP_MODE_AUTO; t = HW_BREAKPOINT_X; break;
        case HY_BP_SCHEME_HW_EXEC:  m = HY_BP_MODE_HW;   t = HW_BREAKPOINT_X; break;
        case HY_BP_SCHEME_PTE:      m = HY_BP_MODE_PTE;  t = HW_BREAKPOINT_X; break;
        case HY_BP_SCHEME_SW:       m = HY_BP_MODE_SW;   t = HW_BREAKPOINT_X; break;
        case HY_BP_SCHEME_WATCH_R:  m = HY_BP_MODE_HW;   t = HW_BREAKPOINT_R; break;
        case HY_BP_SCHEME_WATCH_W:  m = HY_BP_MODE_HW;   t = HW_BREAKPOINT_W; break;
        case HY_BP_SCHEME_WATCH_RW: m = HY_BP_MODE_HW;   t = HW_BREAKPOINT_RW; break;
        default: return false;   /* STEP / DPT */
        }
        if (mode) *mode = m;
        if (type) *type = t;
        return true;
    }

    /* 设置【用户断点方案】（本地生效，不改内核全局默认） */
    void set_bp_scheme(uint32_t scheme)
    {
        if (scheme >= HY_BP_SCHEME_MAX) { bp_last_err_ = -EINVAL; return; }
        bp_scheme_ = scheme;
        bp_last_err_ = 0;
    }

    uint32_t get_bp_scheme() const { return bp_scheme_; }

    /* 单方案严格模式开关：true=只用指定方案，不叠加不回退 */
    void set_bp_strict(bool on) { bp_strict_ = on; }
    bool get_bp_strict() const  { return bp_strict_; }

    /* 断点长度（观察点用得上） */
    void set_bp_len(uint32_t len) { bp_len_ = len ? len : 4; }
    uint32_t get_bp_len() const   { return bp_len_; }

    int  bp_last_error() const    { return bp_last_err_; }

    /* 设置【全局运行时默认】断点方案（内核编号）。
     * 一般不用 —— 走 set_bp_scheme() 更安全，它不动这里。
     * 优先级：本次显式 > 这里设的运行时默认 > 编译期默认 > 内置回退链 */
    void set_bp_mode(uint32_t m)
    {
        hy_bp_mode_config c{}; c.mode = m;
        do_cmd_obj(HY_NR_BP_SET_MODE, c);
        bp_mode_ = m;
    }
    uint32_t get_bp_mode() const { return bp_mode_; }

    /* ==================================================================
     * 读取后端选择（v1.60.0）—— 与断点方案的选择方式保持一致
     *
     *   drv.set_rw_mode(HY_RW_MODE_KERNEL);   // 0，默认，内核级读取
     *   drv.set_rw_mode(HY_RW_MODE_KMA);      // 1，KMA 硬件级读取
     *
     * 默认 0：不设置就与不加这个功能时行为完全一致。
     * 设成 1 后只对内核虚拟地址 / 物理地址生效；
     * 用户态进程内存不适用，内核自动回落内核级，不会读失败。
     * ================================================================== */
    void set_rw_mode(uint32_t m)
    {
        hy_rw_mode c{};
        c.mode = (m == HY_RW_MODE_KMA) ? HY_RW_MODE_KMA : HY_RW_MODE_KERNEL;
        do_cmd_obj(HY_NR_RWMODE_SET, c);
        rw_mode_ = c.mode;
    }
    uint32_t get_rw_mode() const { return rw_mode_; }

    /* ---------------- 读取缓存开关（v1.63.0） ----------------
     *   drv.set_mem_cache(HY_MEM_CACHE_DEFAULT); // 默认启用缓存
     *   drv.set_mem_cache(HY_MEM_CACHE_OFF);     // 每次重走完整页表
     * 默认 0（启用），作用于所有读取路径。
     */
    void set_mem_cache(uint32_t m) const
    {
        hy_mem_cache_mode c{};
        c.mode = (m == HY_MEM_CACHE_OFF) ? HY_MEM_CACHE_OFF
               : ((m == HY_MEM_CACHE_ON) ? HY_MEM_CACHE_ON
                                         : HY_MEM_CACHE_DEFAULT);
        do_cmd_obj(HY_NR_MEMCACHE_SET, c);
        mem_cache_ = c.mode;
    }

    uint32_t get_mem_cache() const { return mem_cache_; }

    /* 真去内核问一次（上面 get_mem_cache 只是本地缓存的回声） */
    uint32_t mem_cache_runtime() const
    {
        hy_mem_cache_mode c{};
        if (do_cmd_obj(HY_NR_MEMCACHE_GET, c) != 0) return mem_cache_;
        return c.mode;
    }

    /* ---------------- 方案选择（v1.64.0）----------------
     * 每个功能面备了面向 3/4/5/6 系内核的多套做法，默认 AUTO：
     * 先试最高世代，probe 不过就降一档，运行期失败还会再降。
     *   drv.set_scheme(HY_SC_PGTABLE, HY_SCHEME_AUTO);  // 默认
     *   drv.set_scheme(HY_SC_BP,      HY_SCHEME_GEN6);  // 钉死 6 系那套
     * 强制档在本机不可用时不会静默换别的，而是该域停用并如实上报。
     */
    void set_scheme(uint32_t dom, uint32_t gen) const
    {
        hy_scheme_req r{};
        r.dom = dom;
        r.gen = (gen == HY_SCHEME_GEN3 || gen == HY_SCHEME_GEN4 ||
                 gen == HY_SCHEME_GEN5 || gen == HY_SCHEME_GEN6)
              ? gen : HY_SCHEME_AUTO;
        do_cmd_obj(HY_NR_SCHEME_SET, r);
    }
    uint32_t get_scheme(uint32_t dom, uint32_t *gen_out = nullptr) const
    {
        hy_scheme_req r{};
        r.dom = dom;
        do_cmd_obj(HY_NR_SCHEME_GET, r);
        if (gen_out) *gen_out = r.cur_gen;
        return r.chosen;
    }
    /* 文本版：与 echo 'scheme' > /proc/HuanyuD 等价，方便终端对照 */
    std::string scheme_list() const { return do_cmd_str("scheme"); }
    std::string scheme_demote(uint32_t dom) const
    { return do_cmd_str(std::string("scheme demote ") + scheme_dom_name(dom)); }
    std::string scheme_force(uint32_t dom, uint32_t gen) const
    { return do_cmd_str(std::string("scheme force ") + scheme_dom_name(dom)
                        + " " + std::to_string(gen)); }
    /* 内核 scheme 文本子命令收**域名字符串**，传数字会被判 bad dom */
    static const char *scheme_dom_name(uint32_t dom)
    {
        static const char *const nm[] = {
            "physvirt", "pgtable", "memread", "kernrw", "bp", "input", "sym"
        };
        return (dom < 7) ? nm[dom] : "physvirt";
    }

    /* ---------------- 压力测试（v1.60.0）----------------
     * spec 形如 "60s all 1" / "5min cpu 8" / "1h mem 15"
     * 默认全面关闭，只有下命令才跑，到点自动停。
     */
    std::string stress(const std::string &spec) const
    { return do_cmd_str("stress " + spec); }
    std::string stress_off()  const { return do_cmd_str("stress off"); }
    std::string stress_stat() const { return do_cmd_str("stress stat"); }

    /*
     * 查询 KMA 是否真的可用（v1.66.0 修正）
     * 旧实现判 c.reserved != 0，而内核 hy_rw_mode 的 reserved 恒为 0，
     * 于是这个函数**永远返回 false**。改解析 "rwmode stat" 里的 avail=。
     */
    bool rw_kma_available() const
    {
        std::string s = do_cmd_str("rwmode stat");
        size_t p = s.find("avail=");
        if (p == std::string::npos) return false;
        return ::atoi(s.c_str() + p + 6) != 0;
    }

    /* ==================================================================
     * 网络访问（v1.60.0 预留 / v1.66.0 修正）
     *
     * 内核侧**不发任何包**。命令号与结构体只是 ABI 预留，
     * 真正下载由本文件的 net_download() 在用户态完成。
     *
     * 【修正】旧 net_cap()/net_note() 走文本命令 "net cap" / "net <url>"，
     * 但内核 hy_dbg_cmd_dispatch() 里根本没有 net 分支 ——
     * 一律落到 "unknown command"，返回串非空反而被当成成功。
     * 现在改走真正的 nr 86/87/88。
     * ================================================================== */
    int net_cap(hy_net_cap *out = nullptr) const
    {
        hy_net_cap c{};
        if (out) { std::memset(out, 0, sizeof(*out)); }
        if (!initialized_) return -1;
        if (do_cmd_obj(HY_NR_NET_CAP, c) != 0) return -1;
        if (out) *out = c;
        return 0;
    }

    /* 内核对 FETCH 一律返回 -ENOTSUP，这是设计：告诉调用方走用户态 */
    bool net_fetch(const std::string &url,
                   uint32_t method = HY_NET_METHOD_GET,
                   uint32_t timeout_ms = 0,
                   uint32_t flags = 0) const
    {
        if (!initialized_) return false;
        if (url.empty() || url.size() >= HY_NET_URL_MAX) return false;
        hy_net_req r{};
        r.method     = method;
        r.timeout_ms = timeout_ms;
        r.flags      = flags;
        std::memcpy(r.url, url.c_str(), url.size() + 1);
        return do_cmd_obj(HY_NR_NET_FETCH, r) == 0;
    }

    bool net_status(hy_net_rep *out = nullptr) const
    {
        hy_net_rep r{};
        if (out) std::memset(out, 0, sizeof(*out));
        if (!initialized_) return false;
        if (do_cmd_obj(HY_NR_NET_STATUS, r) != 0) return false;
        if (out) *out = r;
        return true;
    }

    /* 隐藏 GUP（get_user_pages）痕迹。
     * 读取进程内存时若走 GUP，会给 page 加引用、触发缺页、拉 LRU、
     * 置 A/D 位 —— 全是可被观测的痕迹。开启后改走纯页表遍历。 */
    bool hide_gup(bool on) const
    {
        uint32_t v = on ? 1u : 0u;
        if (!initialized_) return false;
        return do_cmd(HY_NR_HIDE_GUP_SET, &v, sizeof(v)) == 0;
    }


    /* 查询本内核支持哪些方案：返回 HY_BP_CAP_SW/PTE/HW 的位组合 */
    uint32_t bp_caps(hy_bp_caps *out = nullptr) const
    {
        hy_bp_caps c{};
        do_cmd_obj(HY_NR_BP_GET_CAPS, c);
        if (out) *out = c;
        return c.supported;
    }

    /*
     * 装断点前先自查：当前方案在本机可用吗？
     * 返回 0 = 可用；非 0 = 不可用，并给出原因。
     * 这一步不发命令改状态，只是体检。
     */
    int bp_scheme_check(uint32_t scheme, std::string *why = nullptr) const
    {
        hy_bp_caps c{};
        uint32_t caps = bp_caps(&c);
        uint32_t mode = HY_BP_MODE_AUTO, type = HW_BREAKPOINT_X;

        if (scheme >= HY_BP_SCHEME_MAX) {
            if (why) *why = "方案编号越界";
            return -EINVAL;
        }
        if (scheme == HY_BP_SCHEME_DEFAULT) return 0;   /* 交给内核，一定有解 */

        if (bp_scheme_to_mode(scheme, &mode, &type)) {
            if (mode == HY_BP_MODE_SW  && !(caps & HY_BP_CAP_SW)) {
                if (why) *why = "本内核不支持软件断点（BRK 处理未接管）";
                return -ENOSYS;
            }
            if (mode == HY_BP_MODE_PTE && !(caps & HY_BP_CAP_PTE)) {
                if (why) *why = "本内核不支持 PTE 影子页";
                return -ENOSYS;
            }
            if (mode == HY_BP_MODE_HW  && !(caps & HY_BP_CAP_HW)) {
                if (why) *why = "本内核不支持硬件断点";
                return -ENOSYS;
            }
            if (mode == HY_BP_MODE_HW) {
                /* 硬件槽位是否还有余量 */
                std::vector<hy_bp_item> act = bp_list();
                int used_b = 0, used_w = 0;
                for (size_t k = 0; k < act.size(); k++) {
                    if (!act[k].active || act[k].mode != HY_BP_MODE_HW) continue;
                    if (act[k].addr && (uint32_t)act[k].addr == 0) continue;
                    /* 执行断点占 brps，其余按观察点计 wrps（内核按 type 分，这里保守统计） */
                    used_b++;
                }
                (void)used_w;
                if (type == HW_BREAKPOINT_X && (uint32_t)used_b >= c.num_brps) {
                    if (why) *why = "硬件执行断点槽位已用满 (brps=" +
                                    std::to_string(c.num_brps) + ")，改用 PTE";
                    return -EBUSY;
                }
                if (type != HW_BREAKPOINT_X && (uint32_t)used_b >= c.num_wrps) {
                    if (why) *why = "硬件观察点槽位已用满 (wrps=" +
                                    std::to_string(c.num_wrps) + ")";
                    return -EBUSY;
                }
            }
        }
        return 0;
    }

    /* 单步断点（方案 4 / 独立命令） */
    bool bp_step_set(pid_t p, uint64_t a) const
    {
        struct { int32_t pid; uint32_t resv; uint64_t addr; } r{};
        r.pid = p; r.addr = a;
        bp_last_err_ = (int)do_cmd_obj(HY_NR_STEPBP_SET, r);
        return bp_last_err_ == 0;
    }
    bool bp_step_remove(pid_t p, uint64_t a) const
    {
        struct { int32_t pid; uint32_t resv; uint64_t addr; } r{};
        r.pid = p; r.addr = a;
        bp_last_err_ = (int)do_cmd_obj(HY_NR_STEPBP_REMOVE, r);
        return bp_last_err_ == 0;
    }

    /* DPT 主线程影子页（方案 8 / 独立命令） */
    bool bp_dpt_set(pid_t p, uint64_t a) const
    {
        struct { int32_t pid; uint32_t resv; uint64_t addr; } r{};
        r.pid = p; r.addr = a;
        bp_last_err_ = (int)do_cmd_obj(HY_NR_DPT_SET, r);
        return bp_last_err_ == 0;
    }
    bool bp_dpt_remove(pid_t p, uint64_t a) const
    {
        struct { int32_t pid; uint32_t resv; uint64_t addr; } r{};
        r.pid = p; r.addr = a;
        bp_last_err_ = (int)do_cmd_obj(HY_NR_DPT_REMOVE, r);
        return bp_last_err_ == 0;
    }

    /*
     * 【主入口】按当前方案装一个断点。
     *   drv.set_bp_scheme(HY_BP_SCHEME_PTE);
     *   uint64_t h = drv.bp_inst(pid, addr);
     *
     * 严格模式（默认开）下 args.mode 只放一个方案 + HY_BP_FLAG_STRICT，
     * 内核不会再追加默认和回退链 —— 一次只上一个方案。
     */
    uint64_t bp_inst(pid_t p, uint64_t a) const
    { return bp_inst_scheme(p, a, bp_scheme_); }

    /* 用指定方案装一个（不影响当前方案设置） */
    uint64_t bp_inst_scheme(pid_t p, uint64_t a, uint32_t scheme) const
    {
        bp_last_err_ = 0;

        if (scheme >= HY_BP_SCHEME_MAX) { bp_last_err_ = -EINVAL; return 0; }

        /* 体检：方案不可用就直接返回，不硬装 */
        std::string why;
        int chk = bp_scheme_check(scheme, &why);
        if (chk != 0) {
            bp_last_err_ = chk;
            printf("[-] 欢愉断点：方案 %s 不可用 —— %s (err=%d)\n",
                   bp_scheme_name(scheme), why.c_str(), chk);
            return 0;
        }

        /* STEP / DPT 走独立命令，不经过 BP_INST */
        if (scheme == HY_BP_SCHEME_STEP) {
            if (!bp_step_set(p, a)) {
                printf("[-] 欢愉断点：单步安装失败 (err=%d)\n", bp_last_err_);
                return 0;
            }
            return a;   /* 单步以地址作为标识 */
        }
        if (scheme == HY_BP_SCHEME_DPT) {
            if (!bp_dpt_set(p, a)) {
                printf("[-] 欢愉断点：DPT 安装失败 (err=%d)\n", bp_last_err_);
                return 0;
            }
            return a;
        }

        uint32_t mode = HY_BP_MODE_AUTO, type = HW_BREAKPOINT_X;
        if (!bp_scheme_to_mode(scheme, &mode, &type)) { bp_last_err_ = -EINVAL; return 0; }

        hy_bp_inst_args args{};
        args.pid    = p;
        args.addr   = a;
        args.bp_len = (scheme == HY_BP_SCHEME_HW_EXEC) ? HW_BREAKPOINT_LEN_4 : bp_len_;
        args.bp_type = type;
        args.mode   = mode;                 /* 本次显式指定：最优先 */
        args.flags  = HY_BP_FLAG_RECORD;    /* 记录上下文，命中项才有寄存器 */
        if (bp_strict_ && mode != HY_BP_MODE_AUTO)
            args.flags |= HY_BP_FLAG_STRICT;   /* 只装这一个，不叠加不回退 */

        long rc = do_cmd_obj(HY_NR_BP_INST, args);
        if (rc != 0) {
            bp_last_err_ = (int)rc;
            printf("[-] 欢愉断点：安装失败 pid=%d addr=0x%llx 方案=%s err=%ld%s\n",
                   (int)p, (unsigned long long)a, bp_scheme_name(scheme), rc,
                   bp_strict_ ? "（严格模式：未降级）" : "");
            return 0;
        }
        return args.addr;
    }

    /*
     * 装完验证：读回内核实际落到的方案。
     * 严格模式下应与你请求的方案完全一致；非严格模式可能已被降级。
     * 返回 true = 找到了该 handle；resolved 为内核实际 mode 编号。
     */
    bool bp_verify(uint64_t h, uint32_t *resolved = nullptr) const
    {
        if (!h) return false;
        std::vector<hy_bp_item> v = bp_list();
        for (size_t i = 0; i < v.size(); i++) {
            if (v[i].handle != h) continue;
            if (resolved) *resolved = v[i].mode;
            uint32_t want = HY_BP_MODE_AUTO;
            (void)bp_scheme_to_mode(bp_scheme_, &want, nullptr);
            if (bp_strict_ && want != HY_BP_MODE_AUTO && v[i].mode != want) {
                printf("[-] 欢愉断点：方案不符 请求=%s 实际=%s\n",
                       bp_mode_name(want), bp_mode_name(v[i].mode));
                return false;
            }
            return true;
        }
        return false;
    }

    /* 列出当前所有断点 */
    std::vector<hy_bp_item> bp_list(size_t max = 64) const
    {
        std::vector<hy_bp_item> out;
        if (max == 0 || max > 128) max = 128;
        out.resize(max);
        hy_bp_list_req r{};
        r.max_count = (uint32_t)max;
        r.buf_ptr   = (uint64_t)(uintptr_t)out.data();
        if (do_cmd_obj(HY_NR_BP_LIST, r) != 0) return std::vector<hy_bp_item>();
        /* 内核按 max_count 填，未用到的项 handle 为 0 */
        std::vector<hy_bp_item> real;
        for (size_t i = 0; i < out.size(); i++)
            if (out[i].handle) real.push_back(out[i]);
        return real;
    }

    /* 一次性打印当前断点方案 + 能力 + 已装列表（排查用） */
    void bp_dump() const
    {
        hy_bp_caps c{};
        uint32_t caps = bp_caps(&c);
        printf("==== 欢愉断点状态 ====\n");
        printf("  当前方案   : [%u] %s\n", bp_scheme_, bp_scheme_name(bp_scheme_));
        printf("  严格模式   : %s\n", bp_strict_ ? "开（只上一个方案，不回退）" : "关（允许回退链）");
        printf("  断点长度   : %u 字节\n", bp_len_);
        printf("  内核支持   : 0x%x  SW=%d PTE=%d HW=%d\n",
               caps, !!(caps & HY_BP_CAP_SW), !!(caps & HY_BP_CAP_PTE),
               !!(caps & HY_BP_CAP_HW));
        printf("  硬件槽位   : brps=%u wrps=%u\n", c.num_brps, c.num_wrps);
        std::vector<hy_bp_item> v = bp_list();
        printf("  已装断点   : %zu 个\n", v.size());
        for (size_t i = 0; i < v.size(); i++) {
            printf("    #%zu handle=0x%llx pid=%d addr=0x%llx 实际方案=%s "
                   "命中=%llu %s%s\n", i,
                   (unsigned long long)v[i].handle, v[i].pid,
                   (unsigned long long)v[i].addr, bp_mode_name(v[i].mode),
                   (unsigned long long)v[i].hit_count,
                   v[i].active ? "" : "[未激活]",
                   v[i].suspended ? "[已挂起]" : "");
        }
        printf("======================\n");
    }

    /* ---- 旧接口保留（内核编号版），内部已改为不动全局默认 ---- */

    uint64_t bp_inst_sw (pid_t p, uint64_t a) const
    { return bp_inst_scheme(p, a, HY_BP_SCHEME_SW); }

    uint64_t bp_inst_pte(pid_t p, uint64_t a) const
    { return bp_inst_scheme(p, a, HY_BP_SCHEME_PTE); }

    uint64_t bp_inst_hw (pid_t p, uint64_t a) const
    { return bp_inst_scheme(p, a, HY_BP_SCHEME_HW_EXEC); }

    uint64_t bp_inst_watch(pid_t p, uint64_t a, uint32_t rw) const
    {
        uint32_t sc = HY_BP_SCHEME_WATCH_RW;
        if (rw == HW_BREAKPOINT_R)       sc = HY_BP_SCHEME_WATCH_R;
        else if (rw == HW_BREAKPOINT_W)  sc = HY_BP_SCHEME_WATCH_W;
        return bp_inst_scheme(p, a, sc);
    }

    /* 单次覆盖装断点（旧签名，force_mode 用内核编号） */
    uint64_t bp_inst(pid_t p, uint64_t a, uint32_t force_mode,
                     uint32_t type) const
    {
        uint32_t sc = HY_BP_SCHEME_DEFAULT;
        switch (force_mode) {
        case HY_BP_MODE_SW:  sc = HY_BP_SCHEME_SW;  break;
        case HY_BP_MODE_PTE: sc = HY_BP_SCHEME_PTE; break;
        case HY_BP_MODE_HW:
            sc = (type == HW_BREAKPOINT_X) ? HY_BP_SCHEME_HW_EXEC
               : ((type == HW_BREAKPOINT_R) ? HY_BP_SCHEME_WATCH_R
               : ((type == HW_BREAKPOINT_W) ? HY_BP_SCHEME_WATCH_W
                                            : HY_BP_SCHEME_WATCH_RW));
            break;
        default: break;
        }
        return bp_inst_scheme(p, a, sc);
    }

    bool bp_uninst(uint64_t h) const
    { return h && do_cmd_obj(HY_NR_BP_UNINST, h) == 0; }
    bool bp_suspend(uint64_t h) const
    { return h && do_cmd_obj(HY_NR_BP_SUSPEND, h) == 0; }
    bool bp_resume(uint64_t h) const
    { return h && do_cmd_obj(HY_NR_BP_RESUME, h) == 0; }

    bool bp_hit_count(uint64_t h, uint64_t *total, uint64_t *items) const
    {
        hy_bp_hit_count_arg a{};
        if (!h) return false;
        a.handle = h;
        if (do_cmd_obj(HY_NR_BP_HIT_COUNT, a) != 0) return false;
        if (total) *total = a.hit_total_count;
        if (items) *items = a.hit_item_arr_count;
        return true;
    }

    std::vector<hy_bp_hit_item> bp_get_hits(uint64_t h, size_t max = 100) const
    {
        std::vector<hy_bp_hit_item> out;
        uint64_t total = 0, cnt = 0;
        if (!bp_hit_count(h, &total, &cnt) || cnt == 0) return out;
        size_t n = (cnt < max) ? (size_t)cnt : max;
        out.resize(n);
        hy_bp_hit_items_args a{};
        a.handle = h;
        a.user_buffer_ptr = (uint64_t)(uintptr_t)out.data();
        a.max_bytes = n * sizeof(hy_bp_hit_item);
        if (do_cmd_obj(HY_NR_BP_HIT_ITEMS, a) != 0) return {};
        out.resize((size_t)a.items_copied);
        return out;
    }

    /* ---------------- 欢愉：枚举 / 扩展 ---------------- */

    std::vector<hy_proc_info> enum_processes(size_t max = 128) const
    {
        std::vector<hy_proc_info> v(max);
        hy_enum_req r{};
        r.pid = 0;
        r.max_count = (uint32_t)max;
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        long n = do_cmd_obj(HY_NR_ENUM_PROCESSES, r);
        if (n <= 0) return {};
        v.resize((size_t)n);
        return v;
    }

    std::vector<hy_mod_info> enum_modules(size_t max = 128) const
    {
        std::vector<hy_mod_info> v(max);
        hy_enum_req r{};
        r.pid = pid_;
        r.max_count = (uint32_t)max;
        r.buf_ptr = (uint64_t)(uintptr_t)v.data();
        long n = do_cmd_obj(HY_NR_ENUM_MODULES, r);
        if (n <= 0) return {};
        v.resize((size_t)n);
        return v;
    }

    bool stats(hy_stats &out) const
    {
        memset(&out, 0, sizeof(out));
        return do_cmd_obj(HY_NR_STATS, out) > 0;
    }

    /* ---------------- 欢愉：输入 / 隐藏 / TLS ---------------- */

    bool touch_init(int mode) const
    {
        hy_touch_event_base t{};
        if (mode < 0 || mode > 1) return false;
        t.slot = mode;
        return do_cmd_obj(HY_NR_TOUCH_INIT, t) == 0;
    }
    bool touch_down(int slot, int x, int y) const
    {
        hy_touch_event_base t{}; t.slot = slot; t.x = x; t.y = y;
        return do_cmd_obj(HY_NR_TOUCH_DOWN, t) == 0;
    }
    bool touch_up(int slot) const
    {
        hy_touch_event_base t{}; t.slot = slot;
        return do_cmd_obj(HY_NR_TOUCH_UP, t) == 0;
    }

    bool gyro_init(int method) const
    {
        int m = method;
        if (method < 0 || method > 1) return false;
        return do_cmd_obj(HY_NR_GYRO_INIT, m) == 0;
    }

    bool gyro_modify(float x, float y) const
    {
        hy_gyro_config g{};
        g.enable = 1;
        memcpy(&g.x, &x, sizeof(uint32_t));
        memcpy(&g.y, &y, sizeof(uint32_t));
        return do_cmd_obj(HY_NR_GYRO_CONFIG, g) == 0;
    }

    bool get_thread_tls(pid_t p, pid_t tid, uint64_t *out) const
    {
        hy_tls_request r{};
        if (!out || p <= 0) return false;
        r.pid = p; r.tid = tid;
        if (do_cmd_obj(HY_NR_GET_THREAD_TLS, r) != 0) return false;
        if (r.result != 0) return false;
        *out = r.tls_value;
        return true;
    }

    bool exec_pacga(pid_t p, uint64_t value, uint64_t modifier, uint64_t *out) const
    {
        hy_pacga_request r{};
        if (!out || p <= 0) return false;
        r.pid = p; r.value = value; r.modifier = modifier;
        if (do_cmd_obj(HY_NR_EXEC_PACGA, r) != 0) return false;
        if (!r.ok) return false;
        *out = r.result_pac;
        return true;
    }

    bool file_hide_set(const char *dir, const char *keyword, bool enabled = true)
    {
        hy_file_hide_config c{};
        if (!dir || !keyword) return false;
        size_t dl = strnlen(dir, sizeof(c.directory));
        size_t kl = strnlen(keyword, sizeof(c.keyword));
        if (!dl || !kl || dl >= sizeof(c.directory) || kl >= sizeof(c.keyword)) return false;
        memcpy(c.directory, dir, dl);
        memcpy(c.keyword, keyword, kl);
        c.enabled = enabled ? 1u : 0u;
        return do_cmd_obj(HY_NR_FILE_HIDE_SET, c) == 0;
    }

    bool file_hide_clear() const { return do_cmd_empty(HY_NR_FILE_HIDE_CLEAR) == 0; }

    /* ---------------- /proc/huanyu ---------------- */

    static bool proc_exists() { struct stat st; return ::stat("/proc/huanyu", &st) == 0; }

    static std::string proc_read()
    {
        int fd = ::open("/proc/huanyu", O_RDONLY);
        if (fd < 0) return std::string();
        std::string out;
        char buf[256];
        ssize_t n;
        while ((n = ::read(fd, buf, sizeof(buf) - 1)) > 0) { buf[n] = '\0'; out += buf; }
        ::close(fd);
        return out;
    }
};

/* 与原头文件保持一致：全局单例 */
static c_driver *driver = new c_driver();


/* ==========================================================================
 * 网络下载（用户态实现，v1.60.0）
 *
 * 【为什么在这里而不是内核】
 *   内核里做 HTTP 要解析 sock_create_kern / kernel_connect / kernel_recvmsg
 *   一整套未导出符号，还要猜 struct socket / msghdr / iov_iter 的布局 ——
 *   历史上正是这样反复炸内核。用户态做，崩了只死自己这个进程。
 *
 * 【能力边界】
 *   支持 http:// 明文。
 *   不支持 https:// —— TLS 需要 OpenSSL/mbedTLS，本文件不引入外部依赖；
 *   遇到 https 直接返回 -2，调用方自行用 curl 或链接 TLS 库。
 * ========================================================================== */

struct hy_http_result {
    int         status_code;   /* HTTP 状态码，0 表示没拿到 */
    int         err;           /* 0 成功；-1 参数/解析错；-2 不支持(https)；
                                  -3 DNS 失败；-4 连接失败；-5 收发失败；
                                  -6 写文件失败 */
    size_t      body_bytes;
    std::string error;
};

/*
 * url   形如 http://host[:port]/path ，必须 http
 * path  非空则把响应体写入该文件；为空则只取回头部与长度
 */
inline hy_http_result hy_http_download(const std::string &url,
                                       const std::string &out_path,
                                       int timeout_ms = 10000)
{
    hy_http_result r{};
    r.err = -1;

    if (url.size() < 8 || url.compare(0, 7, "http://") != 0) {
        if (url.compare(0, 8, "https://") == 0) {
            r.err = -2;
            r.error = "https not supported here (needs TLS library)";
        } else {
            r.error = "only http:// is supported";
        }
        return r;
    }

    /* --- 解析 host[:port] 与 path --- */
    std::string rest = url.substr(7);
    size_t slash = rest.find('/');
    std::string hostport = (slash == std::string::npos) ? rest : rest.substr(0, slash);
    std::string path     = (slash == std::string::npos) ? std::string("/")
                                                        : rest.substr(slash);
    std::string host = hostport;
    int port = 80;
    size_t colon = hostport.rfind(':');
    if (colon != std::string::npos) {
        host = hostport.substr(0, colon);
        port = ::atoi(hostport.substr(colon + 1).c_str());
        if (port <= 0 || port > 65535) { r.error = "bad port"; return r; }
    }
    if (host.empty()) { r.error = "empty host"; return r; }

    /* --- DNS --- */
    struct addrinfo hints, *res = nullptr;
    std::memset(&hints, 0, sizeof(hints));
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (::getaddrinfo(host.c_str(), std::to_string(port).c_str(),
                      &hints, &res) != 0 || !res) {
        r.err = -3; r.error = "getaddrinfo failed"; return r;
    }

    /* --- 连接 --- */
    int fd = ::socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) { ::freeaddrinfo(res); r.err = -4; r.error = "socket failed"; return r; }

    {
        struct timeval tv;
        tv.tv_sec  = timeout_ms / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;
        ::setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        ::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    }

    if (::connect(fd, res->ai_addr, res->ai_addrlen) != 0) {
        ::close(fd); ::freeaddrinfo(res);
        r.err = -4; r.error = "connect failed"; return r;
    }
    ::freeaddrinfo(res);

    /* --- 发请求 --- */
    std::string req = "GET " + path + " HTTP/1.1\r\nHost: " + hostport +
                      "\r\nConnection: close\r\nUser-Agent: Huanyu/1.66\r\n\r\n";
    if (::send(fd, req.c_str(), req.size(), 0) != (ssize_t)req.size()) {
        ::close(fd); r.err = -5; r.error = "send failed"; return r;
    }

    /* --- 收响应，边收边找头部结束 --- */
    std::string raw;
    char buf[4096];
    size_t header_end = std::string::npos;
    int out_fd = -1;

    if (!out_path.empty()) {
        out_fd = ::open(out_path.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (out_fd < 0) {
            ::close(fd); r.err = -6; r.error = "cannot open output file"; return r;
        }
    }

    for (;;) {
        ssize_t n = ::recv(fd, buf, sizeof(buf), 0);
        if (n < 0) { if (errno == EINTR) continue; break; }
        if (n == 0) break;

        if (header_end == std::string::npos) {
            raw.append(buf, (size_t)n);
            header_end = raw.find("\r\n\r\n");
            if (header_end != std::string::npos) {
                /* 解析状态码：HTTP/1.1 200 xxx */
                size_t sp1 = raw.find(' ');
                if (sp1 != std::string::npos) {
                    size_t sp2 = raw.find(' ', sp1 + 1);
                    if (sp2 != std::string::npos)
                        r.status_code = ::atoi(raw.substr(sp1 + 1, sp2 - sp1 - 1).c_str());
                }
                /* 头部之后的正文部分先落盘 */
                size_t body_off = header_end + 4;
                size_t chunk = raw.size() - body_off;
                r.body_bytes += chunk;
                if (out_fd >= 0) {
                    if (::write(out_fd, raw.data() + body_off, chunk) != (ssize_t)chunk) {
                        ::close(out_fd); ::close(fd);
                        r.err = -6; r.error = "write failed"; return r;
                    }
                }
                raw.clear();
            } else if (raw.size() > 65536) {
                break;   /* 头部异常大，放弃 */
            }
        } else {
            r.body_bytes += (size_t)n;
            if (out_fd >= 0) {
                if (::write(out_fd, buf, (size_t)n) != (ssize_t)n) {
                    ::close(out_fd); ::close(fd);
                    r.err = -6; r.error = "write failed"; return r;
                }
            }
        }
    }

    if (out_fd >= 0) ::close(out_fd);
    ::close(fd);

    if (r.status_code == 0) { r.err = -5; r.error = "no valid response"; return r; }
    r.err = 0;
    return r;
}

/*
 * 只取回内容、不落盘的便捷版。
 * 需要 HTTP 以外的协议或 https，请自行接 curl / TLS 库。
 */
inline std::string hy_http_get(const std::string &url, int timeout_ms = 10000)
{
    hy_http_result r = hy_http_download(url, std::string(), timeout_ms);
    if (r.err != 0) return std::string();
    /* 不落盘时无法取正文（已边收边丢），仅用状态码表达成功与否 */
    return (r.status_code == 200) ? std::string("OK") : std::to_string(r.status_code);
}

#endif   /* WANBAI_H */
