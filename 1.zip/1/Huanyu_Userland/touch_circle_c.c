/*
 * 欢愉 —— 虚拟手指连续画圆（C 版，可直接静态编译成 arm64 二进制）
 *
 * 与 touch_circle.cpp 功能等价，但不依赖 C++ 标准库，
 * 因此可以用 zig cc 交叉编译成静态可执行文件，直接推到手机上运行。
 * 协议（命令号 / 五层密钥 / 挑战应答算法）全部与 huanyu_wanbai.hpp 一致，
 * hy_keys_gen.h 是从该对接文件自动提取生成的，不是手抄。
 *
 * 默认流程（无参数）：
 *   阶段一：1 根手指在屏幕正中画圈，20 秒
 *   阶段二：3 根手指在屏幕上/中/下各画一圈，20 秒
 *   结束：自动抬起全部手指并退出，不留残指
 *
 * 用法：
 *   ./touch_circle            # 默认 1指20s → 3指20s → 自动退出
 *   ./touch_circle 1 15       # 只跑 1 指 15 秒
 *   ./touch_circle 3 15       # 只跑 3 指 15 秒
 *   ./touch_circle 3 20 120 2000   # 3指/20秒/120Hz/一圈2000ms
 */
/*
 * 特性测试宏必须在任何 #include 之前。
 * 缺了它：glibc/NDK 下 syscall() / usleep() / CLOCK_MONOTONIC 全部未声明，
 * 直接编译失败（musl 默认放开所以侥幸能过，但不能依赖这个差异）。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#ifndef _DEFAULT_SOURCE
#define _DEFAULT_SOURCE 1
#endif

#include "hy_keys_gen.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <sys/syscall.h>
#include <sys/prctl.h>

/* ---------------- 协议常量（与 huanyu_wanbai.hpp 一致） ---------------- */
#define HY_PRCTL_MAGIC      0x4879756eULL   /* "Hyun" */
#define HY_NR_HANDSHAKE     93
#define HY_NR_TI_DOWN_ID    103
#define HY_NR_TI_MOVE_ID    104
#define HY_NR_TI_UP_ID      105
#define HY_NR_TI_UP_ALL     106
#define HY_NR_TI_CAPACITY   107

#define HY_HS_STEP_REQ      1
#define HY_HS_STEP_ANS      2
#define HY_CHAL_LEN         32

#define HY_KEY_MAGIC_LOW    ((uint32_t)(HY_MAGIC & 0xFFFFu))
#define HY_HS_MAGIC_OF(st)  ((uint32_t)(HY_KEY_MAGIC_LOW | \
                                       (((uint32_t)(st) & 0xFFFFu) << 16)))

#define HY_HS_OK       0
#define HY_HS_BAD_MAGIC 1
#define HY_HS_BAD_VER  2
#define HY_HS_BAD_KEY  3
#define HY_HS_BAD_BOTH 4
#define HY_HS_NO_CHAL  5
#define HY_HS_DONE     6

#define HY_VER_MAJOR 1
#define HY_VER_MINOR 78
#define HY_VERSION_STRING "1.78.0"


/* ---- 自实现 cos/sin（查表 + 线性插值，避免静态链接 libm 的巨大开销）----
 * 画圆只需要角度 -> 坐标，面板坐标还要取整，1024 项表的精度远远够用。
 */
#define HY_TRIG_STEPS 1024
static double g_cos_tbl[HY_TRIG_STEPS + 1];

static double hy_floor(double x)
{
    double xi = (double)(long long)x;
    if (x < 0.0 && xi != x) xi -= 1.0;
    return xi;
}

static void trig_init(void)
{
    int i;
    for (i = 0; i <= HY_TRIG_STEPS; i++) {
        /* 用泰勒级数在建表时算一次，避免依赖 libm */
        double x = 6.28318530717958647692 * (double)i / (double)HY_TRIG_STEPS;
        double t = 1.0, sum = 1.0;
        int k;
        for (k = 1; k <= 10; k++) {
            t = -t * x * x / (double)((2 * k - 1) * (2 * k));
            sum += t;
        }
        g_cos_tbl[i] = sum;
    }
}

static double trig_cos(double a)
{
    const double TAU = 6.28318530717958647692;
    double u, frac, c0, c1;
    int idx;
    a = a - TAU * hy_floor(a / TAU);
    if (a < 0) a += TAU;
    u = a * (double)HY_TRIG_STEPS / TAU;
    idx = (int)u;
    frac = u - (double)idx;
    if (idx >= HY_TRIG_STEPS) idx = HY_TRIG_STEPS - 1;
    c0 = g_cos_tbl[idx];
    c1 = g_cos_tbl[idx + 1];
    return c0 + (c1 - c0) * frac;
}

static double trig_sin(double a)
{
    return trig_cos(1.57079632679489661923 - a);
}

#pragma pack(push, 1)
struct hy_handshake_req {
    uint32_t magic;
    uint32_t uver_major;
    uint32_t uver_minor;
    char     uver_str[24];
    char     key[264];
    uint32_t result;
    uint32_t lock_ver;
    uint32_t lock_key;
    uint32_t locked;
};

struct hy_ti_finger_op {
    int32_t id;
    int32_t x;
    int32_t y;
};

struct hy_ti_cap {
    int32_t capacity;
    int32_t active;
    int32_t total_slots;
    int32_t reserved;
};
#pragma pack(pop)

/* ---------------- prctl 通道 ---------------- */
static long hy_prctl(unsigned int nr, void *payload)
{
    return syscall(__NR_prctl, (unsigned long)HY_PRCTL_MAGIC,
                   (unsigned long)nr, (unsigned long)payload,
                   0UL, 0UL);
}

/* ---------------- 挑战应答解密（与 hpp 的 chal_layer_inv 完全一致） ---- */
static void chal_layer_inv(unsigned char *buf, size_t len,
                           const char *key, size_t klen)
{
    size_t i;
    unsigned acc = 0u, rot;

    if (!klen) return;
    for (i = 0; i < klen; ++i)
        acc = (unsigned)(acc + (unsigned char)key[i]);
    rot = (acc % 7u) + 1u;

    for (i = len; i > 0; --i) {
        size_t j = i - 1;
        unsigned v = (unsigned)buf[j];
        unsigned prev;
        v = ((v >> rot) | (v << (8 - rot))) & 0xFFu;
        prev = (j == 0) ? 0xA5u : (unsigned)buf[j - 1];
        buf[j] = (unsigned char)(v ^ (unsigned)(unsigned char)key[j % klen] ^ prev);
    }
}

/* 解密顺序必须与内核加密顺序严格相反：L5 → L4 → L3 → L2 → L1 */
static void chal_decrypt(unsigned char *buf, size_t len)
{
    chal_layer_inv(buf, len, HY_KEY_L5, (size_t)HY_KEY_LEN_L5);
    chal_layer_inv(buf, len, HY_KEY_L4, (size_t)HY_KEY_LEN_L4);
    chal_layer_inv(buf, len, HY_KEY_L3, (size_t)HY_KEY_LEN_L3);
    chal_layer_inv(buf, len, HY_KEY_L2, (size_t)HY_KEY_LEN_L2);
    chal_layer_inv(buf, len, HY_KEY_L1, (size_t)HY_KEY_LEN_L1);
}

static const char *hs_result_text(uint32_t res)
{
    switch (res) {
    case HY_HS_OK:         return "本步通过";
    case HY_HS_BAD_MAGIC:  return "阶段号或 magic 不匹配";
    case HY_HS_BAD_VER:    return "版本不一致";
    case HY_HS_BAD_KEY:    return "挑战应答与原文不一致（五层密钥解错）";
    case HY_HS_BAD_BOTH:   return "版本与应答都不一致";
    case HY_HS_NO_CHAL:    return "还没请求挑战就提交应答";
    case HY_HS_DONE:       return "两步都过，已放行";
    default:               return "未知结果码";
    }
}

/* 两步握手。失败返回 -1 */
static int do_handshake(void)
{
    struct hy_handshake_req r;
    unsigned char ans[HY_CHAL_LEN];
    size_t i;
    long ret;

    memset(&r, 0, sizeof(r));
    r.magic      = HY_HS_MAGIC_OF(HY_HS_STEP_REQ);
    r.uver_major = HY_VER_MAJOR;
    r.uver_minor = HY_VER_MINOR;
    snprintf(r.uver_str, sizeof(r.uver_str), "%s", HY_VERSION_STRING);

    ret = hy_prctl(HY_NR_HANDSHAKE, &r);
    if (ret != 0) {
        printf("[握手] 第 1 步调用失败 ret=%ld (%s)\n", ret, strerror(errno));
        return -1;
    }
    printf("[握手] 内核版本=%s  lock_ver=%u\n",
           r.uver_str[0] ? r.uver_str : "(空)", r.lock_ver);
    if (!r.lock_ver) {
        printf("[握手] 失败：%s\n", hs_result_text(r.result));
        return -1;
    }

    /* 密文是二进制、可能含 0x00，按定长取，不按字符串 */
    for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
        ans[i] = (unsigned char)r.key[i];
    chal_decrypt(ans, (size_t)HY_CHAL_LEN);

    memset(&r, 0, sizeof(r));
    r.magic      = HY_HS_MAGIC_OF(HY_HS_STEP_ANS);
    r.uver_major = HY_VER_MAJOR;
    r.uver_minor = HY_VER_MINOR;
    snprintf(r.uver_str, sizeof(r.uver_str), "%s", HY_VERSION_STRING);
    for (i = 0; i < (size_t)HY_CHAL_LEN; ++i)
        r.key[i] = (char)ans[i];
    r.key[HY_CHAL_LEN] = 0;

    /* 明文用完就抹 */
    for (i = 0; i < (size_t)HY_CHAL_LEN; ++i) ans[i] = 0;

    ret = hy_prctl(HY_NR_HANDSHAKE, &r);
    if (ret != 0) {
        printf("[握手] 第 2 步调用失败 ret=%ld (%s)\n", ret, strerror(errno));
        return -1;
    }
    if (!r.locked) {
        printf("[握手] 未放行：%s\n", hs_result_text(r.result));
        return -1;
    }
    printf("[握手] 通过（版本一致，密钥正确）\n");
    return 0;
}

/* ---------------- 触摸操作 ---------------- */
static int ti_down_id(int id, int x, int y)
{
    struct hy_ti_finger_op o;
    memset(&o, 0, sizeof(o));
    o.id = id; o.x = x; o.y = y;
    return (int)hy_prctl(HY_NR_TI_DOWN_ID, &o);
}
static int ti_move_id(int id, int x, int y)
{
    struct hy_ti_finger_op o;
    memset(&o, 0, sizeof(o));
    o.id = id; o.x = x; o.y = y;
    return (int)hy_prctl(HY_NR_TI_MOVE_ID, &o);
}
static int ti_up_all(void)
{
    return (int)hy_prctl(HY_NR_TI_UP_ALL, NULL);
}
static int ti_capacity(int *cap, int *active, int *total)
{
    struct hy_ti_cap c;
    memset(&c, 0, sizeof(c));
    long r = hy_prctl(HY_NR_TI_CAPACITY, &c);
    if (r != 0) return -1;
    if (cap)    *cap    = c.capacity;
    if (active) *active = c.active;
    if (total)  *total  = c.total_slots;
    return 0;
}

/* ---------------- 画圆 ---------------- */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* 面板坐标范围 —— getevent -lp /dev/input/event7 实测。
 * 这不是屏幕像素！固定 1080x2354 那档时 面板X = 屏幕X * 18.84 */
#define PANEL_W 20351
#define PANEL_H 44351

static volatile sig_atomic_t g_run = 1;
static void on_stop(int s) { (void)s; g_run = 0; }

/* 看门狗：主线程卡死时的最后兜底 */
static volatile int       g_wd_armed    = 0;
static volatile long long g_wd_deadline = 0;

static void *wd_thread(void *arg)
{
    (void)arg;
    while (g_wd_armed) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        if (ts.tv_sec > g_wd_deadline) {
            fprintf(stderr, "[看门狗] 主线程超时，强制抬起并退出\n");
            ti_up_all();
            _exit(2);
        }
        usleep(200000);
    }
    return NULL;
}
static void wd_arm(int grace_sec)
{
    struct timespec ts;
    pthread_t t;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    g_wd_deadline = ts.tv_sec + grace_sec;
    g_wd_armed = 1;
    pthread_create(&t, NULL, wd_thread, NULL);
    pthread_detach(t);
}

struct Circle {
    int    id;
    double cx, cy, r, phase, speed;
};

/* 绝对时间累加。不能用 usleep —— 每帧误差会累积，采样就不匀 */
static void ts_add(struct timespec *ts, long ns)
{
    ts->tv_nsec += ns;
    while (ts->tv_nsec >= 1000000000L) {
        ts->tv_nsec -= 1000000000L;
        ts->tv_sec  += 1;
    }
}

/* 跑一个阶段：按下 → 连续 move（中途绝不抬手）→ 抬起 */
static long long run_phase(const struct Circle *cs, int n,
                           int hz, int lap_ms, int seconds)
{
    const long   period_ns = 1000000000L / hz;
    const int    frames_per_lap = hz * lap_ms / 1000;
    const double dtheta = 2.0 * M_PI / frames_per_lap;
    struct timespec next;
    long long frame = 0, fails = 0;
    const long long max_frames = (long long)seconds * hz;
    int k;

    printf("\n[阶段] %d 根手指 / %dHz / 一圈 %dms / 时长 %ds\n",
           n, hz, lap_ms, seconds);
    for (k = 0; k < n; k++)
        printf("  id=%d 圆心=(%.0f,%.0f) 半径=%.0f\n",
               cs[k].id, cs[k].cx, cs[k].cy, cs[k].r);

    /* 一次 down，之后只 move —— 这才是"不断触" */
    for (k = 0; k < n; k++) {
        long r = ti_down_id(cs[k].id,
                            (int)(cs[k].cx + cs[k].r), (int)cs[k].cy);
        if (r != 0) printf("[错误] id=%d down 失败 ret=%ld (%s)\n",
                           cs[k].id, r, strerror(errno));
    }

    clock_gettime(CLOCK_MONOTONIC, &next);

    while (g_run && frame < max_frames) {
        for (k = 0; k < n; k++) {
            double a = cs[k].phase + dtheta * cs[k].speed * (double)frame;
            int x = (int)(cs[k].cx + cs[k].r * trig_cos(a));
            int y = (int)(cs[k].cy + cs[k].r * trig_sin(a));
            if (ti_move_id(cs[k].id, x, y) != 0) {
                fails++;
                if (fails < 10)
                    printf("[错误] id=%d 第 %lld 帧 move 失败 (%s)\n",
                           cs[k].id, frame, strerror(errno));
            }
        }

        /* 每 2 秒报一次，好对照 tstat 里 m= 的计数 */
        if ((frame % (long long)(hz * 2)) == 0 && frame > 0)
            printf("[进度] %lld/%lld 帧（%.1f 圈）失败=%lld\n",
                   frame, max_frames, (double)frame / frames_per_lap, fails);

        frame++;
        ts_add(&next, period_ns);
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL);
    }

    printf("[阶段结束] %lld 帧，失败 %lld 次\n", frame, fails);
    ti_up_all();   /* 换手指数量前必须清干净 */
    return frame;
}

int main(int argc, char **argv)
{
    int only    = (argc > 1) ? atoi(argv[1]) : 0;   /* 0=两阶段都跑 */
    int seconds = (argc > 2) ? atoi(argv[2]) : 20;
    int hz      = (argc > 3) ? atoi(argv[3]) : 120;
    int lap_ms  = (argc > 4) ? atoi(argv[4]) : 2000;
    long long total_frames = 0;
    double cx = PANEL_W / 2.0;

    if (only != 0 && only != 1 && only != 3) {
        printf("第一个参数只能是 0（默认跑两阶段）、1 或 3\n");
        return 1;
    }
    if (seconds < 1 || seconds > 600) seconds = 20;
    if (hz < 30 || hz > 500) hz = 120;
    if (lap_ms < 200) lap_ms = 200;

    printf("欢愉 虚拟手指画圆  v%s\n", HY_VERSION_STRING);
    trig_init();

    if (do_handshake() != 0) {
        printf("握手失败 —— 确认 APatch 里已加载欢愉 kpm，且用户态版本与内核一致\n");
        return 1;
    }

    {
        int cap = 0, active = 0, total = 0;
        if (ti_capacity(&cap, &active, &total) == 0) {
            printf("[容量] 可再按=%d 已按着=%d 总槽位=%d\n", cap, active, total);
            if (total > 0 && cap > total)
                printf("[警告] 容量 %d 超过总槽位 %d（1.78.0 应已修复）\n", cap, total);
            if (total > 0 && cap < 3 && (only == 0 || only == 3))
                printf("[警告] 容量 %d < 3 根，可能有真手指占着槽位\n", cap);
        }
    }

    signal(SIGINT,  on_stop);
    signal(SIGTERM, on_stop);

    /* 看门狗：总时长 + 5 秒宽限，超时强制清场退出 */
    wd_arm(seconds * ((only == 0) ? 2 : 1) + 5);

    if (only == 0 || only == 1) {
        struct Circle c1[1] = {
            { 0, cx, PANEL_H / 2.0, 4000.0, 0.0, 1.0 }
        };
        total_frames += run_phase(c1, 1, hz, lap_ms, seconds);
    }

    if (g_run && (only == 0 || only == 3)) {
        struct Circle c3[3] = {
            { 0, cx, PANEL_H * 0.25, 3300.0, 0.0,        1.0 },  /* 上 */
            { 1, cx, PANEL_H * 0.50, 3300.0, M_PI * 2/3, 1.0 },  /* 中 */
            { 2, cx, PANEL_H * 0.75, 3300.0, M_PI * 4/3, 1.0 }   /* 下 */
        };
        usleep(300000);   /* 阶段间小停，让上一次抬起彻底生效 */
        total_frames += run_phase(c3, 3, hz, lap_ms, seconds);
    }

    /* 无论如何都要抬起，否则手指会卡在屏幕上 */
    ti_up_all();
    usleep(100000);
    ti_up_all();

    printf("\n[完成] 共 %lld 帧，已抬起全部虚拟手指，程序退出\n", total_frames);
    g_wd_armed = 0;
    return 0;
}
