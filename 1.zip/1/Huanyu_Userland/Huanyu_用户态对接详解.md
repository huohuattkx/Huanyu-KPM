# 欢愉 Huanyu 用户态对接文档

> 版本 **1.80.0** · 对应内核模块 `huanyu_v1.80.0.kpm`
>
> 本文档**只讲怎么用**——头文件提供哪些类、哪些方法、怎么编译、怎么排错。不涉及内核侧实现。
>
> 配套源码：`huanyu.hpp`（字符串命令通道）、`huanyu_wanbai.hpp`（二进制结构体通道）。

---

## 目录

1. [两个头文件怎么选](#1-两个头文件怎么选)
2. [五分钟上手](#2-五分钟上手)
3. [编译](#3-编译)
4. [核心类 `huanyu_wanbai` 全接口](#4-核心类-huanyu_wanbai-全接口)
5. [触摸注入完整指南](#5-触摸注入完整指南)
6. [坐标系统（必读）](#6-坐标系统必读)
7. [内存读写](#7-内存读写)
8. [进程与模块](#8-进程与模块)
9. [断点](#9-断点)
10. [其他能力](#10-其他能力)
11. [配套工具](#11-配套工具)
12. [错误处理速查](#12-错误处理速查)
13. [版本与密钥规则](#13-版本与密钥规则)

---

## 1. 两个头文件怎么选

| | `huanyu.hpp` | `huanyu_wanbai.hpp` |
|---|---|---|
| 通道 | 字符串命令（`sc_cmds`） | prctl / supercall 二进制 |
| 命令定义 | `HY_CMD_*` | `HY_PRCTL_*` / `HY_NR_*` |
| 参数传递 | 字符串拼接 | 结构体字段 |
| 适合 | 手工调试、脚本、命令面板 | **程序化调用、高频调用** |
| 触摸多指 | 有（带 `id`） | 有（`ti_down_id` 等） |

> **做程序用 `huanyu_wanbai.hpp`。** 二进制结构体通道是单次 syscall，性能远好于字符串拼接。
>
> 本文档以 `huanyu_wanbai.hpp` 为主。

**两者不能混用**：`huanyu_wanbai.hpp` 里没有 `sc_cmds` / `HY_CMD_TDOWN` / `cmd_touch` 这些；反之亦然。

---

## 2. 五分钟上手

```cpp
#include "huanyu_wanbai.hpp"

int main() {
    huanyu_wanbai drv;
    if (!drv.init(true)) {          // true = 顺便探测链路
        drv.link_dump();            // 打印诊断
        return 1;
    }

    drv.ti_down(10175, 22175);      // 按下
    drv.ti_move(12000, 22175);      // 移动
    drv.ti_up();                    // 抬起
    return 0;
}
```

编译：

```bash
aarch64-linux-android31-clang++ -std=c++17 -O2 main.cpp -o main -lm -lpthread
```

---

## 3. 编译

### 3.1 NDK（推荐）

```bash
# 用配套脚本
make -f Makefile.testui ndk NDK=/path/to/android-ndk-r27c

# 或手动
$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android31-clang++ \
    -std=c++17 -O2 -static huanyu_test_ui.cpp -o hy_ui -lm -lpthread
```

### 3.2 手机端 Termux

```bash
clang++ -std=c++17 -O2 huanyu_test_ui.cpp -o hy_ui -lm -lpthread
```

### 3.3 通用

```bash
g++ -std=c++17 -Wall -Wextra -O2 xxx.cpp -o xxx -lm -lpthread
```

**依赖**：`-lm`（数学）、`-lpthread`（线程）。仅此两项，无第三方库。

---

## 4. 核心类 `huanyu_wanbai` 全接口

### 4.1 生命周期

| 方法 | 说明 |
|---|---|
| `bool init(bool probe = true)` | 初始化并建立握手。`probe=true` 时顺便探测链路并打印诊断 |
| `bool is_ready() const` | 是否完成初始化 |
| `bool is_authed() const` | 是否已通过鉴权 |
| `bool handshake_ok() const` | 握手结果 |
| `uint32_t handshake_result() const` | 握手返回码 |
| `hy_link_report link_report() const` | 返回链路探测报告结构体 |
| `void link_dump() const` | 打印链路诊断（排错第一步） |
| `bool kernelpatch_ready() const` | KernelPatch 是否就绪 |
| `int get_fd() const` | 内部 fd |

### 4.2 触摸注入

| 方法 | 说明 |
|---|---|
| `bool ti_down(int x, int y) const` | 按下（自动分配 id） |
| `bool ti_move(int x, int y) const` | 移动（作用于默认手指） |
| `bool ti_up() const` | 抬起（默认手指） |
| `bool ti_down_id(int id, int x, int y) const` | **指定 id 按下** |
| `bool ti_move_id(int id, int x, int y) const` | **指定 id 移动** |
| `bool ti_up_id(int id) const` | **指定 id 抬起** |
| `bool ti_up_all() const` | **抬起全部手指** |
| `bool ti_clear() const` | **强制清除残留手指** |
| `bool ti_capacity(int *cap, int *active = nullptr, int *total = nullptr) const` | 查询容量 / 活跃数 / 总槽位 |

多指示例：

```cpp
drv.ti_down_id(0, x0, y0);      // 第一根
drv.ti_down_id(1, x1, y1);      // 第二根
drv.ti_move_id(0, x0b, y0b);    // 各自独立滑动
drv.ti_move_id(1, x1b, y1b);
drv.ti_up_all();                // 一键清场
```

> `ti_up_all()` 建议放在程序退出路径上——异常退出不留残指。
>
> 手指卡住不消失时调 `ti_clear()`。

### 4.3 内存读写

```cpp
uintptr_t read_ptr(uintptr_t addr) const;
bool read(uintptr_t addr, void *buf, uint32_t n) const;
bool write(uintptr_t addr, const void *buf, uint32_t n) const;
bool read_chain(uintptr_t base, const uint32_t *offs, int n, uintptr_t *out) const;
```

`read_chain` 用于跟随多级指针（解引用链路）。

### 4.4 进程与模块

```cpp
long enum_processes(...);
long enum_modules(pid_t pid, ...);
uintptr_t module_base(pid_t pid, const char *name);   // 有 8 项缓存
void base_cache_clear() const;
pid_t find_pid(const char *pkg);
int init_pid(pid_t target_pid);                       // 设置默认目标进程
```

### 4.5 断点

```cpp
uint32_t bp_caps(...);
long bp_install(...);
long bp_remove(...);
int bp_scheme_check(int scheme, ...);
```

### 4.6 其他

| 方法 | 说明 |
|---|---|
| `std::string sysmon_read(...)` | 系统调用监控读数 |
| `enum_segments(...)` / `enum_regions(...)` | 段 / 可扫描区域枚举 |
| `bool shm_ready() const` | 共享内存通道是否就绪 |
| `long daemon_cmd(...)` | 走守护进程通道（若有） |
| `hy_http_result hy_http_download(url, ...)` | HTTP 下载（工具用） |

---

## 5. 触摸注入完整指南

### 5.1 一次完整的滑动

```cpp
// 一个 down 对应全程 move，中途绝不抬手
drv.ti_down(x0, y0);
for (int i = 1; i <= frames; ++i) {
    drv.ti_move(xi, yi);
    sleep_until(next_frame);     // 见 5.2
}
drv.ti_up();
```

**连续滑动不需要任何特殊设置**——这是输入协议本身的语义：按下时分配一次标识，之后只改坐标，内核就认为还是同一根手指。

### 5.2 匀速时序（关键）

不要用 `usleep(8333)`——每帧误差会累积，几百帧后采样就歪了。

用**绝对时间累加**：

```cpp
#include <time.h>

struct FrameClock {
    struct timespec next;
    long period_ns;               // 120Hz → 8333333

    void start(long hz) {
        period_ns = 1000000000L / hz;
        clock_gettime(CLOCK_MONOTONIC, &next);
    }
    void wait_next() {
        next.tv_nsec += period_ns;
        while (next.tv_nsec >= 1000000000L) {
            next.tv_nsec -= 1000000000L;
            next.tv_sec  += 1;
        }
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, nullptr);
    }
};
```

### 5.3 多指独立运动

三根手指画圆（不同圆心、不同相位）：

```cpp
const int N = 3;
double cx[N], cy[N], phase[N];
// 圆心：屏幕 25% / 50% / 75% 高度
// 相位：各错开 120°

for (int id = 0; id < N; ++id)
    drv.ti_down_id(id, cx[id] + r, cy[id]);

FrameClock clk; clk.start(120);
for (int f = 0; f < total_frames; ++f) {
    for (int id = 0; id < N; ++id) {
        double a = phase[id] + 2*M_PI * f / frames_per_circle;
        drv.ti_move_id(id, cx[id] + r*cos(a), cy[id] + r*sin(a));
    }
    clk.wait_next();
}
drv.ti_up_all();
```

**要是三根黏在一起动，说明槽位串了**——一眼能看出来。

### 5.4 防卡死（必须做）

四层保险，配套工具 `hytool` 里都有：

1. **SIGINT/SIGTERM 捕获** → 立刻 `ti_up_all()`
2. **看门狗线程**：总时长 + 宽限，超时强制 `ti_up_all()` 后 `_exit()`
3. 每阶段结束自动 `ti_up_all()`
4. 退出前**连抬两次**（间隔 ~100ms），防最后一帧没生效

### 5.5 容量是动态的

```
可再按虚拟手指 = 总槽位 − 真手指占用
```

真手指落下时，多余的虚拟手指会自动让位（不报错，但会失效）。用 `ti_capacity()` 实时查：

```cpp
int cap, active, total;
drv.ti_capacity(&cap, &active, &total);
```

---

## 6. 坐标系统（必读）

### 6.1 两套坐标

| | 范围 | 用途 |
|---|---|---|
| **屏幕像素** | `1080 × 2354` | 你在设置里看到的 |
| **触摸面板坐标** | `20351 × 44351` | **注入接口要的是这个** |

**面板 ≠ 像素**，两者差一个倍率。注入接口**不做换算**，传进去多少就是多少。

### 6.2 倍率

```
本机：面板 = 屏幕像素 × 18.84
```

（20351 ÷ 1080 = 18.84，44351 ÷ 2354 = 18.84，两个方向一致）

```cpp
int panel_x = (int)(screen_x * 18.84);
int panel_y = (int)(screen_y * 18.84);
```

### 6.3 ⚠️ 分辨率档位陷阱

系统若设为**「智能切换」**，会在 `1080×2354` 和 `1272×2772` 两档间自动切换。

切到 1272 档时倍率变成 **16.0**（20351÷1272 ≈ 15.997），同一组面板坐标对应的屏幕位置会偏。

> **调试期间请把分辨率固定到「FHD+ 高清 1080×2354」。**

### 6.4 拿到真实面板范围

模块自学的范围偏小（它记的是"摸到过的最大值"，没滑到边缘就偏小）。用这条拿真实值：

```bash
getevent -lp /dev/input/event7
```

看 `ABS_MT_POSITION_X` / `ABS_MT_POSITION_Y` 的 `max`。

然后用 `trange` 下发给模块（设过之后自学不再覆盖）：

```bash
echo 'trange 0 20351 0 44351' > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tslots 10' > /proc/HuanyuD; cat /proc/HuanyuD
```

### 6.5 中心点参考

面板 `20351 × 44351` 的正中心 = **`(10175, 22175)`**。

---

## 7. 内存读写

```cpp
uintptr_t base = drv.module_base(pid, "libUE4.so");
uintptr_t val  = drv.read_ptr(base + 0x1234);

uint32_t offs[] = {0x20, 0x270};
uintptr_t out;
drv.read_chain(base, offs, 2, &out);
```

写入：

```cpp
uint32_t v = 1;
drv.write(addr, &v, sizeof(v));
```

---

## 8. 进程与模块

```cpp
pid_t pid = drv.find_pid("com.example.app");
drv.init_pid(pid);                              // 设为默认目标
uintptr_t b = drv.module_base(pid, "libxxx.so");
```

`module_base` 内部有 8 项缓存，反复查同一模块不会重复解析 `/proc/pid/maps`。进程重启后调 `base_cache_clear()`。

---

## 9. 断点

```cpp
uint32_t caps;
drv.bp_caps(&caps);                    // 查能力
int chk = drv.bp_scheme_check(scheme, &why);   // 方案自检
```

具体安装/移除参数见头文件内注释。

---

## 10. 其他能力

| 能力 | 入口 |
|---|---|
| 系统调用监控 | `sysmon_read(...)` |
| 段枚举 | `enum_segments(...)` |
| 可扫描区域枚举 | `enum_regions(...)`（rw-p，排除特殊区） |
| 共享内存通道 | `shm_ready()` + `shm_cmd_obj(...)` |
| 守护进程通道 | `daemon_cmd_obj(...)` |
| HTTP 下载 | `hy_http_download(url, ...)` |

---

## 11. 配套工具

### 11.1 `hytool`（无交互测试器，推荐）

```bash
./hytool info                          # 链路 / 容量 / 范围 / protect
./hytool setup                         # 下发 20351x44351 + 10 槽
./hytool --px click 540 1177           # 用屏幕像素点击
./hytool --px slide 200 1000 900 1000 1000 120
./hytool --px circle 1 20 120          # 单指画圈 20 秒
./hytool --px circle 3 20 120          # 三指：屏幕 25%/50%/75% 各画一圈
./hytool jitter 10 120                 # 只统计抖动，不下发
./hytool up                            # 抬手 + 强制清除
```

- **`--px`** = 输入屏幕像素，内部自动按 18.84 换算成面板坐标
- **`jitter`** 直接回答"为什么抽搐"：统计实测帧间隔的最小/平均/最大，算抖动峰峰值百分比。`<30%` 顺滑，`>100%` 明显抽搐。它**不下发任何事件**，测的是纯调度抖动，能区分"内核丢事件"和"调用侧喂得不匀"

### 11.2 `huanyu_test_ui`（终端菜单 UI）

14 个功能页：连接诊断 / 触摸诊断 / 注入测试（单点、直线、画圈、多指、往复、抖动压测、帧率对照）/ 参数设置 / 安全清理。参数可调、回车执行。

### 11.3 `touch_circle.cpp` / `touch_circle_c.c`

纯画圈示例。C 版自包含（连 cos/sin 都自己查表），可直接编成 arm64 静态二进制。

---

## 12. 错误处理速查

| 现象 | 原因 / 处理 |
|---|---|
| `init()` 返回 false | 先调 `drv.link_dump()` 看诊断 |
| 编译失败：静态断言 | 版本号三处不一致，见 [13](#13-版本与密钥规则) |
| 握手失败 | 版本串不一致，或密钥未同步换 |
| 按下没反应 | ① 坐标用了屏幕像素而非面板坐标 ② 未 `trange` ③ 屏幕没固定到 1080 档 |
| 手指卡住不消失 | `ti_clear()` |
| 滑动一跳一跳 | 调用侧时序不匀，用 `jitter` 定性；改绝对时间累加 |
| 多指黏在一起 | 槽位串了，检查 `ti_capacity()` 的 `cap` 是否 ≤ `total` |
| cap > total | 异常，说明槽位口径有问题 |

**排错第一步永远是**：

```cpp
drv.link_dump();
```

或者直接命令行：

```bash
echo 'touchstat' > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tstat'     > /proc/HuanyuD; cat /proc/HuanyuD
```

---

## 13. 版本与密钥规则

### 13.1 三处必须同步

改版本号时必须同时改：

1. 内核侧版本串
2. `huanyu.hpp`
3. `huanyu_wanbai.hpp`

> 头文件里有**静态断言**检查版本字符串与 `MAJOR/MINOR/PATCH` 数字是否一致。漏改会直接编译失败——这是保护机制，不是 bug。

### 13.2 密钥

五层密钥，L1 固定 6 字节，L2/L3/L4 各 64 字节，L5 为 256 字节。三处逐字节一致。

**换新版本时两个 hpp 必须一起换**，否则：
- 版本不一致 → 编译失败（静态断言）
- 侥幸通过 → 握手被拒

命令行 `echo ... > /proc/HuanyuD` 调试**不受密钥影响**。

### 13.3 验证版本

```bash
echo 'version' > /proc/HuanyuD; cat /proc/HuanyuD
```

---

## 附：加载后标准流程

```bash
# 1. 确认版本
echo 'version' > /proc/HuanyuD; cat /proc/HuanyuD

# 2. 开探测，摸几下屏让模块认设备
echo 'probe on' > /proc/HuanyuD; cat /proc/HuanyuD

# 3. 固定真实范围（自学值偏小）
echo 'trange 0 20351 0 44351' > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tslots 10' > /proc/HuanyuD; cat /proc/HuanyuD

# 4. 看容量
echo 'tfinger' > /proc/HuanyuD; cat /proc/HuanyuD

# 5. 单指测中心
echo 'tdown 10175 22175' > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tup' > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tstat' > /proc/HuanyuD; cat /proc/HuanyuD
```

开「开发者选项 → 指针位置」看落点。

**调试期间把分辨率固定到「FHD+ 高清 1080×2354」。**

---

*文档对应版本 1.80.0*
