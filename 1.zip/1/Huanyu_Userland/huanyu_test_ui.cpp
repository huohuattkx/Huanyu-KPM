/*
 * ============================================================================
 *  欢愉 (Huanyu) —— 内核模块驱动测试台  v1.78.0
 * ============================================================================
 *
 *  基于 huanyu_wanbai.hpp 编译。终端菜单式 UI，所有参数可现场调整。
 *
 *  编译（Android arm64 / NDK）：
 *    aarch64-linux-android31-clang++ -std=c++17 -O2 -static \
 *        huanyu_test_ui.cpp -o huanyu_test_ui -lpthread -lm
 *
 *  编译（手机 Termux）：
 *    clang++ -std=c++17 -O2 huanyu_test_ui.cpp -o huanyu_test_ui -lpthread -lm
 *
 *  前置：APatch 中已加载 huanyu_<版本>.kpm，且以 root 运行本程序。
 *
 * ----------------------------------------------------------------------------
 *  设计要点（决定"能不能不断触"的三件事，都在代码里落实了）
 * ----------------------------------------------------------------------------
 *  1) 一次 down 对应全程 move，中途绝不抬手。
 *     TRACKING_ID 在 down 时分配一次后一直有效，内核据此认作同一根手指。
 *
 *  2) 绝对时间累加（clock_nanosleep + TIMER_ABSTIME），不是 usleep(8333)。
 *     后者每帧误差会累积，几百帧后采样间隔就歪了，InputReader 重采样会跳。
 *
 *  3) 匀速小步长。每帧只走一点点，别一帧跳几千像素。
 *
 *  另外三层防卡死：SIGINT/SIGTERM 捕获、看门狗线程硬超时、退出前连抬两次。
 * ============================================================================
 */

#include "huanyu_wanbai.hpp"

#include <cctype>
#include <cmath>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <string>
#include <thread>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* ============================ 全局可调参数 ============================ */

struct GParams {
    /* ---- 坐标系 ---- */
    int  panel_w      = 20351;   /* 面板 X 上限（getevent ABS_MT_POSITION_X max） */
    int  panel_h      = 44351;   /* 面板 Y 上限 */
    int  screen_w     = 1080;    /* 屏幕像素宽（用于换算，不注入） */
    int  screen_h     = 2354;    /* 屏幕像素高 */
    bool use_screen_px = true;   /* true = 菜单里填屏幕像素，程序自动换算成面板坐标 */

    /* ---- 时序 ---- */
    int  hz           = 120;     /* 注入帧率 */
    int  dur_ms       = 20000;   /* 单次动作时长 */
    int  circle_ms    = 2000;    /* 转一圈的时长 */

    /* ---- 轨迹 ---- */
    double radius_pct = 0.12;    /* 半径 = min(面板宽,高) * 该比例 */
    int  n_fingers    = 3;       /* 多指手指数 */

    /* ---- 安全 ---- */
    int  watchdog_grace_ms = 5000;

} P;

/* 把"用户输入的坐标"换算成面板坐标 */
static int to_panel_x(double v) {
    return P.use_screen_px ? (int)llround(v * P.panel_w / P.screen_w) : (int)llround(v);
}
static int to_panel_y(double v) {
    return P.use_screen_px ? (int)llround(v * P.panel_h / P.screen_h) : (int)llround(v);
}
static double from_panel_x(int v) {
    return P.use_screen_px ? (v * (double)P.screen_w / P.panel_w) : v;
}
static double from_panel_y(int v) {
    return P.use_screen_px ? (v * (double)P.screen_h / P.panel_h) : v;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

/* ============================ 防卡死 ============================ */

static volatile sig_atomic_t g_stop = 0;
static std::thread  g_wd;
static volatile int g_wd_limit_ms = 0;
static time_t       g_wd_start    = 0;

static void emergency_lift() {
    if (driver) {
        driver->ti_up_all();
        /* 连抬两次：防最后一帧被内核侧竞态吃掉 */
        struct timespec ts = {0, 100 * 1000 * 1000};
        nanosleep(&ts, nullptr);
        driver->ti_up_all();
    }
}

extern "C" void hyui_sig(int s) {
    (void)s;
    g_stop = 1;
    emergency_lift();
    printf("\n[!] 收到中断信号，已抬起全部虚拟手指。\n");
    fflush(stdout);
    _exit(0);
}

static void watchdog_main() {
    while (!g_stop) {
        struct timespec ts = {0, 200 * 1000 * 1000};
        nanosleep(&ts, nullptr);
        if (g_wd_limit_ms > 0 && !g_stop) {
            long long el = (long long)(time(nullptr) - g_wd_start) * 1000;
            if (el > g_wd_limit_ms) {
                printf("\n[!] 看门狗超时（%lld ms > %d ms），强制抬手退出。\n",
                       el, g_wd_limit_ms);
                fflush(stdout);
                emergency_lift();
                _exit(2);
            }
        }
    }
}

static void wd_arm(int total_ms) {
    g_wd_start     = time(nullptr);
    g_wd_limit_ms  = total_ms + P.watchdog_grace_ms;
}
static void wd_disarm() { g_wd_limit_ms = 0; }

/* ============================ 时间工具 ============================ */

static long long now_ns() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static void sleep_until(long long abs_ns) {
    struct timespec ts;
    ts.tv_sec  = (time_t)(abs_ns / 1000000000LL);
    ts.tv_nsec = (long)(abs_ns % 1000000000LL);
    clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, nullptr);
}

/* ============================ UI 小工具 ============================ */

#define C_RESET "\033[0m"
#define C_BOLD  "\033[1m"
#define C_CYAN  "\033[36m"
#define C_GRN   "\033[32m"
#define C_YEL   "\033[33m"
#define C_RED   "\033[31m"
#define C_GRAY  "\033[90m"

static void hr()  { printf(C_GRAY "---------------------------------------------------------------\n" C_RESET); }
static void hr2() { printf(C_CYAN "===============================================================\n" C_RESET); }

static void clear_screen() { printf("\033[2J\033[H"); }

static std::string ask_str(const char *prompt, const std::string &def) {
    printf("%s [%s]: ", prompt, def.c_str());
    fflush(stdout);
    std::string line;
    if (!std::getline(std::cin, line)) return def;
    /* 去首尾空白 */
    size_t a = line.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return def;
    size_t b = line.find_last_not_of(" \t\r\n");
    return line.substr(a, b - a + 1);
}

static int ask_int(const char *prompt, int def) {
    std::string s = ask_str(prompt, std::to_string(def));
    if (s.empty()) return def;
    return (int)strtol(s.c_str(), nullptr, 0);
}

static double ask_dbl(const char *prompt, double def) {
    char buf[64];
    snprintf(buf, sizeof(buf), "%.4g", def);
    std::string s = ask_str(prompt, buf);
    if (s.empty()) return def;
    return strtod(s.c_str(), nullptr);
}

static void pause_enter() {
    printf(C_GRAY "\n按回车继续..." C_RESET);
    fflush(stdout);
    std::string s;
    std::getline(std::cin, s);
}

/* ============================ 诊断打印 ============================ */

static void print_ti_stat(const char *tag) {
    hy_ti_stat st{};
    if (!driver->ti_status(&st)) {
        printf(C_RED "  [%s] ti_status 读取失败\n" C_RESET, tag);
        return;
    }
    const char *sname = st.state == HY_TI_ACTIVE     ? "ACTIVE"
                      : st.state == HY_TI_CONFLICTED ? "CONFLICTED"
                      : st.state == HY_TI_IDLE       ? "IDLE" : "?";
    printf("  [%-8s] state=%-10s slot=%d/%d  d=%d m=%d u=%d  busy=%d conf=%d protect=%d\n",
           tag, sname, st.inj_slot, st.max_slots,
           st.downs, st.moves, st.ups, st.busy, st.conflicts, st.protects);
}

/* 直接走 /proc/HuanyuD：写命令再读回，避开对接文件里的私有方法 */
static std::string hy_proc_cmd(const char *cmd)
{
    FILE *w = fopen("/proc/HuanyuD", "w");
    if (!w) return std::string();
    fprintf(w, "%s\n", cmd);
    fclose(w);

    FILE *r = fopen("/proc/HuanyuD", "r");
    if (!r) return std::string();
    char buf[8192];
    std::string all;
    while (fgets(buf, sizeof(buf), r)) all += buf;
    fclose(r);

    /* 只取 [last command] 块，避免整屏帮助刷屏 */
    size_t p = all.find("[last command]");
    if (p == std::string::npos) return all;
    size_t q = all.find("[commands]", p);
    if (q == std::string::npos) q = all.size();
    return all.substr(p, q - p);
}

static void print_capacity() {
    int cap = 0, act = 0, tot = 0;
    if (!driver->ti_capacity(&cap, &act, &tot)) {
        printf(C_RED "  容量查询失败\n" C_RESET);
        return;
    }
    int real = tot - cap - act;
    if (real < 0) real = 0;
    printf("  可再按=%d  虚拟已按=%d  真手指占用=%d  总槽位=%d   %s\n",
           cap, act, real, tot,
           (cap > tot) ? C_RED "<< 异常：cap 超过总槽位！" C_RESET : C_GRN "OK" C_RESET);
}

/* ============================ 注入动作 ============================ */

struct FTrack {
    double cx, cy;     /* 圆心（面板坐标） */
    double r;          /* 半径（面板坐标） */
    double phase;      /* 起始相位（弧度） */
    double speed;      /* 角速度倍率 */
};

/*
 * 通用转圈：所有手指同时 down，之后每帧各自 move，最后统一 up。
 * measure=true 时统计实际帧间隔，用于判断"喂得匀不匀"。
 */
static int run_circles(const std::vector<FTrack> &fs, int dur_ms, int hz,
                       int circle_ms, bool measure)
{
    if (fs.empty()) return -1;

    int cap = 0, act = 0, tot = 0;
    driver->ti_capacity(&cap, &act, &tot);
    if ((int)fs.size() > cap && cap > 0) {
        printf(C_YEL "  [!] 手指数 %zu 超过当前容量 %d，超出的会被内核拒绝。\n" C_RESET,
               fs.size(), cap);
    }

    const long long period_ns = 1000000000LL / (hz > 0 ? hz : 120);
    const long long circle_ns = (long long)circle_ms * 1000000LL;
    const int frames = dur_ms * hz / 1000;

    wd_arm(dur_ms + 3000);

    /* --- down --- */
    for (size_t k = 0; k < fs.size(); k++) {
        int x = clampi((int)llround(fs[k].cx + fs[k].r * cos(fs[k].phase)), 0, P.panel_w - 1);
        int y = clampi((int)llround(fs[k].cy + fs[k].r * sin(fs[k].phase)), 0, P.panel_h - 1);
        if (!driver->ti_down_id((int)k, x, y)) {
            printf(C_RED "  down id=%zu 失败\n" C_RESET, k);
        }
    }
    printf(C_GRN "  已按下 %zu 根手指\n" C_RESET, fs.size());

    /* --- 帧循环 --- */
    long long t0 = now_ns();
    long long next = t0;
    long long jitter_min = 0, jitter_max = 0, jitter_sum = 0;
    int jitter_n = 0;
    long long prev = t0;
    int sent = 0;

    for (int i = 1; i <= frames && !g_stop; i++) {
        long long el = (long long)i * period_ns;
        for (size_t k = 0; k < fs.size(); k++) {
            double a = fs[k].phase + 2.0 * M_PI * fs[k].speed * ((double)el / circle_ns);
            int x = clampi((int)llround(fs[k].cx + fs[k].r * cos(a)), 0, P.panel_w - 1);
            int y = clampi((int)llround(fs[k].cy + fs[k].r * sin(a)), 0, P.panel_h - 1);
            driver->ti_move_id((int)k, x, y);
            sent++;
        }

        long long nowv = now_ns();
        if (measure) {
            long long d = nowv - prev;
            if (jitter_n == 0) { jitter_min = jitter_max = d; }
            else {
                if (d < jitter_min) jitter_min = d;
                if (d > jitter_max) jitter_max = d;
            }
            jitter_sum += d; jitter_n++;
        }
        prev = nowv;

        next = t0 + el;
        sleep_until(next);
    }

    /* --- up --- */
    driver->ti_up_all();
    wd_disarm();

    long long total = now_ns() - t0;
    printf(C_GRN "  已抬起全部手指\n" C_RESET);
    printf("  计划 %d 帧 × %zu 指 = %d 次 move，实际发出 %d 次\n",
           frames, fs.size(), frames * (int)fs.size(), sent);
    printf("  实测总耗时 %.3f s（目标 %.3f s）\n",
           total / 1e9, dur_ms / 1000.0);

    if (measure && jitter_n > 1) {
        double avg = (double)jitter_sum / jitter_n;
        double target = 1e9 / hz;
        printf("  帧间隔: 目标 %.0f ns | 实测 平均 %.0f ns 最小 %lld 最大 %lld\n",
               target, avg, (long long)jitter_min, (long long)jitter_max);
        printf("  抖动峰峰值 %.0f ns（%.1f%%）%s\n",
               (double)(jitter_max - jitter_min),
               (jitter_max - jitter_min) * 100.0 / target,
               (jitter_max - jitter_min) > target ? C_YEL "  << 偏大，可能出现抽搐" C_RESET
                                                  : C_GRN "  << 均匀" C_RESET);
    }
    print_ti_stat("动作后");
    return 0;
}

/* 直线滑动 */
static void run_line(double x0, double y0, double x1, double y1, int dur_ms, int hz)
{
    const long long period_ns = 1000000000LL / (hz > 0 ? hz : 120);
    const int frames = dur_ms * hz / 1000;
    if (frames <= 0) return;

    int px0 = clampi(to_panel_x(x0), 0, P.panel_w - 1);
    int py0 = clampi(to_panel_y(y0), 0, P.panel_h - 1);
    int px1 = clampi(to_panel_x(x1), 0, P.panel_w - 1);
    int py1 = clampi(to_panel_y(y1), 0, P.panel_h - 1);

    printf("  面板坐标 (%d,%d) -> (%d,%d)\n", px0, py0, px1, py1);

    wd_arm(dur_ms + 3000);
    driver->ti_down_id(0, px0, py0);

    long long t0 = now_ns();
    for (int i = 1; i <= frames && !g_stop; i++) {
        int x = px0 + (px1 - px0) * i / frames;
        int y = py0 + (py1 - py0) * i / frames;
        driver->ti_move_id(0, x, y);
        sleep_until(t0 + (long long)i * period_ns);
    }
    driver->ti_up_all();
    wd_disarm();
    printf(C_GRN "  直线滑动完成（%d 帧）\n" C_RESET, frames);
    print_ti_stat("动作后");
}

/* 单点点击 */
static void run_tap(double x, double y, int hold_ms)
{
    int px = clampi(to_panel_x(x), 0, P.panel_w - 1);
    int py = clampi(to_panel_y(y), 0, P.panel_h - 1);
    printf("  面板坐标 (%d,%d)\n", px, py);

    wd_arm(hold_ms + 3000);
    bool ok = driver->ti_down_id(0, px, py);
    printf("  down: %s\n", ok ? C_GRN "ok" C_RESET : C_RED "失败" C_RESET);
    if (ok) {
        struct timespec ts;
        ts.tv_sec = hold_ms / 1000;
        ts.tv_nsec = (long)(hold_ms % 1000) * 1000000L;
        nanosleep(&ts, nullptr);
        driver->ti_up_id(0);
        printf(C_GRN "  up: ok\n" C_RESET);
    }
    wd_disarm();
    print_ti_stat("动作后");
}

/* 左右往复摆动 */
static void run_swing(double cx, double cy, double amp, int dur_ms, int hz, int circle_ms)
{
    const long long period_ns = 1000000000LL / (hz > 0 ? hz : 120);
    const int frames = dur_ms * hz / 1000;
    int pcx = clampi(to_panel_x(cx), 0, P.panel_w - 1);
    int pcy = clampi(to_panel_y(cy), 0, P.panel_h - 1);
    int pamp = clampi(to_panel_x(amp), 0, P.panel_w / 2);

    wd_arm(dur_ms + 3000);
    driver->ti_down_id(0, pcx - pamp, pcy);

    long long t0 = now_ns();
    for (int i = 1; i <= frames && !g_stop; i++) {
        double a = 2.0 * M_PI * ((double)(i * period_ns) / ((long long)circle_ms * 1000000LL));
        int x = clampi(pcx + (int)llround(pamp * cos(a)), 0, P.panel_w - 1);
        driver->ti_move_id(0, x, pcy);
        sleep_until(t0 + (long long)i * period_ns);
    }
    driver->ti_up_all();
    wd_disarm();
    printf(C_GRN "  往复摆动完成（%d 帧）\n" C_RESET, frames);
    print_ti_stat("动作后");
}

/* ============================ 各菜单 ============================ */

static void menu_conn()
{
    clear_screen();
    hr2();
    printf(C_BOLD "  连接与版本诊断\n" C_RESET);
    hr2();

    printf("\n[握手]\n");
    printf("  is_ready  : %s\n", driver->is_ready()  ? C_GRN "true"  C_RESET : C_RED "false" C_RESET);
    printf("  is_authed : %s\n", driver->is_authed() ? C_GRN "true"  C_RESET : C_RED "false" C_RESET);
    printf("  handshake : %s\n", driver->handshake_ok() ? C_GRN "通过" C_RESET : C_RED "未通过" C_RESET);
    printf("  说明      : %s\n", driver->handshake_text());

    char want[64] = {0};
    if (driver->version_consistent(want, sizeof(want)))
        printf("  内核版本  : %s  %s一致%s\n", want, C_GRN, C_RESET);
    else
        printf("  内核版本  : %s  %s不一致%s\n", want, C_RED, C_RESET);

    printf("  本程序版本: %s\n", HY_VERSION_STRING);
    printf("  KernelPatch 就绪: %s\n",
           driver->kernelpatch_ready() ? C_GRN "yes" C_RESET : C_RED "no" C_RESET);

    printf("\n[CPU 能力]\n");
    hy_hwcap2 c = driver->hwcap2();
    printf("  MTE=%u SPE=%u PAN=%u BTI=%u PAC=%u LSE=%u brps=%u wrps=%u ghost=%u\n",
           c.mte, c.spe, c.pan, c.bti, c.pac, c.lse, c.brps, c.wrps, c.ghost);

    printf("\n[断点能力]\n");
    hy_bp_caps bc{};
    driver->bp_caps(&bc);
    printf("  SW=%d PTE=%d HW=%d (brps=%d wrps=%d)\n",
           !!(bc.supported & HY_BP_CAP_SW),
           !!(bc.supported & HY_BP_CAP_PTE),
           !!(bc.supported & HY_BP_CAP_HW),
           bc.num_brps, bc.num_wrps);

    printf("\n[运行统计]\n");
    hy_stats st{};
    if (driver->stats(st))
        printf("  缓存命中=%llu 未命中=%llu 活跃断点=%llu 总命中=%llu 符号缺失=%llu\n",
               (unsigned long long)st.cache_hits, (unsigned long long)st.cache_miss,
               (unsigned long long)st.bp_active,  (unsigned long long)st.hit_total,
               (unsigned long long)st.sym_failures);

    printf("\n[proc 自检]\n");
    printf("  /proc/huanyu 存在: %s\n",
           c_driver::proc_exists() ? C_GRN "yes" C_RESET : C_YEL "no（本模块用 /proc/HuanyuD）" C_RESET);

    printf("\n[方案世代]\n");
    std::string sl = driver->scheme_list();
    if (!sl.empty()) printf("%s\n", sl.c_str());

    hr();
    pause_enter();
}

static void menu_touch_diag()
{
    clear_screen();
    hr2();
    printf(C_BOLD "  触摸诊断\n" C_RESET);
    hr2();

    printf("\n[注入状态]\n");
    print_ti_stat("当前");

    printf("\n[容量]\n");
    print_capacity();

    printf("\n[坐标范围]\n");
    int mnx = 0, mxx = 0, mny = 0, mxy = 0;
    if (driver->ti_get_range(&mnx, &mxx, &mny, &mxy))
        printf("  内核当前: x %d..%d   y %d..%d\n", mnx, mxx, mny, mxy);
    else
        printf(C_YEL "  读取失败（老版本无 ti_get_range）\n" C_RESET);
    printf("  本程序参数: x 0..%d  y 0..%d\n", P.panel_w, P.panel_h);

    printf("\n[注入总闸]\n");
    printf("  当前: %s\n", driver->ti_inject_gate_query() ? C_GRN "开（允许注入）" C_RESET
                                                          : C_RED "关（禁止生成手指）" C_RESET);

    printf("\n[设备]\n");
    std::string ts = hy_proc_cmd("touchstat");
    if (ts.empty()) printf(C_YEL "  （无法访问 /proc/HuanyuD，请以 root 运行）\n" C_RESET);
    else printf("%s\n", ts.c_str());

    hr();
    printf("\n%s提示%s：若 range 显示为 1080x2400，那是源码里的硬编码默认值，\n", C_YEL, C_RESET);
    printf("       不是你的真实分辨率。请用「设置」菜单把面板宽高改成\n");
    printf("       getevent -lp 查到的 ABS_MT_POSITION_X/Y 的 max。\n");
    hr();
    pause_enter();
}

/* ---- 注入测试子菜单 ---- */

static void sub_inject()
{
    for (;;) {
        clear_screen();
        hr2();
        printf(C_BOLD "  注入测试\n" C_RESET);
        hr2();
        printf("  当前参数: 面板 %dx%d | %d Hz | 时长 %d ms | 圈周期 %d ms | 半径 %.0f%%\n",
               P.panel_w, P.panel_h, P.hz, P.dur_ms, P.circle_ms, P.radius_pct * 100);
        printf("  坐标输入: %s\n\n",
               P.use_screen_px ? C_CYAN "屏幕像素（自动换算）" C_RESET : C_YEL "面板原始坐标" C_RESET);

        printf("  " C_CYAN "1" C_RESET "  单点点击（tap）\n");
        printf("  " C_CYAN "2" C_RESET "  直线滑动\n");
        printf("  " C_CYAN "3" C_RESET "  单指画圈\n");
        printf("  " C_CYAN "4" C_RESET "  三指画圈（上 / 中 / 下）\n");
        printf("  " C_CYAN "5" C_RESET "  N 指画圈（自定义数量）\n");
        printf("  " C_CYAN "6" C_RESET "  左右往复摆动\n");
        printf("  " C_CYAN "7" C_RESET "  均匀性/抖动压测（无轨迹，纯统计）\n");
        printf("  " C_CYAN "8" C_RESET "  连续性对照：120Hz vs 30Hz（各 6 秒）\n");
        printf("  " C_CYAN "0" C_RESET "  返回\n\n");

        int ch = ask_int("选择", 0);
        if (ch == 0) return;

        double rbase = (P.panel_w < P.panel_h ? P.panel_w : P.panel_h) * P.radius_pct;

        if (ch == 1) {
            double x = ask_dbl("  X", P.use_screen_px ? P.screen_w / 2.0 : P.panel_w / 2.0);
            double y = ask_dbl("  Y", P.use_screen_px ? P.screen_h / 2.0 : P.panel_h / 2.0);
            int hold = ask_int("  按住时长 ms", 120);
            run_tap(x, y, hold);
            pause_enter();
        }
        else if (ch == 2) {
            double x0 = ask_dbl("  起点 X", P.use_screen_px ? P.screen_w * 0.2 : P.panel_w * 0.2);
            double y0 = ask_dbl("  起点 Y", P.use_screen_px ? P.screen_h * 0.5 : P.panel_h * 0.5);
            double x1 = ask_dbl("  终点 X", P.use_screen_px ? P.screen_w * 0.8 : P.panel_w * 0.8);
            double y1 = ask_dbl("  终点 Y", P.use_screen_px ? P.screen_h * 0.5 : P.panel_h * 0.5);
            run_line(x0, y0, x1, y1, P.dur_ms, P.hz);
            pause_enter();
        }
        else if (ch == 3) {
            double cx = ask_dbl("  圆心 X", P.use_screen_px ? P.screen_w / 2.0 : P.panel_w / 2.0);
            double cy = ask_dbl("  圆心 Y", P.use_screen_px ? P.screen_h / 2.0 : P.panel_h / 2.0);
            int dur  = ask_int("  时长 ms", P.dur_ms);
            int hz   = ask_int("  帧率 Hz", P.hz);
            int cms  = ask_int("  转一圈 ms", P.circle_ms);
            std::vector<FTrack> fs;
            FTrack f; f.cx = to_panel_x(cx); f.cy = to_panel_y(cy);
            f.r = rbase; f.phase = 0.0; f.speed = 1.0;
            fs.push_back(f);
            printf("\n  开始：单指画圈 %d ms @ %d Hz\n", dur, hz);
            run_circles(fs, dur, hz, cms, false);
            pause_enter();
        }
        else if (ch == 4) {
            int dur = ask_int("  时长 ms", P.dur_ms);
            int hz  = ask_int("  帧率 Hz", P.hz);
            int cms = ask_int("  转一圈 ms", P.circle_ms);
            std::vector<FTrack> fs;
            double ys[3] = {0.25, 0.50, 0.75};
            double sp[3] = {1.0, 1.0, 1.0};
            for (int k = 0; k < 3; k++) {
                FTrack f;
                f.cx    = P.panel_w / 2.0;
                f.cy    = P.panel_h * ys[k];
                f.r     = rbase;
                f.phase = 2.0 * M_PI * k / 3.0;   /* 起始相位错开 120° */
                f.speed = sp[k];
                fs.push_back(f);
            }
            printf("\n  开始：三指画圈（屏幕 25%% / 50%% / 75%% 高度）%d ms @ %d Hz\n", dur, hz);
            printf("  " C_YEL "三根应各自独立转圈；若黏在一起动，说明槽位串了。\n" C_RESET);
            run_circles(fs, dur, hz, cms, false);
            pause_enter();
        }
        else if (ch == 5) {
            int n   = ask_int("  手指数量", P.n_fingers);
            int dur = ask_int("  时长 ms", P.dur_ms);
            int hz  = ask_int("  帧率 Hz", P.hz);
            int cms = ask_int("  转一圈 ms", P.circle_ms);
            if (n < 1) n = 1;
            if (n > 16) n = 16;
            std::vector<FTrack> fs;
            for (int k = 0; k < n; k++) {
                FTrack f;
                f.cx    = P.panel_w / 2.0;
                f.cy    = P.panel_h * (k + 1) / (double)(n + 1);
                f.r     = rbase * 0.8;
                f.phase = 2.0 * M_PI * k / (double)n;
                f.speed = 1.0;
                fs.push_back(f);
            }
            printf("\n  开始：%d 指画圈 %d ms @ %d Hz\n", n, dur, hz);
            run_circles(fs, dur, hz, cms, false);
            pause_enter();
        }
        else if (ch == 6) {
            double cx = ask_dbl("  中心 X", P.use_screen_px ? P.screen_w / 2.0 : P.panel_w / 2.0);
            double cy = ask_dbl("  中心 Y", P.use_screen_px ? P.screen_h / 2.0 : P.panel_h / 2.0);
            double amp = ask_dbl("  振幅", P.use_screen_px ? P.screen_w * 0.3 : P.panel_w * 0.3);
            int dur = ask_int("  时长 ms", P.dur_ms);
            int hz  = ask_int("  帧率 Hz", P.hz);
            int cms = ask_int("  摆一个来回 ms", P.circle_ms);
            run_swing(cx, cy, amp, dur, hz, cms);
            pause_enter();
        }
        else if (ch == 7) {
            int dur = ask_int("  压测时长 ms", 8000);
            int hz  = ask_int("  目标帧率 Hz", P.hz);
            std::vector<FTrack> fs;
            FTrack f; f.cx = P.panel_w / 2.0; f.cy = P.panel_h / 2.0;
            f.r = rbase; f.phase = 0.0; f.speed = 1.0;
            fs.push_back(f);
            printf("\n  开始抖动压测：%d ms @ %d Hz（单指转圈，统计帧间隔）\n", dur, hz);
            run_circles(fs, dur, hz, P.circle_ms, true);
            pause_enter();
        }
        else if (ch == 8) {
            printf("\n  " C_CYAN "对照测试：先 120Hz 再 30Hz，各 6 秒，屏幕上看连续性问题。\n" C_RESET);
            std::vector<FTrack> fs;
            FTrack f; f.cx = P.panel_w / 2.0; f.cy = P.panel_h / 2.0;
            f.r = rbase; f.phase = 0.0; f.speed = 1.0;
            fs.push_back(f);
            printf("\n  --- 120 Hz ---\n");
            run_circles(fs, 6000, 120, P.circle_ms, true);
            printf("\n  --- 30 Hz ---\n");
            run_circles(fs, 6000, 30, P.circle_ms, true);
            printf("\n  " C_YEL "若 30Hz 明显一顿一顿、120Hz 顺滑，说明内核侧正常，\n" C_RESET);
            printf("  " C_YEL "之前的抽搐是「调用侧喂得不匀」导致的。\n" C_RESET);
            pause_enter();
        }
    }
}

/* ---- 参数设置子菜单 ---- */

static void sub_params()
{
    for (;;) {
        clear_screen();
        hr2();
        printf(C_BOLD "  参数设置\n" C_RESET);
        hr2();
        printf("\n  [坐标系]\n");
        printf("  " C_CYAN " 1" C_RESET " 面板宽 panel_w      = %d\n", P.panel_w);
        printf("  " C_CYAN " 2" C_RESET " 面板高 panel_h      = %d\n", P.panel_h);
        printf("  " C_CYAN " 3" C_RESET " 屏幕像素宽 screen_w = %d\n", P.screen_w);
        printf("  " C_CYAN " 4" C_RESET " 屏幕像素高 screen_h = %d\n", P.screen_h);
        printf("  " C_CYAN " 5" C_RESET " 菜单里填屏幕像素    = %s\n",
               P.use_screen_px ? "是" : "否（填面板原始坐标）");
        printf("\n  [时序]\n");
        printf("  " C_CYAN " 6" C_RESET " 帧率 hz             = %d\n", P.hz);
        printf("  " C_CYAN " 7" C_RESET " 默认时长 dur_ms     = %d\n", P.dur_ms);
        printf("  " C_CYAN " 8" C_RESET " 转一圈 circle_ms    = %d\n", P.circle_ms);
        printf("\n  [轨迹]\n");
        printf("  " C_CYAN " 9" C_RESET " 半径比例 radius_pct = %.3f\n", P.radius_pct);
        printf("  " C_CYAN "10" C_RESET " 多指数量 n_fingers  = %d\n", P.n_fingers);
        printf("  " C_CYAN "11" C_RESET " 看门狗宽限 ms       = %d\n", P.watchdog_grace_ms);
        printf("\n  [下发到内核]\n");
        printf("  " C_GRN "20" C_RESET " 把面板宽高写进内核（trange 0 W 0 H）\n");
        printf("  " C_GRN "21" C_RESET " 设定总槽位数（tslots）\n");
        printf("  " C_GRN "22" C_RESET " 按屏幕像素自动换算并下发\n");
        printf("\n  " C_CYAN " 0" C_RESET " 返回\n\n");

        int ch = ask_int("选择", 0);
        switch (ch) {
        case 0:  return;
        case 1:  P.panel_w = ask_int("  面板宽", P.panel_w); break;
        case 2:  P.panel_h = ask_int("  面板高", P.panel_h); break;
        case 3:  P.screen_w = ask_int("  屏幕像素宽", P.screen_w); break;
        case 4:  P.screen_h = ask_int("  屏幕像素高", P.screen_h); break;
        case 5:  P.use_screen_px = !P.use_screen_px; break;
        case 6:  P.hz = ask_int("  帧率 Hz", P.hz); if (P.hz < 1) P.hz = 1; if (P.hz > 1000) P.hz = 1000; break;
        case 7:  P.dur_ms = ask_int("  时长 ms", P.dur_ms); break;
        case 8:  P.circle_ms = ask_int("  转一圈 ms", P.circle_ms); break;
        case 9:  P.radius_pct = ask_dbl("  半径比例", P.radius_pct); break;
        case 10: P.n_fingers = ask_int("  手指数量", P.n_fingers); break;
        case 11: P.watchdog_grace_ms = ask_int("  看门狗宽限 ms", P.watchdog_grace_ms); break;
        case 20:
            if (driver->ti_set_range(0, P.panel_w, 0, P.panel_h))
                printf(C_GRN "  已下发 range=0..%d x 0..%d\n" C_RESET, P.panel_w, P.panel_h);
            else
                printf(C_RED "  下发失败\n" C_RESET);
            pause_enter();
            break;
        case 21: {
            int n = ask_int("  总槽位数", 10);
            if (driver->ti_set_slots(n)) printf(C_GRN "  tslots ok (%d)\n" C_RESET, n);
            else printf(C_RED "  tslots 失败\n" C_RESET);
            pause_enter();
            break;
        }
        case 22: {
            /* 按屏幕像素反推面板坐标并下发 */
            printf("  当前换算：面板 = 屏幕像素 × (%.4f, %.4f)\n",
                   P.panel_w / (double)P.screen_w, P.panel_h / (double)P.screen_h);
            if (driver->ti_set_range(0, P.panel_w, 0, P.panel_h))
                printf(C_GRN "  已下发 range=0..%d x 0..%d\n" C_RESET, P.panel_w, P.panel_h);
            int n = ask_int("  同时下发总槽位数", 10);
            driver->ti_set_slots(n);
            pause_enter();
            break;
        }
        default: break;
        }
    }
}

/* ---- 安全清理 ---- */

static void sub_safe()
{
    for (;;) {
        clear_screen();
        hr2();
        printf(C_BOLD "  安全与清理\n" C_RESET);
        hr2();
        printf("\n  " C_CYAN "1" C_RESET " 抬起全部虚拟手指（ti_up_all）\n");
        printf("  " C_CYAN "2" C_RESET " 强制清除残留手指（ti_clear，不看位图无条件发抬起序列）\n");
        printf("  " C_CYAN "3" C_RESET " 注入总闸：关（禁止生成手指 + 自动清除）\n");
        printf("  " C_CYAN "4" C_RESET " 注入总闸：开\n");
        printf("  " C_CYAN "5" C_RESET " 查询注入总闸\n");
        printf("  " C_CYAN "6" C_RESET " 重新识别触摸屏（touch_rescan）\n");
        printf("  " C_CYAN "7" C_RESET " 自动匹配触摸屏（touch_set_name_auto）\n");
        printf("\n  " C_CYAN "0" C_RESET " 返回\n\n");

        int ch = ask_int("选择", 0);
        if (ch == 0) return;

        if (ch == 1) {
            driver->ti_up_all();
            printf(C_GRN "  已抬全部\n" C_RESET);
        } else if (ch == 2) {
            if (driver->ti_clear()) printf(C_GRN "  tclear ok\n" C_RESET);
            else printf(C_RED "  tclear 失败\n" C_RESET);
        } else if (ch == 3) {
            driver->ti_inject_gate(false);
            printf(C_GRN "  闸门已关\n" C_RESET);
        } else if (ch == 4) {
            driver->ti_inject_gate(true);
            printf(C_GRN "  闸门已开\n" C_RESET);
        } else if (ch == 5) {
            printf("  闸门: %s\n", driver->ti_inject_gate_query() ? C_GRN "开" C_RESET : C_RED "关" C_RESET);
        } else if (ch == 6) {
            printf("  rescan: %s\n", driver->touch_rescan() ? C_GRN "ok" C_RESET : C_RED "失败" C_RESET);
        } else if (ch == 7) {
            printf("  auto: %s\n", driver->touch_set_name_auto() ? C_GRN "ok" C_RESET : C_RED "失败" C_RESET);
        }
        print_ti_stat("操作后");
        pause_enter();
    }
}

/* ============================ 主流程 ============================ */

static void menu_main()
{
    for (;;) {
        clear_screen();
        hr2();
        printf(C_BOLD "  欢愉 Huanyu 驱动测试台   " C_RESET C_GRAY "v%s\n" C_RESET, HY_VERSION_STRING);
        hr2();
        printf("  模块: %s   握手: %s\n\n",
               driver->is_ready() ? C_GRN "已就绪" C_RESET : C_RED "未就绪" C_RESET,
               driver->handshake_ok() ? C_GRN "通过" C_RESET : C_RED "未通过" C_RESET);

        printf("  " C_CYAN "1" C_RESET "  连接与版本诊断\n");
        printf("  " C_CYAN "2" C_RESET "  触摸诊断（状态 / 容量 / 范围 / 设备）\n");
        printf("  " C_CYAN "3" C_RESET "  注入测试  " C_GRAY "<— 点击 / 直线 / 单指圈 / 三指圈 / N指 / 摆动 / 抖动压测\n" C_RESET);
        printf("  " C_CYAN "4" C_RESET "  参数设置  " C_GRAY "<— 面板尺寸 / 帧率 / 时长 / 半径 / 下发内核\n" C_RESET);
        printf("  " C_CYAN "5" C_RESET "  安全与清理  " C_GRAY "<— 抬手 / 清手指 / 注入闸门\n" C_RESET);
        printf("\n  " C_CYAN "0" C_RESET "  退出（自动抬起全部手指）\n\n");

        int ch = ask_int("选择", 0);
        switch (ch) {
        case 0: return;
        case 1: menu_conn();      break;
        case 2: menu_touch_diag();break;
        case 3: sub_inject();     break;
        case 4: sub_params();     break;
        case 5: sub_safe();       break;
        default: break;
        }
    }
}

int main(int argc, char **argv)
{
    (void)argc; (void)argv;

    signal(SIGINT,  hyui_sig);
    signal(SIGTERM, hyui_sig);

    g_wd = std::thread(watchdog_main);

    if (!driver || !driver->is_ready()) {
        printf(C_RED "模块未就绪。请确认：\n" C_RESET);
        printf("  1) APatch 中已加载 huanyu_%s.kpm\n", HY_VERSION_STRING);
        printf("  2) 本程序版本与内核版本一致（当前 %s）\n", HY_VERSION_STRING);
        printf("  3) 以 root 运行\n");
        return 1;
    }

    printf(C_GRN "模块就绪，握手：%s\n" C_RESET, driver->handshake_text());

    menu_main();

    emergency_lift();
    printf(C_GRN "已退出，全部虚拟手指已抬起。\n" C_RESET);
    g_stop = 1;
    return 0;
}
