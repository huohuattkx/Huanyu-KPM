/* 自动从 huanyu_wanbai.hpp 提取 —— 请勿手改 */
#ifndef HY_KEYS_GEN_H
#define HY_KEYS_GEN_H
#define HY_MAGIC 0x4879756eu
#define HY_KEY_L1 "Huanyu"
#define HY_KEY_LEN_L1 6
#define HY_KEY_L2 "j9BVo9EK.@7Wvz)kq7{]QEiiUcR=;KPV9C#W%x8n6*D,b_rgZMVf-vG)>^V:x$4;"
#define HY_KEY_LEN_L2 64
#define HY_KEY_L3 "4;LjmfsGWmXkU<;X=$g!tmsHq{U+4a@vtG]43V}]TG[<{.JS4xN2MH9SYtgL7ebv"
#define HY_KEY_LEN_L3 64
#define HY_KEY_L4 "gM?l+s$5AcQ+K$[6;trqZQ2n2<83fN4!qRXaoIFq?3_qTe)YQw+.i7FV=02YCq=R"
#define HY_KEY_LEN_L4 64
#define HY_KEY_L5 "Q@{+22RKsIf5X#ll?{-$2tlF8wR>d5jEJ8zotDHOd{#^Dw={IEZGhOxP(<HPUFIW)fXDXZAM}X@:LUJDFcq9]l+]4y1mb%qH%[P:F(p,7C7*$FF&6c.Ln^s)p(}#+5mmw<_pEG_MhkHA}O9>ait,U{@&dmQ5pAM{EPDzf(rOW)5Opc4s4#KOVPP4fIzProUq%4.Ujq;.2?OB]n-N<,_llfhB_.V!@lx9tYPdJlOGMqkF?ZV]2qE}rbPphU1zgFrY"
#define HY_KEY_LEN_L5 256
#endif
