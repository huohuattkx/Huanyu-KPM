/*
 * 欢愉 —— 虚拟手指连续画圆（1 指 + 3 指，各 20 秒，自动收尾）
 *
 * 验证两件事：
 *   1) 轨迹是否连续 —— down 一次后连续 move，中途绝不抬手
 *   2) 多指是否独立 —— 每根手指占独立槽位，坐标互不干扰
 *
 * 默认流程（无需任何参数）：
 *   阶段一：1 根手指在屏幕正中画圈，20 秒
 *   阶段二：3 根手指在屏幕上/中/下各画一圈，20 秒
 *   结束：自动抬起全部手指并退出，不留残指
 *
 * 用法：
 *   ./touch_circle                  # 默认：1指20s → 3指20s → 自动退出
 *   ./touch_circle 1 15             # 只跑 1 指，15 秒
 *   ./touch_circle 3 15             # 只跑 3 指，15 秒
 *   ./touch_circle 3 20 120 2000    # 3指/20秒/120Hz/一圈2000ms
 *
 * 防卡死三重保险：
 *   a) 主线程到点即停，退出前必 ti_up_all()
 *   b) SIGINT/SIGTERM 也会走清理路径
 *   c) 看门狗线程：主线程若卡住（超过预期 5 秒），直接 _exit 前强制抬起
 *
 * 调试建议：先开「开发者选项 → 指针位置」，能看到轨迹和点数。
 */
#include "huanyu_wanbai.hpp"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <csignal>
#include <ctime>
#include <unistd.h>
#include <pthread.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/*
 * 面板坐标范围 —— getevent -lp /dev/input/event7 实测。
 * 这不是屏幕像素 1080x2354！注入用的是面板坐标。
 * 固定 1080x2354 那档时：面板X = 屏幕X * 18.84
 */
static const int PANEL_W = 20351;
static const int PANEL_H = 44351;

static volatile sig_atomic_t g_run = 1;
static void on_stop(int) { g_run = 0; }

/* ---- 看门狗：主线程卡死时的最后兜底 ---- */
static volatile int        g_wd_armed   = 0;
static volatile long long  g_wd_deadline = 0;   /* 秒（CLOCK_MONOTONIC） */
static void *wd_thread(void *)
{
    while (g_wd_armed) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        if (ts.tv_sec > g_wd_deadline) {
            /* 超期：强制清场后立刻退出，不等主线程 */
            fprintf(stderr, "[看门狗] 主线程超时，强制抬起并退出\n");
            if (driver) driver->ti_up_all();
            _exit(2);
        }
        usleep(200000);
    }
    return nullptr;
}
static void wd_arm(int grace_sec)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    g_wd_deadline = ts.tv_sec + grace_sec;
    g_wd_armed = 1;
    pthread_t t;
    pthread_create(&t, nullptr, wd_thread, nullptr);
    pthread_detach(t);
}

struct Circle {
    int    id;
    double cx, cy;    /* 圆心（面板坐标） */
    double r;         /* 半径 */
    double phase;     /* 起始相位，错开避免同步 */
    double speed;     /* 角速度倍率 */
};

/* 绝对时间累加。不能用 usleep —— 每帧误差会累积，采样就不匀了 */
static void ts_add(struct timespec &ts, long ns)
{
    ts.tv_nsec += ns;
    while (ts.tv_nsec >= 1000000000L) {
        ts.tv_nsec -= 1000000000L;
        ts.tv_sec  += 1;
    }
}

/* 跑一个阶段：按下 → 连续 move → 抬起。返回发出的帧数 */
static long long run_phase(Circle *cs, int n, int hz, int lap_ms, int seconds)
{
    const long   period_ns = 1000000000L / hz;
    const int    frames_per_lap = hz * lap_ms / 1000;
    const double dtheta = 2.0 * M_PI / frames_per_lap;

    printf("\n[阶段] %d 根手指 / %dHz / 一圈 %dms / 时长 %ds\n",
           n, hz, lap_ms, seconds);
    for (int k = 0; k < n; k++)
        printf("  id=%d 圆心=(%.0f,%.0f) 半径=%.0f\n",
               cs[k].id, cs[k].cx, cs[k].cy, cs[k].r);

    /* 一次 down，之后只 move，全程不抬手 —— 这才是"不断触" */
    for (int k = 0; k < n; k++) {
        int x = (int)(cs[k].cx + cs[k].r);
        int y = (int)(cs[k].cy);
        if (!driver->ti_down_id(cs[k].id, x, y))
            printf("[错误] id=%d down 失败\n", cs[k].id);
    }

    struct timespec next;
    clock_gettime(CLOCK_MONOTONIC, &next);

    long long frame = 0, fails = 0;
    const long long max_frames = (long long)seconds * hz;

    while (g_run && frame < max_frames) {
        for (int k = 0; k < n; k++) {
            double a = cs[k].phase + dtheta * cs[k].speed * frame;
            int x = (int)(cs[k].cx + cs[k].r * cos(a));
            int y = (int)(cs[k].cy + cs[k].r * sin(a));
            if (!driver->ti_move_id(cs[k].id, x, y)) {
                fails++;
                if (fails < 10)
                    printf("[错误] id=%d 第 %lld 帧 move 失败\n", cs[k].id, frame);
            }
        }

        /* 每 2 秒报一次，好对照 tstat 里 m= 的计数 */
        if ((frame % (hz * 2)) == 0 && frame > 0)
            printf("[进度] %lld/%lld 帧（%.1f 圈）失败=%lld\n",
                   frame, max_frames, (double)frame / frames_per_lap, fails);

        frame++;
        ts_add(next, period_ns);
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, nullptr);
    }

    printf("[阶段结束] %lld 帧，失败 %lld 次\n", frame, fails);

    /* 阶段之间抬起 —— 换手指数量前必须清干净 */
    driver->ti_up_all();
    return frame;
}

int main(int argc, char **argv)
{
    /* 默认：两个阶段都跑；给了第一参数就只跑那一个 */
    int  only      = (argc > 1) ? atoi(argv[1]) : 0;   /* 0=都跑 1/3=只跑 */
    int  seconds   = (argc > 2) ? atoi(argv[2]) : 20;
    int  hz        = (argc > 3) ? atoi(argv[3]) : 120;
    int  lap_ms    = (argc > 4) ? atoi(argv[4]) : 2000;

    if (only != 0 && only != 1 && only != 3) {
        printf("第一个参数只能是 0（默认跑两阶段）、1 或 3\n");
        return 1;
    }
    if (seconds < 1 || seconds > 600) seconds = 20;
    if (hz < 30 || hz > 500) hz = 120;
    if (lap_ms < 200) lap_ms = 200;

    if (!driver || !driver->is_ready()) {
        printf("模块未连接。确认 APatch 里已加载欢愉 kpm\n");
        return 1;
    }

    /* 先看容量，别盲目按 */
    int cap = 0, active = 0, total = 0;
    if (driver->ti_capacity(&cap, &active, &total))
        printf("[容量] 可再按=%d 已按着=%d 总槽位=%d\n", cap, active, total);
    if (total > 0 && cap < 3 && (only == 0 || only == 3)) {
        printf("[警告] 容量 %d < 3 根，可能有真手指占着槽位\n", cap);
    }
    if (total > 0 && cap > total)
        printf("[警告] 容量 %d 超过总槽位 %d —— 已被内核钳位（1.78.0 修复）\n", cap, total);

    signal(SIGINT,  on_stop);
    signal(SIGTERM, on_stop);

    /* 看门狗：总时长 + 5 秒宽限，超时强制清场退出 */
    int phases = (only == 0) ? 2 : 1;
    wd_arm(seconds * phases + 5);

    double cx = PANEL_W / 2.0;
    long long total_frames = 0;

    if (only == 0 || only == 1) {
        Circle c1[1] = {
            {0, cx, PANEL_H / 2.0, 4000.0, 0.0, 1.0}
        };
        total_frames += run_phase(c1, 1, hz, lap_ms, seconds);
    }

    if (g_run && (only == 0 || only == 3)) {
        /* 换阶段前小停一下，让上一次抬起彻底生效 */
        usleep(300000);
        Circle c3[3] = {
            {0, cx, PANEL_H * 0.25, 3300.0, 0.0,       1.0},   /* 上 */
            {1, cx, PANEL_H * 0.50, 3300.0, M_PI * 2/3, 1.0},   /* 中 */
            {2, cx, PANEL_H * 0.75, 3300.0, M_PI * 4/3, 1.0}    /* 下 */
        };
        total_frames += run_phase(c3, 3, hz, lap_ms, seconds);
    }

    /* 无论如何都要抬起，否则手指会卡在屏幕上 */
    driver->ti_up_all();
    usleep(100000);
    driver->ti_up_all();   /* 再来一次，确保没有残指 */

    printf("\n[完成] 共 %lld 帧，已抬起全部虚拟手指，程序退出\n", total_frames);
    g_wd_armed = 0;
    return 0;
}
