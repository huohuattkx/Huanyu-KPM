/*
 * HuanyuD —— 欢愉内核调试命令行工具（对应 /proc/HuanyuD）
 *
 * 用法（手机终端，需 root）：
 *   HuanyuD help
 *   HuanyuD version
 *   HuanyuD touch on|off
 *   HuanyuD grab on|off|stat
 *   HuanyuD slotbase <n>
 *   HuanyuD bpstat
 *   HuanyuD devinfo            采集并上报设备信息
 *   HuanyuD version
 *
 * 无参数时等价于 help。
 * 原理：经 prctl 免鉴权通道下发 HY_NR_DBG_CMD(82)，
 * 不需要超级密钥。
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <errno.h>

#ifndef __NR_prctl
#define __NR_prctl 167
#endif

#define HY_PRCTL_MAGIC 0x4879756eULL   /* "Hyun" */
#define HY_NR_DBG_CMD  82

/* ---- 虚拟定位 ---- */
#define HY_NR_GNSS_INIT    55
#define HY_NR_GNSS_REPORT  56
#define HY_NR_GNSS_STOP    57

struct hy_gnss_req {
    int  latitude_e7;
    int  longitude_e7;
    unsigned int enable;
};

struct hy_dbg_req {
    unsigned int cmd_len;
    unsigned int out_len;
    char cmd[160];
    char out[160];
};

static long prctl_ctl(unsigned int nr, void *payload)
{
    return syscall(__NR_prctl,
                   (unsigned long)HY_PRCTL_MAGIC,
                   (unsigned long)nr,
                   (unsigned long)payload,
                   0UL, 0UL);
}

/* 下发一条调试命令，返回 0 表示内核有回复 */
static int dbg_send(const char *cmdline)
{
    struct hy_dbg_req req;
    long rc;

    memset(&req, 0, sizeof(req));
    strncpy(req.cmd, cmdline, sizeof(req.cmd) - 1);
    req.cmd_len = (unsigned int)strlen(req.cmd);

    rc = prctl_ctl(HY_NR_DBG_CMD, &req);
    if (rc < 0) return -1;
    (void)req.out_len;
    return 0;
}

/* 去掉首尾空白与换行 */
static void trim(char *s)
{
    size_t n, i, j = 0;
    if (!s) return;
    n = strlen(s);
    while (n && (s[n-1] == '\n' || s[n-1] == '\r' || s[n-1] == ' ')) s[--n] = 0;
    while (s[0] == ' ' || s[0] == '\t') { for (i = 0; s[i]; i++) s[i] = s[i+1]; }
    (void)j;
}

/* 读 shell 命令首行输出 */
static int sh_line(const char *cmd, char *out, size_t cap)
{
    FILE *fp;
    out[0] = 0;
    fp = popen(cmd, "r");
    if (!fp) return -1;
    if (!fgets(out, (int)cap, fp)) { pclose(fp); return -1; }
    pclose(fp);
    trim(out);
    return out[0] ? 0 : -1;
}

/* 读普通文件首行 */
static int file_line(const char *path, char *out, size_t cap)
{
    FILE *fp;
    out[0] = 0;
    fp = fopen(path, "r");
    if (!fp) return -1;
    if (!fgets(out, (int)cap, fp)) { fclose(fp); return -1; }
    fclose(fp);
    trim(out);
    return out[0] ? 0 : -1;
}

/*
 * v1.45.0：设备信息由用户态采集、内核只缓存显示。
 * 内核态读文件需要 struct file 布局，KPM 没有，之前连续四版加载即炸。
 */
/*
 * 虚拟定位开关。
 *   HuanyuD gnss <纬度> <经度>    例：HuanyuD gnss 39.9042 116.4074
 *   HuanyuD gnss off              关闭
 *
 * 内核侧是 hook ioctl + 改写 binder parcel 里的 Location 字段，
 * 生效对象是走 ILocation 接口的位置回调（系统定位、多数 App 的 fused
 * provider 都走这条路）。是否真的生效看 /proc/Huanyu 的
 * [ls-port] -> gnss spoof : on (hooked=1 patched=N)，
 * patched 有增长才说明确实改到了 parcel。
 */
static int gnss_cmd(int argc, char **argv)
{
    struct hy_gnss_req req;
    long rc;

    memset(&req, 0, sizeof(req));

    if (argc >= 3) {
        double lat = 0, lon = 0;
        if (sscanf(argv[1], "%lf", &lat) != 1 ||
            sscanf(argv[2], "%lf", &lon) != 1) {
            printf("[-] 坐标解析失败，用法：HuanyuD gnss <纬度> <经度>\n");
            return 1;
        }
        if (lat < -90.0 || lat > 90.0 || lon < -180.0 || lon > 180.0) {
            printf("[-] 超出范围：纬度 -90~90，经度 -180~180\n");
            return 1;
        }
        req.latitude_e7  = (int)(lat * 10000000.0);
        req.longitude_e7 = (int)(lon * 10000000.0);
        req.enable = 1;
        rc = prctl_ctl(HY_NR_GNSS_INIT, &req);
        if (rc < 0) {
            printf("[-] 启用失败 rc=%ld errno=%d\n", rc, errno);
            return 1;
        }
        printf("[+] 虚拟定位已启用 lat=%.6f lon=%.6f (e7=%d,%d)\n",
               lat, lon, req.latitude_e7, req.longitude_e7);
        printf("    验证：cat /proc/Huanyu  看 [ls-port] 的 gnss spoof\n");
        printf("    patched 有增长才说明真的改到了 parcel\n");
        return 0;
    }

    if (argc == 2 && !strcmp(argv[1], "off")) {
        rc = prctl_ctl(HY_NR_GNSS_STOP, &req);
        if (rc < 0) {
            printf("[-] 关闭失败 rc=%ld errno=%d\n", rc, errno);
            return 1;
        }
        printf("[+] 虚拟定位已关闭\n");
        return 0;
    }

    printf("用法：\n"
           "  HuanyuD gnss <纬度> <经度>   启用（十进制，例 39.9042 116.4074）\n"
           "  HuanyuD gnss off             关闭\n");
    return 1;
}

static int devinfo_collect(void)
{
    static const char *props[] = {
        /* ---- 产品标识 ---- */
        "ro.product.manufacturer", "manufacturer",
        "ro.product.brand",        "brand",
        "ro.product.model",        "model",
        "ro.product.device",       "device",
        "ro.product.board",        "board",
        "ro.product.name",         "name",
        "ro.product.marketname",   "market name",
        /* ---- 系统与版本 ---- */
        "ro.build.version.release","android",
        "ro.build.version.sdk",    "android sdk",
        "ro.build.id",             "build id",
        "ro.build.display.id",     "display id",
        "ro.build.version.incremental", "incremental",
        "ro.build.version.security_patch", "security patch",
        "ro.build.type",           "build type",
        "ro.build.tags",           "build tags",
        "ro.build.date",           "build date",
        "ro.build.fingerprint",    "fingerprint",
        "ro.build.host",           "build host",
        /* ---- 硬件平台 ---- */
        "ro.board.platform",       "soc",
        "ro.hardware",             "hardware",
        "ro.hardware.chipname",    "chipname",
        "ro.boot.hardware.sku",    "hardware sku",
        "ro.bootloader",           "bootloader",
        "ro.serialno",             "serialno",
        /* ---- ABI / 架构 ---- */
        "ro.product.cpu.abi",      "abi",
        "ro.product.cpu.abi2",     "abi2",
        "ro.product.cpu.abilist",  "abilist",
        /* ---- 分区 / Treble ---- */
        "ro.treble.enabled",       "treble",
        "ro.product.first_api_level", "first api level",
        "ro.vendor.product.device", "vendor device",
        "ro.vendor.build.fingerprint", "vendor fingerprint",
        "ro.odm.product.device",   "odm device",
        "ro.product.vendor.model", "vendor model",
        /* ---- 安全 / 调试 ---- */
        "ro.debuggable",           "debuggable",
        "ro.secure",               "ro.secure",
        "ro.build.selinux",        "build selinux",
        /* ---- 基带 ---- */
        "gsm.version.baseband",    "baseband",
        /* ---- 系统属性（易变，仅供参考） ---- */
        "persist.sys.timezone",    "timezone",
        "sys.usb.config",          "usb config",
    };
    char val[256], line[180], kern[256], mem[128];
    unsigned int i;

    dbg_send("devinfo reset");

    for (i = 0; i + 1 < sizeof(props)/sizeof(props[0]); i += 2) {
        char cmd[320];
        snprintf(cmd, sizeof(cmd), "getprop %s 2>/dev/null", props[i]);
        if (sh_line(cmd, val, sizeof(val)) != 0) {
            snprintf(line, sizeof(line), "devinfo add %s=unknown", props[i+1]);
        } else {
            if (strlen(val) > 120) val[120] = 0;
            snprintf(line, sizeof(line), "devinfo add %s=%s", props[i+1], val);
        }
        dbg_send(line);
    }

    if (file_line("/proc/version", kern, sizeof(kern)) == 0) {
        if (strlen(kern) > 120) kern[120] = 0;
        snprintf(line, sizeof(line), "devinfo add kernel release=%s", kern);
        dbg_send(line);
    }

    if (file_line("/proc/meminfo", mem, sizeof(mem)) == 0) {
        if (strlen(mem) > 60) mem[60] = 0;
        snprintf(line, sizeof(line), "devinfo add meminfo=%s", mem);
        dbg_send(line);
    }

    /* ---- 需要 shell 命令才能拿到的 ---- */
    {
        static const char *shcmds[] = {
            "getenforce",           "selinux mode",
            "wm size",              "wm size",
            "wm density",           "wm density",
            "id -u",                "shell uid",
        };
        unsigned int j;
        for (j = 0; j + 1 < sizeof(shcmds)/sizeof(shcmds[0]); j += 2) {
            char cmd[320];
            snprintf(cmd, sizeof(cmd), "%s 2>/dev/null", shcmds[j]);
            if (sh_line(cmd, val, sizeof(val)) == 0 && val[0]) {
                if (strlen(val) > 110) val[110] = 0;
                snprintf(line, sizeof(line), "devinfo add %s=%s",
                         shcmds[j+1], val);
                dbg_send(line);
            }
        }
    }

    printf("[+] 设备信息已上报，执行 cat /proc/Huanyu 查看 [device] 段\n");
    return 0;
}

static void usage(void)
{
    printf(
      "HuanyuD <command> [args]\n"
      "\n"
      "  help                 显示本帮助（cat /proc/HuanyuD 同内容）\n"
      "  version              版本信息\n"
      "\n"
      "  gnss <lat> <lon>     启用虚拟定位（十进制，例 39.9042 116.4074）\n"
      "  gnss off             关闭虚拟定位\n"
      "  touch on|off         触摸自动识别开关\n"
      "  devinfo              采集设备信息并上报到 /proc/Huanyu 的 [device] 段\n"
      "  devinfo reset|add <k=v>|show\n"
      "  bpstat               断点能力与当前占用\n"
      "\n"
      "  guard on|off|status  防格机开关与状态\n"
      "  unlock [seconds]     开解锁窗口（默认 300 秒），窗口内放行一切\n"
      "  lock                 立即结束解锁窗口\n"
      "  说明：防格机默认加载即启用；自己刷机前先 unlock，\n"
      "        窗口到期自动恢复保护（无时钟时为手动模式，需 lock）\n");
}

int main(int argc, char **argv)
{
    struct hy_dbg_req req;
    char cmdline[160];
    long rc;
    int i, first = 1;

    if (argc < 2) { usage(); return 0; }

    if (!strcmp(argv[1], "help") || !strcmp(argv[1], "-h") ||
        !strcmp(argv[1], "--help") || !strcmp(argv[1], "?")) {
        usage();
        return 0;
    }

    if (!strcmp(argv[1], "devinfo") && argc == 2)
        return devinfo_collect();
    if (!strcmp(argv[1], "gnss"))
        return gnss_cmd(argc - 1, argv + 1);

    cmdline[0] = 0;
    for (i = 1; i < argc; i++) {
        size_t used = strlen(cmdline);
        size_t room = sizeof(cmdline) - used - 1;
        if (!first) { if (room > 0) { strncat(cmdline, " ", room); room--; } }
        if (room > 0) strncat(cmdline, argv[i], room);
        first = 0;
    }

    memset(&req, 0, sizeof(req));
    memcpy(req.cmd, cmdline, sizeof(req.cmd) - 1 < strlen(cmdline)
                             ? sizeof(req.cmd) - 1 : strlen(cmdline));
    req.cmd_len = (unsigned int)strlen(req.cmd);

    rc = prctl_ctl(HY_NR_DBG_CMD, &req);
    if (rc < 0) {
        printf("[-] 通道调用失败: prctl errno=%d (%s)\n", errno, strerror(errno));
        printf("    可能原因：模块未加载 / prctl hook 未生效\n");
        printf("    排查：cat /proc/Huanyu  看 [channels] 段 prctl 是否 READY\n");
        return 1;
    }

    if (req.out[0]) {
        printf("%s", req.out);
        if (req.out[strlen(req.out) - 1] != '\n') printf("\n");
    } else {
        printf("[-] 无返回内容（rc=%ld）。模块可能不支持本命令或版本过旧。\n", rc);
        return 1;
    }
    return 0;
}
