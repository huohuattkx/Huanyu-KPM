/*
 * huanyu_daemon —— 欢愉守护进程（与 lsdriver 的 "LS" 进程同款）
 *
 * 【背景】
 *   lsdriver 内核侧是这样找用户态的：
 *       for_each_process(task) {
 *           if (strcmp(task->comm, "LS") != 0) continue;
 *           mm = get_task_mm(task);
 *           get_user_pages_remote(mm, 0x2025827000, ...);
 *           vmap(...);
 *       }
 *   那个 "LS" 进程是 ls 用户态套件里的独立程序，不是内核创建的。
 *   内核只负责扫名字 —— 这是关键，别搞反。
 *
 *   欢愉之前照抄"扫名字"失败了，因为欢愉的用户态是注入进游戏的，
 *   游戏进程名永远不可能是 "Huanyu"。
 *
 * 【解法：欢愉也带一个独立 daemon】
 *   这个程序做三件事：
 *     1. prctl(PR_SET_NAME) 把自己改名 "Huanyu"（可被 shm_name= 覆盖）
 *     2. mmap MAP_FIXED 到 0x2025827000
 *     3. 写 magic，然后活着（保持共享区有效）
 *
 *   之后内核扫到名字就 GUP + vmap，握手完成。
 *
 * 【同时它是请求代理】
 *   游戏进程被注入的 so 通常不方便自己 mmap 固定地址
 *   （可能和游戏自己的内存布局冲突）。
 *   所以 daemon 还监听一个 unix socket：
 *       游戏 so  --(socket)-->  daemon  --(共享内存)-->  内核
 *   这样游戏侧不需要 mmap，连名称冲突也避免了。
 *
 *   若你的注入环境能直接 mmap，也可以不用 daemon，
 *   内核会自动退化为"全量 magic 探测"。
 *
 * 【编译】
 *   aarch64-linux-android31-clang++ -std=c++17 -O2 -static \
 *       -o huanyu_daemon huanyu_daemon.cpp
 *
 * 【运行】
 *   adb push huanyu_daemon /data/local/tmp/
 *   adb shell chmod +x /data/local/tmp/huanyu_daemon
 *   adb shell /data/local/tmp/huanyu_daemon &
 */
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/syscall.h>

#define HY_SHM_FIXED_VA 0x2025827000ULL
#define HY_SHM_MAGIC    0x48796e75u
#define HY_SHM_VERSION  1u
#define HY_SHM_PAYLOAD  (128u * 1024u)

#define HY_SHM_IDLE 0u
#define HY_SHM_REQ  1u
#define HY_SHM_BUSY 2u
#define HY_SHM_F_READY (1u << 0)

#define HY_DAEMON_SOCK "/data/local/tmp/.huanyu_daemon_sock"

#pragma pack(1)

struct hy_shm_obj {
    volatile uint32_t magic;
    volatile uint32_t version;
    volatile uint32_t state;
    volatile uint32_t seq;
    volatile uint32_t ack;
    volatile int32_t  ret;
    volatile uint32_t nr;
    volatile uint32_t len;
    volatile uint32_t flags;
    volatile uint32_t reserved0;
    volatile uint64_t shm_va;
    volatile uint64_t shm_size;
    volatile uint64_t requests;
    volatile uint64_t errors;
    uint8_t payload[HY_SHM_PAYLOAD];
};

#pragma pack()

/* socket 协议：客户端发 [u32 nr][u32 len][payload]，回 [u32 ret][u32 len][payload] */
struct hy_sock_hdr {
    uint32_t nr;
    uint32_t len;
};

static struct hy_shm_obj *g_shm = nullptr;
static volatile sig_atomic_t g_running = 1;

static void on_signal(int) { g_running = 0; }

/*
 * 提交一条命令到共享区，等内核完成。
 */
static int32_t shm_submit(uint32_t nr, void *payload, uint32_t len)
{
    static uint32_t seq_counter = 0;

    if (!g_shm) return -1000;
    if (len > HY_SHM_PAYLOAD) return -1001;

    /* 等空闲 */
    for (int i = 0; i < 20000; i++) {
        if (g_shm->state == HY_SHM_IDLE) break;
        if (i > 200) usleep(100);
    }
    if (g_shm->state != HY_SHM_IDLE) return -1002;

    if (len > 0 && payload) memcpy(g_shm->payload, payload, len);

    uint32_t seq = ++seq_counter;
    g_shm->nr    = nr;
    g_shm->len   = len;
    g_shm->ret   = 0;
    g_shm->ack   = 0;
    g_shm->seq   = seq;
    g_shm->state = HY_SHM_REQ;

    for (int i = 0; i < 20000; i++) {
        if (g_shm->ack == seq && g_shm->state == HY_SHM_IDLE) break;
        if (i > 2000) usleep(100);
    }

    if (g_shm->ack != seq) return -1003;

    if (len > 0 && payload) memcpy(payload, g_shm->payload, len);
    return g_shm->ret;
}

static int serve_client(int fd)
{
    char buf[HY_SHM_PAYLOAD + sizeof(struct hy_sock_hdr)];
    struct hy_sock_hdr hdr;

    /* 读头部 */
    if (recv(fd, &hdr, sizeof(hdr), MSG_WAITALL) != (ssize_t)sizeof(hdr))
        return -1;

    if (hdr.len > HY_SHM_PAYLOAD) return -1;

    /* 读 payload */
    if (hdr.len > 0) {
        if (recv(fd, buf, hdr.len, MSG_WAITALL) != (ssize_t)hdr.len)
            return -1;
    }

    /* 提交给内核 */
    int32_t ret = shm_submit(hdr.nr, hdr.len ? buf : nullptr, hdr.len);

    /* 回 [ret][len][payload] */
    if (send(fd, &ret, sizeof(ret), 0) < 0) return -1;
    if (hdr.len > 0) {
        if (send(fd, &hdr.len, sizeof(hdr.len), 0) < 0) return -1;
        if (send(fd, buf, hdr.len, 0) < 0) return -1;
    }

    return 0;
}

int main(int argc, char **argv)
{
    const char *name = "Huanyu";
    if (argc > 1 && argv[1][0]) name = argv[1];

    printf("[欢愉守护进程] 启动中...\n");
    printf("  进程名  : %s\n", name);
    printf("  共享地址: 0x%llx\n", (unsigned long long)HY_SHM_FIXED_VA);

    /* 1. 改名 —— 内核靠这个找到我们 */
    if (prctl(PR_SET_NAME, (unsigned long)name, 0, 0, 0) != 0)
        perror("  prctl(PR_SET_NAME) 失败");
    else
        printf("  已改名  : %s\n", name);

    /* 2. mmap 固定地址 */
    size_t len = sizeof(struct hy_shm_obj);
    long ps = sysconf(_SC_PAGESIZE);
    if (ps > 0) len = ((len + (size_t)ps - 1) / (size_t)ps) * (size_t)ps;

    void *p = mmap((void *)(uintptr_t)HY_SHM_FIXED_VA, len,
                   PROT_READ | PROT_WRITE,
                   MAP_SHARED | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (p == MAP_FAILED) {
        perror("  mmap 失败");
        return 1;
    }
    if ((uintptr_t)p != HY_SHM_FIXED_VA) {
        printf("  mmap 地址不符: %p\n", p);
        return 1;
    }
    printf("  已映射  : %p (%zu 字节)\n", p, len);

    /* 3. 写 magic */
    memset(p, 0, len);
    g_shm = (struct hy_shm_obj *)p;
    g_shm->magic    = HY_SHM_MAGIC;
    g_shm->version  = HY_SHM_VERSION;
    g_shm->shm_va   = HY_SHM_FIXED_VA;
    g_shm->shm_size = len;
    g_shm->state    = HY_SHM_IDLE;
    printf("  magic   : 0x%x 已写入，等待内核连接\n", HY_SHM_MAGIC);

    /* 4. 等内核握手 */
    printf("  等待内核连接");
    for (int i = 0; i < 600; i++) {
        if (g_shm->flags & HY_SHM_F_READY) break;
        if (i % 60 == 0) { printf("."); fflush(stdout); }
        usleep(10000);
    }
    if (!(g_shm->flags & HY_SHM_F_READY)) {
        printf("\n  [!] 内核 6 秒内未连接\n");
        printf("      确认欢愉 KPM 已加载：dmesg | grep shm\n");
        /* 不退出，继续等 —— 内核可能后加载 */
    } else {
        printf(" 已连接!\n");
    }

    /* 5. 起 unix socket，做请求代理 */
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGPIPE, SIG_IGN);

    unlink(HY_DAEMON_SOCK);
    int srv = socket(AF_UNIX, SOCK_STREAM, 0);
    if (srv < 0) {
        perror("  socket 失败");
    } else {
        struct sockaddr_un addr;
        memset(&addr, 0, sizeof(addr));
        addr.sun_family = AF_UNIX;
        strncpy(addr.sun_path, HY_DAEMON_SOCK, sizeof(addr.sun_path) - 1);

        if (bind(srv, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
            perror("  bind 失败");
            close(srv);
            srv = -1;
        } else {
            chmod(HY_DAEMON_SOCK, 0666);
            listen(srv, 8);
            printf("  监听中  : %s\n", HY_DAEMON_SOCK);
            printf("\n[欢愉守护进程] 就绪。Ctrl+C 退出。\n");
        }
    }

    while (g_running) {
        if (srv < 0) { sleep(1); continue; }

        int fd = accept(srv, nullptr, nullptr);
        if (fd < 0) {
            if (errno == EINTR) continue;
            usleep(1000);
            continue;
        }

        while (g_running) {
            if (serve_client(fd) != 0) break;
        }
        close(fd);
    }

    if (srv >= 0) close(srv);
    unlink(HY_DAEMON_SOCK);
    munmap(p, len);
    printf("\n[欢愉守护进程] 已退出\n");
    return 0;
}
