/*
 * 断点方案选择 —— 完整演示
 *
 * 优先级（高 → 低）：
 *   1) 本次调用显式指定（bp_inst_sw / bp_inst_pte / bp_inst_hw，或 force_mode 参数）
 *   2) set_bp_mode() 设的【运行时默认】（用户选择，覆盖模块默认）
 *   3) 模块编译期默认 HY_DEFAULT_BP_SCHEME
 *   4) 内置回退链：硬件 -> PTE -> 软件
 *
 * 注意：方案不可用时不会安装失败，会自动沿回退链降级，
 *       真实生效的方案可从命中项读回。
 */

#include "huanyu_wanbai.hpp"

#include <cstdio>
#include <cstdint>

int main()
{
    c_driver drv;

    /* ---------- 0. 先看本内核支持哪些方案 ---------- */
    hy_bp_caps caps{};
    uint32_t cap = drv.bp_caps(&caps);

    printf("caps = 0x%x\n", cap);
    printf("  软件 SW  : %s\n", (cap & HY_BP_CAP_SW)  ? "支持" : "不支持");
    printf("  PTE 影子 : %s\n", (cap & HY_BP_CAP_PTE) ? "支持" : "不支持");
    printf("  硬件 HW  : %s\n", (cap & HY_BP_CAP_HW)  ? "支持" : "不支持");
    printf("  brps=%u wrps=%u\n", caps.num_brps, caps.num_wrps);

    /* ---------- 1. 用户选择：设置全局运行时默认 ---------- */
    /* 这一步就是"用户选择 > 模块默认"的开关 */
    drv.set_bp_mode(HY_BP_MODE_PTE);
    printf("当前运行时默认 = %u (2=PTE)\n", drv.get_bp_mode());

    /* 之后所有不带 force_mode 的 bp_inst 都按 PTE 走 */
    // uint64_t h1 = drv.bp_inst(target_pid, addr);

    /* 还原成交给内核决定 */
    drv.set_bp_mode(HY_BP_MODE_AUTO);
    printf("已还原为 AUTO = %u\n", drv.get_bp_mode());

    /* ---------- 2. 单次覆盖：只影响这一个断点 ---------- */
    uint32_t saved = drv.get_bp_mode();
    drv.set_bp_mode(HY_BP_MODE_SW);
    // uint64_t h2 = drv.bp_inst(target_pid, addr);   /* 这次走 SW */
    drv.set_bp_mode(saved);                           /* 装完还原 */

    /* 或者直接用快捷入口，内部自动还原，不污染全局 */
    // uint64_t h3 = drv.bp_inst_sw (pid, addr);   /* 强制软件 */
    // uint64_t h4 = drv.bp_inst_pte(pid, addr);   /* 强制 PTE 影子页 */
    // uint64_t h5 = drv.bp_inst_hw (pid, addr);   /* 强制硬件 */

    /* ---------- 3. 各方案适用场景 ---------- */
    printf("\n方案对照：\n");
    printf("  HW  (3) 调试寄存器。最快、不改内存、最难被检测；槽位有限(brps=%u)\n",
           caps.num_brps);
    printf("  PTE (2) 影子页。代码字节不变，隐蔽性好；页粒度，需影子页池\n");
    printf("  SW  (1) 替换指令为 BRK。最兼容；会改代码段，可被完整性校验发现\n");
    printf("  AUTO(0) 交给内核：按优先级选，不可用则沿链降级\n");

    return 0;
}
