// 欢愉内核模块的命令行加载器（aarch64 静态可执行文件）
//
// 为什么需要它：
//   .kpm 是 ELF，开头必须是 \x7fELF 才能被 APatch 解析；
//   而 Linux 执行文件要么以 \x7fELF 开头（走 binfmt_elf），
//   要么以 #! 开头（走 binfmt_script）。两者都要求占据文件第 0 字节，
//   所以同一个文件不可能既被 APatch 当模块解析、又被 shell 当脚本执行。
//   解决办法是把 kpm 内嵌进一个真正的可执行程序里：
//   推到手机上一个文件，chmod +x 之后直接跑，由它自己通过 supercall 加载。
//
// 用法：
//   ./huanyu_load <superkey> [模块参数...]
//   ./huanyu_load -k <superkey> -o /data/local/tmp/huanyu.kpm "touch=1 grab=1"
//   ./huanyu_load --kp=0.13.9 <superkey>        # 显式指定 KernelPatch 版本
//   ./huanyu_load --unload <superkey> [模块名]
//
// 退出码：0 成功；非 0 失败。

const std = @import("std");

const kpm_blob = @embedFile("huanyu_v1.69.0.kpm");

const NR_SUPERCALL: usize = 45;
const SUPERCALL_HELLO: usize = 0x1000;
const SUPERCALL_KPM_LOAD: usize = 0x1020;
const SUPERCALL_KPM_UNLOAD: usize = 0x1021;

const DEFAULT_OUT = "/data/local/tmp/huanyu_v1.69.0.kpm";
const DEFAULT_MODNAME = "huanyu";

// KernelPatch 0.13.9：MAJOR=0 MINOR=13 PATCH=9
var kp_major: usize = 0;
var kp_minor: usize = 13;
var kp_patch: usize = 9;

fn verAndCmd(cmd: usize) usize {
    const vc: usize = (kp_major << 16) + (kp_minor << 8) + kp_patch;
    return (vc << 32) | (0x1158 << 16) | (cmd & 0xFFFF);
}

// 直接用 svc 指令，不依赖 Zig 版本间变过好几次的 std.os.linux.syscall6 签名。
fn sc(key: usize, cmd: usize, a1: usize, a2: usize, a3: usize) i64 {
    return asm volatile ("svc #0"
        : [ret] "={x0}" (-> i64),
        : [nr] "{x8}" (NR_SUPERCALL),
          [k] "{x0}" (key),
          [c] "{x1}" (cmd),
          [a1] "{x2}" (a1),
          [a2] "{x3}" (a2),
          [a3] "{x4}" (a3),
        : "memory", "cc"
    );
}

fn die(comptime fmt: []const u8, args: anytype) noreturn {
    std.io.getStdErr().writer().print(fmt ++ "\n", args) catch {};
    std.process.exit(1);
}

pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    const alloc = gpa.allocator();

    var superkey: ?[]const u8 = null;
    var out_path: []const u8 = DEFAULT_OUT;
    var do_unload = false;
    var mod_name: []const u8 = DEFAULT_MODNAME;
    var mod_args_buf = std.ArrayList(u8).init(alloc);

    const argv = try std.process.argsAlloc(alloc);
    var i: usize = 1;
    while (i < argv.len) : (i += 1) {
        const a = argv[i];
        if (std.mem.startsWith(u8, a, "--kp=")) {
            var it = std.mem.splitScalar(u8, a["--kp=".len..], '.');
            kp_major = try std.fmt.parseInt(usize, it.next() orelse "0", 10);
            kp_minor = try std.fmt.parseInt(usize, it.next() orelse "13", 10);
            kp_patch = try std.fmt.parseInt(usize, it.next() orelse "9", 10);
        } else if (std.mem.eql(u8, a, "-k") or std.mem.eql(u8, a, "--key")) {
            i += 1;
            if (i >= argv.len) die("-k 后面缺少 superkey", .{});
            superkey = argv[i];
        } else if (std.mem.eql(u8, a, "-o") or std.mem.eql(u8, a, "--out")) {
            i += 1;
            if (i >= argv.len) die("-o 后面缺少路径", .{});
            out_path = argv[i];
        } else if (std.mem.eql(u8, a, "--unload")) {
            do_unload = true;
        } else if (std.mem.eql(u8, a, "-h") or std.mem.eql(u8, a, "--help")) {
            try usage();
            return;
        } else if (superkey == null) {
            superkey = a;
        } else {
            if (mod_args_buf.items.len > 0) try mod_args_buf.append(' ');
            try mod_args_buf.appendSlice(a);
        }
    }

    const key = superkey orelse {
        try usage();
        std.process.exit(2);
    };

    const stdout = std.io.getStdOut().writer();

    // 先探一下 supercall 通不通。返回负值说明密钥或 KP 版本不对。
    const hello = sc(@intFromPtr(key.ptr), verAndCmd(SUPERCALL_HELLO), 0, 0, 0);
    if (hello < 0) {
        try stdout.print(
            "supercall 不可用（ret={d}）\n" ++
                "  可能原因：superkey 不对，或 KernelPatch 版本不是 {d}.{d}.{d}\n" ++
                "  用 --kp=<主>.<次>.<补丁> 显式指定版本再试\n",
            .{ hello, kp_major, kp_minor, kp_patch },
        );
        std.process.exit(1);
    }
    try stdout.print("supercall OK（KernelPatch {d}.{d}.{d}）\n", .{ kp_major, kp_minor, kp_patch });

    if (do_unload) {
        const ret = sc(@intFromPtr(key.ptr), verAndCmd(SUPERCALL_KPM_UNLOAD), @intFromPtr(mod_name.ptr), 0, 0);
        if (ret < 0) {
            try stdout.print("卸载失败 ret={d}\n", .{ret});
            std.process.exit(1);
        }
        try stdout.print("已卸载 {s}\n", .{mod_name});
        return;
    }

    // 把内嵌的 kpm 落盘：supercall 的加载接口收的是路径，不是内存指针。
    {
        const f = std.fs.cwd().createFile(out_path, .{ .truncate = true, .mode = 0o644 }) catch |e|
            die("写 {s} 失败：{s}", .{ out_path, @errorName(e) });
        defer f.close();
        try f.writeAll(kpm_blob);
    }
    try stdout.print("已释放模块到 {s}（{d} 字节）\n", .{ out_path, kpm_blob.len });

    const args_z = try alloc.dupeZ(u8, mod_args_buf.items);
    const ret = sc(@intFromPtr(key.ptr), verAndCmd(SUPERCALL_KPM_LOAD), @intFromPtr(out_path.ptr), @intFromPtr(args_z.ptr), 0);
    if (ret < 0) {
        try stdout.print(
            "加载失败 ret={d}\n" ++
                "  常见原因：模块已加载（先 --unload）、内核版本不匹配、或 KP 版本不符\n",
            .{ret},
        );
        std.process.exit(1);
    }
    try stdout.print("加载成功（ret={d}）参数：\"{s}\"\n", .{ ret, mod_args_buf.items });
    try stdout.print("查看状态：cat /proc/Huanyu   或   echo 'handshake' > /proc/HuanyuD\n", .{});
}

fn usage() !void {
    const w = std.io.getStdOut().writer();
    try w.print(
        \\欢愉命令行加载器（内嵌 v1.69.0）
        \\
        \\  {s} <superkey> [模块参数...]
        \\  {s} -k <superkey> -o <落盘路径> [模块参数...]
        \\  {s} --kp=0.13.9 <superkey>
        \\  {s} --unload <superkey>
        \\
        \\  -k / -o / --kp= / --unload / -h 见上
        \\  模块参数会原样传给内核模块的 args（例如 "touch=1 grab=1"）
        \\
    , .{ "huanyu_load", "huanyu_load", "huanyu_load", "huanyu_load" });
}
