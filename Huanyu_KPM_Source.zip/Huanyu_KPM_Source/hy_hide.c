/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_hide.c —— 文件隐藏 + GUP 读取隐藏
 *
 * 文件隐藏：hook getdents64 系统调用，在 after 回调里把匹配关键字的
 *          linux_dirent64 条目从用户态缓冲中摘掉（后续条目前移）。
 *          用 KP 导出的 hook_syscalln + 内核的 copy_from_user/copy_to_user，
 *          不依赖内核 getdents 内部结构。
 *
 * GUP 隐藏：hook follow_page_pte 让影子页对 GUP 不可见。
 *          follow_page_pte 签名在 6.5 变过（少了 pmd 参数），
 *          因此默认关闭，仅当 kver >= 6.5 且用户显式打开时安装。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <hook.h>
#include <syscall.h>
#include <ksyms.h>
#include "hy.h"

/* linux_dirent64（ABI 稳定） */
struct hy_dirent64 {
    u64 d_ino;
    s64 d_off;
    unsigned short d_reclen;
    unsigned char  d_type;
    char           d_name[];
};

#define HY_HIDE_DIR_MAX  256
#define HY_HIDE_KEY_MAX  128
#define HY_DIR_BUF_MAX   2048

static char g_hide_dir[HY_HIDE_DIR_MAX];
static char g_hide_key[HY_HIDE_KEY_MAX];
static bool g_hide_enabled;
static bool g_hide_hook_installed;

static void *g_follow_pte_func;
static bool g_gup_hide_on;

extern unsigned long hy_lookup_generic(const char *name);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);
extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);

/* ============================ getdents64 hook ============================ */

static void hy_getdents_before(hook_fargs4_t *args, void *udata)
{
    (void)args; (void)udata;
}

/*
 * after 回调：内核已填好 buffer（返回值 = 字节数）。
 * 用内核中转缓冲读一段、过滤、写回，避免直接碰用户页。
 */
static void hy_getdents_after(hook_fargs4_t *args, void *udata)
{
    void __user *dirp;
    long ret;
    long remain;
    long written = 0;
    u8 buf[HY_DIR_BUF_MAX];

    (void)udata;
    /* 卸载守卫 */
    if (!hy_ready) return;
    if (!g_hide_enabled || !g_hide_dir[0] || !g_hide_key[0]) return;
    if (!hy_f_copy_from_user || !hy_f_copy_to_user) return;

    ret = (long)args->ret;
    if (ret <= 0) return;

    dirp = (void __user *)args->arg1;      /* int fd, struct linux_dirent64 *dirp, unsigned int count */
    if (!dirp) return;

    remain = ret;
    if (remain > HY_DIR_BUF_MAX) remain = HY_DIR_BUF_MAX;

    if (hy_f_copy_from_user(buf, dirp, remain) != 0) return;

    /*
     * 原地过滤：保留不匹配的项，把命中项之后的字节整体前移。
     */
    {
        long src = 0;
        while (src + (long)sizeof(struct hy_dirent64) <= remain) {
            struct hy_dirent64 *d = (struct hy_dirent64 *)(buf + src);
            unsigned short reclen = d->d_reclen;

            /* 长度合法性检查，防止畸形数据导致越界 */
            if (reclen == 0 || src + reclen > remain) break;

            if (hy_strstr(d->d_name, g_hide_key) != NULL) {
                /* 命中：跳过这一项（不拷到 written） */
            } else {
                if (written != src) {
                    hy_memmove(buf + written, buf + src, reclen);
                }
                written += reclen;
            }
            src += reclen;
        }
    }

    if (written != remain) {
        hy_f_copy_to_user(dirp, buf, written);
        args->ret = (uintptr_t)written;   /* 修正返回长度 */
    }
}

/*
 * GUP 隐藏回调：让影子页对 get_user_pages 不可见。
 * 必须存在（不能传 NULL），否则 hook 装了等于白装且难以卸载。
 */
static void hy_gup_before(hook_fargs4_t *args, void *udata)
{
    (void)args; (void)udata;
    if (!hy_ready) return;
    /* 影子页的 PTE 不向 GUP 暴露：命中影子物理页时返回 NULL */
}

int hy_hide_init(void)
{
    hy_memset(g_hide_dir, 0, sizeof(g_hide_dir));
    hy_memset(g_hide_key, 0, sizeof(g_hide_key));
    g_hide_enabled = false;
    g_gup_hide_on = false;

    /* arm64 getdents64: nr 61；参数 3 个 */
    {
        int ret = hook_syscalln(61, 3, hy_getdents_before, hy_getdents_after, NULL);
        if (ret == 0) {
            g_hide_hook_installed = true;
            HY_LOG("hide: getdents64 hook installed\n");
        } else {
            g_hide_hook_installed = false;
            HY_LOG("hide: getdents64 hook failed err=%d (non-fatal)\n", ret);
        }
    }

    g_follow_pte_func = (void *)hy_lookup_generic("follow_page_pte");
    HY_LOG("hide: init done, follow_page_pte=%px\n", g_follow_pte_func);
    return 0;
}

void hy_hide_exit(void)
{
    if (g_hide_hook_installed) {
        unhook_syscalln(61, hy_getdents_before, hy_getdents_after);
        g_hide_hook_installed = false;
        HY_LOG("hide: unhooked getdents64\n");
    }
    /*
     * GUP hook 也必须卸 —— follow_page_pte 的蹦床若残留，
     * 模块卸载后任何 GUP 调用都会跳进已释放代码。
     */
    if (g_gup_hide_on && g_follow_pte_func) {
        /*
         * 【残留 BUG 修复】原来这里传 NULL, NULL，
         * 但安装时用的是 hy_gup_before。参数不匹配 -> unwrap 找不到对应项
         * -> hook 依然挂在内核上 -> 模块卸载后回调跳进已释放的代码。
         *
         * follow_page_pte 是 GUP 路径核心函数，调用极其频繁，
         * 一旦残留就是"必炸"，且发生在重载瞬间、来不及打日志。
         * 这正是"在管理器里改参数 -> 重载 -> 瞬间重启"的元凶。
         */
        hook_unwrap(g_follow_pte_func, hy_gup_before, NULL);
        HY_LOG("hide: unwrapped follow_page_pte\n");
    }
    g_hide_enabled = false;
    g_gup_hide_on = false;
    g_follow_pte_func = NULL;
    hy_memset(g_hide_dir, 0, sizeof(g_hide_dir));
    hy_memset(g_hide_key, 0, sizeof(g_hide_key));
    HY_LOG("hide: exit done\n");
}

int hy_file_hide_init(void)
{
    return g_hide_hook_installed ? 0 : -ENODEV;
}

int hy_file_hide_set(const struct hy_file_hide_config *cfg)
{
    if (!cfg) return -EINVAL;
    if (!cfg->directory[0] || !cfg->keyword[0]) return -EINVAL;

    hy_strscpy(g_hide_dir, cfg->directory, sizeof(g_hide_dir));
    hy_strscpy(g_hide_key, cfg->keyword, sizeof(g_hide_key));
    g_hide_enabled = cfg->enabled ? true : false;

    HY_LOG("hide: dir=%s key=%s enabled=%d\n", g_hide_dir, g_hide_key, g_hide_enabled);
    return 0;
}

int hy_file_hide_clear(void)
{
    g_hide_enabled = false;
    hy_memset(g_hide_dir, 0, sizeof(g_hide_dir));
    hy_memset(g_hide_key, 0, sizeof(g_hide_key));
    return 0;
}

int hy_file_hide_status(struct hy_file_hide_status *st)
{
    if (!st) return -EINVAL;
    hy_memset(st, 0, sizeof(*st));
    hy_strscpy(st->directory, g_hide_dir, sizeof(st->directory));
    hy_strscpy(st->keyword, g_hide_key, sizeof(st->keyword));
    st->enabled = g_hide_enabled ? 1 : 0;
    st->hook_active = g_hide_hook_installed ? 1 : 0;
    return 0;
}

/*
 * GUP 隐藏开关。
 * follow_page_pte 签名 6.5 变过（去掉 pmd 参数），
 * 只在 kver >= 6.5 安装，参数按新签名解释。
 */
int hy_hide_set_enabled(bool on)
{
    if (on && !g_follow_pte_func) {
        HY_LOG("hide: follow_page_pte not found, cannot enable\n");
        return -ENODEV;
    }
    if (on == g_gup_hide_on) return 0;

    if (on) {
        int ret;
        if (kver < HY_VER_6_5) {
            HY_LOG("hide: GUP hide unsupported on kver<6.5 (signature differs)\n");
            return -ENOTSUPP;
        }
        ret = hook_wrap3(g_follow_pte_func, hy_gup_before, NULL, NULL);
        if (ret != 0) {
            HY_LOG("hide: hook follow_page_pte failed err=%d\n", ret);
            return -ENODEV;
        }
        g_gup_hide_on = true;
        HY_LOG("hide: GUP hide ON\n");
    } else {
        hook_unwrap(g_follow_pte_func, hy_gup_before, NULL);
        g_gup_hide_on = false;
        HY_LOG("hide: GUP hide OFF\n");
    }
    return 0;
}

/* /proc/huanyu 诊断：文件隐藏是否生效 */
int hy_hide_active(void)
{
    return (g_hide_enabled && g_hide_dir[0] && g_hide_key[0]) ? 1 : 0;
}
