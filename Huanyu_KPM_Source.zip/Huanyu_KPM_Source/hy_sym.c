/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_sym.c —— 符号解析
 *
 * 【铁律】候选列表只放签名完全一致的名字。
 *
 * wxshadow 崩溃的两次根因都来自"回退到签名不同的函数"：
 *   - kzalloc 回退到 kmalloc_trace(kmem_cache*, gfp, size)
 *     把 size 数值当 kmem_cache 指针解引用 -> 访问 0x80 -> panic
 *   - __get_free_pages 回退到 __get_free_pages_node(gfp, order, nid)
 *     nid 取自未初始化寄存器 -> 索引 NODE_DATA -> panic
 *
 * 因此这里：
 *   1. 优先用 KP 导出的 kallsyms_lookup_name（版本无关）
 *   2. 回退路径按 kver 分支（kallsyms_on_each_symbol 回调参数个数 6.1 变了）
 *   3. 地址合法性校验：不在内核地址空间一律当作"未找到"
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <kallsyms.h>
#include <ksyms.h>
#include "hy.h"
#include "hy_scheme.h"

/* ---- 函数指针 ---- */
void *(*hy_f_find_get_task_by_vpid)(int pid);
void (*hy_f_put_task_struct)(void *task);
void *(*hy_f_get_task_mm)(void *task);
void (*hy_f_mmput)(void *mm);
void *(*hy_f_find_vma)(void *mm, unsigned long addr);
unsigned long (*hy_f___get_free_pages)(unsigned int gfp, unsigned int order);
void (*hy_f_free_pages)(unsigned long addr, unsigned int order);
long (*hy_f_copy_from_user)(void *dst, const void *src, unsigned long n);
long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
void (*hy_f_user_enable_single_step)(void *task);
void (*hy_f_user_disable_single_step)(void *task);
void *(*hy_f_do_mem_abort)(unsigned long addr, unsigned int esr, void *regs);
void *(*hy_f_do_page_fault)(unsigned long addr, unsigned int esr, void *regs);
void *(*hy_f_follow_page_pte)(void *vma, unsigned long addr, unsigned int flags);
void (*hy_f_flush_tlb_range)(void *vma, unsigned long start, unsigned long end);
void (*hy_f_kick_all_cpus_sync)(void);

/* ---- 变量指针 ---- */
long *hy_v_memstart_addr;
long *hy_v_physvirt_offset;
long *hy_v_vabits_actual;   /* v1.64.0：arm64 实际 VA 位数，页表参数备用数据源 */

/*
 * v1.64.3：swapper_pg_dir 的内核虚拟地址。
 *
 * 它是 TTBR1_EL1 里那个页表的内核侧地址，于是
 *     off = swapper_pg_dir(VA) - TTBR1(物理地址)
 * 是一个**完全不需要走页表**的线性映射偏移求法 —— 纯算术，零解引用。
 * 这比"靠走页表反推"安全得多，也正是替换掉原 PGTABLE_DERIVE 档的原因。
 */
unsigned long hy_v_swapper_pg_dir;

/* ---- 内部状态 ---- */
static int sym_fail_count;

static inline bool hy_addr_ok(unsigned long a)
{
    /* aarch64 内核地址必然在 0xffffff00_00000000 以上 */
    return (a & 0xffffff0000000000UL) == 0xffffff0000000000UL;
}

struct hy_lookup_data {
    const char *name;
    unsigned long addr;
};

/* 6.1 及以下：回调带 struct module * */
static int hy_cb_mod(void *data, const char *name, struct module *mod, unsigned long addr)
{
    struct hy_lookup_data *ld = data;
    (void)mod;   /* 6.1+ 才带这个参数，本回调不用 */
    if (hy_strcmp(name, ld->name) == 0) { ld->addr = addr; return 1; }
    return 0;
}

/* 6.1 以上：回调不带 struct module * */
typedef int (*hy_on_each_nomod_t)(int (*fn)(void *, const char *, unsigned long), void *data);

static int hy_cb_nomod(void *data, const char *name, unsigned long addr)
{
    struct hy_lookup_data *ld = data;
    if (hy_strcmp(name, ld->name) == 0) { ld->addr = addr; return 1; }
    return 0;
}

/*
 * v1.64.0：符号解析策略（由 hy_scheme 选择，见 hy_scheme.h 的 HY_SYM_*）。
 *
 * 默认双路：先问 kallsyms_lookup_name，查不到再遍历。
 * 降级路径是"只用 lookup_name" -> "只遍历" -> "完全不解析"。
 * 最后那档只在两套接口都不可用时才会被选中，此时 hy_lookup 一律返回 0，
 * 模块退化为只使用 KernelPatch 已经导出的符号。
 */
static int g_sym_strategy = HY_SYM_LOOKUP_ON_EACH;

/*
 * 与 KernelPatch 的 kallsyms_on_each_match_symbol 保持同样的版本分支。
 */
static unsigned long hy_lookup(const char *name)
{
    struct hy_lookup_data ld = { .name = name, .addr = 0 };
    unsigned long a;

    if (g_sym_strategy == HY_SYM_PRESET_ONLY) return 0;

    if (g_sym_strategy == HY_SYM_ON_EACH_ONLY) goto do_each;

    if (kallsyms_lookup_name) {
        a = kallsyms_lookup_name(name);
        if (hy_addr_ok(a)) return a;
    }

    if (g_sym_strategy == HY_SYM_LOOKUP_ONLY) return 0;

do_each:
    if (!kallsyms_on_each_symbol) return 0;

    if (kver <= HY_VER_6_1) {
        kallsyms_on_each_symbol(hy_cb_mod, &ld);
    } else {
        hy_on_each_nomod_t fn = (hy_on_each_nomod_t)kallsyms_on_each_symbol;
        fn(hy_cb_nomod, &ld);
    }

    if (!hy_addr_ok(ld.addr)) return 0;
    return ld.addr;
}

/*
 * 多候选解析。candidates 里的名字**必须签名完全一致**。
 */
static unsigned long hy_lookup_any(const char *const *cands, int n, const char *what)
{
    int i;
    for (i = 0; i < n; i++) {
        unsigned long a = hy_lookup(cands[i]);
        if (a) {
            HY_LOG("sym: %s -> %s @ %px\n", what, cands[i], (void *)a);
            return a;
        }
    }
    HY_LOG("sym: %s NOT FOUND (%d candidates)\n", what, n);
    sym_fail_count++;
    return 0;
}

#define SYMN(ptr, cands, n) \
    do { ptr = (typeof(ptr))hy_lookup_any(cands, n, #ptr); } while (0)

#define SYM1(ptr, name) \
    do { ptr = (typeof(ptr))hy_lookup(name); \
         if (!ptr) { HY_LOG("sym: MISS %s\n", name); sym_fail_count++; } } while (0)

int hy_resolve_symbols(void)
{
    hy_f_memcpy = (void *(*)(void *, const void *, unsigned long))hy_lookup_generic("kf_memcpy");
    sym_fail_count = 0;
    static const char *const gfp_cands[] = {
        "__get_free_pages",
        "__get_free_pages_noprof",
        /* 绝不回退 __get_free_pages_node：3 参数，签名不同 */
    };
    static const char *const fp_cands[] = {
        "free_pages",
        "free_pages_noprof",
        /* 绝不回退 __free_pages：首参是 struct page *，不是虚拟地址 */
    };
    static const char *const fault_cands_new[] = { "do_page_fault" };
    static const char *const fault_cands_old[] = { "do_mem_abort" };

    sym_fail_count = 0;

    /* 任务与地址空间 */
    SYM1(hy_f_find_get_task_by_vpid, "find_get_task_by_vpid");
    SYM1(hy_f_get_task_mm, "get_task_mm");
    SYM1(hy_f_mmput, "mmput");
    SYM1(hy_f_put_task_struct, "put_task_struct");
    SYM1(hy_f_find_vma, "find_vma");

    /* 页分配：只接受两参数签名 */
    hy_f___get_free_pages = (typeof(hy_f___get_free_pages))
        hy_lookup_any(gfp_cands, 2, "__get_free_pages");
    hy_f_free_pages = (typeof(hy_f_free_pages))
        hy_lookup_any(fp_cands, 2, "free_pages");

    /* 用户态拷贝 */
    /*
     * 【prctl 通道之前禁用的真因】
     *
     * 日志：`sym: MISS copy_from_user` / `MISS copy_to_user`
     * 结果：`prctl: copy_*_user missing, channel disabled`
     * 连带：用户态只能走 supercall -> 鉴权过不去 -> "鉴权未通过"
     *
     * 原因：ARM64 内核里 copy_from_user 是【宏】，不是函数。
     * 它展开后调用真正的内核函数，名字带下划线前缀：
     *     copy_from_user  ->  _copy_from_user    (5.x ~ 6.x 主流)
     *                     ->  __copy_from_user   (部分配置)
     *                     ->  raw_copy_from_user (老版本)
     * 直接查 "copy_from_user" 在 kallsyms 里根本不存在。
     *
     * 这里改成多候选。签名都是 (dst, src, n) -> 未拷贝字节数，
     * 三者完全一致，可以安全回退。
     */
    {
        static const char *cfu[] = {
            "_copy_from_user",
            "__copy_from_user",
            "raw_copy_from_user",
            "copy_from_user",
        };
        static const char *ctu[] = {
            "_copy_to_user",
            "__copy_to_user",
            "raw_copy_to_user",
            "copy_to_user",
        };
        SYMN(hy_f_copy_from_user, cfu, 4);
        SYMN(hy_f_copy_to_user,   ctu, 4);
    }

    /* 单步 */
    SYM1(hy_f_user_enable_single_step, "user_enable_single_step");
    SYM1(hy_f_user_disable_single_step, "user_disable_single_step");

    /* 页错误入口：arm64 在 6.8 前后改名 */
    if (kver >= HY_VER_6_8) {
        hy_f_do_page_fault = (typeof(hy_f_do_page_fault))
            hy_lookup_any(fault_cands_new, 1, "do_page_fault");
    } else {
        hy_f_do_mem_abort = (typeof(hy_f_do_mem_abort))
            hy_lookup_any(fault_cands_old, 1, "do_mem_abort");
    }

    /* GUP：follow_page_pte 签名在 6.5 变过，这里只取地址，调用侧按 kver 解释参数 */
    SYM1(hy_f_follow_page_pte, "follow_page_pte");

    /* TLB */
    SYM1(hy_f_flush_tlb_range, "flush_tlb_range");
    SYM1(hy_f_kick_all_cpus_sync, "kick_all_cpus_sync");

    /* 地址换算变量 */
    hy_v_memstart_addr = (long *)hy_lookup("memstart_addr");
    if (!hy_v_memstart_addr) { HY_LOG("sym: MISS memstart_addr\n"); sym_fail_count++; }
    hy_v_physvirt_offset = (long *)hy_lookup("physvirt_offset");

    /*
     * v1.64.0：页表参数的备用数据源。
     * 查不到不算失败 —— 它只是 5 系那一档的输入，缺了就降级到
     * 页表反推（4 系）或固定假设（3 系），不影响主流程。
     */
    hy_v_vabits_actual = (long *)hy_lookup("vabits_actual");
    HY_LOG("sym: vabits_actual=%d\n", !!hy_v_vabits_actual);

    /*
     * v1.64.3：查不到不算失败，只是少一种偏移求法与校验手段。
     * 它既能当 4 系档的输入，也能在 pt_validate() 里做**纯算术**的
     * 独立交叉校验（virt_to_phys(swapper_pg_dir) 必须等于 TTBR1），
     * 那条校验不依赖任何解引用，是 init 不再秒炸的关键。
     */
    hy_v_swapper_pg_dir = hy_lookup("swapper_pg_dir");
    HY_LOG("sym: swapper_pg_dir=%d\n", !!hy_v_swapper_pg_dir);

    HY_LOG("sym: done, failures=%d, kver=0x%x\n", sym_fail_count, kver);
    return sym_fail_count;
}

/*
 * 供其他模块复用的通用解析（带地址合法性校验）。
 */
void *(*hy_f_memcpy)(void *dest, const void *src, unsigned long n);

unsigned long hy_lookup_generic(const char *name)
{
    return hy_lookup(name);
}

void hy_report_symbols(void)
{
    HY_LOG("SYMS task=%d mm=%d gfp=%d free=%d fault=%d gup=%d memstart=%d\n",
           !!hy_f_find_get_task_by_vpid,
           !!hy_f_get_task_mm,
           !!hy_f___get_free_pages,
           !!hy_f_free_pages,
           !!(hy_f_do_page_fault ?: hy_f_do_mem_abort),
           !!hy_f_follow_page_pte,
           !!hy_v_memstart_addr);
}

/* 供 STATS 使用 */
int hy_sym_failures(void) { return sym_fail_count; }

/* ==================== 方案选择支持（v1.64.0） ==================== */

/*
 * available() 只看"这套策略的输入在不在"：
 *   6 系要两条接口都在，5 系只要 lookup_name，4 系只要 on_each，
 *   3 系什么都不要（但代价是所有动态解析都拿不到）。
 */
int hy_sym_strategy_available(int kind)
{
    switch (kind) {
    case HY_SYM_LOOKUP_ON_EACH:
        return (kallsyms_lookup_name && kallsyms_on_each_symbol) ? 0 : -1;
    case HY_SYM_LOOKUP_ONLY:
        return kallsyms_lookup_name ? 0 : -1;
    case HY_SYM_ON_EACH_ONLY:
        return kallsyms_on_each_symbol ? 0 : -1;
    case HY_SYM_PRESET_ONLY:
        return 0;
    default:
        return -1;
    }
}

int hy_sym_apply_strategy(int kind)
{
    if (hy_sym_strategy_available(kind) != 0) return -1;
    g_sym_strategy = kind;
    return 0;
}

int hy_sym_strategy_kind(void) { return g_sym_strategy; }
