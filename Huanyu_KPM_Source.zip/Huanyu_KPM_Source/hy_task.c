/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_task.c —— TLS 读取 与 PACGA 计算
 *
 * TLS：ARM64 上线程局部存储指针保存在 TPIDR_EL0，
 *      上下文切换时存进 task->thread.uw.tp_value。
 *      该偏移在 5.10~6.18 间变过，因此这里**不硬编码**：
 *      init 时用当前进程的已知 (current_task, tpidr_el0) 对，
 *      在 task_struct 内搜索该值，缓存得到偏移，之后复用。
 *
 * PACGA：直接用 pacga 指令（ARMv8.3-PAuth）。
 *        需要 CPU 支持；运行时从 ID_AA64ISAR1_EL1.APA 判断。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <ksyms.h>
#include <asm/current.h>
#include "hy.h"

extern void *(*hy_f_find_get_task_by_vpid)(int pid);
extern void (*hy_f_put_task_struct)(void *task);
extern unsigned long hy_lookup_generic(const char *name);

/* tp_value 在 task_struct 内的偏移，-1 表示未校准 */
static int g_tp_offset = -1;

/* 当前进程的 task 指针（通过 sp_el0 或 current 获取） */
static inline void *hy_get_current_task(void)
{
    void *task = NULL;
    unsigned long sp_el0;

    asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));

    if (sp_el0_is_current) {
        task = (void *)sp_el0;
    } else if (sp_el0_is_thread_info) {
        if (task_in_thread_info_offset >= 0)
            task = *(void **)(sp_el0 + task_in_thread_info_offset);
    } else {
        /* sp_el0 指向 task_struct 或栈底，按已知信息换算 */
        if (stack_in_task_offset >= 0)
            task = (void *)(sp_el0 - stack_in_task_offset);
    }
    return task;
}

static inline u64 hy_read_tpidr_el0(void)
{
    u64 v;
    asm volatile("mrs %0, tpidr_el0" : "=r"(v));
    return v;
}

/*
 * 【v1.48.0】安全读取当前进程 comm。
 * hy_current_task() 由 hy_discover.c 提供，这里不再重复定义。
 * 不走 __get_task_comm（需要合法的 task 指针，且该函数在部分内核
 * 上是 static/未导出），改为按 hy_comm_offset() 直接读内存。
 */
void hy_current_comm(char *out, unsigned long cap)
{
    void *cur;
    int off;

    if (!out || cap == 0) return;
    out[0] = 0;

    cur = hy_current_task();
    off = hy_comm_offset();
    if (!cur || off < 0) return;
    if (!hy_kern_addr_mapped((unsigned long)cur + (unsigned long)off)) return;

    hy_strscpy(out, (const char *)((unsigned long)cur + (unsigned long)off), cap);
    if (cap > 15) out[15] = 0;
}

/*
 * 校准 tp_value 偏移：
 * 用当前进程自己的 tpidr_el0，在当前 task_struct 里搜索这个值。
 * 版本无关，无需知道 thread 在哪。
 */
int hy_task_init(void)
{
    void *cur = hy_get_current_task();
    u64 tpidr = hy_read_tpidr_el0();
    int i;

    if (!cur || tpidr == 0) {
        HY_LOG("task: cannot calibrate (cur=%px tpidr=%llx)\n", cur, tpidr);
        return -1;
    }

    /* 在 task_struct 前 4096 字节内按 8 字节对齐搜索 */
    for (i = 0; i < 4096; i += 8) {
        u64 v = *(u64 *)((unsigned long)cur + i);
        if (v == tpidr) {
            g_tp_offset = i;
            HY_LOG("task: tp_value offset calibrated = %d (tpidr=%llx)\n", i, tpidr);
            return 0;
        }
    }

    HY_LOG("task: tp_value offset NOT found\n");
    return -1;
}

/*
 * 读目标线程的 TLS（TPIDR_EL0）。
 * 若目标是当前线程，直接读寄存器；否则读 task->thread.uw.tp_value。
 */
int hy_get_thread_tls(struct hy_tls_request *req)
{
    void *task;
    int32_t tid;

    if (!req || req->pid <= 0) return -EINVAL;

    tid = req->tid;
    if (tid <= 0) tid = req->pid;

    /* 目标就是当前线程：直接读寄存器最准 */
    {
        void *cur = hy_get_current_task();
        s32 *curpid = (cur && hy_pid_offset() >= 0) ? (s32 *)((unsigned long)cur + hy_pid_offset()) : NULL;
        if (curpid && *curpid == tid) {
            req->tls_value = hy_read_tpidr_el0();
            req->result = 0;
            return 0;
        }
    }

    if (g_tp_offset < 0) {
        req->result = -ENOTSUPP;
        return -ENOTSUPP;
    }
    if (!hy_f_find_get_task_by_vpid) {
        req->result = -ENODEV;
        return -ENODEV;
    }

    task = hy_f_find_get_task_by_vpid(tid);
    if (!task) {
        req->result = -ESRCH;
        return -ESRCH;
    }

    req->tls_value = *(u64 *)((unsigned long)task + g_tp_offset);
    req->result = 0;

    if (hy_f_put_task_struct) hy_f_put_task_struct(task);
    return 0;
}

/*
 * PACGA：用 value 和 modifier 计算 PACGA 值。
 * 注意 KPM 编译带 -mgeneral-regs-only，但 pacga 只用通用寄存器，
 * 不涉及 FP/SIMD，因此可以安全内联。
 */
static inline bool hy_cpu_has_pacga(void)
{
    u64 isar1;
    asm volatile("mrs %0, ID_AA64ISAR1_EL1" : "=r"(isar1));
    /* APA 字段 bit 4..7，非 0 表示实现了 PAuth（含 PACGA） */
    return ((isar1 >> 4) & 0xf) != 0;
}

int hy_exec_pacga(struct hy_pacga_request *req)
{
    u64 result;

    if (!req || req->pid <= 0) return -EINVAL;

    if (!hy_cpu_has_pacga()) {
        req->ok = 0;
        req->result_pac = 0;
        return -ENOTSUPP;
    }

    asm volatile(
        "pacga %0, %1, %2\n"
        : "=r"(result)
        : "r"(req->value), "r"(req->modifier)
    );

    req->result_pac = result;
    req->ok = 1;
    return 0;
}
