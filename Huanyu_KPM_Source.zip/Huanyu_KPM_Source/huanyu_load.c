/*
 * 欢愉内核模块的命令行加载器（aarch64 静态可执行文件，自解压）
 *
 * 为什么需要它：
 *   .kpm 是 ELF，第 0 字节必须是 \x7fELF，APatch 才能解析；
 *   而 Linux 执行文件要么第 0 字节起是 \x7fELF（binfmt_elf），
 *   要么第 0 字节起是 #!（binfmt_script）。两者互斥 ——
 *   同一个文件不可能既被 APatch 当模块解析、又被 shell 当脚本/程序执行。
 *
 *   做法：把 kpm 原样追加在本可执行文件尾部（追加不破坏 ELF 合法性），
 *   运行时从 /proc/self/exe 里把它抠出来落盘，再用 supercall 加载。
 *   于是推到手机上只要一个文件：chmod +x 之后直接跑。
 *
 * 用法：
 *   ./huanyu_load <superkey> [模块参数...]
 *   ./huanyu_load -k <superkey> -o /data/local/tmp/huanyu.kpm "touch=1 grab=1"
 *   ./huanyu_load --kp=0.13.9 <superkey>      显式指定 KernelPatch 版本
 *   ./huanyu_load --unload <superkey> [模块名]
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>

#define NR_SUPERCALL        45
#define SUPERCALL_HELLO     0x1000
#define SUPERCALL_KPM_LOAD  0x1020
#define SUPERCALL_KPM_UNLOAD 0x1021

#define DEFAULT_OUT      "/data/local/tmp/huanyu_v1.69.0.kpm"
#define DEFAULT_MODNAME  "huanyu"
#define BLOB_MAGIC       "HUANYUKBLOB1"
#define BLOB_MAGIC_LEN   12

static int kp_major = 0, kp_minor = 13, kp_patch = 9;   /* KernelPatch 0.13.9 */

static long ver_and_cmd(long cmd)
{
    long vc = (long)((kp_major << 16) + (kp_minor << 8) + kp_patch);
    return (vc << 32) | (0x1158L << 16) | (cmd & 0xFFFFL);
}

/* 直接 svc，避免依赖 libc 的 syscall 封装在不同 NDK/内核版本上的差异 */
static long sc(long key_ptr, long cmd, long a1, long a2, long a3)
{
    register long x8 __asm__("x8") = NR_SUPERCALL;
    register long x0 __asm__("x0") = key_ptr;
    register long x1 __asm__("x1") = cmd;
    register long x2 __asm__("x2") = a1;
    register long x3 __asm__("x3") = a2;
    register long x4 __asm__("x4") = a3;
    __asm__ __volatile__("svc #0"
                         : "+r"(x0)
                         : "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x8)
                         : "memory", "cc");
    return x0;
}

/* 从自身尾部取出内嵌的 kpm 并落盘 */
static int extract_self(const char *out_path, size_t *out_len)
{
    int fd = open("/proc/self/exe", O_RDONLY | O_CLOEXEC);
    if (fd < 0) { fprintf(stderr, "打开 /proc/self/exe 失败: %s\n", strerror(errno)); return -1; }

    size_t cap = 1 << 22, len = 0;
    unsigned char *buf = malloc(cap);
    if (!buf) { close(fd); return -1; }
    for (;;) {
        if (len == cap) { cap *= 2; unsigned char *nb = realloc(buf, cap); if (!nb) { free(buf); close(fd); return -1; } buf = nb; }
        ssize_t n = read(fd, buf + len, cap - len);
        if (n < 0) { if (errno == EINTR) continue; free(buf); close(fd); return -1; }
        if (n == 0) break;
        len += (size_t)n;
    }
    close(fd);

    size_t pos = 0;
    for (size_t i = 0; i + BLOB_MAGIC_LEN <= len; i++) {
        if (memcmp(buf + i, BLOB_MAGIC, BLOB_MAGIC_LEN) == 0) { pos = i; break; }
    }
    if (!pos) { fprintf(stderr, "自身尾部没找到内嵌模块标记\n"); free(buf); return -1; }

    size_t off = pos + BLOB_MAGIC_LEN;
    if (off + 8 > len) { fprintf(stderr, "内嵌模块头损坏\n"); free(buf); return -1; }
    uint64_t klen = 0;
    memcpy(&klen, buf + off, 8);
    off += 8;
    if (klen == 0 || off + klen > len) { fprintf(stderr, "内嵌模块长度非法: %llu\n", (unsigned long long)klen); free(buf); return -1; }

    int of = open(out_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (of < 0) { fprintf(stderr, "写 %s 失败: %s\n", out_path, strerror(errno)); free(buf); return -1; }
    size_t w = 0;
    while (w < klen) {
        ssize_t n = write(of, buf + off + w, klen - w);
        if (n < 0) { if (errno == EINTR) continue; fprintf(stderr, "写 %s 失败: %s\n", out_path, strerror(errno)); close(of); free(buf); return -1; }
        w += (size_t)n;
    }
    close(of);
    free(buf);
    *out_len = (size_t)klen;
    return 0;
}

static void usage(const char *self)
{
    printf("欢愉命令行加载器（内嵌 v1.69.0）\n"
           "  %s <superkey> [模块参数...]\n"
           "  %s -k <superkey> -o <落盘路径> [模块参数...]\n"
           "  %s --kp=0.13.9 <superkey>          显式指定 KernelPatch 版本\n"
           "  %s --unload <superkey> [模块名]\n"
           "  模块参数会原样传给内核模块 args，例如 \"touch=1 grab=1\"\n",
           self, self, self, self);
}

int main(int argc, char **argv)
{
    const char *superkey = NULL;
    const char *out_path = DEFAULT_OUT;
    const char *mod_name = DEFAULT_MODNAME;
    int do_unload = 0;
    char args_buf[1024];
    size_t args_len = 0;
    args_buf[0] = 0;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!strncmp(a, "--kp=", 5)) {
            unsigned M = 0, m = 13, p = 9;
            if (sscanf(a + 5, "%u.%u.%u", &M, &m, &p) != 3) { fprintf(stderr, "--kp 格式应为 主.次.补丁\n"); return 2; }
            kp_major = (int)M; kp_minor = (int)m; kp_patch = (int)p;
        } else if (!strcmp(a, "-k") || !strcmp(a, "--key")) {
            if (++i >= argc) { fprintf(stderr, "-k 后缺少 superkey\n"); return 2; }
            superkey = argv[i];
        } else if (!strcmp(a, "-o") || !strcmp(a, "--out")) {
            if (++i >= argc) { fprintf(stderr, "-o 后缺少路径\n"); return 2; }
            out_path = argv[i];
        } else if (!strcmp(a, "--unload")) {
            do_unload = 1;
        } else if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            usage(argv[0]); return 0;
        } else if (!superkey) {
            superkey = a;
        } else {
            if (args_len && args_len + 1 < sizeof(args_buf)) { args_buf[args_len++] = ' '; args_buf[args_len] = 0; }
            strncat(args_buf, a, sizeof(args_buf) - strlen(args_buf) - 1);
            args_len = strlen(args_buf);
        }
    }

    if (!superkey) { usage(argv[0]); return 2; }

    long hello = sc((long)(uintptr_t)superkey, ver_and_cmd(SUPERCALL_HELLO), 0, 0, 0);
    if (hello < 0) {
        printf("supercall 不可用（ret=%ld）\n"
               "  可能原因：superkey 不对，或 KernelPatch 版本不是 %d.%d.%d\n"
               "  用 --kp=<主>.<次>.<补丁> 显式指定版本再试\n",
               hello, kp_major, kp_minor, kp_patch);
        return 1;
    }
    printf("supercall OK（KernelPatch %d.%d.%d）\n", kp_major, kp_minor, kp_patch);

    if (do_unload) {
        long r = sc((long)(uintptr_t)superkey, ver_and_cmd(SUPERCALL_KPM_UNLOAD),
                    (long)(uintptr_t)mod_name, 0, 0);
        if (r < 0) { printf("卸载失败 ret=%ld\n", r); return 1; }
        printf("已卸载 %s\n", mod_name);
        return 0;
    }

    size_t klen = 0;
    if (extract_self(out_path, &klen) != 0) return 1;
    printf("已释放模块到 %s（%zu 字节）\n", out_path, klen);

    long r = sc((long)(uintptr_t)superkey, ver_and_cmd(SUPERCALL_KPM_LOAD),
                (long)(uintptr_t)out_path, (long)(uintptr_t)args_buf, 0);
    if (r < 0) {
        printf("加载失败 ret=%ld\n"
               "  常见原因：模块已加载（先 --unload）、内核版本不匹配、KP 版本不符\n", r);
        return 1;
    }
    printf("加载成功（ret=%ld）参数：\"%s\"\n", r, args_buf);
    printf("查看状态：cat /proc/Huanyu   或   echo 'handshake' > /proc/HuanyuD\n");
    return 0;
}
