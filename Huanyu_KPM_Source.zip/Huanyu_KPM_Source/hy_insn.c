/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_insn.c —— ARM64 指令解码
 *
 * 为什么需要它：断点（尤其 PTE 影子页与软件断点）必须知道
 *   1. 被覆盖的指令是不是 PC 相关（是的话搬到别处执行要修正偏移）
 *   2. 是不是分支（分支目标要跟着搬移改）
 *   3. 是不是 SIMD（涉及 FP 寄存器保存恢复）
 *   4. 是不是系统调用/特权指令（搬移后可能行为不同）
 *
 * 解码策略：
 *   65536 项前缀表（索引 = insn >> 16）做 O(1) 粗分类，
 *   再用表项里的 mask/value 做精确校验，
 *   最后对少数关键指令（B/BL/ADR/ADRP/CBZ/TBZ）做逐位精解。
 *
 * 这张表占 .rodata 约 1MB —— 用空间换零分支的查表速度，
 * 并且让解码逻辑不依赖任何内核头文件。
 */
#include <linux/printk.h>
#include <linux/string.h>
#include "hy_insn.h"
#include "hy.h"

const struct hy_insn_entry *hy_insn_lookup_prefix(u32 insn)
{
    return &hy_insn_prefix[insn >> 16];
}

void hy_insn_decode(u32 insn, struct hy_insn_info *out)
{
    const struct hy_insn_entry *e;

    if (!out) return;
    hy_memset(out, 0, sizeof(*out));

    out->insn = insn;
    e = hy_insn_lookup_prefix(insn);

    out->cls = e->cls;
    out->flags = e->flags;
    out->match_mask = e->mask;
    out->match_value = e->value;
    out->name = (e->name_idx < hy_insn_names_size)
                    ? hy_insn_names[e->name_idx] : "?";

    /* 精确校验：mask/value 匹配才算真命中 */
    if (e->mask && ((insn & e->mask) == (e->value & e->mask)))
        out->matched = true;

    /* 逐位精解，修正前缀表的粗判 */
    {
        u32 op31_26 = insn >> 26;
        u32 op31_24 = insn >> 24;

        /* B / BL */
        if (op31_26 == 0x05) {
            out->cls = HY_CLS_BRANCH;
            out->flags |= HY_F_BRANCH | HY_F_PCREL;
            out->name = (insn & 0x80000000u) ? "BL" : "B";
            out->matched = true;
        }
        /* B.cond */
        else if (op31_24 == 0x54) {
            out->cls = HY_CLS_BRANCH;
            out->flags |= HY_F_BRANCH | HY_F_PCREL;
            out->name = "B.cond";
            out->matched = true;
        }
        /* CBZ / CBNZ */
        else if ((op31_24 & 0xFE) == 0x34) {
            out->cls = HY_CLS_BRANCH;
            out->flags |= HY_F_BRANCH | HY_F_PCREL;
            out->name = (insn & 0x01000000u) ? "CBNZ" : "CBZ";
            out->matched = true;
        }
        /* TBZ / TBNZ */
        else if ((op31_24 & 0xFE) == 0x36) {
            out->cls = HY_CLS_BRANCH;
            out->flags |= HY_F_BRANCH | HY_F_PCREL;
            out->name = (insn & 0x01000000u) ? "TBNZ" : "TBZ";
            out->matched = true;
        }
        /* ADRP */
        else if (op31_24 == 0x90 || op31_24 == 0xF0) {
            out->cls = HY_CLS_DP_IMM;
            out->flags |= HY_F_PCREL;
            out->name = "ADRP";
            out->matched = true;
        }
        /* ADR */
        else if (op31_24 == 0x10 || op31_24 == 0x30 ||
                 op31_24 == 0x50 || op31_24 == 0x70) {
            out->cls = HY_CLS_DP_IMM;
            out->flags |= HY_F_PCREL;
            out->name = "ADR";
            out->matched = true;
        }
        /* SVC / HVC / SMC / BRK */
        else if (op31_24 == 0xD4) {
            out->cls = HY_CLS_SYS;
            out->flags |= HY_F_SYS;
            {
                u32 imm = (insn >> 5) & 0xFFFF;
                if (imm == 0) out->name = (insn & 3) == 0 ? "SVC" : "HVC/SMC";
                else out->name = "BRK";
            }
            out->matched = true;
        }
    }
}

bool hy_insn_is_branch(u32 insn)
{
    return (hy_insn_prefix[insn >> 16].flags & HY_F_BRANCH) != 0;
}

bool hy_insn_is_pcrel(u32 insn)
{
    return (hy_insn_prefix[insn >> 16].flags & HY_F_PCREL) != 0;
}

bool hy_insn_is_syscall(u32 insn)
{
    return (hy_insn_prefix[insn >> 16].flags & HY_F_SYS) != 0;
}

bool hy_insn_is_memory(u32 insn)
{
    return (hy_insn_prefix[insn >> 16].flags & HY_F_MEM) != 0;
}

bool hy_insn_is_simd(u32 insn)
{
    return (hy_insn_prefix[insn >> 16].flags & HY_F_SIMD) != 0;
}

bool hy_insn_can_relocate(u32 insn)
{
    u16 f = hy_insn_prefix[insn >> 16].flags;
    /* PC 相关的不能直接搬；其余可以 */
    return (f & HY_F_PCREL) == 0;
}

/*
 * 解码分支目标。
 * B/BL    : imm26 << 2
 * B.cond  : imm19 << 2
 * CBZ/CBNZ: imm19 << 2
 * TBZ/TBNZ: imm14 << 2
 */
u64 hy_insn_branch_target(u32 insn, u64 pc)
{
    u32 op31_26 = insn >> 26;
    u32 op31_24 = insn >> 24;
    s64 off = 0;

    if (op31_26 == 0x05) {
        u32 imm26 = insn & 0x03FFFFFFu;
        /* 符号扩展 26 位 */
        off = (imm26 & 0x02000000u) ? (s64)(imm26 | 0xFC000000u) : (s64)imm26;
        off <<= 2;
        return pc + (u64)off;
    }
    if (op31_24 == 0x54) {
        u32 imm19 = (insn >> 5) & 0x7FFFFu;
        off = (imm19 & 0x40000u) ? (s64)(imm19 | 0xFFF80000u) : (s64)imm19;
        off <<= 2;
        return pc + (u64)off;
    }
    if ((op31_24 & 0xFE) == 0x34) {
        u32 imm19 = (insn >> 5) & 0x7FFFFu;
        off = (imm19 & 0x40000u) ? (s64)(imm19 | 0xFFF80000u) : (s64)imm19;
        off <<= 2;
        return pc + (u64)off;
    }
    if ((op31_24 & 0xFE) == 0x36) {
        u32 imm14 = (insn >> 5) & 0x3FFFu;
        off = (imm14 & 0x2000u) ? (s64)(imm14 | 0xFFFFC000u) : (s64)imm14;
        off <<= 2;
        return pc + (u64)off;
    }
    return 0;
}

/*
 * 指令重定位：把 src_pc 处的指令搬到 dst_pc。
 *
 * PC 相关的需要改写立即数；改不了（超出立即数范围）就返回 false，
 * 调用方应改为"在原地执行 + 跳回"，而不是硬搬。
 */
bool hy_insn_relocate(u32 insn, u64 src_pc, u64 dst_pc, u32 *out)
{
    u32 op31_26 = insn >> 26;
    u32 op31_24 = insn >> 24;
    s64 delta = (s64)dst_pc - (s64)src_pc;

    if (!out) return false;

    /* 不相关：原样搬 */
    if (!hy_insn_is_pcrel(insn)) {
        *out = insn;
        return true;
    }

    /* B / BL：imm26，范围 ±128MB */
    if (op31_26 == 0x05) {
        u32 imm26 = insn & 0x03FFFFFFu;
        s64 cur = (imm26 & 0x02000000u) ? (s64)(imm26 | 0xFC000000u) : (s64)imm26;
        s64 nv = (cur << 2) - delta;
        if ((nv & 3) != 0) return false;
        nv >>= 2;
        if (nv > 0x1FFFFFF || nv < -0x2000000) return false;
        *out = (insn & 0xFC000000u) | ((u32)nv & 0x03FFFFFFu);
        return true;
    }

    /* B.cond / CBZ / CBNZ：imm19，范围 ±1MB */
    if (op31_24 == 0x54 || (op31_24 & 0xFE) == 0x34) {
        u32 imm19 = (insn >> 5) & 0x7FFFFu;
        s64 cur = (imm19 & 0x40000u) ? (s64)(imm19 | 0xFFF80000u) : (s64)imm19;
        s64 nv = (cur << 2) - delta;
        if ((nv & 3) != 0) return false;
        nv >>= 2;
        if (nv > 0x3FFFF || nv < -0x40000) return false;
        *out = (insn & 0xFF00001Fu) | (((u32)nv & 0x7FFFFu) << 5);
        return true;
    }

    /* ADRP：页偏移 ±4GB，改写 immlo/immhi */
    if (op31_24 == 0x90 || op31_24 == 0xF0) {
        u32 immlo = (insn >> 29) & 3;
        u32 immhi = (insn >> 5) & 0x7FFFF;
        s64 cur = (s64)(((immhi << 2) | immlo) & 0x1FFFFFu);
        if (cur & 0x100000u) cur |= ~0x1FFFFFu;
        s64 cur_page = cur << 12;
        s64 nv_page = cur_page - delta;
        if ((nv_page & 0xFFF) != 0) return false;
        {
            s64 nv = nv_page >> 12;
            if (nv > 0xFFFFF || nv < -0x100000) return false;
            *out = (insn & 0x9000001Fu) |
                   (((u32)nv & 3u) << 29) |
                   (((u32)(nv >> 2) & 0x7FFFFu) << 5);
            return true;
        }
    }

    /* ADR：21 位，范围 ±1MB */
    if (op31_24 == 0x10 || op31_24 == 0x30 ||
        op31_24 == 0x50 || op31_24 == 0x70) {
        u32 immlo = (insn >> 29) & 3;
        u32 immhi = (insn >> 5) & 0x7FFFF;
        s64 cur = (s64)(((immhi << 2) | immlo) & 0x1FFFFFu);
        if (cur & 0x100000u) cur |= ~0x1FFFFFu;
        s64 nv = cur - delta;
        if (nv > 0xFFFFF || nv < -0x100000) return false;
        *out = (insn & 0x9000001Fu) |
               (((u32)nv & 3u) << 29) |
               (((u32)(nv >> 2) & 0x7FFFFu) << 5);
        return true;
    }

    /* TBZ/TBNZ 等其余 PC 相关：保守拒绝 */
    return false;
}
