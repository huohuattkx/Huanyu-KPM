/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_mem.c —— 进程内存读写 / 按名取 PID / 模块 base 与 bss
 *
 * 路径选择：先用页表定位 + 线性映射（快，不走 GUP），
 * 跨页时自动分段。找不到线性映射才放弃，绝不手撕页表写数据。
 *
 * 按名取 PID：遍历 init_task 的 tasks 链表，用 KP 提供的
 * 偏移取自 hy_discover（优先 KP，校验失败才自扫描）。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <linux/mm_types.h>
#include <ksyms.h>
#include "hy.h"
#include "hy_scheme.h"

extern void *(*hy_f_find_get_task_by_vpid)(int pid);
extern void *(*hy_f_get_task_mm)(void *task);
extern void (*hy_f_mmput)(void *mm);
extern void (*hy_f_put_task_struct)(void *task);
extern void *(*hy_f_find_vma)(void *mm, unsigned long addr);
extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);

extern unsigned long hy_lookup_generic(const char *name);

static void *g_init_task;

int hy_mem_init(void)
{
    g_init_task = (void *)hy_lookup_generic("init_task");
    HY_LOG("mem: init_task=%px\n", g_init_task);
    return g_init_task ? 0 : -1;
}

/*
 * 【页表路径缓存】
 *   连续读写（最典型的场景）会反复命中同一页，
 *   每字节都重走一遍 4 级页表太浪费。
 *   这里缓存"上一次的 mm + 页基址 -> 内核 VA"，
 *   命中就直接算偏移返回，省掉整趟 walk。
 */
/*
 * 【修复 v1.19.0】缓存键的粒度标记（现并入每路的 mask 字段）。
 * 0 = 4K 页映射（偏移 = addr & 0xfff）
 * 1 = 块映射（偏移 = addr & (gran-1)，可能是 2M 或 1G）
 *
 * 原来没有这个标记：块映射时缓存键存的是 4K 对齐的 page_base，
 * 但返回地址用的是 g_cache_kva + (addr & 0x1fffff)。
 * 于是同一 2M 块内**第二次**访问会走缓存命中分支，
 * 按 (addr - page_base) 也就是 4K 内偏移计算 —— 整整差了一个 4K 页，
 * 读/写到的是错误的物理地址。块映射（透明大页、.so 的 2M 映射）下
 * 这个 bug 会让内存读写静默返回脏数据或破坏无关内存。
 *
 * 【v1.63.0 单槽 -> 8 路 + 命中校验】
 *   单槽的问题：扫描代码段的同时读数据段，两个地址交替访问会让
 *   唯一那一槽反复被顶掉，命中率跌到接近 0。
 *   改成 8 路直接映射后，交替访问各占一路，命中率回到正常水平。
 *
 *   更关键的是**命中必须校验**：
 *     旧实现只比 mm 指针 + 基址。mm 被释放后地址完全可能被
 *     分配器复用给另一个进程，此时只看指针就会命中 —— 读到别人的内存。
 *     现在必须同时满足：pid 相同、mm 相同、ptep 相同、
 *     *ptep 仍等于缓存时记录的 PTE 值、addr 落在同一映射单元。
 *   最后一条是硬保证：PTE 值没变，物理页就还是那一页。
 */

/* 容量按最大值开，实际用几路由方案选择器决定（见 hy_mem_apply_backend） */
#define HY_CACHE_WAYS 8
static int g_cache_ways = HY_CACHE_WAYS;

struct hy_map_cache {
    void          *mm;
    int            pid;     /* 最后写入，充当"本条已完整可见"的发布标记 */
    u64           *ptep;
    u64            pte;
    unsigned long  base;    /* 映射单元起始的用户 VA */
    unsigned long  mask;    /* 粒度掩码：4K-1 / 2M-1 / 1G-1 */
};

static struct hy_map_cache g_cache[HY_CACHE_WAYS];
static u32                 g_cache_mode = HY_MEM_CACHE_DEFAULT; /* 默认启用 */
static int                 g_cache_user_set;  /* 用户态是否显式设过（见下） */
static unsigned long       g_cache_hits;
static unsigned long       g_cache_miss;

/*
 * 屏障：KPM 拿不到内核的 smp_wmb/smp_rmb，arm64 上直接发 dmb ish。
 * 用途是保证"除 pid 外的字段先可见，最后才写 pid"，
 * 读侧看到 pid 匹配就意味着整条记录已经完整。
 */
static inline void hy_smp_wmb(void)
{
    __asm__ __volatile__("dmb ish" : : : "memory");
}
static inline void hy_smp_rmb(void)
{
    __asm__ __volatile__("dmb ish" : : : "memory");
}

void hy_cache_invalidate(void)
{
    int i;
    for (i = 0; i < g_cache_ways; i++) {
        g_cache[i].pid = -1;
        g_cache[i].mm = NULL;
        g_cache[i].ptep = NULL;
        g_cache[i].pte = 0;
    }
}

/* 缓存是否启用：只有显式 OFF 才关，DEFAULT/ON 都算启用 */
int hy_mem_cache_enabled(void)
{
    return (g_cache_mode == HY_MEM_CACHE_OFF) ? 0 : 1;
}

/*
 * 用户态在对接文件里显式设过之后，方案选择器就不再改这个开关：
 * 降级只调"路数"，不推翻用户明确表达的"我要缓存/我不要缓存"。
 * 否则自动降档会静默把用户选的 ON 改成 OFF，还看不出是谁改的。
 */
void hy_mem_cache_set(u32 mode)
{
    if (mode == HY_MEM_CACHE_OFF || mode == HY_MEM_CACHE_ON ||
        mode == HY_MEM_CACHE_DEFAULT)
        g_cache_mode = mode;
    else
        g_cache_mode = HY_MEM_CACHE_DEFAULT;

    g_cache_user_set = 1;

    /* 切换模式一律作废：避免旧模式的条目被新模式沿用 */
    hy_cache_invalidate();
    HY_LOG("mem: cache mode=%u (enabled=%d)\n", g_cache_mode,
           hy_mem_cache_enabled());
}

u32 hy_mem_cache_mode(void) { return g_cache_mode; }

static inline unsigned int hy_cache_index(void *mm, unsigned long addr)
{
    unsigned long h = ((unsigned long)mm >> 4) ^ (addr >> 12);
    return (unsigned int)(h & ((unsigned int)g_cache_ways - 1));
}

/*
 * 把用户态地址映射成内核可访问的 VA。
 * 只用页表定位 + 线性映射，避免依赖 GUP 的签名（6.x 上变过多次）。
 */
static void *hy_map_user_page(void *mm, unsigned long addr, int pid)
{
    u64 *ptep;
    int level;
    void *kva;
    unsigned long page_base = addr & HY_PAGE_MASK;
    unsigned int idx;
    struct hy_map_cache *c;
    u64 pte_val;

    if (!hy_mem_cache_enabled()) {
        /* 关闭缓存：每次都走完整页表，也不写缓存 */
        g_cache_miss++;
        goto slow;
    }

    idx = hy_cache_index(mm, addr);
    c = &g_cache[idx];

    /* 先读 pid：它是最后写入的字段，读到这里匹配才说明整条已完整 */
    if (c->pid == pid && c->mm == mm && c->ptep) {
        hy_smp_rmb();
        if ((addr & ~c->mask) == c->base && *c->ptep == c->pte) {
            /*
             * kva 现算，不用缓存里的副本：
             * PTE 值已确认等于缓存时的值，由它反推出来的内核 VA 必然正确。
             * 这样即便别的 CPU 正在并发更新这一路，也不会读到半新半旧的地址。
             */
            kva = hy_phys_to_virt(HY_ENTRY_PHYS(c->pte));
            if (kva) {
                g_cache_hits++;
                return (void *)((unsigned long)kva + (addr & c->mask));
            }
        }
    }
    g_cache_miss++;

slow:
    /*
     * 用 hy_find_user_pte_lvl 拿**原始**粒度：
     * 0=4K页 1=2M块 2=1G块。
     * 不能用 hy_find_user_pte 的 level —— 它把 2M 和 1G 都压成 2，
     * 无法判断块到底是多大，偏移就会算错。
     */
    ptep = hy_find_user_pte_lvl(mm, addr, &level);
    if (!ptep) return NULL;

    pte_val = *ptep;
    kva = hy_phys_to_virt(HY_ENTRY_PHYS(pte_val));
    if (!kva) return NULL;

    /*
     * 关闭缓存时直接返回。
     * 偏移必须按**实际粒度**算：块映射（2M/1G）下 kva 指向的是块的
     * 起始，偏移若按 4K 取就会整整差一个页 —— 与 v1.19.0 修过的
     * 是同一类错误，只是发生在另一条分支上。
     */
    if (!hy_mem_cache_enabled()) {
        unsigned long m = (level == 1) ? (0x200000UL - 1)
                        : (level == 2) ? (0x40000000UL - 1)
                                       : (HY_PAGE_SIZE - 1);
        return (void *)((unsigned long)kva + (addr & m));
    }

    /* 回填缓存：pid 最后写，前面用写屏障隔开 */
    idx = hy_cache_index(mm, addr);
    c = &g_cache[idx];
    c->ptep = ptep;
    c->pte = pte_val;
    c->mm = mm;
    if (level == 1 || level == 2) {
        /*
         * 块映射（2M / 1G）：缓存键必须用**块**基址，
         * 否则同块内第二次访问会按 4K 偏移算，读到错误物理地址。
         */
        unsigned long gran = (level == 1) ? 0x200000UL : 0x40000000UL;
        c->mask = gran - 1;
        c->base = addr & ~c->mask;
    } else {
        c->mask = HY_PAGE_SIZE - 1;
        c->base = page_base;
    }
    hy_smp_wmb();
    c->pid = pid;

    return (void *)((unsigned long)kva + (addr & c->mask));
}

/*
 * 【读取为什么是"无痕"的 —— 这条性质要靠维护，别无意破坏】
 *
 *   1. 不走 GUP（get_user_pages）：GUP 会给 page 加引用、可能触发缺页、
 *      把页拉回 LRU、设置 A/D 位 —— 全是可被观测的副作用。
 *      这里只做**页表只读遍历** + 线性映射访问，一个字节都不写进
 *      目标进程的页表。
 *   2. 不触碰目标 PTE：hy_find_user_pte_lvl 返回的是 PTE 指针，
 *      我们只解引用读值，从不回写。目标页的 Accessed / Dirty 位
 *      保持读取前的原样。
 *   3. 优先共享内存零拷贝：命中 shm 时连 copy_to_user 都不调用，
 *      少一次经过内核通用拷贝路径的机会。
 *
 * 以上任一条被改成都可能让"读过哪些页"变成可观测信息，改这里前先想清楚。
 */

/* 单次最多处理一页，跨页由调用方循环 */
static int hy_rw_one(void *mm, unsigned long addr, void *ubuf, u32 len, bool is_write,
                    int pid)
{
    void *kva;
    unsigned long off;
    unsigned long room;

    kva = hy_map_user_page(mm, addr, pid);
    if (!kva) return -EFAULT;

    off = addr & (HY_PAGE_SIZE - 1);
    room = HY_PAGE_SIZE - off;
    if (len > room) len = (u32)room;

    if (is_write) hy_memcpy(kva, ubuf, len);
    else hy_memcpy(ubuf, kva, len);

    return (int)len;
}

int hy_mem_rw(int pid, unsigned long addr, void *ubuf, u32 len, bool is_write)
{
    void *task, *mm;
    int done = 0;

    if (!ubuf || len == 0) return -EINVAL;
    if (!hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;

    task = hy_f_find_get_task_by_vpid(pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    while (done < (int)len) {
        unsigned long cur = addr + done;
        unsigned long seg_end = (cur & HY_PAGE_MASK) + HY_PAGE_SIZE;
        u32 seg = (u32)(seg_end - cur);
        if (seg > len - done) seg = len - done;

        int r = hy_rw_one(mm, cur, (u8 *)ubuf + done, seg, is_write, pid);
        if (r <= 0) break;
        done += r;
    }

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);

    /*
     * 【为什么这里不再无条件作废缓存】
     *   旧实现每读完一次就清空，因为只比 mm 指针不够安全
     *   （mm 释放后地址会被复用，下次光看指针就会命中错误条目）。
     *   v1.63.0 起命中必须额外满足 PTE 值未变：
     *   PTE 没变就意味着物理页还是那一页，
     *   于是"跨进程读到别人内存"这条路被彻底堵死，
     *   缓存可以安全地跨调用保留 —— 这才是它真正起作用的方式。
     *
     *   缓存关闭时（HY_MEM_CACHE_OFF）本来就不查不填，这里无需处理。
     */
    /*
     * 【v1.72.0】删掉了原有的 "if (!cache_enabled) hy_cache_invalidate()"。
     *   缓存关闭时 hy_map_user_page 走 slow 且**不回填**（见该函数的
     *   go slow 分支末尾），数组里根本不会有本轮产生的条目；
     *   而模式切换只在 hy_mem_cache_set() 发生，那里已经作废过了。
     *   所以这行是纯浪费 —— 每次读写调用都要白清 g_cache_ways 路。
     */
    /* 缓存关闭时无需作废：不查不填，切换模式的唯一入口已自行作废 */

    return done > 0 ? done : -EFAULT;
}

/*
 * CTL0 版本：payload 是 struct hy_request，buffer 是用户态指针。
 * 内核侧用一个临时内核缓冲做中转，再 copy_to_user 给调用方。
 * 这样避免直接写用户态指针带来的缺页问题。
 */

/*
 * 【共享内存零拷贝】
 * payload 里的 buffer 若指向共享区，内核可直接 memcpy，
 * 不需要 copy_to_user / copy_from_user。
 * hy_shm_translate() 命中返回内核指针，未命中返回 NULL 走原路径。
 */
extern void *hy_shm_translate(uint64_t uaddr, size_t need);

static int hy_xfer_out(uint64_t ubuf, const void *src, size_t n)
{
    void *k = hy_shm_translate(ubuf, n);
    if (k) { hy_memcpy(k, src, n); return 0; }
    if (!hy_f_copy_to_user) return -EFAULT;
    return hy_f_copy_to_user((void __user *)(unsigned long)ubuf, src, n);
}

static int hy_xfer_in(void *dst, uint64_t ubuf, size_t n)
{
    void *k = hy_shm_translate(ubuf, n);
    if (k) { hy_memcpy(dst, k, n); return 0; }
    if (!hy_f_copy_from_user) return -EFAULT;
    return hy_f_copy_from_user(dst, (void __user *)(unsigned long)ubuf, n);
}

int hy_mem_rw_ex(const struct hy_request *req, bool is_write)
{
    void *task, *mm;
    unsigned long addr;
    u32 remain;
    int done = 0;
    /*
     * 【中转缓冲 512 -> 4096】
     *   512 B 时一次 64 KB 读取要 128 次 copy_to_user 往返；
     *   4 KB 只需 16 次。栈上多占 3.5 KB，换 8 倍往返削减。
     */
    u8 tmp[4096];

    if (!req || req->size == 0 || !req->buffer) return -EINVAL;
    if (!hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;

    task = hy_f_find_get_task_by_vpid(req->pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    addr = req->addr;
    remain = (u32)req->size;

    while (remain > 0) {
        u32 chunk;
        int r;

        /*
         * 【连续 VA 快路径】
         *   如果当前页的内核 VA 与下一页恰好连续（线性映射下常见），
         *   一次就能拷完整个跨页区间，不必按页切分。
         */
        /*
         * 【修复 v1.17.0】原来的跨页快路径只验证了首页和最后一页，
         * 中间页是否连续**根本没检查**。
         * 若 want 跨越 3 页而中间那页的物理地址不连续，
         * 就会从错误的物理地址读/写 —— 读到脏数据，写则破坏无关内存。
         *
         * 现在逐页验证：每前进一页都确认内核 VA 正好 +PAGE_SIZE，
         * 一旦断开就在那里截断，绝不越界。
         */
        {
            void *kva0 = hy_map_user_page(mm, addr + done, req->pid);

            if (kva0) {
                unsigned long off = (addr + done) & (HY_PAGE_SIZE - 1);
                unsigned long avail = HY_PAGE_SIZE - off;   /* 首页剩余 */
                unsigned long want = remain;

                if (want > sizeof(tmp)) want = sizeof(tmp);
                if (want > remain)     want = remain;

                /* 逐页检查连续性，能连多少算多少 */
                while (want > avail) {
                    void *knext = hy_map_user_page(mm, addr + done + avail,
                                                       req->pid);
                    if (!knext ||
                        (unsigned long)knext != (unsigned long)kva0 + avail)
                        break;                 /* 断了，就在 avail 处收手 */
                    avail += HY_PAGE_SIZE;
                }
                if (want > avail) want = avail;

                if (want > 0) {
                    chunk = (u32)want;
                    if (is_write) {
                        if (hy_xfer_in(tmp, req->buffer + done, chunk) != 0)
                            break;
                        hy_memcpy(kva0, tmp, chunk);
                    } else {
                        hy_memcpy(tmp, kva0, chunk);
                        if (hy_xfer_out(req->buffer + done, tmp, chunk) != 0)
                            break;
                    }
                    done += chunk;
                    remain -= chunk;
                    continue;
                }
            }
        }

        chunk = remain > sizeof(tmp) ? sizeof(tmp) : remain;

        if (is_write) {
            /* 先从用户态取出要写的数据 */
            if (hy_xfer_in(tmp, req->buffer + done, chunk) != 0)
                break;
            r = hy_rw_one(mm, addr + done, tmp, chunk, true, req->pid);
        } else {
            r = hy_rw_one(mm, addr + done, tmp, chunk, false, req->pid);
            if (r > 0 && hy_xfer_out(req->buffer + done, tmp, r) != 0)
                break;
        }
        if (r <= 0) break;
        done += r;
        remain -= r;
    }

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);
    /* 同上：命中带 PTE 校验后，缓存可跨调用保留 */
    /*
     * 【v1.72.0】删掉了原有的 "if (!cache_enabled) hy_cache_invalidate()"。
     *   缓存关闭时 hy_map_user_page 走 slow 且**不回填**（见该函数的
     *   go slow 分支末尾），数组里根本不会有本轮产生的条目；
     *   而模式切换只在 hy_mem_cache_set() 发生，那里已经作废过了。
     *   所以这行是纯浪费 —— 每次读写调用都要白清 g_cache_ways 路。
     */
    /* 缓存关闭时无需作废：不查不填，切换模式的唯一入口已自行作废 */
    return done > 0 ? done : -EFAULT;
}

/*
 * 遍历 init_task->tasks 链表按 comm 找进程。
 * 用 hy_discover 提供的偏移，不硬编码。
 */
/*
 * 【修复 v1.17.0】原来直接 hy_strcmp(comm, name_buf)，
 * 而 name_buf 是**用户态指针**。内核里解引用用户指针，
 * 若该地址未映射或被换出，直接缺页崩溃；
 * 传个垃圾地址进来就是任意地址读。
 *
 * 现在先用 copy_from_user 把名字拷到内核栈，再比较。
 */
int hy_get_pid_by_name(char *name_buf)
{
    void *task;
    int found = -1;
    char want[64];
    int guard = 0;

    if (!g_init_task || !name_buf) return -EINVAL;

    if (hy_comm_offset() < 0 || hy_pid_offset() < 0 || hy_tasks_offset() < 0) {
        HY_LOG("mem: offsets not discovered, cannot scan tasks\n");
        return -ENOTSUPP;
    }

    hy_memset(want, 0, sizeof(want));

    if (hy_f_copy_from_user) {
        if (hy_f_copy_from_user(want, (void __user *)name_buf, sizeof(want) - 1) != 0)
            return -EFAULT;
    } else if (hy_uaddr_ok((unsigned long)name_buf, sizeof(want) - 1)) {
        hy_memcpy(want, name_buf, sizeof(want) - 1);
    } else {
        return -EFAULT;
    }
    want[sizeof(want) - 1] = '\0';

    /*
     * 遍历 tasks 链表。
     * 加 guard 上限：链表若在遍历中被并发修改形成环，
     * 这里不会变成死循环。
     */
    task = g_init_task;
    do {
        char *comm = (char *)((unsigned long)task + hy_comm_offset());
        s32 *pidp = (s32 *)((unsigned long)task + hy_pid_offset());

        if (hy_strncmp(comm, want, 15) == 0) {
            found = *pidp;
            break;
        }

        {
            struct list_head *tasks =
                (struct list_head *)((unsigned long)task + hy_tasks_offset());
            task = (void *)((unsigned long)tasks->next - hy_tasks_offset());
        }
    } while (task && task != g_init_task && ++guard < 65536);

    return found;
}

/*
 * vm_area_struct 前四个字段在 5.10~6.18 稳定：
 *   offset 0  : vm_start
 *   offset 8  : vm_end
 *   offset 16 : vm_next
 *   offset 24 : vm_prev（6.6 起改成 rb_subtree_last，但 vm_next 不变）
 * vm_flags 的位置变过，因此这里**不读 vm_flags**，
 * 改用"可执行段"的间接判据：PTE 的 UXN 位为 0。
 */
#define HY_VMA_START(v) (*(unsigned long *)((unsigned long)(v) + 0))
#define HY_VMA_END(v)   (*(unsigned long *)((unsigned long)(v) + 8))
#define HY_VMA_NEXT(v)  (*(unsigned long *)((unsigned long)(v) + 16))

static bool hy_vma_executable(void *mm, unsigned long addr)
{
    u64 *ptep;
    int level;

    ptep = hy_find_user_pte(mm, addr, &level);
    if (!ptep || !HY_ENTRY_VALID(*ptep)) return false;
    /* UXN(bit54)=0 表示用户态可执行 */
    return (*ptep & HY_PTE_UXN) == 0;
}

/*
 * 模块 base / bss。
 *
 * 说明（诚实标注）：KernelPatch 未导出 dentry / path 相关头文件，
 * 无法从 VMA 拿到映射文件名，因此**按名字精确匹配 so 做不到**。
 * 这里的实现是：
 *   base = 第一个"可执行"段的起始地址（对主程序/首个可执行模块准确）
 *   bss  = 最后一个可读写匿名段的起始地址（近似）
 * name 仅用于日志。若需要精确按名匹配，需用户态传地址进来。
 */
static int hy_scan_module(const struct hy_request *req, bool want_bss)
{
    void *task, *mm = NULL;
    unsigned long result = 0;
    unsigned long last_rw = 0;
    int found_exec = 0;

    if (!req || !hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;

    task = hy_f_find_get_task_by_vpid(req->pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    {
        unsigned long probe = 0x1000;
        int iter;
        for (iter = 0; iter < 4096; iter++) {
            void *vma = hy_f_find_vma(mm, probe);
            unsigned long vs, ve;
            if (!vma) break;
            vs = HY_VMA_START(vma);
            ve = HY_VMA_END(vma);
            if (ve <= vs) break;

            if (!found_exec && hy_vma_executable(mm, vs)) {
                result = vs;
                found_exec = 1;
                if (!want_bss) break;
            }
            last_rw = vs;
            probe = ve;
            if (probe == 0) break;
        }
    }

    if (want_bss) result = last_rw;

    HY_LOG("mem: scan_module name=%s pid=%d exec_found=%d result=%lx\n",
           (const char *)(unsigned long)req->buffer, req->pid, found_exec, result);

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);
    return (int)result;
}

int hy_get_module_base(const struct hy_request *req)
{
    return hy_scan_module(req, false);
}

int hy_get_module_bss(const struct hy_request *req)
{
    return hy_scan_module(req, true);
}

/*
 * 带检查的版本：先用 find_vma 确认地址落在某个 VMA 内，
 * 避免对未映射地址做页表遍历时误判。
 */
int hy_mem_rw_ex_checked(const struct hy_request *req, bool is_write)
{
    void *task, *mm = NULL;
    int ret;

    if (!req || !hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;

    task = hy_f_find_get_task_by_vpid(req->pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    /* 地址必须落在某个 VMA 内 */
    if (hy_f_find_vma) {
        void *vma = hy_f_find_vma(mm, req->addr);
        if (!vma || HY_VMA_END(vma) <= req->addr) {
            if (hy_f_mmput) hy_f_mmput(mm);
            if (hy_f_put_task_struct) hy_f_put_task_struct(task);
            return -EFAULT;
        }
    }

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);

    ret = hy_mem_rw_ex(req, is_write);
    return ret;
}

/* 供 hy_extra.c 的 STATS 使用 */
u64 hy_cache_hits_cnt(void) { return g_cache_hits; }
u64 hy_cache_miss_cnt(void) { return g_cache_miss; }

/* ==================== 方案选择支持（v1.64.0） ==================== */

/*
 * 进程内存读取后端。四档的差别只有"缓存用几路"：
 *   8 路  —— 扫代码段的同时读数据段也不会互相顶掉，命中率最高（默认）
 *   4 路  —— 折中
 *   1 路  —— 直接映射，实现最简单，但交替访问必然冲突
 *   无缓存 —— 每次重走完整页表，最慢，且不留任何跨调用状态
 *
 * 注意"无缓存"不只是慢：它是唯一一个**不保留任何跨调用状态**的档，
 * 对"读过哪些地址会留下痕迹"这件事最干净，所以作为降级兜底而不是可选优化。
 *
 * 用户在对接文件里显式设的 HY_MEM_CACHE_OFF 优先于这里的档位：
 * 那是明确表达"我就是不要缓存"，不应该被自动降级悄悄改回去。
 */
int hy_mem_apply_backend(int kind)
{
    switch (kind) {
    case HY_MR_PT_WAY8:  g_cache_ways = 8; break;
    case HY_MR_PT_WAY4:  g_cache_ways = 4; break;
    case HY_MR_PT_WAY1:  g_cache_ways = 1; break;
    case HY_MR_PT_NOCACHE: g_cache_ways = 1; break;
    default: return -1;
    }

    /* 用户显式设过就不动开关，只走路数；没设过才由档位决定 */
    if (!g_cache_user_set) {
        hy_cache_invalidate();
        g_cache_mode = (kind == HY_MR_PT_NOCACHE) ? HY_MEM_CACHE_OFF
                                                  : HY_MEM_CACHE_DEFAULT;
    } else {
        hy_cache_invalidate();
    }
    return 0;
}

int hy_mem_backend_kind(void)
{
    if (!hy_mem_cache_enabled()) return HY_MR_PT_NOCACHE;
    switch (g_cache_ways) {
    case 8: return HY_MR_PT_WAY8;
    case 4: return HY_MR_PT_WAY4;
    case 1: return HY_MR_PT_WAY1;
    default: return HY_MR_PT_WAY8;
    }
}
