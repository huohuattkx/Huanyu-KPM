/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_discover.c —— 内核布局的自发现与校验
 *
 * 【设计立场】"不过度依赖"，而不是"完全不依赖"。
 *
 *   wxshadow 的做法：完全不信任任何外部偏移，用 1369 行代码自己扫
 *     task_struct.tasks / mm_struct.pgd / vm_area_struct.vm_mm。
 *     好处是与 KernelPatch 解耦；代价是代码量大、扫描本身有崩溃风险
 *     （它正是这么炸的）。
 *
 *   本模块的做法：三级递进
 *     1) 优先用 KP 导出的偏移（快，零风险）
 *     2) 但**自己校验**：用已知值验证偏移是否真的对得上
 *     3) 校验不过，才启动自扫描兜底
 *
 *   这样既省掉大部分扫描代码，也不会因为 KP 给的值在某一版上不对
 *   就直接踩野指针。
 *
 * 【校验方法】全部用"已知值比对"，不去猜：
 *   comm_offset : 该偏移处必须是可打印 ASCII（comm 必然是进程名）
 *   pid_offset  : 该偏移处必须是小正整数，且与 /proc 语义一致
 *   tasks_offset: 从 init_task 走一圈必须能回到自己
 *   pgd_offset  : 遍历当前进程页表，必须能定位到已知虚拟地址
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <linux/mm_types.h>
#include <asm/current.h>
#include <ksyms.h>
#include <kallsyms.h>
#include "hy.h"

/* 自发现的偏移（-1 表示未发现） */
static int g_comm_offset  = -1;
static int g_pid_offset   = -1;
static int g_tasks_offset = -1;
static int g_pgd_offset   = -1;

/* 每个偏移的来源：0=KP提供 1=自扫描 2=校验失败降级 */
static int g_src_comm;
static int g_src_pid;
static int g_src_tasks;
static int g_src_pgd;

#define HY_SCAN_RANGE 4096      /* 在 task_struct 前 4KB 内扫描 */
#define HY_SCAN_ALIGN 8

extern unsigned long hy_lookup_generic(const char *name);
extern void *(*hy_f_get_task_mm)(void *task);
extern void (*hy_f_mmput)(void *mm);

/* ============================ 当前 task ============================ */

void *hy_current_task(void)
{
    void *task = NULL;
    unsigned long sp_el0;

    asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));

    if (sp_el0_is_current) {
        task = (void *)sp_el0;
    } else if (sp_el0_is_thread_info) {
        if (task_in_thread_info_offset >= 0)
            task = *(void **)(sp_el0 + task_in_thread_info_offset);
    } else {
        if (stack_in_task_offset >= 0)
            task = (void *)(sp_el0 - stack_in_task_offset);
    }
    return task;
}

/* ============================ 校验 ============================ */

static bool hy_looks_like_comm(const char *p)
{
    int i;
    if (!p) return false;
    /* comm 是可打印字符串，首字符不能是 NUL，长度 1..15 */
    if (p[0] == 0) return false;
    for (i = 0; i < 16; i++) {
        unsigned char c = (unsigned char)p[i];
        if (c == 0) return i > 0;
        if (c < 0x20 || c > 0x7e) return false;
    }
    return true;
}

static bool hy_looks_like_pid(s32 v)
{
    return v > 0 && v < 0x80000;   /* pid 是小正整数 */
}

/* ============================ 自扫描 ============================ */

/*
 * 扫描 comm 偏移：找一段像进程名的可打印字符串。
 * 只接受 8 字节对齐的位置（comm 在结构体里通常对齐）。
 */
static int hy_scan_comm(void *task)
{
    int i;
    for (i = 0; i < HY_SCAN_RANGE; i += HY_SCAN_ALIGN) {
        if (hy_looks_like_comm((char *)((unsigned long)task + i)))
            return i;
    }
    return -1;
}

/*
 * 扫描 pid 偏移：与已知 comm 偏移相邻，找一个小正整数。
 * 用当前 task 的真实 pid 做锚点：先拿到 comm 里的名字，
 * 再找与该名字语义一致的 pid —— 但我们没有 /proc，
 * 所以退一步：找位于 [1, 65536] 的 8 字节对齐整数，
 * 且与 thread_pid 的常见邻近布局一致（pid 通常紧跟 comm 之后）。
 */
static int hy_scan_pid(void *task, int comm_off)
{
    int i;
    int start = (comm_off >= 0) ? comm_off : 0;
    for (i = start; i < HY_SCAN_RANGE; i += 4) {
        s32 v = *(s32 *)((unsigned long)task + i);
        if (hy_looks_like_pid(v))
            return i;
    }
    return -1;
}

/*
 * 扫描 tasks 偏移：找一个 list_head，其 next->prev 指回自己，
 * 且顺着 next 能走回起点（双向链表特征）。
 */
static int hy_scan_tasks(void *task)
{
    int i;
    for (i = 0; i < HY_SCAN_RANGE; i += HY_SCAN_ALIGN) {
        struct list_head *lh = (struct list_head *)((unsigned long)task + i);
        unsigned long nx, pv;
        unsigned long nx_prev;

        /* 先粗筛：地址必须像内核地址 */
        nx = (unsigned long)lh->next;
        pv = (unsigned long)lh->prev;
        if ((nx & 0xffffff0000000000UL) != 0xffffff0000000000UL) continue;
        if ((pv & 0xffffff0000000000UL) != 0xffffff0000000000UL) continue;

        /* 双向链表特征：next->prev == 自己 */
        nx_prev = *(unsigned long *)(nx + 8);
        if (nx_prev == (unsigned long)lh)
            return i;
    }
    return -1;
}

/*
 * 扫描 pgd 偏移：mm_struct 里能成功完成"已知地址 -> PTE"遍历的那个。
 * 用当前进程的一个已知内核/用户地址做验证。
 */
static int hy_scan_pgd(void *mm, unsigned long test_addr)
{
    int i;
    (void)test_addr;
    for (i = 0; i < 512; i += HY_SCAN_ALIGN) {
        u64 *pgdp = *(u64 **)((unsigned long)mm + i);
        unsigned long a;
        if ((unsigned long)pgdp < 0xffffff0000000000UL) continue;

        /*
         * 试着用这个 pgd 走一遍页表，看能否拿到合法的下一级地址。
         * 简化判据：pgd 项里能取出一个内核地址的项存在。
         */
        for (a = 0; a < 512; a++) {
            u64 e = pgdp[a];
            if ((e & 1UL) && ((e & 0x0000fffffffff000UL) != 0))
                return i;
        }
    }
    return -1;
}

/* ============================ 对外接口 ============================ */

int hy_comm_offset(void)  { return g_comm_offset; }
int hy_pid_offset(void)   { return g_pid_offset; }
int hy_tasks_offset(void) { return g_tasks_offset; }
int hy_pgd_offset(void)   { return g_pgd_offset; }

/*
 * 初始化：先用 KP 的偏移，逐个校验，失败则自扫描。
 */
int hy_discover_init(void)
{
    void *cur = hy_current_task();
    void *init_task_p = (void *)hy_lookup_generic("init_task");

    HY_LOG("discover: begin cur=%px init_task=%px\n", cur, init_task_p);

    if (!cur) {
        HY_LOG("discover: cannot get current task\n");
        return -1;
    }

    /*
     * 【优先级：KP 绝对优先】
     *   只要 KP 给出了有效值（>= 0），就用 KP 的 —— 即使自扫描得出不同结果。
     *   自扫描仅在 KP 完全没有提供（< 0）时才启用。
     *
     *   校验结果只用于告警，不再触发切换：
     *     - KP 值校验通过  -> src=0，正常
     *     - KP 值校验失败  -> src=3，仍用 KP 值，但打 WARN
     *     - KP 没提供      -> 自扫描，src=1；扫描失败 src=2
     *
     *   这样保证"用谁的"这件事完全透明，不虚标自研能力。
     */
    {
        int kp_val, mine;
        bool ok;

        /* ---- comm ---- */
        kp_val = task_struct_offset.comm_offset;
        if (kp_val >= 0) {
            g_comm_offset = kp_val;
            ok = hy_looks_like_comm((char *)((unsigned long)cur + kp_val));
            g_src_comm = ok ? 0 : 3;
            if (!ok)
                HY_LOG("discover: WARN comm from KP(%d) failed sanity check\n", kp_val);
        } else {
            mine = hy_scan_comm(cur);
            g_comm_offset = mine;
            g_src_comm = (mine >= 0) ? 1 : 2;
        }

        /* ---- pid ---- */
        kp_val = task_struct_offset.pid_offset;
        if (kp_val >= 0) {
            g_pid_offset = kp_val;
            ok = hy_looks_like_pid(*(s32 *)((unsigned long)cur + kp_val));
            g_src_pid = ok ? 0 : 3;
            if (!ok)
                HY_LOG("discover: WARN pid from KP(%d) failed sanity check\n", kp_val);
        } else {
            mine = hy_scan_pid(cur, g_comm_offset);
            g_pid_offset = mine;
            g_src_pid = (mine >= 0) ? 1 : 2;
        }

        /* ---- tasks ---- */
        kp_val = task_struct_offset.tasks_offset;
        if (kp_val >= 0) {
            g_tasks_offset = kp_val;
            g_src_tasks = 0;
        } else {
            mine = hy_scan_tasks(init_task_p ? init_task_p : cur);
            g_tasks_offset = mine;
            g_src_tasks = (mine >= 0) ? 1 : 2;
        }

        /* ---- pgd ---- */
        kp_val = mm_struct_offset.pgd_offset;
        if (kp_val >= 0) {
            g_pgd_offset = kp_val;
            g_src_pgd = 0;
        } else {
            void *mm = hy_f_get_task_mm ? hy_f_get_task_mm(cur) : NULL;
            mine = mm ? hy_scan_pgd(mm, (unsigned long)cur) : -1;
            g_pgd_offset = mine;
            g_src_pgd = (mine >= 0) ? 1 : 2;
            if (mm && hy_f_mmput) hy_f_mmput(mm);
        }
    }

    HY_LOG("discover: comm=%d(src%d) pid=%d(src%d) tasks=%d(src%d) pgd=%d(src%d)\n",
           g_comm_offset, g_src_comm,
           g_pid_offset,  g_src_pid,
           g_tasks_offset, g_src_tasks,
           g_pgd_offset,  g_src_pgd);
    HY_LOG("discover: src 0=KP 1=self-scanned 2=unavailable 3=KP-but-warn\n");

    return 0;
}

void hy_discover_report(void)
{
    HY_LOG("DISCOVER comm=%d/%d pid=%d/%d tasks=%d/%d pgd=%d/%d\n",
           g_comm_offset, g_src_comm,
           g_pid_offset,  g_src_pid,
           g_tasks_offset, g_src_tasks,
           g_pgd_offset,  g_src_pgd);
}
