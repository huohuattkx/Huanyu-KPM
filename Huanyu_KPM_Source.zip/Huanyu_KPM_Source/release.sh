#!/bin/bash
# =============================================================================
# 欢愉 kpm 发布脚本 —— 先校验，后打包
#
# 背景：v1.73.1 出现过「单独发的 kpm 是 1.73.1，zip 里还是 1.73.0」。
#       原因是打包发生在重编之前。本脚本把校验前置，任何一项不过就不出包。
#
# 用法： bash release.sh
# =============================================================================
set -u
cd "$(dirname "$0")"
DIR="$(pwd)"
ZIPSRC="/data/workspace/huanyu_all"

fail() { echo "!! 发布中止：$*"; exit 1; }
ok()   { echo "  [OK] $*"; }

echo "==================== 欢愉发布校验 ===================="

# ---------------------------------------------------------------- 1. 版本号
VER=$(grep -aoE 'HY_VERSION_STRING +"[^"]*"' hy.h | head -1 | sed 's/.*"\(.*\)".*/\1/')
[ -n "$VER" ] || fail "hy.h 里读不出 HY_VERSION_STRING"
echo "  内核源码版本 : $VER"

# 三个版本常量必须与字符串自洽（防止只改字符串忘改常量）
M=$(grep -aoE '#define HY_VER_MAJOR +[0-9]+' hy.h | grep -oE '[0-9]+$')
N=$(grep -aoE '#define HY_VER_MINOR +[0-9]+' hy.h | grep -oE '[0-9]+$')
P=$(grep -aoE '#define HY_VER_PATCH +[0-9]+' hy.h | grep -oE '[0-9]+$')
[ "$M.$N.$P" = "$VER" ] || fail "hy.h 版本常量($M.$N.$P) 与字符串($VER) 不一致"
ok "内核版本常量自洽 $M.$N.$P"

# ---------------------------------------------------------------- 2. kpm 文件
# 目录里只允许存在一个 kpm，且它的版本必须等于 hy.h 版本
KPMS=( *.kpm )
[ -e "${KPMS[0]}" ] || fail "目录里没有 kpm，先编译"
[ "${#KPMS[@]}" -eq 1 ] || fail "目录里有 ${#KPMS[@]} 个 kpm：${KPMS[*]} —— 先清理旧版"
KPM="${KPMS[0]}"

# kpm 文件名里的版本
FV=$(echo "$KPM" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
[ "$FV" = "$VER" ] || fail "kpm 文件名版本($FV) != hy.h 版本($VER)"
ok "kpm 文件名版本 $FV"

# kpm 二进制内必须含该版本串
strings -a "$KPM" | grep -qF "$VER" || fail "kpm 二进制内找不到版本串 $VER"
ok "kpm 二进制内含版本串 $VER"

# 不允许其它形如 x.yz.w 的版本串出现在文件名层（rootfs 里只留一个 kpm）
echo "$KPM" | grep -q "huanyu_v$VER.kpm" || fail "kpm 文件名应为 huanyu_v$VER.kpm"
ok "kpm 文件名规范 huanyu_v$VER.kpm"

# ---------------------------------------------------------------- 3. 用户态
for H in userland/huanyu.hpp userland/huanyu_wanbai.hpp; do
    [ -f "$H" ] || fail "缺少 $H"
    UV=$(grep -oaE '#define HY_VERSION_STRING +"[^"]*"' "$H" | head -1 | sed 's/.*"\(.*\)".*/\1/')
    [ "$UV" = "$VER" ] || fail "$H 版本($UV) != 内核版本($VER) —— 握手会被拒"
    ok "$H 版本 $UV"
done

# ---------------------------------------------------------------- 4. 五层密钥
K1=$(grep -aoE '#define HY_KEY_L[1-5] "[^"]*"' hy.h | sed 's/.*"\(.*\)".*/\1/' | md5sum)
K2=$(grep -aoE '#define HY_KEY_L[1-5] "[^"]*"' userland/huanyu.hpp | sed 's/.*"\(.*\)".*/\1/' | md5sum)
K3=$(grep -aoE '#define HY_KEY_L[1-5] "[^"]*"' userland/huanyu_wanbai.hpp | sed 's/.*"\(.*\)".*/\1/' | md5sum)
[ "$K1" = "$K2" ] && [ "$K2" = "$K3" ] || fail "三处五层密钥不一致"
ok "三处五层密钥逐字节一致 ($K1)"

# 每层长度：L1=6 固定 Huanyu，L2/3/4=64，L5=256
for i in 1 2 3 4 5; do
    L=$(grep -aoE "#define HY_KEY_L$i \"[^\"]*\"" hy.h | sed 's/.*"\(.*\)".*/\1/' | wc -c)
    L=$((L-1))
    case $i in
        1) W=6;;  4) W=64;; 5) W=256;; *) W=64;;
    esac
    [ "$L" = "$W" ] || fail "HY_KEY_L$i 长度 $L != 期望 $W"
done
ok "五层密钥长度 6/64/64/64/256"

# ---------------------------------------------------------------- 5. ELF 结构
readelf -h "$KPM" 2>/dev/null | grep -q 'REL (Relocatable file)' || fail "$KPM 不是 ET_REL，APatch 不接受"
ok "ELF 类型 ET_REL"
for S in .kpm.info .kpm.init .kpm.exit .kpm.ctl0; do
    readelf -S "$KPM" | grep -q "$S" || fail "缺少段 $S"
done
ok "KPM 四段齐全"

# ---------------------------------------------------------------- 6. 清理与打包
rm -f huanyu_all.zip ./*.o
find . -name '*.o' -delete 2>/dev/null
echo "  清理旧 zip 与 .o"

cd /data/workspace
rm -f huanyu_all.zip
zip -r -q huanyu_all.zip huanyu_all -x 'huanyu_all/huanyu_all.zip' -x 'huanyu_all/*.o'
[ -f huanyu_all.zip ] || fail "打包失败"

# ---------------------------------------------------------------- 7. 打包后复检
echo "-------------------- 打包后复检 --------------------"
TMP=$(mktemp -d)
unzip -q -o huanyu_all.zip -d "$TMP"
ZIPKPMS=( "$TMP"/huanyu_all/*.kpm )
[ "${#ZIPKPMS[@]}" -eq 1 ] || fail "zip 内有 ${#ZIPKPMS[@]} 个 kpm"
ZK=$(basename "${ZIPKPMS[0]}")
[ "$ZK" = "huanyu_v$VER.kpm" ] || fail "zip 内 kpm 是 $ZK，不是 huanyu_v$VER.kpm"
ok "zip 内唯一 kpm = $ZK"

# zip 内的 kpm 必须与目录里的逐字节相同
cmp -s "$TMP/huanyu_all/$ZK" "$ZIPSRC/$ZK" || fail "zip 内 kpm 与目录里的不一致"
ok "zip 内 kpm 与单独发出的 kpm 逐字节相同"

# zip 内 hpp 版本
for H in huanyu.hpp huanyu_wanbai.hpp; do
    ZV=$(grep -oaE '#define HY_VERSION_STRING +"[^"]*"' "$TMP/huanyu_all/userland/$H" | head -1 | sed 's/.*"\(.*\)".*/\1/')
    [ "$ZV" = "$VER" ] || fail "zip 内 $H 版本 $ZV != $VER"
    ok "zip 内 $H 版本 $ZV"
done

rm -rf "$TMP"
echo "===================================================="
echo "  发布完成  版本 $VER"
echo "  kpm : $ZIPSRC/huanyu_v$VER.kpm  ($(stat -c%s "$ZIPSRC/huanyu_v$VER.kpm") 字节, md5 $(md5sum "$ZIPSRC/huanyu_v$VER.kpm" | cut -d' ' -f1))"
echo "  zip : /data/workspace/huanyu_all.zip ($(stat -c%s /data/workspace/huanyu_all.zip) 字节)"
echo "===================================================="
