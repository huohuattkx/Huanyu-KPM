/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_trampoline.c —— 指令搬移与蹦床
 *
 * 【要解决的问题】
 *   软件断点把目标指令替换成 BRK 后，命中时必须能执行"原本那条指令"。
 *   但直接改回原指令再单步，断点就失效了（别的线程会漏掉命中）。
 *
 *   标准做法是蹦床：把原指令搬到一个可执行的临时区域，
 *   在蹦床里执行它，再跳回断点之后。
 *
 * 【难点在 PC 相关指令】
 *   B / BL / ADR / ADRP / CBZ / TBZ 这类指令的语义是相对 PC 的，
 *   搬到别处后必须修正立即数 —— 这正是 hy_insn.c 那张 65536 项
 *   前缀表存在的意义：先判定类别，再决定能否搬、怎么改。
 *
 *   改不了的（立即数范围不够）就拒绝搬移，调用方改用
 *   "临时摘除断点 + 单步 + 重新装上"。
 */
#include <linux/printk.h>
#include <linux/string.h>
#include "hy.h"
#include "hy_insn.h"

#define HY_TRAMP_SLOTS   32
#define HY_TRAMP_INSNS   16       /* 每个蹦床最多 16 条指令 */
#define HY_TRAMP_SIZE    (HY_TRAMP_INSNS * 4)

/* 蹦床代码区（静态分配，不依赖 kmalloc） */
static u32  g_tramp_code[HY_TRAMP_SLOTS][HY_TRAMP_INSNS];
static bool g_tramp_init_done;
static bool g_tramp_used[HY_TRAMP_SLOTS];
static bool  g_tramp_simd[HY_TRAMP_SLOTS];   /* v1.21.0 */
static u64  g_tramp_owner[HY_TRAMP_SLOTS];   /* 归属的断点 handle */

/*
 * 蹦床布局（每个 slot）：
 *   [0]       被搬移的指令（已重定位）
 *   [1..n-3]  可能的补充指令
 *   [n-2]     BRK #7  —— 执行完通知我们，用于单步回收
 *   [n-1]     备用
 *
 * 注意：这里没有真正"跳回"的指令，因为执行完原指令后
 * 由 BRK 处理器根据 regs 里的 pc 决定下一步走向。
 */

int hy_tramp_init(void)
{
    hy_memset(g_tramp_used, 0, sizeof(g_tramp_used));
    hy_memset(g_tramp_owner, 0, sizeof(g_tramp_owner));
    g_tramp_init_done = true;
    HY_LOG("tramp: %d slots x %d insns, %zu bytes\n",
           HY_TRAMP_SLOTS, HY_TRAMP_INSNS, sizeof(g_tramp_code));
    return 0;
}

static int hy_tramp_alloc(u64 handle)
{
    int i;
    for (i = 0; i < HY_TRAMP_SLOTS; i++) {
        if (!g_tramp_used[i]) {
            g_tramp_used[i] = true;
            g_tramp_owner[i] = handle;
            return i;
        }
    }
    return -1;
}

static void hy_tramp_free(int slot)
{
    if (slot < 0 || slot >= HY_TRAMP_SLOTS) return;
    g_tramp_used[slot] = false;
    g_tramp_owner[slot] = 0;
}

/*
 * 构建一个蹦床。
 *   insn    : 被断点覆盖的原始指令
 *   hit_pc  : 该指令原本所在的地址
 *   tramp_pc: 蹦床区地址
 * 成功返回 slot，失败返回负数。
 */
int hy_tramp_build(u64 handle, u32 insn, u64 hit_pc, u64 tramp_pc)
{
    int slot;
    u32 relocated;
    struct hy_insn_info info;

    slot = hy_tramp_alloc(handle);
    if (slot < 0) {
        HY_LOG("tramp: no free slot\n");
        return -1;
    }

    hy_insn_decode(insn, &info);

    /* PC 相关：尝试重定位，改不了就放弃 */
    if (!hy_insn_relocate(insn, hit_pc, tramp_pc, &relocated)) {
        HY_LOG("tramp: cannot relocate %08x (%s) pc=%llx -> %llx\n",
               insn, info.name ? info.name : "?",
               (unsigned long long)hit_pc, (unsigned long long)tramp_pc);
        hy_tramp_free(slot);
        return -2;
    }

    hy_memset(g_tramp_code[slot], 0, HY_TRAMP_SIZE);
    g_tramp_code[slot][0] = relocated;
    /* 末尾放 BRK #7：执行完原指令后回到我们手里 */
    g_tramp_code[slot][1] = HY_BRK_INSN;

    /*
     * 【v1.21.0】hy_tramp_needs_simd() 此前零调用点。
     * SIMD 指令在内核态执行需要先保存/恢复 FP 寄存器上下文，
     * 这里把判定结果记下来并告警，调用方据此决定
     * 是走蹦床还是退回"摘断点 + 单步"方案。
     */
    g_tramp_simd[slot] = hy_tramp_needs_simd(insn);
    if (g_tramp_simd[slot])
        HY_LOG("tramp: WARN slot=%d is SIMD, needs FP context save\n", slot);

    HY_LOG("tramp: slot=%d insn=%08x -> %08x (%s) cls=%d\n",
           slot, insn, relocated, info.name ? info.name : "?", info.cls);

    return slot;
}

u32 *hy_tramp_addr(int slot)
{
    if (slot < 0 || slot >= HY_TRAMP_SLOTS) return NULL;
    if (!g_tramp_used[slot]) return NULL;
    return g_tramp_code[slot];
}

void hy_tramp_release(int slot)
{
    if (slot < 0 || slot >= HY_TRAMP_SLOTS) return;
    hy_memset(g_tramp_code[slot], 0, HY_TRAMP_SIZE);
    hy_tramp_free(slot);
}

void hy_tramp_release_by_handle(u64 handle)
{
    int i;
    for (i = 0; i < HY_TRAMP_SLOTS; i++) {
        if (g_tramp_used[i] && g_tramp_owner[i] == handle)
            hy_tramp_release(i);
    }
}

void hy_tramp_exit(void)
{
    hy_memset(g_tramp_used, 0, sizeof(g_tramp_used));
    hy_memset(g_tramp_owner, 0, sizeof(g_tramp_owner));
    hy_memset(g_tramp_code, 0, sizeof(g_tramp_code));
    HY_LOG("tramp: exit\n");
}

/*
 * 判断一条指令是否需要 SIMD 上下文（搬移执行时得保存 FP 寄存器）。
 * SIMD 指令在内核态执行需要谨慎，这里是给调用方的提示。
 */
bool hy_tramp_needs_simd(u32 insn)
{
    return hy_insn_is_simd(insn);
}

/* /proc/huanyu 诊断：蹦床区是否就绪 */
int hy_tramp_ready(void)
{
    return g_tramp_init_done ? 1 : 0;
}
