/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_shm.c —— 共享内存通道（内核侧）
 *
 * 建立：用户态 mmap 一块内存 -> 通过命令通道注册 -> 内核 GUP + vmap
 * 运行：内核线程轮询 state，见到 REQ 就执行 hy_ctl_switch()
 * 传输：payload 内指针若落在共享区，直接 memcpy（零拷贝）
 *
 * 【为什么所有符号都走 kallsyms】
 *   KP 只导出 173 个符号，kthread / GUP / vmap 一个都不在里面。
 *   但 kallsyms_lookup_name 在导出表里，且内核开了 CONFIG_KALLSYMS_ALL，
 *   所以能查任意符号 —— 这是本项目一直在用的机制。
 *
 * 【绝不用的东西】
 *   - kmalloc / kmalloc_array：6.12 上实测查不到（详见 README）
 *     pages 数组用静态数组，最大支持 256 KB 共享区
 *   - 任何签名不确定的符号做"看起来像"的回退
 *
 * 【卸载安全】
 *   顺序：置 hy_ready=false -> kthread_stop（等线程退出）-> vunmap -> 放页
 *   kthread_stop 必须在 vunmap 之前，否则线程可能访问已释放的映射。
 */
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <asm/current.h>
#include <kpmodule.h>
#include <symbol.h>
#include "hy.h"
#include "hy_shm.h"

static void hy_shm_sleep_ms(int ms);
#ifndef EILSEQ
#define EILSEQ 84
#endif
#ifndef ENOTSUPP
#define ENOTSUPP 95
#endif
#ifndef ENOENT
#define ENOENT 2
#endif

#ifndef ENOSYS
#define ENOSYS 38
#endif
#ifndef ESRCH
#define ESRCH 3
#endif
#ifndef EFAULT
#define EFAULT 14
#endif
#ifndef ENOMEM
#define ENOMEM 12
#endif
#ifndef EINVAL
#define EINVAL 22
#endif

/* ==========================================================================
 * 运行时符号
 * ========================================================================== */

/* struct page 对模块不透明，只传指针 */
struct hy_page;

typedef long (*gup_remote_t)(void *mm, unsigned long start,
                             int nr_pages, unsigned int gfp_flags,
                             struct hy_page **pages, int *locked);
typedef void *(*vmap_t)(struct hy_page **pages, unsigned int count,
                        unsigned long flags, unsigned long prot);
typedef void (*vunmap_t)(void *addr);
typedef void (*put_page_t)(struct hy_page *page);

typedef void *(*kthread_create_t)(int (*fn)(void *), void *data,
                                  int node, const char *namefmt);
typedef int  (*wake_up_process_t)(void *task);
typedef int  (*kthread_stop_t)(void *task);
typedef int  (*kthread_should_stop_t)(void);
typedef void (*msleep_t)(unsigned int msecs);
typedef void *(*get_task_mm_t)(void *task);
typedef void (*mmput_t)(void *mm);

static gup_remote_t          hy_f_gup;
static vmap_t                hy_f_vmap;
static vunmap_t              hy_f_vunmap;
static put_page_t            hy_f_put_page;
static kthread_create_t      hy_f_kthread_create;
static wake_up_process_t     hy_f_wake_up;
static kthread_stop_t        hy_f_kthread_stop;
static kthread_should_stop_t hy_f_should_stop;
static msleep_t              hy_f_msleep;
static get_task_mm_t         hy_f_get_task_mm;
static mmput_t               hy_f_mmput;

/* 静态页数组：256 KB / 4K = 64 页。不依赖 kmalloc。 */
#define HY_SHM_MAX_PAGES 64
static struct hy_page *g_pages[HY_SHM_MAX_PAGES];

static void        *g_shm_kva;              /* 内核虚拟地址 */
static uint64_t     g_shm_uva;              /* 用户态虚拟地址 */
static uint64_t     g_shm_size;
static int          g_shm_pages;
static void        *g_shm_task;             /* 拥有共享区的进程 task */
static void        *g_shm_mm;

static void        *g_thread;               /* 命令轮询线程 */
static int          g_thread_running;

/* ---- ls 同款：连接线程 ---- */
static int          g_magic_scan_on;
static int          g_shm_enabled = 1;
static int          g_name_explicit;   /* 通道总开关，默认开但需线程可用 */   /* 全量 magic 探测开关，默认关 */

static void        *g_conn_thread;
static int          g_conn_running;
static void        *g_target_task;          /* 已连接的目标进程 task */
static char         g_target_name[HY_SHM_TARGET_NAME_MAX];

/* 进程遍历：沿用 hy_discover 已算好的偏移（KP 优先 + 自校验） */
int  hy_comm_offset(void);
int  hy_pid_offset(void);
int  hy_tasks_offset(void);
unsigned long hy_lookup_generic(const char *name);

static uint64_t     g_requests;
static uint64_t     g_errors;

/*
 * VM_MAP / PAGE_KERNEL 的值。
 *
 * 【风险点，需实测确认】
 *   模块是外部编译的，拿不到内核头里的 PAGE_KERNEL 宏，只能硬编码。
 *   arm64 6.x 的定义：
 *       PTE_TYPE_PAGE = 3 << 0
 *       PTE_AF        = 1 << 10
 *       PTE_SHARED    = 3 << 8
 *       PTE_DIRTY     = 1 << 51
 *       PROT_NORMAL   = PTE_TYPE_PAGE | PTE_AF | PTE_SHARED | PTE_DIRTY
 *       PAGE_KERNEL   = PROT_NORMAL
 *   算出来 = 0x8000000000703
 *
 *   若你的内核布局不同，vmap 映射出的页属性会不对，访问时触发异常。
 *   届时 dmesg 里会出现 "shm: mapped" 之后立刻崩溃 —— 改这个常量即可。
 *
 *   共享内存是【可选】通道，默认不启用（用户态主动调 shm_init 才建），
 *   所以即便这里有问题，也不影响主功能。
 */
#define HY_VM_MAP        0x00000004UL
#define HY_PAGE_KERNEL   0x8000000000703UL

/* ==========================================================================
 * 地址翻译：共享区内的用户指针 -> 内核指针
 * ========================================================================== */

/*
 * 供 hy_mem.c 调用。命中返回内核可直接访问的指针，否则返回 NULL，
 * 调用方退回 copy_to_user / copy_from_user。
 */
void *hy_shm_translate(uint64_t uaddr, size_t need)
{
    uint64_t off;

    if (!g_shm_kva || !g_shm_uva || !g_shm_size) return NULL;
    if (uaddr < g_shm_uva) return NULL;
    if (need > g_shm_size) return NULL;

    off = uaddr - g_shm_uva;
    if (off + need > g_shm_size) return NULL;

    return (void *)((unsigned long)g_shm_kva + (unsigned long)off);
}

/* ==========================================================================
 * 映射 / 解除
 * ========================================================================== */

static void hy_shm_unmap(void)
{
    int i;

    if (g_shm_kva && hy_f_vunmap) {
        hy_f_vunmap(g_shm_kva);
        HY_LOG("shm: vunmap done\n");
    }
    g_shm_kva = NULL;

    if (g_shm_pages > 0 && hy_f_put_page) {
        for (i = 0; i < g_shm_pages; i++) {
            if (g_pages[i]) { hy_f_put_page(g_pages[i]); g_pages[i] = NULL; }
        }
    }
    g_shm_pages = 0;

    if (g_shm_mm && hy_f_mmput) { hy_f_mmput(g_shm_mm); }
    g_shm_mm = NULL;
    g_shm_task = NULL;
    g_shm_uva = 0;
    g_shm_size = 0;
}

/*
 * 把当前进程（current）的 [va, va+size) 映射到内核。
 */
static int hy_shm_map(uint64_t va, uint64_t size)
{
    int nr;
    long got;
    void *mm;

    if (!va || !size) return -EINVAL;
    if (size > (uint64_t)HY_SHM_MAX_PAGES * 4096ULL) return -EINVAL;

    nr = (int)((size + 4095ULL) / 4096ULL);
    if (nr <= 0 || nr > HY_SHM_MAX_PAGES) return -EINVAL;

    if (!hy_f_gup || !hy_f_vmap) return -ENOSYS;
    if (!hy_f_get_task_mm || !hy_f_mmput) return -ENOSYS;

    /* 已有映射先释放 */
    if (g_shm_kva) hy_shm_unmap();

    /* 注册者就是当前进程，直接用 current */
    mm = hy_f_get_task_mm((void *)current);
    if (!mm) return -ESRCH;

    hy_memset(g_pages, 0, sizeof(g_pages));

    /*
     * 6.5+ 签名：
     *   get_user_pages_remote(mm, start, nr_pages, gfp, pages, locked)
     * 6.1 是 7 参数（多一个 vmas）。这里只支持 6.5+，
     * 因为 5.10~6.4 的分支需要另一个符号名，容易误配（历史教训）。
     */
    got = hy_f_gup(mm, (unsigned long)va, nr,
                   0x1 /* FOLL_WRITE */, g_pages, NULL);

    if (got != nr) {
        int i;
        for (i = 0; i < (int)(got > 0 ? got : 0); i++) {
            if (g_pages[i] && hy_f_put_page) hy_f_put_page(g_pages[i]);
            g_pages[i] = NULL;
        }
        hy_f_mmput(mm);
        HY_LOG("shm: GUP got %ld of %d\n", got, nr);
        return -EFAULT;
    }

    g_shm_kva = hy_f_vmap(g_pages, (unsigned int)nr, HY_VM_MAP, HY_PAGE_KERNEL);
    if (!g_shm_kva) {
        int i;
        for (i = 0; i < nr; i++) {
            if (g_pages[i] && hy_f_put_page) hy_f_put_page(g_pages[i]);
            g_pages[i] = NULL;
        }
        hy_f_mmput(mm);
        HY_LOG("shm: vmap failed\n");
        return -ENOMEM;
    }

    g_shm_uva   = va;
    g_shm_size  = size;
    g_shm_pages = nr;
    g_shm_mm    = mm;
    g_shm_task  = (void *)current;   /* 仅记录，不做解引用 */

    /* 握手：告诉用户态内核已就绪 */
    {
        struct hy_shm_obj *o = (struct hy_shm_obj *)g_shm_kva;
        if (o->magic == HY_SHM_MAGIC) {
            o->flags |= HY_SHM_F_READY;
            o->shm_va = va;
            o->shm_size = size;
        }
    }

    HY_LOG("shm: mapped uva=0x%llx size=%llu pages=%d kva=%px\n",
           (unsigned long long)va, (unsigned long long)size, nr, g_shm_kva);
    return 0;
}

/* ==========================================================================
 * 轮询线程
 * ========================================================================== */

static int hy_shm_thread(void *data)
{
    /*
     * 空闲退避计数：连续没有请求时逐步拉长睡眠。
     * 【v1.80.0 CPU 优化】原来空闲一律 msleep(1)，等于每秒唤醒 1000 次
     * 什么也不做 —— 模块从开机一直加载，这是实打实的常驻唤醒源与耗电。
     * 现在空闲时逐级退避到 20ms（50 次/秒），一旦有请求立刻回到 1ms。
     */
    unsigned int idle = 0;

    (void)data;

    /*
     * 【防死循环空转】msleep 缺失时绝不能进下面的忙等：
     * 那会占满一个核、把机身烤热。直接退出并置位故障标志。
     */
    if (!hy_f_msleep) {
        HY_LOG("shm: FATAL msleep missing, thread NOT started (avoid busy-spin)\n");
        g_thread_running = 0;
        return 0;
    }

    while (1) {
        struct hy_shm_obj *o;

        /*
         * 【只从 should_stop 退出】
         * 见下面连接线程的说明：线程绝不能自己 return，
         * 否则 kthread_stop 会拿到已释放的 task_struct -> UAF -> panic。
         */
        if (hy_f_should_stop && hy_f_should_stop()) break;

        if (!hy_ready) {
            hy_shm_sleep_ms(100);
            continue;
        }

        if (!g_shm_kva) {
            hy_shm_sleep_ms(200);
            continue;
        }

        o = (struct hy_shm_obj *)g_shm_kva;

        if (o->state == HY_SHM_REQ) {
            uint32_t seq = o->seq;

            /* 有活干：退避清零，下一轮回到 1ms 快响应 */
            idle = 0;

            o->state = HY_SHM_BUSY;

            /*
             * 命令直接复用现有分发器 —— 与 prctl / supercall 完全同一套。
             * 这是刻意的设计：三条通道共享一个实现，行为必然一致。
             */
            hy_usage_set_channel(3);   /* shm */
            o->ret = hy_ctl_switch(o->nr, o->payload);

            if (o->ret < 0) g_errors++;
            g_requests++;
            o->requests = g_requests;
            o->errors = g_errors;

            o->ack = seq;
            o->state = HY_SHM_IDLE;
            continue;
        }

        /*
         * 空闲：自适应退避 1 -> 2 -> 5 -> 10 -> 20ms 封顶。
         * 有请求时已把 idle 清零，所以响应延迟仍是 1ms；
         * 长期无人使用则降到 50 次/秒，常驻唤醒源大幅减少。
         */
        {
            unsigned int slp;
            if (idle < 2)       slp = 1;
            else if (idle < 5)  slp = 2;
            else if (idle < 10) slp = 5;
            else if (idle < 20) slp = 10;
            else                slp = 20;
            if (idle < 0xFFFFFFFFu) idle++;
            hy_f_msleep(slp);
        }
    }

    g_thread_running = 0;
    HY_LOG("shm: thread exit\n");
    return 0;
}


/* ==========================================================================
 * ls 同款连接线程：扫描进程名 -> GUP 固定地址 -> vmap
 * ========================================================================== */

/*
 * 【关键设计：靠 magic 探测，不看进程名】
 *
 * 之前照抄 lsdriver 的"进程名扫描"是错的。
 * ls 能用进程名，是因为它有一个独立的用户态守护进程叫 "LS"。
 * 而欢愉的用户态是【注入进游戏进程】的，游戏进程名永远不可能是
 * "Huanyu" —— 所以按名字扫永远扫不到，永远连不上。
 *
 * 正确做法：遍历所有进程，对每个有 mm 的尝试 GUP 固定地址，
 * 然后检查共享区头部的 magic。谁 mmap 了这块内存且 magic 对上，
 * 谁就是连接方。
 *
 * 这样用户态只需要：
 *     mmap(0x2025827000, ...)  +  写 magic
 * 不需要改名、不需要发注册命令、不依赖任何已有通道。
 */

/*
 * task 指针合法性检查。
 * arm64 内核地址：高位置位（0xffffff8... 之类）。
 * 用户地址或 NULL 一律拒绝，绝不拿去调 get_task_mm。
 */

/*
 * 响应式睡眠。
 * msleep(2000) 一次睡死会让 kthread_stop 卡住最多 2 秒，
 * 卸载路径上这个延迟很危险（APatch 可能超时 / 触发别的清理）。
 * 拆成 50ms 小段，每段问一次 should_stop，卸载即可秒回。
 */
static void hy_shm_sleep_ms(int ms)
{
    int left = ms;
    if (!hy_f_msleep) return;
    while (left > 0) {
        int step = left > 50 ? 50 : left;
        if (hy_f_should_stop && hy_f_should_stop()) return;
        hy_f_msleep((unsigned int)step);
        left -= step;
    }
}

static int hy_task_plausible(void *task)
{
    unsigned long v = (unsigned long)task;
    if (!v) return 0;
#if defined(__aarch64__)
    /* 内核地址必须高位全 1 */
    if ((v >> 48) != 0xffff) return 0;
#else
    if (v < 0x80000000UL) return 0;
#endif
    /* 8/16 字节对齐 */
    if (v & 7) return 0;
    return 1;
}

static int hy_shm_magic_scan(void);

/*
 * 【与 ls 完全同款：进程名优先 + magic 校验】
 *
 * lsdriver 的做法是 hy_strcmp(task->comm, "LS")。
 * 欢愉现在也是：先按名字找 "Huanyu"，找到后再校验 magic。
 *
 * 之所以能做到，是因为欢愉现在【也提供一个独立的守护进程】
 * （见 huanyu_daemon.cpp，NDK 编译后放手机上跑）。
 * 这个 daemon 会 prctl(PR_SET_NAME) 把自己改名成 "Huanyu"，
 * 然后 mmap 固定地址 —— 和 ls 的 "LS" 进程一模一样。
 *
 * 仍然保留 magic 校验，是为了防止误连到同名但无关的进程。
 * 若名字没匹配上（比如用户没启动 daemon），则退化为全量 magic 探测。
 */
static int hy_shm_try_connect(void *task, void *mm, int nr)
{
    long got;
    void *kva;
    struct hy_shm_obj *o;
    int i;

    hy_memset(g_pages, 0, sizeof(g_pages));

    got = hy_f_gup(mm, (unsigned long)HY_SHM_FIXED_VA, nr,
                   0x1 /* FOLL_WRITE */, g_pages, NULL);
    if (got != nr) {
        for (i = 0; i < (int)(got > 0 ? got : 0); i++) {
            if (g_pages[i] && hy_f_put_page) hy_f_put_page(g_pages[i]);
            g_pages[i] = NULL;
        }
        return -EFAULT;
    }

    kva = hy_f_vmap(g_pages, (unsigned int)nr, HY_VM_MAP, HY_PAGE_KERNEL);
    if (!kva) {
        for (i = 0; i < nr; i++) {
            if (g_pages[i] && hy_f_put_page) hy_f_put_page(g_pages[i]);
            g_pages[i] = NULL;
        }
        return -ENOMEM;
    }

    o = (struct hy_shm_obj *)kva;
    if (o->magic != HY_SHM_MAGIC || o->version != HY_SHM_VERSION) {
        /* 不是我们的人 */
        if (hy_f_vunmap) hy_f_vunmap(kva);
        for (i = 0; i < nr; i++) {
            if (g_pages[i] && hy_f_put_page) hy_f_put_page(g_pages[i]);
            g_pages[i] = NULL;
        }
        return -EILSEQ;
    }

    g_shm_kva   = kva;
    g_shm_uva   = HY_SHM_FIXED_VA;
    g_shm_size  = HY_SHM_SIZE;
    g_shm_pages = nr;
    g_shm_mm    = mm;
    g_shm_task  = task;
    g_target_task = task;

    o->flags   |= HY_SHM_F_READY;
    o->shm_va   = HY_SHM_FIXED_VA;
    o->shm_size = HY_SHM_SIZE;
    o->state    = HY_SHM_IDLE;

    HY_LOG("shm: CONNECTED task=%px va=0x%llx pages=%d kva=%px\n",
           task, (unsigned long long)HY_SHM_FIXED_VA, nr, kva);
    return 0;
}

/*
 * 第一轮：按进程名找（ls 同款）。
 * 第二轮：全量 magic 探测（名字没命中时的兜底）。
 */
static int hy_shm_probe_all(void)
{
    void *init_task;
    void *task;
    int tasks_off, comm_off;
    int visited;
    int nr;
    int name_hit = 0;
    unsigned long nx;

    init_task = (void *)hy_lookup_generic("init_task");
    if (!init_task) return -ENOENT;

    tasks_off = hy_tasks_offset();
    if (tasks_off < 0) return -ENOTSUPP;
    comm_off = hy_comm_offset();

    nr = (int)((HY_SHM_SIZE + 4095ULL) / 4096ULL);

    task = init_task;
    visited = 0;

    do {
        void *mm;
        int match = 0;

        /* 先看名字（ls 同款） */
        if (comm_off >= 0 && g_target_name[0]) {
            char *comm = (char *)((unsigned long)task + (unsigned long)comm_off);
            int i;
            match = 1;
            for (i = 0; g_target_name[i]; i++) {
                if (comm[i] != g_target_name[i]) { match = 0; break; }
            }
            if (match && comm[i] != '\0' && comm[i] != '\n') match = 0;
        }

        /*
         * 【v1.34.0 发热优化】不命中就【绝对不要】碰 get_task_mm。
         *
         * get_task_mm 是原子引用计数 + RCU 操作，对几百个进程每轮都调一次
         * 纯属浪费 —— 不命中时拿到的 mm 下一行就 mmput 掉了，什么也没做。
         * 这是整个模块最主要的无谓发热源（每 2 秒一轮 × 全部进程）。
         *
         * comm 比较只是读几字节内存，非常便宜；只有命中才值得拿 mm。
         */
        if (!match) goto next;

        mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
        if (!mm) goto next;

        name_hit = 1;
        /* 名字命中：直接尝试连接，成功就保留 mm */
        if (hy_shm_try_connect(task, mm, nr) == 0) return 0;
        hy_f_mmput(mm);

next:
        /*
         * 【链表推进 —— 这里是之前炸内核的真凶】
         *
         * tasks_offset 是 struct list_head tasks 在 task_struct 里的偏移。
         * 所以 *(task + tasks_off) 读到的是 tasks.next，
         * 它指向【下一个 task 的 tasks 字段】，而不是 task_struct 基址！
         *
         * 内核的 for_each_process / list_next_entry 会做 container_of，
         * 等价于： next_task = next_list_head - offsetof(task_struct, tasks)
         *
         * 之前少了这个减法，第二次循环就拿着 list_head 地址当 task_struct 用，
         * get_task_mm(野指针) 直接 panic —— 表现就是"加载即炸、卸载也炸"。
         */
        nx = *(unsigned long *)((unsigned long)task + (unsigned long)tasks_off);
        if (!nx) break;
        task = (void *)(nx - (unsigned long)tasks_off);
        if (!hy_task_plausible(task)) break;
        visited++;
    } while (task && task != init_task && visited < 2048);

    if (!name_hit && g_magic_scan_on) {
        HY_LOG("shm: no process named \"%s\", falling back to magic scan\n",
               g_target_name);
        return hy_shm_magic_scan();
    }

    /*
     * 【v1.34.0 发热优化】日志降频。
     *
     * 原来每轮（2 秒）都打一条，实测用户的 dmesg 里几十条连排。
     * 这不仅刷屏（把真正有用的 init 日志挤出环形缓冲），
     * 每次 HY_LOG 本身也是实打实的内核日志开销。
     * 该信息只需告知一次，之后静默。
     */
    if (!name_hit && !g_magic_scan_on) {
        static int once;
        if (!once) {
            once = 1;
            HY_LOG("shm: no \"%s\" process; magic scan disabled "
                   "(add shmscan=1) [this message prints once]\n",
                   g_target_name);
        }
    }

    return -ESRCH;
}

/* 全量 magic 探测（名字没命中时的兜底） */
static int hy_shm_magic_scan(void)
{
    void *init_task;
    void *task;
    int tasks_off;
    int visited;
    int nr;
    int tried = 0;
    unsigned long nx;

    init_task = (void *)hy_lookup_generic("init_task");
    if (!init_task) return -ENOENT;

    tasks_off = hy_tasks_offset();
    if (tasks_off < 0) return -ENOTSUPP;

    nr = (int)((HY_SHM_SIZE + 4095ULL) / 4096ULL);
    task = init_task;
    visited = 0;

    do {
        void *mm;

        mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
        if (!mm) goto next;

        tried++;
        if (hy_shm_try_connect(task, mm, nr) == 0) {
            HY_LOG("shm: found via magic scan (tried %d procs)\n", tried);
            return 0;
        }
        hy_f_mmput(mm);

next:
        /*
         * 【链表推进 —— 这里是之前炸内核的真凶】
         *
         * tasks_offset 是 struct list_head tasks 在 task_struct 里的偏移。
         * 所以 *(task + tasks_off) 读到的是 tasks.next，
         * 它指向【下一个 task 的 tasks 字段】，而不是 task_struct 基址！
         *
         * 内核的 for_each_process / list_next_entry 会做 container_of，
         * 等价于： next_task = next_list_head - offsetof(task_struct, tasks)
         *
         * 之前少了这个减法，第二次循环就拿着 list_head 地址当 task_struct 用，
         * get_task_mm(野指针) 直接 panic —— 表现就是"加载即炸、卸载也炸"。
         */
        nx = *(unsigned long *)((unsigned long)task + (unsigned long)tasks_off);
        if (!nx) break;
        task = (void *)(nx - (unsigned long)tasks_off);
        if (!hy_task_plausible(task)) break;
        visited++;
    } while (task && task != init_task && visited < 2048);

    return -ESRCH;
}

static int hy_shm_conn_thread(void *data)
{
    int scans = 0;
    (void)data;

    /* 先让 init 跑完，避免在模块初始化关键期做 GUP */
    hy_shm_sleep_ms(2000);

    while (1) {
        /*
         * 【卸载炸内核的根因就在这里】
         *
         * 原写法有两个 break 出口：should_stop 和 !hy_ready。
         * 后者会在 exit 设 hy_ready=false 后让线程【自己退出】。
         * 线程一退出就 do_exit、task_struct 引用归零被释放，
         * 而 exit 随后又拿 g_thread 这个【已释放】的指针调 kthread_stop
         * -> use-after-free -> panic。
         *
         * 正确做法：线程【只能】通过 kthread_should_stop() 退出，
         * 由 kthread_stop() 负责唤醒并等待、再归还引用。
         * 这是内核 kthread 的标准契约。
         */
        if (hy_f_should_stop && hy_f_should_stop()) break;

        /* hy_ready 只作为"回调/扫描守卫生效"的信号，不再用于退出 */
        if (!hy_ready) {
            hy_shm_sleep_ms(100);
            continue;
        }

        if (!g_shm_kva) {
            /*
             * 扫描是侵入操作（会对目标进程 GUP），
             * 只在没连上时做，且受总体次数限制，避免长期空转。
             */
            /*
             * 节能期间不做进程扫描 —— 这是整个模块最耗 CPU 的部分
             * （要对每个候选进程做 GUP + vmap）。
             * 有命令进来时 hy_pm_touch() 会立即清除节能标记。
             */
            if (hy_pm_is_saving()) {
                hy_shm_sleep_ms(HY_SHM_SCAN_MS);
                continue;
            }
            if (g_shm_enabled && scans < 900) { scans++; hy_shm_probe_all(); }
        } else {
            /*
             * 已连接：周期性确认目标进程还在。
             * 目标没了（被杀）就断开，等待新的。
             */
            /*
             * 已连接：周期性复核共享区仍然有效。
             * 目标进程退出 / 解除映射后，magic 会被破坏或页消失。
             * 这里只做轻量检查：magic 不对就断开，等下一轮重连。
             */
            if (g_shm_kva) {
                struct hy_shm_obj *o = (struct hy_shm_obj *)g_shm_kva;
                if (o->magic != HY_SHM_MAGIC) {
                    HY_LOG("shm: shared area invalidated, disconnect\n");
                    hy_shm_unmap();
                    g_target_task = NULL;
                }
            }
        }

        hy_shm_sleep_ms(HY_SHM_SCAN_MS);
    }

    g_conn_running = 0;
    HY_LOG("shm: conn thread exit\n");
    return 0;
}

void hy_shm_set_magic_scan(int on)
{
    g_magic_scan_on = on ? 1 : 0;
    HY_LOG("shm: magic scan = %d\n", g_magic_scan_on);
}

int hy_shm_set_name(const char *name)
{
    g_name_explicit = 1;
    int i;
    if (!name || !name[0]) return -EINVAL;
    for (i = 0; i < HY_SHM_TARGET_NAME_MAX - 1 && name[i]; i++)
        g_target_name[i] = name[i];
    g_target_name[i] = '\0';
    HY_LOG("shm: target name = \"%s\"\n", g_target_name);
    return 0;
}

/* ==========================================================================
 * 对外接口
 * ========================================================================== */

int hy_shm_init(void)
{
    hy_f_gup         = (gup_remote_t)hy_lookup_generic("get_user_pages_remote");
    hy_f_vmap        = (vmap_t)hy_lookup_generic("vmap");
    hy_f_vunmap      = (vunmap_t)hy_lookup_generic("vunmap");
    hy_f_put_page    = (put_page_t)hy_lookup_generic("put_page");
    hy_f_get_task_mm = (get_task_mm_t)hy_lookup_generic("get_task_mm");
    hy_f_mmput       = (mmput_t)hy_lookup_generic("mmput");
    hy_f_kthread_create = (kthread_create_t)hy_lookup_generic("kthread_create_on_node");
    hy_f_wake_up     = (wake_up_process_t)hy_lookup_generic("wake_up_process");
    hy_f_kthread_stop= (kthread_stop_t)hy_lookup_generic("kthread_stop");
    hy_f_should_stop = (kthread_should_stop_t)hy_lookup_generic("kthread_should_stop");
    hy_f_msleep      = (msleep_t)hy_lookup_generic("msleep");

    if (!hy_f_gup)         HY_LOG("shm: WARN get_user_pages_remote not found\n");
    if (!hy_f_vmap)        HY_LOG("shm: WARN vmap not found\n");
    if (!hy_f_msleep)      HY_LOG("shm: WARN msleep not found\n");

    /*
     * 【线程创建的前置条件必须是全部符号齐备】
     *
     * 缺任何一个都不能起线程：
     *   - 缺 kthread_stop  -> 卸载时无法安全回收 -> UAF
     *   - 缺 should_stop   -> 线程永不退出       -> 模块卸不掉
     *   - 缺 msleep        -> 线程空转烧 CPU
     * 宁可功能降级，也不能起一个收不回来的线程。
     */
    if (!hy_f_kthread_create || !hy_f_wake_up ||
        !hy_f_kthread_stop   || !hy_f_should_stop || !hy_f_msleep) {
        HY_LOG("shm: kthread symbols incomplete, channel DISABLED"
               " (create=%d wake=%d stop=%d should=%d sleep=%d)\n",
               !!hy_f_kthread_create, !!hy_f_wake_up, !!hy_f_kthread_stop,
               !!hy_f_should_stop, !!hy_f_msleep);
        g_shm_enabled = 0;
        return 0;
    }

    /* 线程先起，共享区可以后注册 */
    if (hy_f_kthread_create && hy_f_wake_up) {
        /*
         * 传 4 个参数给 variadic 的 kthread_create_on_node 是安全的：
         * namefmt 不含 '%'，内核内部的 vsnprintf 不会去读可变参数。
         */
        g_thread = hy_f_kthread_create(hy_shm_thread, NULL, -1, "hy_shm");
        if (g_thread) {
            hy_f_wake_up(g_thread);
            g_thread_running = 1;
            HY_LOG("shm: thread started\n");
        } else {
            HY_LOG("shm: thread create failed\n");
        }
    } else {
        HY_LOG("shm: no kthread symbols, channel disabled\n");
        return 0;
    }

    /* 默认目标进程名 */
    if (!g_target_name[0])
        hy_shm_set_name(HY_SHM_DEFAULT_NAME);

    /*
     * 【默认不做全量扫描】
     * 没有 daemon（进程名匹配不上）时，若还对每个进程 GUP，
     * 既白耗 CPU 又是侵入操作。所以默认只在【显式指定 shmname=】
     * 或【显式打开 shmscan=1】时才让连接线程干活。
     * 命令线程（处理已建立的共享区）不受影响。
     */
    if (!g_magic_scan_on && !g_name_explicit) {
        HY_LOG("shm: no shmname= given and shmscan=0;"
               " conn thread idle (shared area still usable if mapped)\n");
        g_shm_enabled = 0;
    }

    /* 启动连接线程（ls 同款：内核主动扫描） */
    g_conn_thread = hy_f_kthread_create(hy_shm_conn_thread, NULL, -1, "hy_shmc");
    if (g_conn_thread) {
        hy_f_wake_up(g_conn_thread);
        g_conn_running = 1;
        HY_LOG("shm: conn thread started (name=\"%s\" va=0x%llx)\n",
               g_target_name, (unsigned long long)HY_SHM_FIXED_VA);
    } else {
        HY_LOG("shm: conn thread create failed\n");
    }

    return 0;
}

void hy_shm_exit(void)
{
    /*
     * 【顺序至关重要】
     *   1) 停线程：kthread_stop 会等线程函数返回
     *   2) 再解映射：此时绝不会再有线程访问
     * 反过来做，线程可能在 vunmap 之后踩到已释放地址 —— 必崩。
     */
    if (g_thread && hy_f_kthread_stop) {
        hy_f_kthread_stop(g_thread);
        HY_LOG("shm: thread stopped\n");
    }
    g_thread = NULL;
    g_thread_running = 0;

    if (g_conn_thread && hy_f_kthread_stop) {
        hy_f_kthread_stop(g_conn_thread);
        HY_LOG("shm: conn thread stopped\n");
    }
    g_conn_thread = NULL;
    g_conn_running = 0;
    g_target_task = NULL;

    hy_shm_unmap();
    HY_LOG("shm: exit done\n");
}

/* 注册命令入口 */
int hy_shm_register(struct hy_shm_register *reg)
{
    int rc;

    if (!reg) return -EINVAL;

    (void)reg->pid;   /* 目前只支持注册者自己的共享区 */
    rc = hy_shm_map(reg->va, reg->size);
    if (rc != 0) return rc;

    return 0;
}

int hy_shm_status(struct hy_shm_status *st)
{
    if (!st) return -EINVAL;
    hy_memset(st, 0, sizeof(*st));
    st->ready    = g_shm_kva ? 1u : 0u;
    st->nr_pages = (uint32_t)(g_shm_pages > 0 ? g_shm_pages : 0);
    st->kva      = (uint64_t)(unsigned long)g_shm_kva;
    st->requests = g_requests;
    st->errors   = g_errors;
    return (int)sizeof(*st);
}

int hy_shm_ready(void) { return g_shm_kva ? 1 : 0; }
