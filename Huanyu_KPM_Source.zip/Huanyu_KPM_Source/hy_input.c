/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_input.c —— 虚拟触摸与虚拟陀螺仪
 *
 * ============================ 关键背景 ============================
 * KernelPatch 不导出 input 子系统头文件，struct input_dev 对我们是
 * **不透明指针**。因此只能：
 *   1) 一切通过 kallsyms 解析的内核函数完成（绝不猜结构体偏移）
 *   2) 需要"读结构体字段"的能力一律放弃，改用等价的函数调用替代
 *
 * ============================ 历史 bug ============================
 * 上一版触摸**完全不可用**，两个致命原因：
 *
 *   (1) 没有 absinfo → 坐标被内核清零
 *       Linux input.c 的 input_handle_abs_event():
 *           if (!dev->absinfo) { dev_warn_once(...); *pval = 0; return; }
 *       也就是：只要 dev->absinfo 为 NULL，任何 ABS_* 事件的 value
 *       都会被强制改写为 0。上一版只用 input_set_capability() 设了
 *       能力位，从没设过 absinfo，所以 X/Y 永远上报 0。
 *       → 必须用 input_set_abs_params() 设置每个轴的范围。
 *
 *   (2) 自建设备 ≠ 触摸屏
 *       Android EventHub 靠 INPUT_PROP_DIRECT 判定 TOUCH_MT（多点触摸）。
 *       没有该属性、只有 BTN_TOUCH+ABS_X+ABS_Y 的设备会被当成
 *       INPUT_DEVICE_CLASS_TOUCH（单点），ABS_MT_* 事件不被解析。
 *       而我们无法写 propbit（无结构体布局）。
 *       → 正解是 lsdriver 的做法：**劫持真实触摸屏设备**，
 *         事件从真设备出去，Android 早已绑定它，多点完全正常。
 *
 * ============================ 本版方案 ============================
 *   路径 A（首选，ls 原版思路）：劫持真实触摸屏 input_dev
 *       发现方式：hook input_event()，在 before 里看参数：
 *           type==EV_ABS && code∈{ABS_MT_POSITION_X/Y}
 *       命中即记录该 dev，然后**立刻 unhook**（零后续开销）。
 *       这是纯参数判断，完全不碰结构体。
 *
 *   路径 B（降级）：自建设备
 *       必须 input_set_abs_params() 设置全部轴的 min/max，
 *       并调用 input_mt_init_slots() 建立多点槽位。
 *       在单点模式（mode 0，同时上报 ABS_X/ABS_Y）下可用。
 *
 * 注入顺序：A 优先，A 不可用才用 B。
 *
 * ============================ 虚拟陀螺仪 ============================
 * 上一版用 input_event 发 ABS_X/ABS_Y 冒充陀螺仪 —— 完全错误的路径，
 * Android 传感器数据根本不走 input 子系统。
 *
 * lsdriver 原版做法（本版照搬）：
 *   SensorService 通过 BitTube（socketpair）用 send() 把 sensors_event_t
 *   推给 App。arm64 上 send() 走 sendto 路径。
 *   → hook sendto，在 before 里就地改写用户缓冲区的 ASensorEvent：
 *       offset 0  : version (int)
 *       offset 8  : type    (int)  4 = GYROSCOPE, 16 = GYRO_UNCALIBRATED
 *       offset 24 : data[0..] (float[3])  rad/s
 *   改写后**不拦截**系统调用，让真实 sendto 把改好的数据发出去。
 *   这样最安全：即使我们判断失误，原语义也不受影响。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <hook.h>
#include <ksyms.h>
#include <syscall.h>
#include "hy.h"
#include "hy_scheme.h"

/* ---------------- input 子系统函数（全部 kallsyms 解析） ---------------- */
static void *(*hy_f_input_allocate_device)(void);
static void  (*hy_f_input_free_device)(void *dev);
static int   (*hy_f_input_register_device)(void *dev);
static void  (*hy_f_input_unregister_device)(void *dev);
static void  (*hy_f_input_event)(void *dev, unsigned int type,
                                 unsigned int code, int value);
/*
 * v1.59.0：input_handle_event —— 与 input_event 同签名（dev,type,code,value）。
 * KernelPatch 自己在 patch/android/userd.c 里拦截音量键用的就是它，
 * 而不是 input_event —— 说明在 Android GKI 内核上它才是可靠的观察点。
 * 原因：GKI 开 LTO，input_event 作为小函数常被内联进各家触摸驱动
 * （驱动与 input.c 同一 LTO 单元），于是 hook 挂在 input_event 符号上
 * 看到的是"没被内联的那部分调用者"，往往根本不是触摸屏。
 */
static void  (*hy_f_input_handle_event)(void *dev, unsigned int type,
                                        unsigned int code, int value);
static void  (*hy_f_input_set_capability)(void *dev, unsigned int type,
                                          unsigned int code);
static void  (*hy_f_input_set_abs_params)(void *dev, unsigned int axis,
                                          int min, int max, int fuzz, int flat);
static int   (*hy_f_input_mt_init_slots)(void *dev, unsigned int num_slots,
                                         unsigned int flags);

/* ---------------- 事件常量 ---------------- */
#define HY_EV_SYN   0x00
#define HY_EV_KEY   0x01
#define HY_EV_ABS   0x03

#define HY_SYN_REPORT 0
/* linux/input-event-codes.h: SYN_MT_REPORT = 2 —— Protocol A 的手指分隔符 */
#define HY_SYN_MT_REPORT 2

#define HY_ABS_X 0x00
#define HY_ABS_Y 0x01
#define HY_ABS_Z 0x02

#define HY_ABS_MT_SLOT         0x2f
#define HY_ABS_MT_POSITION_X   0x35
#define HY_ABS_MT_POSITION_Y   0x36
#define HY_ABS_MT_TOUCH_MAJOR  0x30
#define HY_ABS_MT_WIDTH_MAJOR  0x32
#define HY_ABS_MT_PRESSURE     0x3a
#define HY_ABS_MT_TRACKING_ID  0x39

#define HY_BTN_TOUCH        0x14a
#define HY_BTN_TOOL_FINGER  0x145
#define HY_BTN_TOOL_DOUBLE  0x14d

#define HY_INPUT_MT_DIRECT       0x0002
#define HY_INPUT_MT_DROP_UNUSED  0x0004

/* ---------------- 触摸状态 ---------------- */
#define HY_MAX_SLOTS 16

static void *g_own_dev;                 /* 路径 B：自建设备 */
static bool g_own_dev_failed;           /* v1.30.0 创建失败只试一次 */
extern int hy_opt_noowndev;
extern int hy_opt_probe;
extern int hy_opt_grab;   /* v1.46.0 槽位抢占，默认关 */
static int  g_no_own_dev;               /* v1.30.1 noowndev=1 */
static int g_probe_enabled = 1;   /* v1.32.0 默认开：只读 hook，安全 */            /* v1.30.0 默认 0，probe=1 才开 */
static void *g_real_dev;                /* 路径 A：劫持的真实触摸屏 */
static bool  g_real_found;
static bool  g_touch_ready;
static int   g_touch_mode;
static bool  g_slot_down[HY_MAX_SLOTS];
static int   g_slot_track[HY_MAX_SLOTS];

/* 屏幕范围与槽位布局（可由用户态配置） */
static int g_max_x = 1080;
static int g_max_y = 2400;
/* v1.79.0：用户用 trange 显式设过范围后置位，自学习不再覆盖手设值 */
static int g_range_manual;
static int g_slot_base = 5;             /* 虚拟手指起始槽位，避开真实手指 */
static char g_want_name[HY_TOUCH_NAME_MAX];  /* v1.22.0：期望锁定的触摸屏名字 */

/*
 * v1.22.0：三个本地极小实现，刻意不新增外部符号依赖。
 * KP 导出的 kf_* 字符串函数在部分版本上是 static 的（不可解析），
 * 而这里只需要在 before 回调里做一次名字比对 —— 自己写最稳。
 */
static int hy_lkaddr_ok(const void *p)
{
    unsigned long a = (unsigned long)p;
    /* arm64 内核地址：高 16 位全 1 */
    return a >= 0xffff000000000000UL;
}
static size_t hy_lstrlen(const char *s)
{
    size_t i = 0;
    if (!s) return 0;
    while (s[i]) i++;
    return i;
}
static void hy_lstrscpy(char *dst, const char *src, size_t n)
{
    size_t i = 0;
    unsigned long inpage;
    if (!dst || !src || n == 0) { if (dst && n) dst[0] = '\0'; return; }

    /*
     * 【v1.73.3】绝不跨页读取。
     * 字符串末尾那一页有可能没映射（虽然线性映射区通常连续，但在
     * 极高频回调里没有第二次机会）—— 宁可截断也不冒跨页 oops 的风险。
     * 设备名长度远小于一页，正常情况不会触发截断。
     */
    inpage = 0x1000UL - ((unsigned long)src & 0xfffUL);
    if (n > inpage) n = (size_t)inpage;
    if (n == 0) { dst[0] = '\0'; return; }

    while (i + 1 < n && src[i]) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}
/* 子串匹配：在 haystack 里找 needle */
static int hy_lstrstr(const char *haystack, const char *needle)
{
    size_t i, j;
    if (!haystack || !needle) return 0;
    if (!needle[0]) return 1;
    for (i = 0; haystack[i]; i++) {
        for (j = 0; needle[j] && haystack[i + j] == needle[j]; j++)
            ;
        if (!needle[j]) return 1;
    }
    return 0;
}

/* input_event 探测 hook */
static bool g_probe_hooked;
/* 自己注入中，避免递归处理。
 * 【v1.73.0】改成计数而非布尔：嵌套/重叠的注入路径不会把守卫提前清掉
 * （参考实现同样用 atomic_t 计数，注释里明确写了这个理由）。 */
static int  g_injecting;

/* ---- v1.46.0 抢夺增强（默认关，需 touch=1 且 grab=1） ---- */
static bool g_grab_slots;               /* 抢占槽位：丢弃物理驱动对我们保留槽位的事件 */
static int  g_drv_slot = -1;            /* 物理驱动当前选中的槽位 */
/* v1.64.0：触摸观察点档位，由 hy_scheme 选择 */
static int g_observer_kind = HY_IN_HANDLE_EVENT;
/* 自学习总闸。低档位关掉：少一份运行期状态，也少一个出错来源 */
static int g_learn_enabled = 1;

static int  g_max_drv_slot = -1;        /* 物理驱动用过的最大槽位（推算有效虚拟起点） */
static int  g_seen_max_x;               /* 观测到的最大 X（自学习分辨率） */
static int  g_seen_max_y;               /* 观测到的最大 Y */
static u64  g_slots_dropped;            /* 被我们丢弃的物理事件数 */

/*
 * ==========================================================================
 * v1.58.0  secure_touch_inject 纯事件层移植
 * --------------------------------------------------------------------------
 * 参考实现是 LKM（带 <linux/input.h>），靠 input_handler 绑定真实触摸屏、
 * 读 dev->absinfo 拿槽位数与坐标范围、只用**空闲 slot** 注入。
 *
 * KPM 没有内核头文件，拿不到 dev->absinfo / dev->evbit 的偏移，硬猜就是
 * 历史上炸内核的老路。但它的**核心算法完全不依赖结构体布局**，可以
 * 在 input_event 这一层等价实现：
 *
 *   原实现                          | 本移植
 *   ------------------------------- | ------------------------------------
 *   input_handler 绑定 dev           | g_seen[].dev（回调第一参数，内核亲送）
 *   dev_supports_mt_b() 读 evbit     | 观察事件流：见过 SLOT+TID+X+Y 即 MT B
 *   absinfo[SLOT].maximum 算槽位数   | 自学习物理用过的最大 slot + 保守上限
 *   absinfo[X/Y] 取坐标范围          | 自学习观测最大值 / 屏幕分辨率兜底
 *   real_used bitmap 维护            | 完全相同（TRACKING_ID >=0 置位,==-1 清位）
 *   input_event(dev,...) 注入        | 完全相同（hy_f_input_event + 真实 dev）
 *   injecting 递归守卫               | 完全相同
 *   tracking_id 0x70000000 起        | 完全相同
 *   CONFLICTED 冲突取消状态机        | 完全相同
 *
 * 结果：不创建任何 /dev/input 节点、不改设备能力位、不抢真手指的槽位。
 * 系统看到的只是"同一块屏上多了一根手指" —— 正常的多点触摸，无可检测面。
 * ==========================================================================
 */
#define TI_MAX_SLOTS        256
#define TI_WORDS            (TI_MAX_SLOTS / (8 * sizeof(unsigned long)))
#define TI_TID_BASE         0x70000000u   /* 虚拟手指 tracking id 起点 */
#define TI_IDLE             0
#define TI_ACTIVE           1
#define TI_CONFLICTED       2

static unsigned long g_ti_used[TI_WORDS];  /* 物理手指占用槽位位图 */
static int  g_ti_cur_slot;                 /* 物理驱动当前槽位 */
static int  g_ti_max_slots = 10;           /* 总槽位数（自学习后收敛） */

/*
 * 【v1.76.0】多指。
 *
 * 原实现是单指状态机：g_ti_inj_slot 只有一个 int，第二次 down 直接
 * -EBUSY。这里改成手指数组 —— 每根虚拟手指独立记录自己占的槽位、坐标
 * 和 tracking id。
 *
 * 关键性质：**容量是动态的**，不是固定值。
 *   可用虚拟手指数 = 总槽位数 - 真实手指已占用数
 *   0 根真手指 -> 10 根虚拟；5 根真手指 -> 5 根虚拟；6 根 -> 4 根。
 * 真手指落下时若超出总量，多余的虚拟手指会被释放（让位），见
 * ti_shrink_for_real()。
 */
#define TI_MAX_FINGERS      16          /* 虚拟手指最大数（实际受槽位总数限制） */

struct ti_finger {
    int slot;               /* 占用的硬件槽位，-1 = 空闲 */
    int x, y;               /* 最近一次坐标 */
    unsigned int tid;       /* tracking id */
    int active;             /* 1 = 正按着 */
};
static struct ti_finger g_ti_f[TI_MAX_FINGERS];
static int  g_ti_last_id = -1;             /* 最近操作的手指 id（兼容不带 id 的调用） */
static int  g_ti_inj_slot = -1;            /* 兼容字段：最近按下的槽位 */

static unsigned int g_ti_tid = TI_TID_BASE;
static int  g_ti_state = TI_IDLE;          /* 聚合状态：有任一手指按着 = ACTIVE */
static int  g_ti_inject_allowed = 1;       /* v1.75.0 注入总闸：1=允许显式注入 */
static int  g_ti_downs;                    /* 成功按下次数 */
static int  g_ti_moves;
static int  g_ti_ups;
static int  g_ti_busy;                     /* 无空闲槽位被丢弃次数 */
static int  g_ti_conflicts;                /* 冲突取消次数 */
static int  g_ti_protects;                 /* v1.60.0：拦下的"抹除虚拟手指"事件数 */

/* ---- v1.73.0 ---- */
/*
 * 并发锁。参考实现（secure_touch_inject）全部状态都在 spinlock 下；
 * 原移植版一把锁都没有，用户态多线程同时 down/move/up 会竞态。
 * KPM 环境不保证能用内核 spinlock，这里用 GCC 内建的原子操作自己实现
 * 一个 test-and-set 自旋锁 —— 编译期直接生成 ldaxr/stxr，零外部符号。
 */
static volatile int g_ti_lock;

static inline void ti_lock(void)
{
    while (__atomic_test_and_set(&g_ti_lock, __ATOMIC_ACQUIRE))
        __asm__ __volatile__("yield" ::: "memory");
}
static inline void ti_unlock(void)
{
    __atomic_clear(&g_ti_lock, __ATOMIC_RELEASE);
}

/*
 * 坐标下限。原来只学 max，min 硬编码 0 —— 少数屏的 ABS_MT_POSITION_X
 * 不是从 0 起（比如边框校准偏移），注入坐标会整体偏一格。
 */
static int  g_min_x;
static int  g_min_y;
/* 见过 BTN_TOOL_FINGER 才发它：参考实现靠 test_bit(keybit)，我们靠观察 */
static bool g_has_tool_finger;

/*
 * 【v1.77.0】多点协议（MT protocol）自学习。
 *
 * Linux input 子系统有两套多指协议，走哪套完全由驱动能力位决定：
 *
 *   Protocol B（5.10+ 绝大多数屏）：有 ABS_MT_SLOT。
 *     input_get_disposition() 对 EV_ABS 先判
 *         is_event_supported(code, dev->absbit, ABS_MAX)
 *     而 input_handle_abs_event() 收到 ABS_MT_SLOT 时只做一件事：
 *         if (mt && val >= 0 && val < mt->num_slots) mt->slot = val;
 *         return INPUT_IGNORE_EVENT;
 *     —— 也就是说 SLOT 根本不会传给上层，它只是"选当前槽"。
 *
 *   Protocol A（5.10 以下的老屏常见）：没有 ABS_MT_SLOT，靠驱动调
 *     input_mt_sync() 发出 SYN_MT_REPORT 来分隔手指。
 *
 * 关键推论：如果设备没有 ABS_MT_SLOT 能力位，那我们发的 ABS_MT_SLOT
 * 会被 input_get_disposition 整条丢掉（不在 absbit 里），SLOT 永远选不中，
 * 多根手指的坐标会全部混进同一个槽、且因为没有 SYN_MT_REPORT 而永远
 * 不会被分隔 —— 表现为"多指调用只有一根生效 / 手指乱跳"。
 *
 * 所以注入方式必须跟着协议走。我们不猜，靠观察真实驱动自己发过什么：
 *   见过 ABS_MT_SLOT            -> Protocol B
 *   只见过 MT 坐标/TRACKING_ID   -> Protocol A
 */
static bool g_mt_seen_slot;   /* 真实驱动自己发过 ABS_MT_SLOT */
static bool g_mt_seen_mt;     /* 真实驱动自己发过 MT 坐标或 TRACKING_ID */

/* 0=未知(按 B 处理) 1=Protocol A 2=Protocol B */
static int hy_mt_proto(void)
{
    if (g_mt_seen_slot) return 2;
    if (g_mt_seen_mt)   return 1;
    return 2;   /* 没证据时按 B —— 与现有行为一致，不引入回归 */
}

/*
 * Protocol A 语义：每个 SYN_REPORT 帧必须重报**全部**活跃触点，
 * 因为 A 是无槽位的、逐帧全量上报。所以 down/move/up 之后都要重发整帧。
 */
/* 注入原语定义在下方（ti_abs / ti_syn），这里先声明以便帧合成复用 */
static void ti_abs(unsigned int code, int value);
static void ti_syn(void);

static void ti_syn_mt(void)
{
    if (!g_real_dev || !hy_f_input_event) return;
    hy_f_input_event(g_real_dev, HY_EV_SYN, HY_SYN_MT_REPORT, 0);
}

static void ti_frame_a(void)
{
    int i, n = 0;

    for (i = 0; i < TI_MAX_FINGERS; i++) {
        if (!g_ti_f[i].active) continue;
        ti_abs(HY_ABS_MT_TRACKING_ID, (int)g_ti_f[i].tid);
        ti_abs(HY_ABS_MT_POSITION_X, g_ti_f[i].x);
        ti_abs(HY_ABS_MT_POSITION_Y, g_ti_f[i].y);
        ti_abs(HY_ABS_MT_TOUCH_MAJOR, 10);
        ti_abs(HY_ABS_MT_PRESSURE, 60);
        ti_syn_mt();
        n++;
    }
    if (n == 0) {
        /* 空帧也要有一个 SYN_MT_REPORT，表示"本帧没有触点" */
        ti_syn_mt();
    }
    ti_syn();
}
/* 观测到的坐标最小值（自学习用，初值取一个物理上不可能达到的大数） */
static int  g_seen_min_x = 0x7fffffff;
static int  g_seen_min_y = 0x7fffffff;

static inline void ti_set(int s)   { if (s >= 0 && s < TI_MAX_SLOTS) g_ti_used[s / (8*sizeof(unsigned long))] |= 1UL << (s % (8*sizeof(unsigned long))); }
static inline void ti_clear(int s) { if (s >= 0 && s < TI_MAX_SLOTS) g_ti_used[s / (8*sizeof(unsigned long))] &= ~(1UL << (s % (8*sizeof(unsigned long)))); }
static inline int  ti_test(int s)  { return (s >= 0 && s < TI_MAX_SLOTS) ? !!(g_ti_used[s / (8*sizeof(unsigned long))] & (1UL << (s % (8*sizeof(unsigned long))))) : 0; }

/* 选一个物理手指没在用的槽位 */
/*
 * 【v1.60.0】改成从最高槽往下挑。
 *
 * 原来从 0 往上挑，而物理驱动分配槽位同样是从 0 开始 —— 于是虚拟手指
 * 总落在驱动最可能占用的那一端，真手指一碰就撞进同一个槽，触发
 * CONFLICTED 放弃整条轨迹。从反向挑可以几乎不冲突：驱动只在所有低槽
 * 都用满时才会碰到高槽。
 */
/* 该槽位是否已被某根虚拟手指占用 */
static int ti_slot_by_virt(int s)
{
    int i;
    for (i = 0; i < TI_MAX_FINGERS; i++)
        if (g_ti_f[i].active && g_ti_f[i].slot == s) return 1;
    return 0;
}

/* 返回占用该槽位的虚拟手指 id，无则 -1 */
static int ti_finger_by_slot(int s)
{
    int i;
    for (i = 0; i < TI_MAX_FINGERS; i++)
        if (g_ti_f[i].active && g_ti_f[i].slot == s) return i;
    return -1;
}

/* 真实手指当前占用的槽位数 */
static int ti_real_count(void)
{
    int s, lim = g_ti_max_slots, n = 0;
    if (lim <= 0 || lim > TI_MAX_SLOTS) lim = TI_MAX_SLOTS;
    for (s = 0; s < lim; s++) if (ti_test(s)) n++;
    return n;
}

/* 当前按着的虚拟手指数 */
static int ti_virt_count(void)
{
    int i, n = 0;
    for (i = 0; i < TI_MAX_FINGERS; i++) if (g_ti_f[i].active) n++;
    return n;
}

/*
 * 【v1.78.0】有效槽位上限。
 *
 * g_ti_max_slots 会被自学习持续抬升（见到 slot=v 就抬到 v+1，上限
 * TI_MAX_SLOTS=256）。驱动真实上限却是 g_max_drv_slot+1（你这台是 10）。
 * 二者不一致时，容量与分配都会算出超过驱动上限的槽位 —— 而
 * input_handle_abs_event() 里 val < mt->num_slots 不成立，SLOT 被静默
 * 忽略，坐标会写进"上一次选中的槽"，表现为手指乱跳或按了没反应。
 *
 * 统一以驱动真实上限为准（未学到时退回 g_ti_max_slots）。
 */
static int ti_slot_limit(void)
{
    int lim = g_ti_max_slots;

    if (g_max_drv_slot >= 0 && g_max_drv_slot + 1 < lim)
        lim = g_max_drv_slot + 1;
    if (lim < 1) lim = 1;
    if (lim > TI_MAX_SLOTS) lim = TI_MAX_SLOTS;
    return lim;
}

/*
 * 【v1.76.0】动态容量。
 *
 * 系统侧的手指总量上限就是驱动的槽位数（你这台 10）。真手指每落一根
 * 就占掉一个槽，能给虚拟手指的额度就少一个 —— 所以容量不是常量，
 * 是 "总槽位 - 真手指占用"，每次 down 都重新算。
 *
 * v1.78.0：改用 ti_slot_limit()，并额外钳到 TI_MAX_FINGERS 以内，
 * 保证 cap <= 真实槽位数，不再出现 cap 比 slots 还大的矛盾输出。
 */
static int ti_capacity(void)
{
    int cap = ti_slot_limit() - ti_real_count();
    if (cap < 0) cap = 0;
    if (cap > TI_MAX_FINGERS) cap = TI_MAX_FINGERS;
    return cap;
}

/*
 * 真手指落下导致总量超额时，释放多余的虚拟手指让位。
 *
 * 这里不发任何事件：那个槽马上就会被真手指自己的 TRACKING_ID 覆写，
 * 我们抢着发只会互相打架。直接把虚拟手指置为失效即可 —— 系统侧看到
 * 的就是"那根手指没了"，不会残留圆点。
 */
static void ti_shrink_for_real(void)
{
    /* v1.78.0：用 ti_slot_limit()，与容量/分配同一口径 */
    int over = ti_real_count() + ti_virt_count() - ti_slot_limit();
    int i;

    if (over <= 0) return;
    /* 从高 id 往低释放，保留最早按下的那几根（更符合调用方预期） */
    for (i = TI_MAX_FINGERS - 1; i >= 0 && over > 0; i--) {
        if (!g_ti_f[i].active) continue;
        g_ti_f[i].active = 0;
        g_ti_f[i].slot = -1;
        g_ti_conflicts++;
        over--;
    }
    if (ti_virt_count() == 0) g_ti_state = TI_IDLE;
}

static int ti_pick_free_slot(void)
{
    /* v1.78.0：同样按驱动真实上限收敛，杜绝分配到 num_slots 之外的槽 */
    int s, lim = ti_slot_limit();
    for (s = lim - 1; s >= 0; s--) {
        if (ti_test(s)) continue;                            /* 真手指在用 */
        if (ti_slot_by_virt(s)) continue;                    /* 虚拟手指在用 */
        return s;
    }
    return -1;
}

/*
 * 【v1.73.0】注入专用的钳位。
 *
 * 原实现用 ti_clamp(x, 0, g_max_x)：g_max_x 靠"看物理驱动报过哪些坐标"
 * 自学习，没摸过屏之前它是初值；一旦为 0，hi <= lo 成立，ti_clamp 直接
 * 返回 lo —— **注入坐标会被静默压成 (0,0)**，表现为"点了没反应"或
 * "永远点在左上角"，极难排查。
 *
 * 范围未知时正确做法是原样透传（让内核按它自己的 absinfo 处理），
 * 而不是猜一个 0。
 */
static inline int ti_clamp_axis(int v, int lo, int hi)
{
    if (hi <= lo) return v;
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

extern unsigned long hy_lookup_generic(const char *name);

/* v1.14.0 修复的 copy 符号（hy_sym.c 定义），失败即跳过，不做直接访问 */
extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);

/* KPM 头文件不保证提供 fls64，自己实现（纯整数） */
static int hy_fls64(u64 x)
{
    int r = 0;
    if (!x) return 0;
    while (x >>= 1) r++;
    return r + 1;
}

/* ---------------- ASensorEvent 布局（Android） ---------------- */
#define HY_ASE_SIZE     104
#define HY_ASE_TYPE_OFF 8
#define HY_ASE_DATA_OFF 24
#define HY_SENSOR_GYRO              4
#define HY_SENSOR_GYRO_UNCAL        16
#define HY_GYRO_CHUNK_EVENTS 8
#define HY_GYRO_CHUNK_BYTES (HY_GYRO_CHUNK_EVENTS * HY_ASE_SIZE)
/* 单次 sendto 最多扫描 8KB（约 78 个事件），够用且开销可控 */
#define HY_GYRO_MAX_SCAN (8 * 1024)

static bool g_gyro_active;
static bool g_gyro_use_raw;                 /* 旧 ABI：直接给 float 位 */
static u32  g_gyro_raw_x, g_gyro_raw_y, g_gyro_raw_z;
static int  g_gyro_x, g_gyro_y, g_gyro_z;   /* mrad/s */
static u64  g_gyro_patches;
static bool g_gyro_hooked;

/*
 * mrad/s -> IEEE754 float 位（纯整数运算）
 * lsdriver 的 vgyro_milli_to_float_bits()，内核不能用 FPU，照抄整数算法。
 */
static u32 hy_milli_to_float_bits(int value)
{
    u32 sign;
    u64 mag, q;
    int top, exp;
    u32 mant;

    if (!value) return 0;

    sign = (value < 0) ? 0x80000000U : 0;
    mag = (value < 0) ? (u64)(-(s64)value) : (u64)value;

    q = (mag << 24) / 1000;
    if (!q) return sign;

    top = hy_fls64(q) - 1;
    exp = top - 24 + 127;
    if (exp <= 0) return sign;
    if (exp >= 255) return sign | 0x7f800000U;

    if (top > 23) {
        int shift = top - 23;
        u64 half = 1ULL << (shift - 1);
        u64 mask = (1ULL << shift) - 1;
        u64 rounded = q >> shift;
        if ((q & mask) >= half) rounded++;
        if (rounded >= (1ULL << 24)) {
            rounded >>= 1;
            exp++;
            if (exp >= 255) return sign | 0x7f800000U;
        }
        mant = (u32)rounded;
    } else {
        mant = (u32)(q << (23 - top));
    }
    return sign | ((u32)exp << 23) | (mant & 0x7fffffU);
}

static void hy_gyro_sendto_before(hook_fargs6_t *args, void *udata);

#ifndef HY_DEV_SEEN_MAX
#define HY_DEV_SEEN_MAX 32   /* v1.34.0: 24 -> 32，为 probe 观测留出槽位 */
#endif

/*
 * 【v1.34.0】登记表补齐 ls match_touchscreen 的等价行为判据
 *
 * ls 靠读结构体能力位判定：
 *     test_bit(EV_ABS,   input->evbit)  &&
 *     test_bit(ABS_MT_SLOT, input->absbit) &&
 *     test_bit(BTN_TOUCH, input->keybit) &&
 *     input->mt
 *
 * 欢愉是 KPM，没有 struct input_dev 布局，读不了 evbit/absbit/keybit。
 * 但"设备上报过什么事件"与"设备具备什么能力位"是行为等价的：
 * 设备不可能上报它不支持的事件。所以改用观测法，零结构体偏移。
 */
struct hy_dev_seen {
    void *dev;
    char  name[32];
    char  phys[40];       /* v1.74.0: input_dev 第 2 成员 = phys，用来反查 /dev/input/eventN */
    int   has_abs;        /* 见过 EV_ABS            ⟵ test_bit(EV_ABS, evbit)   */
    int   has_btn_touch;  /* 见过 EV_KEY+BTN_TOUCH  ⟵ test_bit(BTN_TOUCH,keybit)*/
    int   is_mt;          /* 见过 MT_SLOT/位置坐标   ⟵ absbit + input->mt!=NULL  */
    int   nev;            /* 该设备上报过的事件数，用于判断活跃度 */
};

/*
 * 【v1.74.0】读 input_dev->phys。
 *
 * struct input_dev 的前两个成员固定是：
 *     const char *name;
 *     const char *phys;
 * 所以 phys 就是 name 后面那个指针 —— 与 name 完全同级的取法，
 * 不需要任何结构体偏移推算，也不引入新的解引用风险。
 *
 * 为什么要它：用户 ls /dev/input 看到 event0..event11，
 * 却不知道哪个是屏幕。内核态拿不到 event 编号，但
 * /proc/bus/input/devices 里每个设备都有 P: Phys= 和 H: Handlers=eventN，
 * 把 phys 打出来，用户就能拿它 grep 出对应的 event 号。
 */
static int hy_name_safe(const char *nm);   /* v1.74.0 前向声明：定义在下方 */
static const char *hy_dev_phys_of(void *dev)
{
    const char *p;
    if (!dev || !hy_lkaddr_ok(dev)) return NULL;
    p = ((const char *const *)dev)[1];
    if (!hy_name_safe(p)) return NULL;
    return p;
}

/*
 * 三项齐全 = ls match_touchscreen 的行为等价判定。
 * 不依赖设备名，也不需要任何结构体偏移。
 *
 * 【v1.57.0 放宽】旧判据要求 has_abs && has_btn_touch && is_mt 三项
 * 同时成立 —— 实测在 6.12 真机上永远凑不齐，found 恒为 0。
 *
 * 原因：BTN_TOUCH 是【单点触摸】时代的按键码。现代 B 协议多点屏
 * 由 input_mt_report_slot_state() 直接上报 ABS_MT_SLOT +
 * ABS_MT_TRACKING_ID + ABS_MT_POSITION_X/Y，只有开了
 * input_mt_report_pointer_emulation() 的驱动才会补发 BTN_TOUCH。
 * 大量手机驱动不开这个，于是 has_btn_touch 永远是 0，锁不上。
 *
 * 而 is_mt（见过 SLOT / POSITION_X / POSITION_Y / TRACKING_ID）才是
 * 真正的硬证据 —— 能上报多点坐标的设备就是触摸屏，没有例外。
 *
 * 新判据（二选一）：
 *   A) has_abs && is_mt                     多点屏（主流）
 *   B) has_abs && has_btn_touch && nev>=8   单点屏，用事件数兜底
 */
static int hy_seen_is_touchscreen(const struct hy_dev_seen *s)
{
    if (!s) return 0;
    if (!s->has_abs) return 0;
    if (s->is_mt) return 1;                       /* A：多点，硬证据 */
    if (s->has_btn_touch && s->nev >= 8) return 1; /* B：单点，兜底 */
    return 0;
}

static struct hy_dev_seen g_seen[HY_DEV_SEEN_MAX];
static int g_seen_count;
static unsigned long g_ie_events;

/*
 * v1.59.0 诊断：把"到底看到了什么"摊开，不再靠猜。
 * 用户 v1.58 实测：input_event hook 命中 5261 次，但登记表里
 * abs=0 btn=0 mt=0 —— 说明流经这个符号的事件压根不是触摸屏的。
 * 没有下面这组数据，就只能继续猜。
 */
static unsigned long g_ie_hits_iev;      /* 经 input_event 符号的次数 */
static unsigned long g_ie_hits_ihe;      /* 经 input_handle_event 的次数 */
static unsigned long g_ie_typehist[8];   /* type 0..7 计数（EV_MAX=0x1f，先看低位） */
static int   g_ie_bogus;                 /* dev 指针不像内核结构体（未8字节对齐） */
struct hy_ie_sample {
    unsigned long dev;
    unsigned int  type;
    unsigned int  code;
    int           value;
};
#define HY_IE_RING 8
static struct hy_ie_sample g_ie_ring[HY_IE_RING];
static unsigned int g_ie_ring_i;
/* v1.77.0：抓包开关，默认关。tcap 命令打开后才开始记录。 */
static bool g_ie_trace;
/* 预算：记够这么多条就自动关，避免诊断一次之后长期占用 CPU */
static int  g_ie_trace_budget;
static int g_probe_hooked_ihe;           /* input_handle_event 是否已挂 */

/* 名字是否由可打印字符组成（用于排除随机内存被误当成字符串） */
/*
 * 【v1.40.0】"先确认已映射，再解引用" —— 这是本文件最重要的安全规则。
 * --------------------------------------------------------------------
 * hy_dev_to_input() 从 struct device* 向前扫描，读到的每一个 8 字节
 * 都可能是一个【垃圾值】。它很可能落在内核地址范围内（于是
 * hy_lkaddr_ok() 放行）但那块地址根本没映射 —— 解引用就是 oops。
 *
 * v1.35 ~ v1.39 的加载即炸全部出自这里：tscan 默认开启后，
 * class_for_each_device 对 24 个设备各扫描数百次，每次都可能
 * 踩到未映射的垃圾指针，命中概率被放大到几乎必然。
 *
 * 现在的规则：任何来源不可信的指针，解引用前必须过
 * hy_kern_addr_mapped() —— 真正走一遍 TTBR1 页表确认映射有效。
 */
static int hy_name_safe(const char *nm)
{
    if (!nm) return 0;
    if (!hy_lkaddr_ok(nm)) return 0;
    /*
     * 【v1.73.3 关键修复】这里**绝不能**再调 hy_kern_addr_mapped()。
     *
     * 那是"加载即炸 / 一 probe 就炸"的真正根因，链路如下：
     *   hy_kern_addr_mapped() → hy_walk_pgtable() 走 TTBR1 页表
     *   顶层表用的是 swapper_pg_dir 的 VA（正确，不换算）
     *   但【第二级及更深】必须靠 hy_phys_to_virt(cur_phys)
     *        = cur_phys + g_physvirt_off（线性映射偏移）换算
     *   这台机器上该偏移不成立（scheme 显示 physvirt=gen5 memstart
     *   idx=1，即已降过一档），换出来的中间级表地址是垃圾值；
     *   而 hy_tbl_va_ok() 只判 `va >= 0xfff0000000000000`（纯范围
     *   检查，无法验证映射），垃圾地址照样放行 →
     *   `ent = tbl[idx]` 解引用未映射地址 → oops。
     *
     * v1.73.2 之前为什么不炸？因为 dev 参数是被 syscall_argn() 读坏的
     * 垃圾值，devname 校验在这里就早退了，页表遍历**一次都没被调用过**。
     * v1.73.2 修好参数取法后 dev 变真实、devname 变真实，
     * 这条路径第一次被真正走到 —— 而且是每个 input_event 都走
     * （实测 40 万次/几十秒），命中概率 100%，于是必炸。
     *
     * 结论：input_event 是极高频回调（可能在中断上下文），
     * 本来就不该在里面走页表。此处 dev 来自内核自己传的参数、
     * dev->name 是内核维护的合法字符串，可信度极高，
     * 范围检查 + 下面的"绝不跨页"拷贝已经足够。
     */
    return 1;
}

static int hy_name_printable(const char *nm)
{
    int i;
    if (!nm) return 0;
    for (i = 0; i < 31; i++) {
        unsigned char c = (unsigned char)nm[i];
        if (!c) return i > 0;
        if (c < 0x20 || c > 0x7e) return 0;
    }
    return 1;
}

/*
 * 【v1.34.0】识别"kobj 名字"，不是 input_dev->name
 * --------------------------------------------------
 * class_for_each_device 回调收到的是 struct device*，而
 *     struct device { struct kobject kobj; ... }
 *     struct kobject { const char *name; ... }
 * 所以 o=0 时 *(const char**)dev 读到的是 kobj.name ——
 * 对 input 子设备而言恒为 "inputN" / "eventN"。
 *
 * 上一版的第一步就是这个值，于是 24 个槽位全被 "input0".."event11"
 * 这类名字占满，真正的 input_dev->name（"fts_ts"/"goodix-ts" 等）
 * 在更前面反而读不到 —— 登记表被垃圾填满，probe 观测到的
 * 真实触摸屏再也进不来，三项判据永远凑不齐。
 *
 * 这里显式排除 inputN / eventN / mouseN / jsN 这类内核自动编号名，
 * 让向前扫描继续往真正的 input_dev 头部走。
 */
static int hy_is_kobj_autoname(const char *nm)
{
    static const char *const autos[] = {
        "input", "event", "mouse", "js", "ts", NULL
    };
    int i, j;

    if (!nm || !nm[0]) return 0;
    for (i = 0; autos[i]; i++) {
        int plen = hy_lstrlen(autos[i]);
        /* 前缀必须逐字符相等 */
        for (j = 0; autos[i][j]; j++)
            if (nm[j] != autos[i][j]) break;
        if (autos[i][j]) continue;          /* 前缀不匹配 */
        /* 前缀之后必须全是数字，且至少一位 */
        if (!nm[plen]) return 0;            /* 光秃秃的前缀，不算是自动名 */
        for (j = plen; nm[j]; j++)
            if (nm[j] < '0' || nm[j] > '9') return 0;
        return 1;
    }
    return 0;
}

/* class_for_each_device 遍历上下文 */
struct hy_scan_ctx {
    char  want_name[32];
    void *found;
    char  found_name[32];
    void *devs[HY_DEV_SEEN_MAX];
    char  names[HY_DEV_SEEN_MAX][32];
    int   count;
};

/* 把一次扫描结果并入全局登记表 */
static void hy_seen_merge(struct hy_scan_ctx *ctx)
{
    int i, j;

    if (!ctx) return;
    for (j = 0; j < ctx->count && g_seen_count < HY_DEV_SEEN_MAX; j++) {
        for (i = 0; i < g_seen_count; i++)
            if (g_seen[i].dev == ctx->devs[j]) break;
        if (i < g_seen_count) continue;
        g_seen[g_seen_count].dev = ctx->devs[j];
        hy_lstrscpy(g_seen[g_seen_count].name, ctx->names[j], 32);
        {
            const char *ph = hy_dev_phys_of(ctx->devs[j]);
            hy_lstrscpy(g_seen[g_seen_count].phys, ph ? ph : "-",
                        sizeof(g_seen[g_seen_count].phys));
        }
        g_seen_count++;
    }
}

/* ===================================================================
 * 路径 A：发现真实触摸屏 —— 【v1.28.0 重写为 ls 同款主动枚举】
 * -------------------------------------------------------------------
 * lsdriver 的 virtual_input.h 是这样做的：
 *
 *     struct class *input_class = kallsyms_lookup_name("input_class");
 *     class_for_each_device(input_class, NULL, &found, match_touchscreen);
 *
 *     static int match_touchscreen(struct device *dev, void *data) {
 *         struct input_dev *input = to_input_dev(dev);   // container_of
 *         if (test_bit(EV_ABS,  input->evbit)  &&
 *             test_bit(ABS_MT_SLOT, input->absbit) &&
 *             test_bit(BTN_TOUCH, input->keybit) &&
 *             input->mt)
 *             { *result = input; return 1; }
 *         return 0;
 *     }
 *
 * 关键差异：ls 是内核模块（.ko），有完整头文件，能直接用
 * to_input_dev()/test_bit()。欢愉是 KPM，**没有这些头文件**，
 * 拿不到 struct input_dev 的布局，硬编码偏移风险极大。
 *
 * 所以这里做了等价变换，不依赖任何结构体偏移：
 *
 *   1) 用 kallsyms 查 input_class / class_for_each_device
 *      （两者签名与 ls 完全一致，只是参数类型写成 void*）
 *
 *   2) 回调收到的是 struct device*。不用 container_of ——
 *      改为**向前扫描**找 input_dev 起始：
 *      input_dev 的第一个成员是 const char *name（4.x~6.x 恒为 offset 0），
 *      于是对 o = 0..HY_SCAN_MAX，令 p = dev - o，
 *      若 *(const char**)p 指向一个合法内核字符串，就认为 p 是 input_dev。
 *
 *   3) **用名字做校验**，这是防误判的关键：
 *      - 用户态从 /proc/bus/input/devices 读到触摸屏名字（如 "fts_ts"）
 *      - 内核扫描出的 name 与之比对，一致才锁定
 *      名字来自 VFS 的权威来源，交叉验证后误判概率极低。
 *
 * 这样既拿到了 ls 同款的"真实触摸屏 dev 指针"，
 * 又完全不需要等任何 input_event —— 开机就注册好的设备也能发现。
 * =================================================================== */

/* class_for_each_device(class, start, data, fn) */
typedef int (*hy_cfed_t)(void *cls, void *start, void *data,
                         int (*fn)(void *dev, void *data));

static hy_cfed_t hy_f_class_for_each_device;
static void     *hy_input_class;

/*
 * tscan=1 开关：是否启用 class_for_each_device 主动枚举。
 * 默认 0（关闭）—— 该路径需要对未知设备做启发式指针扫描，有踩未映射内存的风险。
 */
static int g_tscan_enabled = 1;   /* v1.32.0 默认开：已加页边界保护 */

/* 扫描范围：struct device 在 input_dev 内的偏移远小于此 */
#define HY_SCAN_MAX   2048
#define HY_SCAN_STEP  8

/* 向前扫描，从 struct device* 反推 struct input_dev* */
/*
 * 【v1.32.0】页边界限制 —— 这是之前扫描炸内核的真正原因。
 *
 * dev 指针来自 class_for_each_device 回调，是真实的内核对象，
 * 它所在的【那一页必然已映射】。但只要往前扫过页起始地址，
 * 就会读到完全无关的、可能未映射的页 —— hy_lkaddr_ok() 只能
 * 判断"落在内核地址范围"，不代表已映射，于是 oops。
 *
 * 现在：把扫描下界钳制在当前页的起始地址内，保证【永不跨页】。
 * 一页 4096 字节，足够覆盖 struct input_dev 头部到内嵌 dev 的距离。
 */
static unsigned long hy_scan_limit(unsigned long base)
{
    unsigned long page_start = base & ~(unsigned long)(HY_PAGE_SIZE - 1);
    unsigned long room = base - page_start;

    /* 留 8 字节余量，避免读到页的最开头（对齐考虑） */
    if (room > 8) room -= 8;
    else return 0;

    if (room > HY_SCAN_MAX) room = HY_SCAN_MAX;
    return room;
}

static void *hy_dev_to_input(void *dev, const char *want)
{
    unsigned long base = (unsigned long)dev;
    unsigned long limit;
    unsigned long o;

    if (!dev || !hy_lkaddr_ok(dev)) return NULL;

    limit = hy_scan_limit(base);
    if (!limit) return NULL;

    for (o = 0; o <= limit; o += HY_SCAN_STEP) {
        unsigned long p = base - o;
        const char *nm;

        if (!hy_lkaddr_ok((void *)p)) break;
        nm = *(const char *const *)p;
        if (!hy_name_safe(nm)) continue;

        /* 名字必须至少 1 个可打印字符 */
        if (!hy_name_printable(nm)) continue;

        /* 【v1.34.0】跳过 kobj 自动编号名（inputN/eventN） */
        if (hy_is_kobj_autoname(nm)) continue;

        if (want && want[0]) {
            if (hy_lstrstr(nm, want))
                return (void *)p;
        } else {
            /* 未指定名字：只登记，不擅自认定 */
            return NULL;
        }
    }
    return NULL;
}

/*
 * class_for_each_device 的回调。
 * 注意：这里运行在内核的 class 遍历上下文中，
 * 绝不做可能睡眠的操作，只读指针和字符串。
 */
static int hy_match_input(void *dev, void *data)
{
    struct hy_scan_ctx *ctx = (struct hy_scan_ctx *)data;
    void *input;
    const char *nm;

    if (!ctx || ctx->found) return 0;
    if (ctx->count >= HY_DEV_SEEN_MAX) return 0;

    input = hy_dev_to_input(dev, ctx->want_name);
    if (!input) {
        /* 未匹配：若还有空位，尝试登记设备名供用户查看 */
        unsigned long o;
        if (!ctx->want_name[0]) {
            unsigned long lim = hy_scan_limit((unsigned long)dev);
            for (o = 0; o <= lim; o += HY_SCAN_STEP) {
                unsigned long p = (unsigned long)dev - o;
                const char *cand;
                if (!hy_lkaddr_ok((void *)p)) break;
                cand = *(const char *const *)p;
                if (!hy_name_safe(cand)) continue;
                if (!hy_name_printable(cand)) continue;
                /*
                 * 【v1.34.0】跳过 "inputN"/"eventN" —— 那是 kobj.name，
                 * 不是 input_dev->name。不跳过的话每个设备都会以
                 * input0/event0 之类的名字登记，24 个槽位瞬间被垃圾填满，
                 * probe 观测到的真实触摸屏再也进不了表。
                 */
                if (hy_is_kobj_autoname(cand)) continue;
                if (ctx->count < HY_DEV_SEEN_MAX) {
                    hy_lstrscpy(ctx->names[ctx->count], cand, 32);
                    ctx->devs[ctx->count] = dev;
                    ctx->count++;
                }
                break;
            }
        }
        return 0;
    }

    nm = *(const char *const *)input;
    ctx->found = input;
    hy_lstrscpy(ctx->found_name, nm, sizeof(ctx->found_name));
    return 1;   /* 停止遍历 */
}

/* 主动枚举：ls 同款 */
static void *hy_input_find_by_name(const char *want, char *out_name, int out_max)
{
    struct hy_scan_ctx ctx;
    int rc;

    if (!g_tscan_enabled) {
        HY_LOG("input: active enum disabled (tscan=0)\n");
        return NULL;
    }
    if (!hy_f_class_for_each_device || !hy_input_class) return NULL;

    hy_memset(&ctx, 0, sizeof(ctx));
    hy_lstrscpy(ctx.want_name, want ? want : "", sizeof(ctx.want_name));

    rc = hy_f_class_for_each_device(hy_input_class, NULL, &ctx, hy_match_input);
    if (ctx.found) {
        if (out_name && out_max > 0)
            hy_lstrscpy(out_name, ctx.found_name, (size_t)out_max);
        HY_LOG("input: found \"%s\" -> input_dev=%llx (rc=%d)\n",
               want ? want : "?", (u64)ctx.found, rc);

        /* 把扫描到的其它设备也并入登记表，便于诊断 */
        hy_seen_merge(&ctx);
        return ctx.found;
    }

    HY_LOG("input: no input_dev matched \"%s\" (scanned %d, rc=%d)\n",
           want ? want : "?", ctx.count, rc);
    hy_seen_merge(&ctx);
    return NULL;
}

/* ===================================================================
 * 路径 A：发现真实触摸屏
 * =================================================================== */

/*
 * input_event 的 before 回调。
 * 只做参数比较，绝不调用 input_event（否则无限递归），
 * 不做任何可能睡眠/失败的操作。
 */
/* ==========================================================================
 * v1.27.0：设备名登记表
 * --------------------------------------------------------------------------
 * 之前必须等真实手指触摸（ABS_MT_POSITION_X/Y）才能发现触摸屏。
 * 现实是：在 shell/注入场景里没人摸屏幕，于是永远发现不了，
 * 一直停在自建的单点设备上，而多数游戏不认单点设备。
 *
 * 现在：任何 input_event 都会把 (dev, name) 记进登记表。
 * 之后用户态可以直接按名字锁定 —— 只要该设备有过任意活动
 * （哪怕只是 EV_SYN）就能被登记，不必真的触摸。
 * ========================================================================== */
static void hy_dev_note(void *dev)
{
    const char *devname;
    int i;

    if (!dev || g_seen_count >= HY_DEV_SEEN_MAX) return;
    if (!hy_lkaddr_ok(dev)) return;

    for (i = 0; i < g_seen_count; i++)
        if (g_seen[i].dev == dev) return;   /* 已登记 */

    devname = *(const char *const *)dev;    /* struct input_dev 首成员 = name */
    if (!hy_name_safe(devname)) devname = NULL;   /* v1.73.3：不再走页表遍历 */

    g_seen[g_seen_count].dev = dev;
    hy_lstrscpy(g_seen[g_seen_count].name,
                devname ? devname : "?",
                sizeof(g_seen[g_seen_count].name));
    {
        const char *ph = hy_dev_phys_of(dev);
        hy_lstrscpy(g_seen[g_seen_count].phys, ph ? ph : "-",
                    sizeof(g_seen[g_seen_count].phys));
    }
    g_seen_count++;
}

/*
 * v1.31.0：标记"这个设备确实上报过多点触摸坐标"。
 * 这是判断真实触摸屏最硬的证据 —— 比猜名字可靠得多。
 */
/*
 * 返回 1 表示"这个设备刚刚凑齐三项证据"，调用方可立即锁定它。
 */
static int hy_dev_mark(void *dev, unsigned int type, unsigned int code)
{
    int i;
    if (!dev) return 0;

    /*
     * 【发热优化】已经锁定真实触摸屏、且该设备三项证据齐全之后，
     * 登记表就没有继续观测的价值了 —— input_event 是很高频的回调
     * （实测一次开机就上万次），每次都线性扫表是白烧 CPU。
     */
    if (g_real_found && g_real_dev) return 0;

    for (i = 0; i < g_seen_count; i++) {
        if (g_seen[i].dev != dev) continue;
        g_seen[i].nev++;

        /* 判据 1：EV_ABS */
        if (type == HY_EV_ABS) {
            g_seen[i].has_abs = 1;

            /* 判据 3：多点触摸证据
             * ABS_MT_SLOT(0x2f) 是 ls 直接测的位；
             * 但也有屏不发 SLOT 只发 POSITION_X/Y + TRACKING_ID，
             * 同样说明 mt 存在，一并算作证据。 */
            if (code == HY_ABS_MT_SLOT ||
                code == HY_ABS_MT_POSITION_X ||
                code == HY_ABS_MT_POSITION_Y ||
                code == HY_ABS_MT_TRACKING_ID)
                g_seen[i].is_mt = 1;
        }

        /* 判据 2：BTN_TOUCH */
        if (type == HY_EV_KEY && code == HY_BTN_TOUCH)
            g_seen[i].has_btn_touch = 1;

        /*
         * 【v1.34.0】就在这里判定，不再等 touch_down 才 rescan。
         * 三项同时具备 = ls match_touchscreen 的行为等价条件满足，
         * 且完全不看设备名。凑齐的这一刻立即锁定。
         */
        return hy_seen_is_touchscreen(&g_seen[i]);
    }
    return 0;
}

/*
 * 有效虚拟槽位起点：必须严格高于物理驱动用过的最大槽位，
 * 这样虚拟手指永远不会和真手指抢同一个槽位。
 */
static int hy_eff_slot_base(void)
{
    int base = g_slot_base;
    if (g_max_drv_slot >= 0 && g_max_drv_slot >= base)
        base = g_max_drv_slot + 1;
    if (base >= HY_MAX_SLOTS) base = HY_MAX_SLOTS - 1;
    return base;
}

/*
 * v1.59.0：真正干活的公共体被拆出来，外面套两个极薄的壳，
 * 只为区分"这次是从哪个符号进来的" —— 两个观察点各自命中多少次，
 * 是判断 LTO 内联把触摸屏藏到哪去了的唯一依据。
 */
static void hy_ie_common(hook_fargs4_t *args, void *udata)
{
    void *dev;
    (void)udata;   /* 两个观察点共用此回调，靠 udata 区分来源，这里用不到 */
    unsigned int type, code;

    if (g_injecting > 0) return;        /* 自己注入的事件，忽略 */

    /*
     * 【v1.73.2 关键修复】普通函数 hook 绝不能用 syscall_argn()！
     *
     * KP 的 syscall_argn() 是专为【系统调用】hook 设计的（syscall.h）：
     *   if (has_syscall_wrapper)
     *       args = ((struct pt_regs *)fargs->args[0])->regs;   ← 把 arg0 当 pt_regs*
     *   else
     *       args = fargs->args;
     * 6.12 上 has_syscall_wrapper==1，于是走了第一支：把真正的
     * input_dev *dev 当成 struct pt_regs*，而 pt_regs.regs 偏移为 0，
     * 结果 args[n] 实际等于 ((u64*)dev)[n] —— 读的是 input_dev 结构体
     * 自身的连续字段，压根不是函数参数。
     *
     * 实测症状（v1.73.1 真机）：unaligned_dev 100%、type 恒 0（syn 占满
     * 40 万次）、code 恒 0、value=655（结构体里的计数），因此 ABS 事件
     * 一次都没抓到、触摸屏永远认不出、分辨率永远学不到。
     *
     * 普通函数 hook 一律直接取 fargs->args[n]（即 arg0..arg3）。
     * 注意：hook_syscalln 挂的（prctl / sendto）才用 syscall_argn。
     */
    dev  = (void *)args->args[0];
    type = (unsigned int)args->args[1];
    code = (unsigned int)args->args[2];

    if (!dev) return;

    /* 计数很便宜，保留在最前，方便诊断 */
    g_ie_events++;

    /*
     * 【v1.59.0 诊断】记录原始三元组，不依赖任何判据。
     * 只有看到真实数据，才能判断"hook 挂对了但设备不对"还是
     * "hook 根本没挂到触摸屏路径上"。
     */
    /*
     * 【v1.77.0 发热/CPU 优化】抓包与直方图只在需要诊断时才记。
     *
     * input_event 是极高频回调（真机实测开机即 40 万次以上，且只在
     * 摸屏时更是每秒数百次）。旧版每个事件都要写 4 个字的环形缓冲、
     * 一次取模、一次直方图自增、一次对齐判断 —— 这些纯粹是给 tcap
     * 看的，平时全是白烧。
     *
     * 现在默认关闭，只有 tcap 打开过才记。常驻开销降到一个自增
     * （g_ie_events，节能降频采样还要用它做 1/64 抽稀，必须保留）。
     */
    if (g_ie_trace && g_ie_trace_budget > 0) {
        if (type < 8) g_ie_typehist[type]++;
        if (((unsigned long)dev & 7UL) != 0) g_ie_bogus++;
        {
            struct hy_ie_sample *s = &g_ie_ring[g_ie_ring_i];
            s->dev  = (unsigned long)dev;
            s->type = type;
            s->code = code;
            s->value = (int)args->args[3];
            g_ie_ring_i = (g_ie_ring_i + 1) % HY_IE_RING;
        }
        /* 记够就自动关，避免"诊断过一次之后一直烧 CPU" */
        if (--g_ie_trace_budget <= 0) g_ie_trace = false;
    }

    /*
     * 【v1.79.0 热路径早退】
     *
     * 已经锁定触摸屏、槽位上限已学到、坐标范围由 trange 手设固定，
     * 且当前没有任何虚拟手指按着、没开抓包、也没开槽位抢夺 —— 这个
     * 事件对我们毫无意义：既不拦物理驱动（没手指要保护），也不学分辨率
     * （手设优先），更不记抓包。直接返回，把 input_event 热路径压到
     * 只剩一个自增，长时间加载的 CPU 占用进一步下降。
     *
     * 只对已锁定的触摸屏早退；未锁定 / 其它设备仍走原路径去扫描识别。
     */
    if (g_real_found && dev == g_real_dev && !g_ie_trace &&
        g_ti_state != TI_ACTIVE && g_range_manual &&
        g_max_drv_slot >= 0 && !g_grab_slots) {
        return;
    }

    /*
     * 【v1.46.0 抢夺：槽位抢占 + 分辨率自学习】
     * 这一段必须在 g_real_found 早退**之前** —— 锁定之后仍然要跑，
     * 否则就没人去拦物理驱动、也没人继续学坐标上限了。
     * 开销：两次整数比较，比早退略贵但远小于扫表。
     */
    if (g_real_found && dev == g_real_dev) {
        /*
         * 【v1.60.0 关键修复：虚拟手指为什么一注入就被抹掉】
         *
         * 我们注入走的是裸 input_event()，没有经过
         * input_mt_report_slot_state()，所以内核 mt->slots[我们的槽].frame
         * 从来没有被更新过。物理驱动下一帧调用 input_mt_sync_frame() 时，
         * 在 INPUT_MT_DROP_UNUSED 分支里判定"这个槽本帧没出现过"，
         * 于是补发一组：
         *       ABS_MT_SLOT=<我们的槽>
         *       ABS_MT_TRACKING_ID=-1
         * 虚拟手指当场被抹掉。紧接着 input_mt_report_pointer_emulation()
         * 又按它自己数的活跃槽（同样数不到我们）发出 BTN_TOUCH=0，
         * 系统据此认为"触摸结束" —— 这就是"真手指一碰 / 一抬就打断
         * 虚拟滑动"的真正病根，跟槽位冲突是两回事。
         *
         * lsdriver 的解法是改 num_slots 并清 keybit，那需要 dev->mt 与
         * dev->keybit 的偏移，KPM 拿不到（硬猜就是历史上炸内核的老路）。
         * 这里在事件层做等价拦截：只针对"我们正在用的那个槽"和
         * "全局抬起按键"，其余一概不碰。
         *
         * 为什么这样仍然安全：
         *   - 只在 g_ti_state == TI_ACTIVE（虚拟手指确实按着）时生效；
         *   - 抬起由 hy_ti_up() 自己发，那时 g_injecting 为真，
         *     回调开头已 return，不会被这里拦住；
         *   - 真手指的槽位、真手指自己的抬起事件完全不受影响。
         */
        if (g_ti_state == TI_ACTIVE) {
            int val = (int)args->args[3];

            if (type == HY_EV_ABS && code == HY_ABS_MT_TRACKING_ID &&
                val == -1 && ti_finger_by_slot(g_ti_cur_slot) >= 0) {
                args->skip_origin = 1;
                args->ret = 0;
                g_ti_protects++;
                return;
            }

            if (type == HY_EV_KEY && val == 0 &&
                (code == HY_BTN_TOUCH || code == HY_BTN_TOOL_FINGER ||
                 code == HY_BTN_TOOL_DOUBLE)) {
                args->skip_origin = 1;
                args->ret = 0;
                g_ti_protects++;
                return;
            }
        }

        /*
         * 【v1.73.0】BTN_TOOL_FINGER 能力位自学习。
         * 参考实现用 test_bit(BTN_TOOL_FINGER, dev->keybit) 判断要不要发；
         * KPM 读不到 keybit，退而求其次：物理驱动自己发过这个码，
         * 就说明设备支持。
         */
        if (type == HY_EV_KEY && code == HY_BTN_TOOL_FINGER)
            g_has_tool_finger = true;

        if (type == HY_EV_ABS) {
            int v = (int)args->args[3];

            /* 驱动切换槽位：记下来 */
            if (code == HY_ABS_MT_SLOT) {
                /* v1.77.0：驱动自己发过 SLOT -> Protocol B */
                g_mt_seen_slot = true;
                /* 学习物理驱动占用的最大槽位，用于推算有效虚拟起点 */
                if (g_learn_enabled && v > g_max_drv_slot)
                    g_max_drv_slot = v;
                g_drv_slot = v;
                /*
                 * v1.58.0 secure inject：跟踪物理驱动的当前槽位。
                 * 只记不拦 —— 我们不再抢它的槽，而是找它没在用的空槽注入。
                 */
                if (g_injecting == 0 && v >= 0 && v < TI_MAX_SLOTS) {
                    g_ti_cur_slot = v;
                    /* 用过的最大槽位 +1 就是总槽位数的下界，据此收敛上限 */
                    if (v + 1 > g_ti_max_slots && v + 1 <= TI_MAX_SLOTS)
                        g_ti_max_slots = v + 1;
                }
                /*
                 * 它想用我们保留给虚拟手指的槽位 —— 直接丢掉这次切换。
                 * 这样物理手指永远拿不到这些槽，虚拟滑动就不会被打断。
                 * 这是 ls hijack_init_slots() 的等价替代：ls 靠截断
                 * mt->num_slots 实现（要结构体偏移，KPM 拿不到），
                 * 我们在 input_event 这一层拦，效果一样但零偏移依赖。
                 */
                if (g_grab_slots && v >= hy_eff_slot_base()) {
                    args->skip_origin = 1;
                    args->ret = 0;
                    g_slots_dropped++;
                    return;
                }
            } else if (g_grab_slots && g_drv_slot >= hy_eff_slot_base()) {
                /* 槽位还停在我们地盘上，后续的坐标/压力事件也一并丢 */
                args->skip_origin = 1;
                args->ret = 0;
                g_slots_dropped++;
                return;
            }

            /*
             * v1.58.0 secure inject：维护"物理手指占用槽位"位图。
             * 这是整个方案的核心数据 —— 有了它才能挑出真手指没在用的空槽，
             * 从而做到"不抢、不冲突、系统看不出异常"。
             *   TRACKING_ID >= 0 → 该槽有真手指按下
             *   TRACKING_ID == -1 → 该槽真手指抬起
             * 自己注入的事件必须跳过（g_injecting），否则会污染位图。
             */
            if (g_injecting == 0 && code == HY_ABS_MT_TRACKING_ID) {
                int s = g_ti_cur_slot;
                if (s >= 0 && s < TI_MAX_SLOTS) {
                    if (v >= 0) {
                        int fid;
                        ti_set(s);
                        /*
                         * 【v1.76.0 多指】真手指占了某根虚拟手指的槽 ——
                         * 只让那一根失效，不影响其它手指。绝不相争：
                         * 不发任何事件，因为它马上要用这个槽写自己的
                         * TRACKING_ID，我们抢着发只会互相打架。
                         */
                        ti_lock();
                        fid = ti_finger_by_slot(s);
                        if (fid >= 0) {
                            g_ti_f[fid].active = 0;
                            g_ti_f[fid].slot   = -1;
                            g_ti_conflicts++;
                            if (ti_virt_count() == 0) {
                                g_ti_state    = TI_CONFLICTED;
                                g_ti_inj_slot = -1;
                                g_ti_last_id  = -1;
                            }
                        }
                        /* 真手指变多导致总量超额 —— 释放多余的虚拟手指 */
                        ti_shrink_for_real();
                        ti_unlock();
                    } else {
                        ti_clear(s);
                    }
                }
            }

            /* 分辨率自学习：真实驱动报过的最大坐标就是屏幕上限。
             * 比读 absinfo 安全得多 —— 不需要任何结构体偏移。
             * v1.58.0：注入中的事件不算，否则虚拟坐标会被当成屏幕上限。 */
            if (g_injecting == 0) {
                /* v1.77.0：见过 MT 坐标/TRACKING_ID 即证明多指能力存在 */
                if (code == HY_ABS_MT_POSITION_X ||
                    code == HY_ABS_MT_POSITION_Y ||
                    code == HY_ABS_MT_TRACKING_ID)
                    g_mt_seen_mt = true;

                if (code == HY_ABS_MT_POSITION_X || code == HY_ABS_X) {
                    if (v > g_seen_max_x) g_seen_max_x = v;
                    /* v1.73.0：下限同样要学，少数屏不从 0 起 */
                    if (v < g_seen_min_x) g_seen_min_x = v;
                } else if (code == HY_ABS_MT_POSITION_Y || code == HY_ABS_Y) {
                    if (v > g_seen_max_y) g_seen_max_y = v;
                    if (v < g_seen_min_y) g_seen_min_y = v;
                }
            }
        }
    }

    /*
     * 【发热优化 v1.34.0】锁定之后本回调无事可做。
     * 早退放在登记表扫描之前 —— input_event 是极高频回调
     * （实测开机即上万次），每次线性扫表是纯粹的浪费。
     */
    if (g_real_found) return;

    /*
     * 【v1.56.0 修复】节能期间改为**降频采样**，不再完全停止观测。
     *
     * 旧写法是 `if (hy_pm_is_saving()) return;` —— 彻底停止。
     * 实测后果（用户 v1.55 日志）：
     *   命令进来时 hy_pm_touch() 唤醒一次 → 登记到 1 个设备；
     *   50 秒后重新进入 SAVING → 此后所有 input_event 直接丢弃；
     *   于是登记表永远停在 seen=1，三项证据永远凑不齐，
     *   found 恒为 0，真实触摸屏永远锁不上。
     *   （实测 input_event# 涨到 16714，seen/found 却卡在 1/0）
     *   连带 max drv slot / learn resolv 也全是初值 —— 因为那段
     *   自学习代码在 `g_real_found && dev == g_real_dev` 里，
     *   没锁定就根本进不去。
     *
     * 现在：节能期间每 64 个事件只处理 1 个。
     * 开销降到 1/64（可忽略），但仍能保证最终凑齐三项证据并锁定。
     */
    if (hy_pm_is_saving() && (g_ie_events & 63) != 0) return;

    /* 先登记，无论后面是否锁定 */
    hy_dev_note(dev);

    /*
     * 【v1.34.0 主路径】三项证据凑齐即刻锁定。
     * 对应 ls 的 test_bit(EV_ABS) && test_bit(ABS_MT_SLOT)
     *       && test_bit(BTN_TOUCH) && input->mt
     * 全程不看设备名、不依赖任何结构体偏移。
     */
    if (hy_dev_mark(dev, type, code)) {
        g_real_dev = dev;
        g_real_found = true;
        /*
         * 锁定瞬间用自学习到的坐标上限校正屏幕尺寸。
         * 之前 g_max_x/g_max_y 是写死的 1080x2400，
         * 跟真机对不上时注入的坐标会被裁掉。
         */
        /* v1.79.0：手设过范围就不再用自学值覆盖 */
        if (!g_range_manual) {
            if (g_seen_max_x > 0) g_max_x = g_seen_max_x + 1;
            if (g_seen_max_y > 0) g_max_y = g_seen_max_y + 1;
            if (g_seen_min_x != 0x7fffffff) g_min_x = g_seen_min_x;
            if (g_seen_min_y != 0x7fffffff) g_min_y = g_seen_min_y;
        }
        HY_LOG("input: HIJACK by ls-criteria (ABS+BTN_TOUCH+MT) dev=%llx\n",
               (u64)dev);
        return;
    }

    /*
     * v1.27.0：不再限定必须是 EV_ABS 才能按名锁定。
     * 只要登记过名字、且名字匹配，任何事件都能触发锁定
     * —— 这样才能在没有真实触摸的情况下锁定触摸屏。
     */
    if (g_want_name[0]) {
        const char *devname;

        if (!hy_lkaddr_ok(dev)) return;
        devname = *(const char *const *)dev;
        if (!hy_name_safe(devname)) return;   /* v1.73.3：不再走页表遍历 */

        if (hy_lstrstr(devname, g_want_name)) {
            g_real_dev = dev;
            g_real_found = true;
            HY_LOG("input: touchscreen locked by name \"%s\" dev=%llx\n",
                   g_want_name, (u64)dev);
        }
        return;
    }

    if (type != HY_EV_ABS) return;

    /*
     * 两种锁定方式：
     *
     * A) 指定了设备名（用户态从 /proc/bus/input/devices 读到 Name=）：
     *    任何 EV_ABS 事件都拿 dev->name 比对，命中即锁定。
     *    【不需要等用户真手指触摸】—— 只要该设备有任何活动即可。
     *
     * B) 未指定名字：保持原逻辑，必须等真实多点触摸事件
     *    （ABS_MT_POSITION_X / Y），才敢认定这是触摸屏。
     */
    if (g_want_name[0]) {
        const char *devname;

        /*
         * struct input_dev 的第一个成员就是 const char *name，
         * 从 4.x 到 6.x 一直是 offset 0（非常稳定）。
         * 读之前先确认 dev 本身落在内核地址空间，避免野指针。
         */
        if (!hy_lkaddr_ok(dev)) return;
        devname = *(const char *const *)dev;
        if (!hy_name_safe(devname)) return;   /* v1.73.3：不再走页表遍历 */

        if (hy_lstrstr(devname, g_want_name)) {
            g_real_dev = dev;
            g_real_found = true;
            HY_LOG("input: touchscreen locked by name \"%s\" dev=%llx\n",
                   g_want_name, (u64)dev);
        }
        return;
    }

    if (code == HY_ABS_MT_POSITION_X || code == HY_ABS_MT_POSITION_Y) {
        g_real_dev = dev;
        g_real_found = true;
        HY_LOG("input: touchscreen discovered dev=%llx\n", (u64)dev);
    }
}

static void hy_probe_hook_install(void);   /* v1.22.0 前向声明 */
static void hy_probe_hook_remove(void);    /* v1.64.0：方案切换时要重装 */
static void *hy_hijack_try(void);            /* v1.31.0 抢夺真实触摸屏 */

/* 设置期望的触摸屏名字 —— v1.28.0：设完立即主动枚举，不等事件 */
int hy_touch_set_name(const char *name)
{
    if (!name) return -EINVAL;
    hy_memset(g_want_name, 0, sizeof(g_want_name));
    hy_lstrscpy(g_want_name, name, sizeof(g_want_name));
    HY_LOG("input: want touchscreen name=\"%s\"\n", g_want_name);

    /*
     * 【v1.29.0】改为在【已登记设备表】里查找，不再做启发式扫描。
     * 表里的 dev 指针全部来自真实 input_event 调用，绝对有效、零风险。
     * 若表为空（该设备尚无活动），返回 -ENOENT，调用方再触发一次触摸即可。
     */
    {
        int i;
        for (i = 0; i < g_seen_count; i++) {
            if (g_seen[i].name[0] && hy_lstrstr(g_seen[i].name, g_want_name)) {
                g_real_dev   = g_seen[i].dev;
                g_real_found = true;
                HY_LOG("input: touchscreen LOCKED \"%s\" dev=%llx\n",
                       g_seen[i].name, (u64)g_seen[i].dev);
                return 0;
            }
        }
        HY_LOG("input: \"%s\" not in seen table (%d dev) - "
               "touch the screen once, or add tscan=1\n",
               g_want_name, g_seen_count);
    }
    return 0;
}

/* 重新扫描：清空已发现状态，重新主动枚举 + 重挂探测 hook */
int hy_touch_rescan(void)
{
    g_real_found = false;
    g_real_dev = NULL;

    if (g_want_name[0]) {
        int i;
        for (i = 0; i < g_seen_count; i++) {
            if (g_seen[i].name[0] && hy_lstrstr(g_seen[i].name, g_want_name)) {
                g_real_dev   = g_seen[i].dev;
                g_real_found = true;
                HY_LOG("input: rescan locked \"%s\" dev=%llx\n",
                       g_seen[i].name, (u64)g_seen[i].dev);
                break;
            }
        }
    }
    if (!g_real_found && g_tscan_enabled)
        hy_input_find_by_name(g_want_name[0] ? g_want_name : NULL, NULL, 0);

    hy_probe_hook_install();   /* 事件兜底：万一后面有新设备 */
    hy_hijack_try();           /* v1.31.0 抢夺：名字→MT证据→关键词 */
    HY_LOG("input: rescan done (found=%d)\n", (int)g_real_found);
    return 0;
}

static void hy_ie_before_iev(hook_fargs4_t *args, void *udata)
{
    g_ie_hits_iev++;
    hy_ie_common(args, udata);
}

static void hy_ie_before_ihe(hook_fargs4_t *args, void *udata)
{
    g_ie_hits_ihe++;
    hy_ie_common(args, udata);
}

static void hy_probe_hook_install(void)
{
    if (g_real_found) return;

    /*
     * v1.64.0：挂哪些点由观察点档位决定。
     *
     *   handle_event(6 系)：两个点都挂。GKI+LTO 上 input_event 常被内联，
     *       只挂它会收不到触摸屏事件（v1.58 之前 found 恒为 0 的真因），
     *       但 input_handle_event 也不是万能，两个都挂、谁先看到 EV_ABS 用谁。
     *   其余档：只挂 input_event。档位越低挂的点越少，高级档出问题时
     *       降级能立刻收窄怀疑范围，而不是继续在原地打转。
     *   count-only(3 系)：仍要挂 hook，否则连计数都没有；但注入被门控关闭。
     */
    if (!g_probe_hooked && hy_f_input_event) {
        if (hook_wrap4((void *)hy_f_input_event,
                       hy_ie_before_iev, NULL, NULL) == 0) {
            g_probe_hooked = true;
            HY_LOG("input: probe hook installed on input_event\n");
        } else {
            HY_LOG("input: probe hook failed on input_event (non-fatal)\n");
        }
    }

    /*
     * v1.59.0：第二个观察点。KernelPatch 官方拦截音量键用的就是
     * input_handle_event，而不是 input_event —— 在 GKI+LTO 上它更可靠。
     * 两个都挂，哪个先看到 EV_ABS 就用哪个的结果，信号不会丢。
     */
    if (g_observer_kind == HY_IN_HANDLE_EVENT && hy_f_input_handle_event &&
        !g_probe_hooked_ihe) {
        if (hook_wrap4((void *)hy_f_input_handle_event,
                       hy_ie_before_ihe, NULL, NULL) == 0) {
            g_probe_hooked_ihe = true;
            HY_LOG("input: probe hook installed on input_handle_event\n");
        } else {
            HY_LOG("input: probe hook failed on input_handle_event (non-fatal)\n");
        }
    }
}

static void hy_probe_hook_remove(void)
{
    /*
     * 【v1.21.0】原来用 unhook(func) —— 它卸载的是该地址上的整个 hook
     * 结构（hook_uninstall + hook_mem_free），不区分是谁装的。
     * 而装载用的是 hook_wrap4(..., before, NULL, NULL)，
     * 配套的反操作应是 hook_unwrap(..., before, after) 精确移除自己那条。
     * 统一为 hook_unwrap，避免误伤同一地址上其它模块的 hook。
     */
    if (g_probe_hooked) {
        hook_unwrap((void *)hy_f_input_event, hy_ie_before_iev, NULL);
        g_probe_hooked = false;
    }
    if (g_probe_hooked_ihe) {
        hook_unwrap((void *)hy_f_input_handle_event, hy_ie_before_ihe, NULL);
        g_probe_hooked_ihe = false;
    }
    HY_LOG("input: probe hook removed\n");
}

/* ===================================================================
 * 路径 B：自建设备（必须设置 absinfo！）
 * =================================================================== */
static void *hy_create_own_dev(void)
{
    void *dev;

    if (!hy_f_input_allocate_device || !hy_f_input_register_device)
        return NULL;

    dev = hy_f_input_allocate_device();
    if (!dev) return NULL;

    if (hy_f_input_set_capability) {
        hy_f_input_set_capability(dev, HY_EV_SYN, HY_SYN_REPORT);
        hy_f_input_set_capability(dev, HY_EV_KEY, HY_BTN_TOUCH);
        hy_f_input_set_capability(dev, HY_EV_KEY, HY_BTN_TOOL_FINGER);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_X);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_Y);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_MT_SLOT);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_MT_POSITION_X);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_MT_POSITION_Y);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_MT_TRACKING_ID);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_MT_TOUCH_MAJOR);
        hy_f_input_set_capability(dev, HY_EV_ABS, HY_ABS_MT_PRESSURE);
    }

    /*
     * ★★★ 最关键的一步 ★★★
     * 不设置 absinfo，内核 input_handle_abs_event() 会把所有 ABS
     * 的 value 清零，上报出去的坐标永远是 (0,0)。
     */
    if (hy_f_input_set_abs_params) {
        hy_f_input_set_abs_params(dev, HY_ABS_X, 0, g_max_x, 0, 0);
        hy_f_input_set_abs_params(dev, HY_ABS_Y, 0, g_max_y, 0, 0);
        hy_f_input_set_abs_params(dev, HY_ABS_MT_POSITION_X, 0, g_max_x, 0, 0);
        hy_f_input_set_abs_params(dev, HY_ABS_MT_POSITION_Y, 0, g_max_y, 0, 0);
        hy_f_input_set_abs_params(dev, HY_ABS_MT_SLOT, 0, HY_MAX_SLOTS - 1, 0, 0);
        hy_f_input_set_abs_params(dev, HY_ABS_MT_TRACKING_ID, 0, 65535, 0, 0);
        hy_f_input_set_abs_params(dev, HY_ABS_MT_TOUCH_MAJOR, 0, 255, 0, 0);
        hy_f_input_set_abs_params(dev, HY_ABS_MT_PRESSURE, 0, 255, 0, 0);
    } else {
        HY_LOG("input: WARN input_set_abs_params missing -> coords forced to 0\n");
    }

    /* 建立多点槽位。flags 不含 DROP_UNUSED，避免未更新的槽位被丢弃 */
    if (hy_f_input_mt_init_slots)
        hy_f_input_mt_init_slots(dev, HY_MAX_SLOTS, 0);

    if (hy_f_input_register_device(dev) != 0) {
        if (hy_f_input_free_device) hy_f_input_free_device(dev);
        return NULL;
    }
    return dev;
}

/* ===================================================================
 * 初始化 / 退出
 * =================================================================== */

/* ==================== v1.55.0 运行时开关（不再需要重新加载） ====================
 *
 * 为什么必须有它：
 *   v1.54.0 的 "touch on" 只写了 hy_opt_probe 变量，而 probe hook 的
 *   安装只发生在 hy_input_init() 里 —— 模块加载之后就再也不会执行了。
 *   于是命令回 OK、实际什么都没装：devices seen 永远 0、probe hook 永远 off。
 *
 * 这里把"改变量"和"真的装/卸 hook"绑在一起，命令一进来立刻生效。
 * 拆成 probe / tscan 两级，是为了能分开验证崩点：
 *   probe 只装一个只读 before 回调（安全）
 *   tscan 会遍历 input_class 下所有设备（历史崩点）
 */
int hy_input_runtime_enable(int probe_on, int tscan_on)
{
    int rc = 0;

    /* ---- 事件探测 hook ---- */
    if (probe_on >= 0) {
        if (probe_on) {
            g_probe_enabled = 1;
            hy_opt_probe    = 1;
            if (!g_probe_hooked) {
                if (!hy_f_input_event) {
                    HY_LOG("input: runtime probe - input_event NOT FOUND\n");
                    rc = -1;
                } else {
                    hy_probe_hook_install();
                    if (!g_probe_hooked) {
                        /*
                         * 当前观察点档挂不上：降到下一档再试一次。
                         * 降档单调向前，最多把剩下的档走完就停，不会转圈。
                         * 这里在 runtime_enable 里做而不是在 apply 里做，
                         * 是因为 apply 正被 sel_pick_from 调用，
                         * 在里面再调 hy_scheme_fail 会变成自递归。
                         */
                        if (hy_scheme_fail(HY_SC_INPUT) >= 0) {
                            HY_LOG("input: probe demoted to %s, retry\n",
                                   hy_scheme_name(HY_SC_INPUT));
                            hy_probe_hook_install();
                        }
                        if (!g_probe_hooked) {
                            HY_LOG("input: runtime probe hook FAILED\n");
                            rc = -1;
                        } else {
                            HY_LOG("input: runtime probe hook installed"
                                   " on %s\n", hy_scheme_name(HY_SC_INPUT));
                        }
                    } else {
                        HY_LOG("input: runtime probe hook installed\n");
                    }
                }
            }
        } else {
            g_probe_enabled = 0;
            hy_opt_probe    = 0;
            hy_probe_hook_remove();
        }
    }

    /* ---- 主动枚举 ---- */
    if (tscan_on >= 0) {
        g_tscan_enabled = tscan_on ? 1 : 0;
        hy_opt_tscan    = tscan_on ? 1 : 0;
        if (tscan_on) {
            if (hy_f_class_for_each_device && hy_input_class) {
                HY_LOG("input: runtime enum ENABLED\n");
                hy_input_find_by_name(g_want_name[0] ? g_want_name : NULL,
                                      NULL, 0);
                HY_LOG("input: runtime enumerated %d device(s)\n", g_seen_count);
            } else {
                HY_LOG("input: runtime enum unavailable "
                       "(class_for_each_device/input_class missing)\n");
                rc = -1;
            }
        }
    }

    /* 已有登记设备就顺手锁定一次，但不主动创建任何设备 */
    if (!g_real_found && g_seen_count > 0)
        hy_hijack_try();

    return rc;
}

int hy_input_runtime_state(int *probe_on, int *tscan_on, int *hooked,
                           int *seen, int *found)
{
    if (probe_on) *probe_on = g_probe_enabled ? 1 : 0;
    if (tscan_on) *tscan_on = g_tscan_enabled ? 1 : 0;
    if (hooked)   *hooked   = g_probe_hooked  ? 1 : 0;
    if (seen)     *seen     = g_seen_count;
    if (found)    *found    = g_real_found ? 1 : 0;
    return 0;
}

int hy_input_init(void)
{
    hy_f_input_allocate_device = (typeof(hy_f_input_allocate_device))
        hy_lookup_generic("input_allocate_device");
    hy_f_input_free_device = (typeof(hy_f_input_free_device))
        hy_lookup_generic("input_free_device");
    hy_f_input_register_device = (typeof(hy_f_input_register_device))
        hy_lookup_generic("input_register_device");
    hy_f_input_unregister_device = (typeof(hy_f_input_unregister_device))
        hy_lookup_generic("input_unregister_device");
    hy_f_input_event = (typeof(hy_f_input_event))
        hy_lookup_generic("input_event");
    /* v1.59.0：第二观察点（见上方 hy_f_input_handle_event 声明处注释） */
    hy_f_input_handle_event = (typeof(hy_f_input_handle_event))
        hy_lookup_generic("input_handle_event");
    hy_f_input_set_capability = (typeof(hy_f_input_set_capability))
        hy_lookup_generic("input_set_capability");
    hy_f_input_set_abs_params = (typeof(hy_f_input_set_abs_params))
        hy_lookup_generic("input_set_abs_params");
    hy_f_input_mt_init_slots = (typeof(hy_f_input_mt_init_slots))
        hy_lookup_generic("input_mt_init_slots");

    /*
     * 【v1.29.0 修正】v1.28.0 在这里多解了一层引用，导致加载即炸内核。
     *
     * Linux 内核源码 fs/... / drivers/input/input.c 里是这么定义的：
     *     struct class input_class = { .name = "input", ... };
     *     EXPORT_SYMBOL_GPL(input_class);
     *
     * 也就是说 kallsyms 返回的 sym 就是 struct class 的【基地址本身】，
     * 不是指向它的指针。lsdriver 原版也是直接把它当指针用：
     *     struct class *input_class =
     *         (struct class *)generic_kallsyms_lookup_name("input_class");
     *
     * v1.28.0 写了 *(void **)sym，读出来的是 struct class 的【首成员】
     * —— 也就是字符串 "input" 的地址 —— 然后把它当 class 指针传给
     * class_for_each_device，遍历的是完全错乱的内存，必炸。
     *
     * 现在与 ls 原版对齐：直接用 sym，不解引用。
     */
    {
        unsigned long sym = hy_lookup_generic("input_class");
        if (sym && hy_lkaddr_ok((void *)sym)) {
            hy_input_class = (void *)sym;
            HY_LOG("input: input_class=%llx\n", (u64)sym);
        } else {
            HY_LOG("input: input_class NOT FOUND\n");
        }

        hy_f_class_for_each_device = (hy_cfed_t)
            hy_lookup_generic("class_for_each_device");
        HY_LOG("input: class_for_each_device=%s\n",
               hy_f_class_for_each_device ? "ok" : "NOT FOUND");

        if (!hy_input_class || !hy_f_class_for_each_device)
            HY_LOG("input: active enum unavailable, using event probe only\n");
    }

    g_own_dev = NULL;
    g_real_dev = NULL;
    g_real_found = false;
    g_touch_ready = false;
    g_probe_hooked = false;
    g_injecting = 0;
    g_gyro_active = false;
    g_gyro_hooked = false;
    hy_memset(g_slot_down, 0, sizeof(g_slot_down));
    hy_memset(g_slot_track, 0, sizeof(g_slot_track));

    /* v1.29.0：主动枚举开关，默认关闭 */
    g_tscan_enabled = hy_opt_tscan ? 1 : 0;

    /* 陀螺仪：hook sendto（arm64 __NR_sendto = 206） */
    if (hook_syscalln(206, 6, hy_gyro_sendto_before, NULL, NULL) == 0) {
        g_gyro_hooked = true;
        HY_LOG("input: gyro sendto hook installed\n");
    } else {
        HY_LOG("input: gyro sendto hook failed (non-fatal)\n");
    }

    /*
     * 【v1.27.0】init 阶段就装探测 hook，不等 touch_init。
     * 之前只有调用 touch_init 才装，而很多调用方直接 touch_down，
     * 于是 g_real_found 永远是 false，只能用单点自建设备。
     */
    /*
     * 【v1.30.0】init 阶段【不装探测 hook、不创建设备】。
     *
     * v1.27~v1.29 在 init 里就 g_own_dev = hy_create_own_dev()，
     * 这会调 input_allocate_device / input_set_abs_params /
     * input_mt_init_slots / input_register_device。这些函数全是
     * kallsyms 解析 + 自声明原型（KPM 无完整 input 头文件），
     * 任一签名对不上就是崩；且 input_register_device 会触发
     * sysfs 新增设备、惊动 EventHub 重扫，在加载路径里风险极高。
     * 现场现象：加载即炸。
     *
     * 现改为【按需创建】：首次 touch_down/move/up 才建。
     */
    g_no_own_dev  = hy_opt_noowndev;
    g_probe_enabled = hy_opt_probe;
    g_grab_slots    = hy_opt_grab ? true : false;

    if (g_probe_enabled && hy_f_input_event) {
        hy_probe_hook_install();
        HY_LOG("input: probe hook installed\n");
    } else {
        HY_LOG("input: probe hook disabled (add probe=1 to enable)\n");
    }

    /*
     * 【v1.32.0】init 阶段做一次【无名字】枚举，把设备名全部登记进表。
     *
     * v1.28 在这里做导致炸，真因是 hy_dev_to_input 的启发式扫描
     * 会【跨页】读到未映射内存。现在 hy_scan_limit() 把扫描钳制在
     * 当前页内，永不跨页 —— dev 所在页必然已映射，故绝对安全。
     *
     * 这样一加载 devices seen 就有内容，用户能直接挑名字锁定，
     * 不必先摸屏幕。
     */
    HY_LOG("input: alloc=%d reg=%d event=%d cap=%d abs=%d mt=%d\n",
           !!hy_f_input_allocate_device, !!hy_f_input_register_device,
           !!hy_f_input_event, !!hy_f_input_set_capability,
           !!hy_f_input_set_abs_params, !!hy_f_input_mt_init_slots);

    /*
     * 【v1.29.0】主动枚举默认【关闭】，必须显式加加载参数 tscan=1。
     *
     * 原因：hy_dev_to_input() 需要对每个 device 向前扫描 256 次并逐字节
     * 验证字符串，而 hy_lkaddr_ok() 只能判断地址落在内核范围，
     * 【不能】保证该地址已映射。class 下任意一个设备都可能让扫描
     * 踩到未映射的空洞 → 立即 oops。v1.28.0 就是在这一步炸的。
     *
     * 默认走安全的事件探测路径（v1.27 行为），dev 指针来自真实的
     * input_event 调用，绝对有效、零风险。
     */
    if (g_tscan_enabled && hy_f_class_for_each_device && hy_input_class) {
        HY_LOG("input: active enum ENABLED (tscan=1)\n");
        hy_input_find_by_name(NULL, NULL, 0);
        HY_LOG("input: enumerated %d input device(s)\n", g_seen_count);
    } else {
        HY_LOG("input: active enum disabled (add tscan=1 to enable)\n");
    }

    HY_LOG("input: probe=%d own_dev=%d\n", (int)g_probe_hooked, !!g_own_dev);

    return hy_f_input_event ? 0 : -ENODEV;
}

void hy_input_exit(void)
{
    /* 先摘 hook，顺序很重要：残留 hook 指向已释放模块 = 必崩 */
    if (g_gyro_hooked) {
        unhook_syscalln(206, hy_gyro_sendto_before, NULL);
        g_gyro_hooked = false;
    }
    hy_probe_hook_remove();

    if (g_own_dev && hy_f_input_unregister_device)
        hy_f_input_unregister_device(g_own_dev);
    g_own_dev = NULL;
    g_real_dev = NULL;
    g_real_found = false;
    g_touch_ready = false;
    g_gyro_active = false;
    HY_LOG("input: exit\n");
}

/* ===================================================================
 * 触摸
 * =================================================================== */
/*
 * ==========================================================================
 * 【v1.31.0】抢夺（hijack）优先
 *
 * 用户诉求：先抢真实触摸屏，抢不到才启用自建设备。
 * 原因很实在 —— 自建设备是系统里【多出来】的一个输入设备，
 * 安全检测 / 反作弊很容易把它识别成异常触摸点；
 * 而真实触摸屏是系统本来就有的，注入的事件和真手指完全 indistinguishable。
 *
 * 抢夺判据按可靠度排序：
 *   1) 名字匹配用户指定的 g_want_name（用户态从 /proc/bus/input/devices 拿到）
 *   2) is_mt —— 该设备真的上报过 ABS_MT_POSITION_X/Y（最硬的证据）
 *   3) 名字含触屏驱动常见关键词（goodix/fts/synaptics/...）
 *
 * 全部失败 → 返回 NULL，由调用方决定是否回落自建设备。
 * ========================================================================== */
static const char *const hy_ts_keywords[] = {
    "touch", "ts", "tp", "ft", "fts", "goodix", "gt", "synaptics",
    "himax", "hx", "novatek", "nt", "ilitek", "atmel", "focaltech",
    "cypress", "elan", "melfas", "sec_touch", "panel", 0
};

static void *hy_hijack_try(void)
{
    int i, k;

    /* 已经锁定了就直接返回 */
    if (g_real_found && g_real_dev) return g_real_dev;

    /* 判据 1：用户指定名字 */
    if (g_want_name[0]) {
        for (i = 0; i < g_seen_count; i++) {
            if (!g_seen[i].dev || !g_seen[i].name[0]) continue;
            if (hy_lstrstr(g_seen[i].name, g_want_name)) {
                g_real_dev = g_seen[i].dev;
                g_real_found = true;
                HY_LOG("input: HIJACK by name \"%s\" dev=%llx\n",
                       g_seen[i].name, (u64)g_real_dev);
                return g_real_dev;
            }
        }
    }

    /* 判据 2【v1.34.0 新增】：ls match_touchscreen 的行为等价判定
     *   三项同时观测到 = EV_ABS 能力 + BTN_TOUCH 键 + 多点协议，
     *   完全对应 ls 的 test_bit(EV_ABS) && test_bit(ABS_MT_SLOT)
     *          && test_bit(BTN_TOUCH) && input->mt
     * 这是【不依赖设备名】识别真实触摸屏的主路径。 */
    for (i = 0; i < g_seen_count; i++) {
        if (!g_seen[i].dev) continue;
        if (!hy_seen_is_touchscreen(&g_seen[i])) continue;
        g_real_dev = g_seen[i].dev;
        g_real_found = true;
        HY_LOG("input: HIJACK by ls-criteria (ABS+BTN_TOUCH+MT) \"%s\" dev=%llx\n",
               g_seen[i].name, (u64)g_real_dev);
        return g_real_dev;
    }

    /* 判据 3：真的上报过多点坐标（宽松兜底，只有 MT 一项证据） */
    for (i = 0; i < g_seen_count; i++) {
        if (!g_seen[i].dev || !g_seen[i].is_mt) continue;
        g_real_dev = g_seen[i].dev;
        g_real_found = true;
        HY_LOG("input: HIJACK by MT evidence \"%s\" dev=%llx\n",
               g_seen[i].name, (u64)g_real_dev);
        return g_real_dev;
    }

    /* 判据 4：名字关键词 */
    for (i = 0; i < g_seen_count; i++) {
        if (!g_seen[i].dev || !g_seen[i].name[0]) continue;
        for (k = 0; hy_ts_keywords[k]; k++) {
            if (hy_lstrstr(g_seen[i].name, hy_ts_keywords[k])) {
                g_real_dev = g_seen[i].dev;
                g_real_found = true;
                HY_LOG("input: HIJACK by keyword \"%s\" dev=%llx\n",
                       g_seen[i].name, (u64)g_real_dev);
                return g_real_dev;
            }
        }
    }

    return NULL;
}

/*
 * 【v1.30.1】只读版本：只返回【已存在】的设备，绝不创建。
 *
 * 诊断路径（/proc/huanyu 的 show）必须用这个。
 * v1.30.0 里 hy_input_active_name() 走了会创建的版本，
 * 于是 cat /proc/huanyu 反而触发 hy_create_own_dev()，
 * 直接炸内核 —— 这正是"读一下就重启"的原因。
 */
static void *hy_active_dev_ro(void)
{
    if (g_real_found && g_real_dev) return g_real_dev;
    return g_own_dev;
}

/* 注入路径：【先抢夺，抢不到才自建】 */
static void *hy_active_dev(void)
{
    /*
     * 【v1.31.0】抢夺优先。
     * 真实触摸屏是系统既有设备，注入事件与真手指无异，不会被
     * 安全检测当成异常触摸点；自建设备则是"多出来的"设备，容易被发现。
     */
    if (hy_hijack_try()) return g_real_dev;

    /*
     * 抢夺失败（登记表为空，或没有任何像触摸屏的设备）。
     * 这时才回落自建 —— 仍然保留 noowndev=1 作为总开关。
     */
    if (g_no_own_dev) {
        if (!g_own_dev_failed)
            HY_LOG("input: hijack failed, own dev disabled (noowndev=1)\n");
        g_own_dev_failed = true;
        return NULL;
    }
    if (!g_own_dev && !g_own_dev_failed) {
        HY_LOG("input: hijack failed, creating own dev as LAST RESORT\n");
        g_own_dev = hy_create_own_dev();
        if (!g_own_dev) {
            g_own_dev_failed = true;
            HY_LOG("input: own dev creation failed (non-fatal)\n");
        } else {
            HY_LOG("input: own dev created on demand\n");
        }
    }
    return g_own_dev;
}

int hy_touch_init(int mode)
{
    if (mode < 0 || mode > 1) return -EINVAL;
    if (g_touch_ready) return -524; /* EALREADY */

    g_touch_mode = mode;

    /*
     * 【v1.31.0】抢夺优先：先尽量把真实触摸屏拿到手。
     *
     * 探测 hook 是这里唯一的"眼睛" —— 它只 hook input_event 的
     * before 回调、读三个参数做登记，【不创建任何设备】，
     * 所以无条件装是安全的（危险的是创建设备，不是 hook 本身）。
     *
     * 装完之后立刻在已登记表里抢一次；抢不到也不在这里建自建设备，
     * 交由 hy_active_dev() 在真正下发事件时做【最后手段】。
     */
    hy_probe_hook_install();
    hy_hijack_try();

    if (!g_real_found && g_no_own_dev) {
        HY_LOG("input: touch init: no real dev yet, own dev disabled\n");
        return -ENODEV;
    }

    g_touch_ready = true;
    HY_LOG("input: touch ready mode=%d real=%d own=%d\n",
           mode, (int)g_real_found, !!g_own_dev);
    return 0;
}

/* 屏幕范围与槽位配置 */
int hy_touch_setup(int max_x, int max_y, int slot_base)
{
    if (max_x > 0 && max_x <= 65535) g_max_x = max_x;
    if (max_y > 0 && max_y <= 65535) g_max_y = max_y;
    if (slot_base >= 0 && slot_base < HY_MAX_SLOTS) g_slot_base = slot_base;

    /* 已建设备则同步更新范围 */
    if (g_own_dev && hy_f_input_set_abs_params) {
        hy_f_input_set_abs_params(g_own_dev, HY_ABS_X, 0, g_max_x, 0, 0);
        hy_f_input_set_abs_params(g_own_dev, HY_ABS_Y, 0, g_max_y, 0, 0);
        hy_f_input_set_abs_params(g_own_dev, HY_ABS_MT_POSITION_X, 0, g_max_x, 0, 0);
        hy_f_input_set_abs_params(g_own_dev, HY_ABS_MT_POSITION_Y, 0, g_max_y, 0, 0);
    }
    HY_LOG("input: setup max=%dx%d slot_base=%d\n", g_max_x, g_max_y, g_slot_base);
    return 0;
}

static int hy_emit(void *dev, int vslot, int x, int y, bool touching)
{
    int hw_slot;

    if (!dev || !hy_f_input_event) return -ENODEV;
    if (vslot < 0 || vslot >= HY_MAX_SLOTS) return -EINVAL;

    hw_slot = (g_real_found && g_real_dev) ? (hy_eff_slot_base() + vslot) : vslot;
    /*
     * 【v1.76.0】钳进驱动真实槽位范围，而不是 HY_MAX_SLOTS。
     *
     * 你这台 ABS_MT_SLOT 的 max 是 9（getevent 实测），而 hy_eff_slot_base()
     * 在 slotbase=5 / maxdrv=9 时会被抬到 10 —— 于是注入槽位落在 10..15，
     * 全部越过驱动上限，input core 直接丢弃，表现为"调了没反应"。
     * 现在按内核认定的总槽位数钳，事件才真的能发出去。
     */
    {
        /*
         * 【v1.80.0 真越界修复】
         *
         * 这里原先用的是 g_ti_max_slots，而容量/分配/让位三处在 v1.78.0
         * 已统一改用 ti_slot_limit()（以驱动真实上限为准）。口径不一致：
         *   g_ti_max_slots 会被自学习抬升（见到 slot=v 就抬到 v+1，上限
         *   TI_MAX_SLOTS=256），你这台驱动真实上限却是 10。
         * 于是 hw_slot = hy_eff_slot_base()(10) + vslot 可被钳到 15 ——
         * 依然越过驱动的 9，ABS_MT_SLOT 被 input core 静默忽略，坐标写进
         * "上一次选中的槽"，表现为手指乱跳 / 按了没反应。
         *
         * 现在与其余三处同源，一律 ti_slot_limit()。
         */
        int lim = ti_slot_limit();
        if (lim <= 0 || lim > TI_MAX_SLOTS) lim = TI_MAX_SLOTS;
        if (hw_slot >= lim) hw_slot = lim - 1;
        if (hw_slot < 0) hw_slot = 0;
    }

    g_injecting++;

    hy_f_input_event(dev, HY_EV_ABS, HY_ABS_MT_SLOT, hw_slot);
    hy_f_input_event(dev, HY_EV_ABS, HY_ABS_MT_TRACKING_ID,
               touching ? g_slot_track[vslot] : -1);

    if (touching) {
        hy_f_input_event(dev, HY_EV_ABS, HY_ABS_MT_POSITION_X, x);
        hy_f_input_event(dev, HY_EV_ABS, HY_ABS_MT_POSITION_Y, y);
        /* 伪造面积与压力：设备不支持的轴会被 input_event 静默丢弃，安全 */
        hy_f_input_event(dev, HY_EV_ABS, HY_ABS_MT_TOUCH_MAJOR, 10);
        hy_f_input_event(dev, HY_EV_ABS, HY_ABS_MT_WIDTH_MAJOR, 10);
        hy_f_input_event(dev, HY_EV_ABS, HY_ABS_MT_PRESSURE, 60);
    }

    /* 单点模式同步 ABS_X/ABS_Y，让单点映射器也能拿到坐标 */
    if (g_touch_mode == 0) {
        hy_f_input_event(dev, HY_EV_ABS, HY_ABS_X, x);
        hy_f_input_event(dev, HY_EV_ABS, HY_ABS_Y, y);
    }

    /* 全局按键：真实手指 + 虚拟手指的总数决定 BTN_TOUCH */
    {
        int i, count = 0;
        for (i = 0; i < HY_MAX_SLOTS; i++) if (g_slot_down[i]) count++;
        hy_f_input_event(dev, HY_EV_KEY, HY_BTN_TOUCH, count > 0);
        hy_f_input_event(dev, HY_EV_KEY, HY_BTN_TOOL_FINGER, count == 1);
        hy_f_input_event(dev, HY_EV_KEY, HY_BTN_TOOL_DOUBLE, count >= 2);
    }

    hy_f_input_event(dev, HY_EV_SYN, HY_SYN_REPORT, 0);

    g_injecting--;
    return 0;
}

/* ==========================================================================
 * v1.58.0  secure inject —— 注入原语
 *
 * 全部走 hy_f_input_event(g_real_dev, ...)：真实触摸屏节点出来的事件流，
 * 不新建设备、不改能力位。g_injecting 守卫确保我们自己的事件不会被
 * 回调当成"物理手指"记进位图，也不会污染自学习。
 * ========================================================================== */
static void ti_abs(unsigned int code, int value)
{
    if (!g_real_dev || !hy_f_input_event) return;
    hy_f_input_event(g_real_dev, HY_EV_ABS, code, value);
}
static void ti_key(unsigned int code, int value)
{
    if (!g_real_dev || !hy_f_input_event) return;
    hy_f_input_event(g_real_dev, HY_EV_KEY, code, value);
}
static void ti_syn(void)
{
    if (!g_real_dev || !hy_f_input_event) return;
    hy_f_input_event(g_real_dev, HY_EV_SYN, HY_SYN_REPORT, 0);
}
/* 0->1 边沿才发 BTN_TOUCH=1；1->0 边沿才发 BTN_TOUCH=0。
 * 这样真手指抬起时不会把虚拟手指一起带走（"打断"问题的正解）。 */
static void ti_touch_keys(int pressed)
{
    ti_key(HY_BTN_TOUCH, pressed ? 1 : 0);
    /*
     * 【v1.73.0】BTN_TOOL_FINGER 只在设备确实支持时才发。
     * 参考实现是 test_bit(BTN_TOOL_FINGER, dev->keybit)，KPM 读不到
     * keybit，改成"见过物理驱动自己发过这个码"才算支持。
     */
    if (g_has_tool_finger)
        ti_key(HY_BTN_TOOL_FINGER, pressed ? 1 : 0);
}

/*
 * 【v1.76.0】按下指定 id 的虚拟手指。
 *
 * 与旧版的三点区别：
 *   1) 不再"只有一根" —— 每根手指独立占槽，互不影响；
 *   2) 容量按 ti_capacity() 动态计算，真手指多了额度就少；
 *   3) 按下前先看 id 是否已按着，是则转为 move（幂等，符合直觉）。
 *
 * 槽位依然从高往低挑，绝不抢占真手指。
 */
int hy_ti_down_id(int id, int x, int y)
{
    int slot, first, cx, cy;
    unsigned int tid;

    if (!g_real_dev || !hy_f_input_event) return -ENODEV;
    if (!g_ti_inject_allowed) return -EACCES;   /* v1.75.0 注入总闸 */
    if (id < 0 || id >= TI_MAX_FINGERS) return -EINVAL;

    ti_lock();
    if (g_ti_state == TI_CONFLICTED) g_ti_state = TI_IDLE;

    /* 已按着 -> 转 move */
    if (g_ti_f[id].active) {
        ti_unlock();
        return hy_ti_move_id(id, x, y);
    }

    /* 动态容量：真手指 + 虚拟手指 不得超过驱动槽位总数 */
    if (ti_virt_count() + 1 > ti_capacity()) {
        g_ti_busy++;
        ti_unlock();
        return -EBUSY;
    }

    slot = ti_pick_free_slot();
    if (slot < 0) { g_ti_busy++; ti_unlock(); return -EBUSY; }

    /* 全场第一根手指才发 BTN_TOUCH=1（真手指与虚拟手指合计） */
    first = (ti_real_count() == 0 && ti_virt_count() == 0);

    cx = ti_clamp_axis(x, g_min_x, g_max_x);
    cy = ti_clamp_axis(y, g_min_y, g_max_y);
    g_ti_f[id].slot   = slot;
    g_ti_f[id].x      = cx;
    g_ti_f[id].y      = cy;
    g_ti_f[id].tid    = g_ti_tid++;
    g_ti_f[id].active = 1;
    tid = g_ti_f[id].tid;
    g_ti_last_id  = id;
    g_ti_inj_slot = slot;
    g_ti_state = TI_ACTIVE;
    ti_unlock();

    g_injecting++;
    if (hy_mt_proto() == 1) {
        /*
         * Protocol A：无槽位概念，整帧重报全部活跃触点。
         * 发 ABS_MT_SLOT 是没用的 —— 设备没有这个能力位，
         * input_get_disposition() 会把整条事件判为 INPUT_IGNORE_EVENT。
         */
        if (first) ti_touch_keys(1);
        ti_frame_a();
    } else {
        ti_abs(HY_ABS_MT_SLOT, slot);
        ti_abs(HY_ABS_MT_TRACKING_ID, (int)tid);
        ti_abs(HY_ABS_MT_POSITION_X, cx);
        ti_abs(HY_ABS_MT_POSITION_Y, cy);
        /* 面积/压力：设备不支持的轴会被 input_event 静默丢弃，安全 */
        ti_abs(HY_ABS_MT_TOUCH_MAJOR, 10);
        ti_abs(HY_ABS_MT_WIDTH_MAJOR, 10);
        ti_abs(HY_ABS_MT_PRESSURE, 60);
        if (first) ti_touch_keys(1);
        ti_syn();
    }
    g_injecting--;

    g_ti_downs++;
    return 0;
}

/* 按下：自动分配一个空闲 id（从 0 往上找） */
int hy_ti_down(int x, int y)
{
    int i, id = -1;

    ti_lock();
    for (i = 0; i < TI_MAX_FINGERS; i++) {
        if (!g_ti_f[i].active) { id = i; break; }
    }
    ti_unlock();

    if (id < 0) { g_ti_busy++; return -EBUSY; }
    return hy_ti_down_id(id, x, y);
}

/* 移动指定 id 的手指：沿用它的槽位，只更新坐标 */
int hy_ti_move_id(int id, int x, int y)
{
    int slot, cx, cy;

    if (!g_real_dev || !hy_f_input_event) return -ENODEV;
    if (!g_ti_inject_allowed) return -EACCES;
    if (id < 0 || id >= TI_MAX_FINGERS) return -EINVAL;

    ti_lock();
    if (!g_ti_f[id].active) { ti_unlock(); return -EINVAL; }
    slot = g_ti_f[id].slot;
    if (slot < 0) { ti_unlock(); return -EINVAL; }
    cx = ti_clamp_axis(x, g_min_x, g_max_x);
    cy = ti_clamp_axis(y, g_min_y, g_max_y);
    g_ti_f[id].x = cx;
    g_ti_f[id].y = cy;
    g_ti_last_id = id;
    ti_unlock();

    g_injecting++;
    if (hy_mt_proto() == 1) {
        ti_frame_a();      /* A 协议逐帧全量重报 */
    } else {
        ti_abs(HY_ABS_MT_SLOT, slot);
        ti_abs(HY_ABS_MT_POSITION_X, cx);
        ti_abs(HY_ABS_MT_POSITION_Y, cy);
        ti_syn();
    }
    g_injecting--;

    g_ti_moves++;
    return 0;
}

/* 移动：作用于最近一次操作的那根手指（兼容旧的单指调用） */
int hy_ti_move(int x, int y)
{
    int id;

    ti_lock();
    id = g_ti_last_id;
    ti_unlock();

    if (id < 0) return -EINVAL;
    return hy_ti_move_id(id, x, y);
}

/* 抬起指定 id：tracking_id = -1。真手指还在时不发 BTN_TOUCH=0 */
int hy_ti_up_id(int id)
{
    int slot, total_after;

    if (!g_real_dev || !hy_f_input_event) return -ENODEV;
    if (!g_ti_inject_allowed) return -EACCES;
    if (id < 0 || id >= TI_MAX_FINGERS) return -EINVAL;

    ti_lock();
    if (!g_ti_f[id].active) { ti_unlock(); return -EINVAL; }
    slot = g_ti_f[id].slot;
    g_ti_f[id].active = 0;
    g_ti_f[id].slot   = -1;
    if (g_ti_last_id == id) g_ti_last_id = -1;
    /* 全场最后一根手指抬起才发 BTN_TOUCH=0 */
    total_after = ti_real_count() + ti_virt_count();
    if (ti_virt_count() == 0) {
        g_ti_state = TI_IDLE;
        g_ti_inj_slot = -1;
    }
    ti_unlock();

    g_injecting++;
    if (hy_mt_proto() == 1) {
        /*
         * A 协议：这根手指已从 g_ti_f[] 中摘掉，重报整帧即可，
         * 帧里不再包含它；空帧会由 ti_frame_a 补一个 SYN_MT_REPORT。
         */
        if (total_after == 0) ti_touch_keys(0);
        ti_frame_a();
    } else {
        ti_abs(HY_ABS_MT_SLOT, slot);
        ti_abs(HY_ABS_MT_TRACKING_ID, -1);
        if (total_after == 0) ti_touch_keys(0);
        ti_syn();
    }
    g_injecting--;

    g_ti_ups++;
    return 0;
}

/*
 * 抬起全部虚拟手指。
 *
 * 旧版 up() 只抬一根（因为本来只能有一根）。多指化之后保留"不带 id
 * 就抬全部"的语义最安全 —— 调用方想清场时不会漏掉某根手指，而单指
 * 场景下的行为与旧版完全一致。
 */
int hy_ti_up(void)
{
    int i, n = 0;

    for (i = 0; i < TI_MAX_FINGERS; i++) {
        if (!g_ti_f[i].active) continue;
        if (hy_ti_up_id(i) == 0) n++;
    }
    return n ? 0 : -EINVAL;
}

/* 便捷入口：已按下则移动，否则按下 */
int hy_ti_down_or_move(int x, int y)
{
    int id;

    ti_lock();
    id = g_ti_last_id;
    ti_unlock();

    if (id >= 0 && g_ti_f[id].active) return hy_ti_move_id(id, x, y);
    return hy_ti_down(x, y);
}

/* 当前按着的虚拟手指数 / 动态容量 / 各手指槽位（供状态查询） */
int hy_ti_active_count(void) { return ti_virt_count(); }
int hy_ti_capacity(void)     { return ti_capacity(); }
int hy_ti_max_slots_for_cap(void) { return g_ti_max_slots; }
int hy_ti_last_finger(void)  { return g_ti_last_id; }
int hy_ti_finger_slot(int id)
{
    if (id < 0 || id >= TI_MAX_FINGERS) return -1;
    return g_ti_f[id].active ? g_ti_f[id].slot : -1;
}

/* 状态查询 */
void hy_ti_status(int *state, int *slot, int *max_slots, int *downs,
                  int *moves, int *ups, int *busy, int *conflicts)
{
    if (state)      *state      = g_ti_state;
    if (slot)       *slot       = g_ti_inj_slot;
    if (max_slots)  *max_slots  = g_ti_max_slots;
    if (downs)      *downs      = g_ti_downs;
    if (moves)      *moves      = g_ti_moves;
    if (ups)        *ups        = g_ti_ups;
    if (busy)       *busy       = g_ti_busy;
    if (conflicts)  *conflicts  = g_ti_conflicts;
}

/* v1.60.0：被拦下的"抹除虚拟手指"事件计数。
 * 这个数大于 0 就说明拦截真的在起作用 —— 它也是判断"注入后手指
 * 一闪就没"是否被修复的直接证据。 */
int hy_ti_protects(void) { return g_ti_protects; }

/* 手动设定总槽位数（自学习不可靠时用） */
int hy_ti_set_slots(int n)
{
    if (n < 1 || n > TI_MAX_SLOTS) return -EINVAL;
    g_ti_max_slots = n;
    return 0;
}

/*
 * 【v1.73.0】显式设定注入坐标范围。
 *
 * 内核默认是 1080x2400 加自学习 —— 遇到 1440p、曲面屏或者还没摸过屏
 * 的情况就会把坐标钳到错的边界。与其猜，让用户态明确告知。
 * 传 -1 表示该项不自设，沿用内核值。
 */
int hy_ti_set_range(int min_x, int max_x, int min_y, int max_y)
{
    ti_lock();
    if (min_x >= 0) g_min_x = min_x;
    if (max_x > 0)  g_max_x = max_x;
    if (min_y >= 0) g_min_y = min_y;
    if (max_y > 0)  g_max_y = max_y;
    if (g_max_x <= g_min_x) g_max_x = g_min_x + 1;
    if (g_max_y <= g_min_y) g_max_y = g_min_y + 1;
    /* v1.79.0：手设过就不再被自学习悄悄改回去 */
    g_range_manual = 1;
    ti_unlock();
    return 0;
}

/*
 * 【v1.73.1】读回当前坐标范围。
 *
 * 与 hy_ti_set_range() 配对。诊断用途：用户想知道内核从物理驱动自学
 * 到了什么样的分辨率，或者自己设的值有没有真的落进去。
 */
void hy_ti_get_range(struct hy_ti_range *r)
{
    if (!r) return;
    ti_lock();
    r->min_x = g_min_x;
    r->max_x = g_max_x;
    r->min_y = g_min_y;
    r->max_y = g_max_y;
    ti_unlock();
}

/* 【v1.73.0】一次取完 9 个状态字段 */
void hy_ti_stat_fill(struct hy_ti_stat *st)
{
    if (!st) return;
    ti_lock();
    st->state      = g_ti_state;
    st->inj_slot   = g_ti_inj_slot;
    st->max_slots  = g_ti_max_slots;
    st->downs      = g_ti_downs;
    st->moves      = g_ti_moves;
    st->ups        = g_ti_ups;
    st->busy       = g_ti_busy;
    st->conflicts  = g_ti_conflicts;
    st->protects   = g_ti_protects;
    ti_unlock();
}

/*
 * 【v1.73.0】手动解除 CONFLICTED。
 *
 * 参考实现里 down() 会自动把 CONFLICTED 清成 IDLE 再重来，所以正常
 * 不需要这个。但用户态若想在"不按下"的前提下先把状态复位（比如换
 * 一个目标槽位重来），就调它。返回之前的状态。
 */
int hy_ti_reset_conflict(void)
{
    int old;
    ti_lock();
    old = g_ti_state;
    if (g_ti_state == TI_CONFLICTED) {
        g_ti_state = TI_IDLE;
        g_ti_inj_slot = -1;
    }
    ti_unlock();
    return old;
}

/*
 * 【v1.75.0】强制清除虚拟手指 —— "破手指不消失"的终极解法。
 *
 * 病根：hy_ti_up() 靠 g_ti_used 位图判断 keep（还有没有真手指在位），
 * 只要位图里有残留 —— 用户此前为学坐标摸过屏、或某次抬起事件没被
 * 回调捕获 —— keep 就为 1，于是不发 BTN_TOUCH=0。而 BTN_TOUCH=0 才
 * 是上层（Android InputReader）判定"触摸彻底结束"的关键信号，不发它
 * 系统就认为手指仍在屏上，圆点永远不消失。
 *
 * 本函数无条件完成一次完整抬起，不看 keep：
 *   1) 先把状态机置 IDLE —— 保护逻辑只在 ACTIVE 时拦 BTN_TOUCH=0，
 *      不清状态的话我们自己发的抬起会被自己拦截；
 *   2) 对注入槽发 SLOT + TRACKING_ID=-1；
 *   3) 无条件发 BTN_TOUCH=0 / BTN_TOOL_FINGER=0；
 *   4) 清空物理手指位图，消除残留导致的后续误判。
 */
int hy_ti_force_clear(void)
{
    int i, w;

    if (!g_real_dev || !hy_f_input_event) return -ENODEV;

    /*
     * 【v1.76.0 多指】对每一根按着的虚拟手指都发一次抬起，而不是只发
     * 一个槽 —— 否则残留的那几根会继续挂在屏上变成"不消失的破手指"。
     */
    ti_lock();
    g_ti_state   = TI_IDLE;
    g_ti_inj_slot = -1;
    g_ti_last_id  = -1;
    ti_unlock();

    g_injecting++;
    if (hy_mt_proto() == 1) {
        /* A 协议：先把手指全部摘掉，再发一个空帧（含 SYN_MT_REPORT） */
        ti_lock();
        for (i = 0; i < TI_MAX_FINGERS; i++) {
            g_ti_f[i].active = 0;
            g_ti_f[i].slot   = -1;
        }
        ti_unlock();
        ti_key(HY_BTN_TOUCH, 0);
        if (g_has_tool_finger)
            ti_key(HY_BTN_TOOL_FINGER, 0);
        ti_frame_a();
    } else {
        for (i = 0; i < TI_MAX_FINGERS; i++) {
            int slot;
            ti_lock();
            slot = g_ti_f[i].active ? g_ti_f[i].slot : -1;
            ti_unlock();
            if (slot < 0 || slot >= TI_MAX_SLOTS) continue;
            ti_abs(HY_ABS_MT_SLOT, slot);
            ti_abs(HY_ABS_MT_TRACKING_ID, -1);
        }
        ti_key(HY_BTN_TOUCH, 0);
        if (g_has_tool_finger)
            ti_key(HY_BTN_TOOL_FINGER, 0);
        ti_syn();
    }
    g_injecting--;

    ti_lock();
    for (w = 0; w < (int)TI_WORDS; w++) g_ti_used[w] = 0;
    for (i = 0; i < TI_MAX_FINGERS; i++) {
        g_ti_f[i].active = 0;
        g_ti_f[i].slot   = -1;
    }
    g_ti_state    = TI_IDLE;
    g_ti_inj_slot = -1;
    g_ti_last_id  = -1;
    ti_unlock();

    return 0;
}

/*
 * 【v1.75.0】注入总开关。
 *
 * 触摸探测（probe）默认开且是只读的，安全；但"生成手指"必须显式调用。
 * 这里再加一道闸门：关掉后 down/move/up 一律拒绝，连用户态调用也不
 * 放行，确保不存在任何自动生成手指的路径。
 */
int hy_ti_set_inject_allowed(int on)
{
    g_ti_inject_allowed = (on != 0) ? 1 : 0;
    return g_ti_inject_allowed;
}

int hy_ti_get_inject_allowed(void)
{
    return g_ti_inject_allowed;
}

int hy_touch_down(int slot, int x, int y)
{
    void *dev = hy_active_dev();

    if (!g_touch_ready || !dev) return -ENODEV;
    if (slot < 0 || slot >= HY_MAX_SLOTS) return -EINVAL;

    /*
     * 坐标范围校验。
     * 【v1.21.0】越界时明确打出当前生效的屏幕尺寸 —— 调用方一看就知道
     * 是屏幕分辨率不匹配（默认 1080x2400），需要调 touch_setup() 改。
     * 原来只返回 -EINVAL，用户只能猜。
     */
    if (x < 0 || y < 0 || x >= g_max_x || y >= g_max_y) {
        HY_LOG("input: down(%d,%d) out of range %dx%d -- call touch_setup(w,h)\n",
               x, y, g_max_x, g_max_y);
        return -EINVAL;
    }

    if (g_slot_down[slot]) {
        /* 已按下：按 move 处理 */
        return hy_emit(dev, slot, x, y, true);
    }

    g_slot_track[slot] = 40000 + slot;      /* ls 的 tracking id 基数 */
    g_slot_down[slot] = true;
    return hy_emit(dev, slot, x, y, true);
}

int hy_input_touch_move(int slot, int x, int y)
{
    void *dev = hy_active_dev();

    if (!g_touch_ready || !dev) return -ENODEV;
    if (slot < 0 || slot >= HY_MAX_SLOTS) return -EINVAL;
    if (!g_slot_down[slot]) return -EINVAL;
    if (x < 0 || y < 0 || x >= g_max_x || y >= g_max_y) {
        HY_LOG("input: move(%d,%d) out of range %dx%d -- call touch_setup(w,h)\n",
               x, y, g_max_x, g_max_y);
        return -EINVAL;
    }

    return hy_emit(dev, slot, x, y, true);
}

int hy_touch_up(int slot)
{
    void *dev = hy_active_dev();

    if (!g_touch_ready || !dev) return -ENODEV;
    if (slot < 0 || slot >= HY_MAX_SLOTS) return -EINVAL;
    if (!g_slot_down[slot]) return 0;

    g_slot_down[slot] = false;
    g_slot_track[slot] = 0;
    return hy_emit(dev, slot, 0, 0, false);
}

/* 供 procfs 显示触摸状态 */
/* v1.27.0：登记表诊断输出 */
int hy_input_seen_count(void) { return g_seen_count; }

/*
 * 【v1.57.0】按已登记表的索引直接锁定触摸屏。
 *
 * 为什么需要这个：三项行为判据在部分真机上永远凑不齐（实测 6.12
 * 机器 BTN_TOUCH 恒为 0），自动识别就永远锁不上。而 tscan 主动枚举
 * 是历史崩点，不该为了识别去冒崩内核的风险。
 *
 * 这条路径的安全性是最高等级：g_seen[].dev 全部来自真实 input_event
 * 回调的第一个参数，是内核亲手写进来的指针，绝对有效 —— 不需要任何
 * 结构体偏移、不需要读设备内存、不需要枚举。
 *
 * 用法：echo 'tslock 0' > /proc/HuanyuD
 *       （索引号从 touchstat / status 段的 seen 列表里读）
 */
int hy_input_lock_index(int idx)
{
    if (idx < 0 || idx >= g_seen_count) return -EINVAL;
    if (!g_seen[idx].dev) return -EINVAL;

    g_real_dev   = g_seen[idx].dev;
    g_real_found = true;

    /* 锁定瞬间用自学习到的坐标上限校正屏幕尺寸 */
    /* v1.79.0：手设过范围就不再用自学值覆盖 */
    if (!g_range_manual) {
        if (g_seen_max_x > 0) g_max_x = g_seen_max_x + 1;
        if (g_seen_max_y > 0) g_max_y = g_seen_max_y + 1;
        if (g_seen_min_x != 0x7fffffff) g_min_x = g_seen_min_x;
        if (g_seen_min_y != 0x7fffffff) g_min_y = g_seen_min_y;
    }

    HY_LOG("input: LOCKED by index %d name=\"%s\" dev=%llx\n",
           idx, g_seen[idx].name, (u64)g_real_dev);
    return 0;
}

unsigned long hy_input_ie_events(void) { return g_ie_events; }

/* v1.77.0：抓包开关。传 1 打开、0 关闭；返回旧值。 */
int hy_input_ie_trace(int on)
{
    int old = g_ie_trace ? 1 : 0;
    if (on < 0) return old;            /* 负数 = 只查询不改 */
    if (on) {
        g_ie_trace = true;
        g_ie_trace_budget = 8192;   /* 记 8192 条自动停，足够一次诊断 */
    } else {
        g_ie_trace = false;
        g_ie_trace_budget = 0;
    }
    return old;
}

/* v1.77.0：多点协议自学习结果，供 touchstat 显示 */
int hy_input_mt_proto(void) { return hy_mt_proto(); }

/*
 * 【v1.59.0】tcap —— 触摸事件抓包。
 *
 * 为什么需要它：v1.58 实测里 hook 明明命中了 5261 次，但登记表
 * abs=0 btn=0 mt=0 —— 说明流经被 hook 符号的那些事件，压根不是
 * 触摸屏发的。没有原始数据就只能一直猜；有了它，"hook 挂错了地方"
 * 和"判据写错了"这两种故障一眼可分。
 */
static int tc_puts(char *b, int off, int max, const char *s)
{
    int i = 0;
    if (!b || !s) return off;
    while (s[i] && off + 1 < max) b[off++] = s[i++];
    if (off < max) b[off] = 0;
    return off;
}

static int tc_putn(char *b, int off, int max, long v, int hex)
{
    char tmp[24];
    int n = 0, i;
    long base = hex ? 16 : 10;
    unsigned long u;

    if (v < 0) {
        if (off + 1 < max) b[off++] = '-';
        u = (unsigned long)(-v);
    } else {
        u = (unsigned long)v;
    }
    if (!u) tmp[n++] = '0';
    while (u && n < (int)sizeof(tmp) - 1) {
        unsigned long d = u % (unsigned long)base;
        tmp[n++] = (char)(d < 10 ? ('0' + d) : ('a' + (d - 10)));
        u /= (unsigned long)base;
    }
    for (i = n - 1; i >= 0; i--) {
        if (off + 1 >= max) break;
        b[off++] = tmp[i];
    }
    if (off < max) b[off] = 0;
    return off;
}

int hy_input_tcap_dump(char *buf, int max)
{
    static const char *const tname[8] = {
        "syn", "key", "rel", "abs", "msc", "sw", "led", "snd"
    };
    int off = 0, i;

    if (!buf || max <= 8) return 0;

    off = tc_puts(buf, off, max, "hits: iev=");
    off = tc_putn(buf, off, max, (long)g_ie_hits_iev, 0);
    off = tc_puts(buf, off, max, " ihe=");
    off = tc_putn(buf, off, max, (long)g_ie_hits_ihe, 0);
    off = tc_puts(buf, off, max, " total=");
    off = tc_putn(buf, off, max, (long)g_ie_events, 0);
    off = tc_puts(buf, off, max, " unaligned_dev=");
    off = tc_putn(buf, off, max, (long)g_ie_bogus, 0);

    for (i = 0; i < 8; i++) {
        off = tc_puts(buf, off, max, i ? " " : "\ntype: ");
        off = tc_puts(buf, off, max, tname[i]);
        off = tc_puts(buf, off, max, "=");
        off = tc_putn(buf, off, max, (long)g_ie_typehist[i], 0);
    }

    off = tc_puts(buf, off, max, "\nlast:");
    for (i = 0; i < HY_IE_RING; i++) {
        struct hy_ie_sample *s = &g_ie_ring[(g_ie_ring_i + i) % HY_IE_RING];
        if (!s->dev) continue;
        off = tc_puts(buf, off, max, "\n  d=0x");
        off = tc_putn(buf, off, max, (long)s->dev, 1);
        off = tc_puts(buf, off, max, " t=");
        off = tc_putn(buf, off, max, (long)s->type, 0);
        off = tc_puts(buf, off, max, " c=0x");
        off = tc_putn(buf, off, max, (long)s->code, 1);
        off = tc_puts(buf, off, max, " v=");
        off = tc_putn(buf, off, max, s->value, 0);
        if (off + 48 >= max) break;
    }
    return off;
}

const char *hy_input_active_name(void)
{
    void *dev = hy_active_dev_ro();   /* v1.30.1 只读，绝不触发创建 */
    int i;

    if (!dev) return "(none)";
    for (i = 0; i < g_seen_count; i++)
        if (g_seen[i].dev == dev) return g_seen[i].name;

    if (dev == g_own_dev) return "(own device)";
    return "(unknown)";
}

/*
 * 把登记到的设备逐行写进 buf：
 *   "0xffffff88xxxx  fts_ts\n"
 * 返回写入字节数。
 */
int hy_input_seen_dump(char *buf, int max)
{
    static const char hexd[] = "0123456789abcdef";
    int i, off = 0;

    if (!buf || max <= 0) return 0;

    for (i = 0; i < g_seen_count; i++) {
        unsigned long d = (unsigned long)g_seen[i].dev;
        int b;
        const char *nm = g_seen[i].name;

        if (off + 112 >= max) break;   /* v1.74.0: 多了 phys 字段，阈值放宽 */

        buf[off++] = ' '; buf[off++] = ' '; buf[off++] = '[';
        buf[off++] = (char)('0' + (i / 10) % 10);
        buf[off++] = (char)('0' + i % 10);
        buf[off++] = ']'; buf[off++] = ' ';
        buf[off++] = '0'; buf[off++] = 'x';
        for (b = 60; b >= 0; b -= 4)
            buf[off++] = hexd[(d >> b) & 0xf];
        buf[off++] = ' '; buf[off++] = ' ';

        for (b = 0; nm[b] && off < max - 16; b++)
            buf[off++] = nm[b];

        /*
         * 【v1.57.0】把三项证据逐项打出来。
         * 之前只显示 [MT]，锁不上时根本看不出卡在哪一项 ——
         * 实测正是靠这里发现 BTN_TOUCH 恒为 0。
         */
        {
            const char *tag = "  abs=";
            for (b = 0; tag[b]; b++) buf[off++] = tag[b];
            buf[off++] = (char)('0' + (g_seen[i].has_abs ? 1 : 0));
            tag = " btn=";
            for (b = 0; tag[b]; b++) buf[off++] = tag[b];
            buf[off++] = (char)('0' + (g_seen[i].has_btn_touch ? 1 : 0));
            tag = " mt=";
            for (b = 0; tag[b]; b++) buf[off++] = tag[b];
            buf[off++] = (char)('0' + (g_seen[i].is_mt ? 1 : 0));
            tag = " nev=";
            for (b = 0; tag[b]; b++) buf[off++] = tag[b];
            {
                unsigned long n = (unsigned long)g_seen[i].nev;
                char tmp[16];
                int t = 0, k;
                if (n == 0) tmp[t++] = '0';
                while (n > 0 && t < 12) { tmp[t++] = (char)('0' + (n % 10)); n /= 10; }
                for (k = t - 1; k >= 0; k--) buf[off++] = tmp[k];
            }
        }

        /*
         * 【v1.74.0】phys —— 拿它去 /proc/bus/input/devices 里 grep，
         * 就能找到 H: Handlers=eventN，回答"哪个 event 是屏幕"。
         */
        {
            const char *tag2 = " phys=\"";
            const char *ph = g_seen[i].phys[0] ? g_seen[i].phys : "-";
            for (b = 0; tag2[b] && off < max - 48; b++) buf[off++] = tag2[b];
            for (b = 0; ph[b] && off < max - 4; b++) buf[off++] = ph[b];
            if (off < max - 2) buf[off++] = '"';
        }

        if (g_real_found && g_real_dev == g_seen[i].dev) {
            const char *tag = "   <== LOCKED";
            for (b = 0; tag[b]; b++) buf[off++] = tag[b];
        }
        buf[off++] = '\n';
    }

    if (g_seen_count == 0 && off + 40 < max) {
        const char *msg = "  (none seen yet -- touch the screen once)\n";
        for (i = 0; msg[i]; i++) buf[off++] = msg[i];
    }
    buf[off] = 0;
    return off;
}

int hy_input_slot_base(void)
{
    return g_slot_base;
}

int hy_input_max_drv_slot(void)
{
    return g_max_drv_slot;
}

/* 运行时开关槽位抢占（调试接口 HuanyuD grab on|off 用） */
void hy_input_set_grab(int on)
{
    g_grab_slots = on ? true : false;
    HY_LOG("input: slot grab %s\n", on ? "ON" : "OFF");
}

/* 设置虚拟手指起始槽位。合法范围 0..HY_MAX_SLOTS-2 */
int hy_input_set_slot_base(int n)
{
    if (n < 0 || n >= HY_MAX_SLOTS - 1) return -EINVAL;
    g_slot_base = n;
    return 0;
}

void hy_input_grab_status(int *dropped, int *learn_x, int *learn_y)
{
    if (dropped) *dropped = (int)g_slots_dropped;
    if (learn_x) *learn_x = g_seen_max_x;
    if (learn_y) *learn_y = g_seen_max_y;
}

void hy_input_status(int *real_found, int *own_ok, int *down_count,
                     int *probe_on, int *max_x, int *max_y)
{
    int i, c = 0;
    for (i = 0; i < HY_MAX_SLOTS; i++) if (g_slot_down[i]) c++;
    if (real_found)  *real_found  = (int)g_real_found;
    if (own_ok)      *own_ok      = !!g_own_dev;
    if (down_count)  *down_count  = c;
    if (probe_on)    *probe_on    = (int)g_probe_hooked;
    if (max_x)       *max_x       = g_max_x;
    if (max_y)       *max_y       = g_max_y;
}

/* ===================================================================
 * 虚拟陀螺仪：hook sendto，就地改写 ASensorEvent
 * =================================================================== */

/*
 * before 回调：读用户缓冲区 -> 改 data[0..2] -> 写回。
 * 不设置 skip_origin：真实 sendto 照常执行，把我们改好的数据发出去。
 */
static void hy_gyro_sendto_before(hook_fargs6_t *args, void *udata)
{
    void __user *buff;
    size_t len;
    (void)udata;
    size_t off;
    u32 fx, fy, fz;
    unsigned char buf[HY_GYRO_CHUNK_BYTES];

    if (!g_gyro_active) return;

    buff = (void __user *)syscall_argn(args, 1);
    len  = (size_t)syscall_argn(args, 2);

    if (!buff) return;
    /* ASensorEvent 固定 104 字节，按数组传输 */
    if (len < HY_ASE_SIZE) return;
    if (len > HY_GYRO_MAX_SCAN) len = HY_GYRO_MAX_SCAN;
    len -= (len % HY_ASE_SIZE);
    if (!len) return;

    if (g_gyro_use_raw) {
        fx = g_gyro_raw_x;
        fy = g_gyro_raw_y;
        fz = g_gyro_raw_z;
    } else {
        fx = hy_milli_to_float_bits(g_gyro_x);
        fy = hy_milli_to_float_bits(g_gyro_y);
        fz = hy_milli_to_float_bits(g_gyro_z);
    }

    for (off = 0; off < len; off += HY_GYRO_CHUNK_BYTES) {
        size_t n = len - off;
        int i, changed = 0;

        if (n > HY_GYRO_CHUNK_BYTES) n = HY_GYRO_CHUNK_BYTES;

        if (!hy_f_copy_from_user) return;
        if (hy_f_copy_from_user(buf, (const void __user *)((unsigned long)buff + off), n))
            break;

        for (i = 0; i < (int)(n / HY_ASE_SIZE); i++) {
            unsigned char *ev = buf + (size_t)i * HY_ASE_SIZE;
            s32 type;
            hy_memcpy(&type, ev + HY_ASE_TYPE_OFF, sizeof(type));

            if (type != HY_SENSOR_GYRO && type != HY_SENSOR_GYRO_UNCAL)
                continue;

            hy_memcpy(ev + HY_ASE_DATA_OFF + 0, &fx, sizeof(fx));
            hy_memcpy(ev + HY_ASE_DATA_OFF + 4, &fy, sizeof(fy));
            hy_memcpy(ev + HY_ASE_DATA_OFF + 8, &fz, sizeof(fz));
            changed++;
        }

        if (!changed) continue;

        if (!hy_f_copy_to_user) return;
        if (hy_f_copy_to_user((void __user *)((unsigned long)buff + off), buf, n))
            break;

        g_gyro_patches += changed;
    }
}

int hy_gyro_init(int method)
{
    if (method < 0 || method > 1) return -EINVAL;
    if (!g_gyro_hooked) return -ENODEV;

    g_gyro_active = false;
    g_gyro_use_raw = false;
    g_gyro_x = g_gyro_y = g_gyro_z = 0;
    g_gyro_raw_x = g_gyro_raw_y = g_gyro_raw_z = 0;
    HY_LOG("input: gyro ready method=%d (sendto hook)\n", method);
    return 0;
}

/* 新接口：mrad/s */
int hy_gyro_set(s32 x_mrad, s32 y_mrad, s32 z_mrad)
{
    if (!g_gyro_hooked) return -ENODEV;
    g_gyro_use_raw = false;
    g_gyro_x = x_mrad;
    g_gyro_y = y_mrad;
    g_gyro_z = z_mrad;
    g_gyro_active = true;
    return 0;
}

/*
 * 旧 ABI 兼容：x/y 是 float 的位表示。
 * 直接把位模式写进 ASensorEvent 的 data[0]/data[1]。
 */
int hy_gyro_config(const struct hy_gyro_config *cfg)
{
    if (!cfg) return -EINVAL;
    if (!g_gyro_hooked) return -ENODEV;

    if (!cfg->enable) {
        g_gyro_active = false;
        g_gyro_use_raw = false;
        g_gyro_x = g_gyro_y = g_gyro_z = 0;
        return 0;
    }

    g_gyro_raw_x = cfg->x;
    g_gyro_raw_y = cfg->y;
    g_gyro_raw_z = 0;       /* 旧 ABI 只有 x/y 两个字段，z 恒为 0 */
    g_gyro_use_raw = true;
    g_gyro_active = true;
    return 0;
}

void hy_gyro_status(int *active, int *hooked, u64 *patches)
{
    if (active)  *active  = (int)g_gyro_active;
    if (hooked)  *hooked  = (int)g_gyro_hooked;
    if (patches) *patches = g_gyro_patches;
}

/* ==================== 方案选择支持（v1.64.0） ==================== */

int hy_input_observer_available(int kind)
{
    switch (kind) {
    case HY_IN_HANDLE_EVENT:
        /* 两个观察点至少要有一个，否则这台机器根本没有可挂的输入入口 */
        return (hy_f_input_handle_event || hy_f_input_event) ? 0 : -1;
    case HY_IN_EVENT:
    case HY_IN_EVENT_SIMPLE:
        return hy_f_input_event ? 0 : -1;
    case HY_IN_COUNT_ONLY:
        /* 兜底档：不要求任何符号，挂不上就只当没触摸 */
        return 0;
    default:
        return -1;
    }
}

int hy_input_apply_observer(int kind)
{
    int was = g_probe_enabled;

    if (hy_input_observer_available(kind) != 0) return -1;

    g_observer_kind = kind;
    g_learn_enabled = (kind == HY_IN_HANDLE_EVENT || kind == HY_IN_EVENT) ? 1 : 0;

    /*
     * 档位变了，挂的点可能也要变。先摘后装：
     * hy_probe_hook_remove 用的是 hook_unwrap（精确移除自己那条），
     * 不会误伤同一地址上别的模块的 hook。
     */
    if (was) {
        hy_probe_hook_remove();
        hy_probe_hook_install();
    }
    return 0;
}

int hy_input_observer_kind(void) { return g_observer_kind; }

/* 注入门控：3 系档只观察不注入 */
int hy_input_inject_allowed(void)
{
    return (g_observer_kind == HY_IN_COUNT_ONLY) ? 0 : 1;
}
