/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_dbgfs.c —— /proc/HuanyuD 真·可写调试接口
 *
 * 【v1.54.0 紧急修复：proc_ops 槽位错位一格】
 *
 *   v1.53.0 读写 /proc/HuanyuD 会卡死重启。根因是手工构造 proc_ops 时
 *   **漏掉了 proc_read_iter 这个槽位**，导致后面全部错位一格：
 *
 *       struct proc_ops 实际布局（Linux 5.6 ~ 6.x 恒定）：
 *           [0] proc_flags        (unsigned int，占满 8 字节槽)
 *           [1] proc_open
 *           [2] proc_read
 *           [3] proc_read_iter    <-- v1.53 漏了它
 *           [4] proc_write
 *           [5] proc_lseek
 *           [6] proc_release
 *           [7] proc_poll
 *
 *   v1.53 填成 [3]=write [4]=lseek [5]=release，于是内核实际调用：
 *       proc_read_iter  -> dbgfs_write     （读走错路径）
 *       proc_write      -> seq_lseek       （echo 把 buf 当 offset 用）
 *       proc_lseek      -> single_release  （解引用垃圾地址 -> 立即 oops）
 *       proc_release    -> NULL            （seq_file 永不释放，泄漏）
 *   cat / echo 一旦触发 lseek 或 write 就直接踩空，必然炸。
 *
 *   修复：严格按上面的布局填，[3] 显式置 NULL。
 *
 * 【为什么 proc_read_iter 留 NULL 是安全的】
 *   vfs_read() 的分支顺序是 `if (f_op->read) ... else if (f_op->read_iter)`，
 *   内核自己的 proc_single_fops 也只填 proc_read、不填 proc_read_iter。
 *   所以 cat 会走 proc_read -> seq_read，完全正常。read_iter 只在
 *   readv/splice 路径用到，那些场景返回 -EIO 而已，不会崩。
 *
 * 【零结构体布局的做法】
 *   1. proc_ops 用一个 unsigned long 数组手工构造。前 8 个槽位在所有
 *      5.6+ 内核上恒定（CONFIG_* 只影响后面 splice/mmap/ioctl 那几个），
 *      我们只用到前 7 个，因此布局假设是可靠的。
 *   2. struct proc_dir_entry 全程不透明：只存指针、只回传给内核，从不解引用。
 *   3. 内核 < 5.6（proc_ops 尚未引入）→ 直接放弃可写，回退只读页。
 *   4. 加载参数 nowproc=1 可强制只读，用于隔离本文件的一切风险。
 *
 * 【失败即降级】
 *   任何一个符号解析不到、或版本不满足，就返回 NULL，
 *   由 hy_procfs.c 回退创建只读页。加载永远不会因此失败。
 */

#include <linux/printk.h>
#include <linux/string.h>
#include <kpmodule.h>
#include "hy.h"
#include "hy_scheme.h"

#ifndef HY_VER_5_6
#define HY_VER_5_6 HY_KVER(5, 6, 0)
#endif

#ifndef EINVAL
#define EINVAL 22
#endif
#ifndef EFAULT
#define EFAULT 14
#endif
#ifndef ENODEV
#define ENODEV 19
#endif
#ifndef ENOMEM
#define ENOMEM 12
#endif

/* 编译器/CPU 屏障：保证"先填内容、后发布"的顺序 */
#define dbg_barrier() __asm__ __volatile__("" ::: "memory")

/* struct proc_dir_entry：对我们永远不透明 */
struct hy_dbgfs_pde;

typedef struct hy_dbgfs_pde *(*dbgfs_create_t)(const char *name,
                                               unsigned short mode,
                                               struct hy_dbgfs_pde *parent,
                                               const void *ops);
typedef void (*dbgfs_remove_t)(struct hy_dbgfs_pde *entry);
typedef void (*dbgfs_printf_t)(void *seq, const char *fmt, ...);
typedef int  (*dbgfs_single_open_t)(void *file,
                                    int (*show)(void *seq, void *v),
                                    void *data);

static dbgfs_create_t       f_create;
static dbgfs_remove_t       f_remove;
static dbgfs_printf_t       f_printf;
static dbgfs_single_open_t  f_single_open;
static void                *f_seq_read;
static void                *f_seq_lseek;
static void                *f_single_release;

/*
 * proc_ops 槽位表 —— 按内核版本分两套布局。
 *
 * 【关键】proc_read_iter 是 5.8~5.11 之间才加入 struct proc_ops 的。
 *   5.6  ~ 5.10 : [0]flags [1]open [2]read [3]write  [4]lseek [5]release
 *   5.11+       : [0]flags [1]open [2]read [3]read_iter(空) [4]write
 *                 [5]lseek [6]release
 *
 * v1.53.0 用的是【旧布局】，在 6.12 上正好错位一格 —— 这就是
 * "读写 /proc/HuanyuD 卡死重启" 的根因。现在按 kver 自动选。
 *
 * 24 槽（192 字节）远大于实际大小，多出来的全零，绝不会写越界。
 */
#define DBGFS_OP_FLAGS   0
#define DBGFS_OP_OPEN    1
#define DBGFS_OP_READ    2
#define DBGFS_OP_READIT  3   /* 5.11+：proc_read_iter；5.6~5.10：proc_write */
#define DBGFS_OP_WRITE   4
#define DBGFS_OP_LSEEK   5
#define DBGFS_OP_RELEASE 6
#define DBGFS_OP_POLL    7
#define DBGFS_OPS_SLOTS  24

/* proc_read_iter 是否存在：保守以 5.11 为界 */
static int dbgfs_has_read_iter(void)
{
    return (kver >= HY_KVER(5, 11, 0)) ? 1 : 0;
}

static unsigned long g_ops[DBGFS_OPS_SLOTS];

static struct hy_dbgfs_pde *g_entry;

/* 加载参数 nowproc=1 —— 强制只读，隔离本文件风险 */
extern int hy_opt_nowproc;

/* 上一条命令与结果：写进去之后 cat 就能看到 */
static char  g_last_cmd[160];
static char  g_last_out[160];
static int   g_last_valid;
static u64   g_cmd_total;
static u64   g_write_total;

/* ==================== 小工具（不依赖任何 libc） ==================== */


static void dbg_strcpy(char *dst, const char *src, unsigned long cap)
{
    unsigned long i = 0;
    if (!dst || cap == 0) return;
    if (src) { while (src[i] && i + 1 < cap) { dst[i] = src[i]; i++; } }
    dst[i] = 0;
}

static int dbg_is_space(char c)
{
    return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

/* 只接受可打印 ASCII，其余一律替换 —— 防止把垃圾喂给命令分发 */
static void dbg_sanitize(char *s, unsigned long cap)
{
    unsigned long i;
    if (!s) return;
    for (i = 0; i < cap && s[i]; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c < 0x20 || c > 0x7e) s[i] = ' ';
    }
}

/* ==================== write 回调 ==================== */

/*
 * 签名刻意与 proc_ops.proc_write 在 arm64 上逐寄存器一致：
 *   x0=file  x1=buf  x2=count  x3=ppos
 * 我们不碰 file，也不解引用 ppos。
 */
static long dbgfs_write(void *file, const char *buf,
                        unsigned long count, long long *ppos)
{
    char kbuf[160];
    unsigned long n, i;
    struct hy_dbg_req q;

    (void)file;
    (void)ppos;

    if (!hy_f_copy_from_user) return -(long)EFAULT;
    if (count == 0) return 0;

    /*
     * 先把内核缓冲清干净。这样即便 copy_from_user 中途失败，
     * 也不会残留上一次的内容被当成命令执行。
     */
    for (i = 0; i < sizeof(kbuf); i++) kbuf[i] = 0;

    n = count;
    if (n > sizeof(kbuf) - 1) n = sizeof(kbuf) - 1;

    /*
     * 【必须检查返回值】copy_from_user 失败时缓冲区内容未定义。
     * v1.51 的 hy_guard 就是因为不检查、照样当字符串用而随机炸。
     */
    if (n && hy_f_copy_from_user(kbuf, buf, n) != 0)
        return -(long)EFAULT;
    kbuf[n] = 0;

    /* 去掉尾部换行与空格 */
    while (n > 0 && dbg_is_space(kbuf[n - 1])) { kbuf[--n] = 0; }
    dbg_sanitize(kbuf, sizeof(kbuf));

    for (i = 0; i < sizeof(q.cmd); i++) q.cmd[i] = 0;
    for (i = 0; i < sizeof(q.out); i++) q.out[i] = 0;
    n = (n < sizeof(q.cmd) - 1) ? n : (sizeof(q.cmd) - 1);
    for (i = 0; i < n; i++) q.cmd[i] = kbuf[i];
    q.cmd[n] = 0;
    q.cmd_len = (u32)n;
    q.out_len = 0;

    hy_dbg_cmd_dispatch(&q);
    q.out[sizeof(q.out) - 1] = 0;

    /* 先写正文，最后置 valid —— 避免读侧看到半截结果 */
    dbg_strcpy(g_last_cmd, q.cmd, sizeof(g_last_cmd));
    dbg_strcpy(g_last_out, q.out, sizeof(g_last_out));
    dbg_barrier();
    g_cmd_total++;
    g_write_total++;
    g_last_valid = 1;

    return (long)count;
}

/* ==================== open 回调 ==================== */

/* show 定义在下边，这里先声明 */
static int dbgfs_show(void *seq, void *v);

static int dbgfs_open(void *inode, void *file)
{
    (void)inode;
    if (!f_single_open) return -ENODEV;
    return f_single_open(file, dbgfs_show, NULL);
}

/* ==================== show（cat 时输出） ==================== */

static int dbgfs_show(void *seq, void *v)
{
    int dropped = 0, lx = 0, ly = 0;
    int real_found = 0, own_ok = 0, down = 0, probe_on = 0;
    int mx = 0, my = 0;
    char guardline[160];

    (void)v;
    if (!f_printf) return 0;

    f_printf(seq, "Huanyu 内核调试接口（可写）\n");
    f_printf(seq, "  用法: echo '<命令>' > /proc/HuanyuD\n");

    f_printf(seq, "\n[status]\n");
    f_printf(seq, "  version      : %s\n", HY_VERSION_STRING);
    f_printf(seq, "  writable     : yes (proc_ops)\n");
    f_printf(seq, "  kver         : 0x%x\n", (unsigned int)kver);
    {
        int rp = 0, rt = 0, rh = 0, rseen = 0, rfound = 0;
        hy_input_runtime_state(&rp, &rt, &rh, &rseen, &rfound);
        f_printf(seq, "  touch        : %d\n", hy_opt_touch ? 1 : 0);
        f_printf(seq, "  probe        : %d (hooked=%d)\n", rp, rh);
        f_printf(seq, "  tscan        : %d\n", rt);
        f_printf(seq, "  seen/found   : %d / %d\n", rseen, rfound);
    }
    f_printf(seq, "  grab         : %d\n", hy_opt_grab ? 1 : 0);
    f_printf(seq, "  slotbase     : %d\n", hy_input_slot_base());
    f_printf(seq, "  max drv slot : %d\n", hy_input_max_drv_slot());

    hy_input_grab_status(&dropped, &lx, &ly);
    f_printf(seq, "  grab dropped : %d\n", dropped);
    f_printf(seq, "  learn resolv : %dx%d\n", lx, ly);

    /* v1.58.0 secure touch inject 状态 */
    {
        int st = 0, slot = -1, ms = 0, d = 0, m = 0, u = 0, b = 0, c = 0;
        const char *nm;
        hy_ti_status(&st, &slot, &ms, &d, &m, &u, &b, &c);
        nm = (st == 1) ? "ACTIVE" : (st == 2) ? "CONFLICTED" : "IDLE";
        f_printf(seq, "  ti inject    : %s slot=%d/%d d=%d m=%d u=%d busy=%d conf=%d\n",
                 nm, slot, ms, d, m, u, b, c);
    }

    hy_input_status(&real_found, &own_ok, &down, &probe_on, &mx, &my);
    f_printf(seq, "  touchscreen  : real=%d own=%d down=%d probe=%d\n",
             real_found, own_ok, down, probe_on);
    f_printf(seq, "  screen       : %dx%d\n", mx, my);
    f_printf(seq, "  devices seen : %d\n", hy_input_seen_count());
    f_printf(seq, "  input_event# : %llu\n",
             (unsigned long long)hy_input_ie_events());

    guardline[0] = 0;
    hy_guard_cmd("status", NULL, guardline, sizeof(guardline));
    f_printf(seq, "  guard        : %s\n",
             guardline[0] ? guardline : "(n/a)");

    f_printf(seq, "  writes       : %llu\n",
             (unsigned long long)g_write_total);
    {
        static const char *const cn[3] = { "default(on)", "on", "off" };
        u32 cm = hy_mem_cache_mode();
        f_printf(seq, "  mem cache    : %s\n",
                 cn[(cm <= HY_MEM_CACHE_OFF) ? cm : 0]);
        f_printf(seq, "  bp stealth   : %s\n",
                 hy_bp_stealth_default() ? "on" : "off");
    }

    /* v1.64.0：各功能面当前落在哪一档方案 */
    f_printf(seq, "\n[scheme] gen=%d (降级次数累计)\n", hy_scheme_gen());
    {
        int d;
        for (d = 0; d < HY_SC_COUNT; d++) {
            int i = hy_scheme_chosen(d);
            f_printf(seq, "  %-9s : gen%d %-8s idx=%d demote=%u\n",
                     hy_scheme_dom_name(d),
                     hy_scheme_gen_of(d),
                     hy_scheme_name(d),
                     i,
                     (unsigned int)hy_scheme_demotions(d));
        }
    }

    f_printf(seq, "\n[last command]\n");
    if (g_last_valid) {
        f_printf(seq, "  cmd  : %s\n", g_last_cmd);
        f_printf(seq, "  reply: %s\n", g_last_out);
    } else {
        f_printf(seq, "  (none yet)\n");
    }
    f_printf(seq, "  total: %llu\n", (unsigned long long)g_cmd_total);

    f_printf(seq, "\n[commands] echo '<cmd>' > /proc/HuanyuD\n");
    f_printf(seq, "  help                      显示本帮助\n");
    f_printf(seq, "  version                   版本信息\n");
    f_printf(seq, "  handshake                 版本/密钥握手状态(只显示版本号)\n");
    f_printf(seq, "  touch on|off              触摸总开关(probe+tscan)\n");
    f_printf(seq, "  probe on|off              事件探测(安全,摸屏才识别)\n");
    f_printf(seq, "  tscan on|off              主动枚举设备(历史崩点,单试)\n");
    f_printf(seq, "  touchstat                 触摸详细状态(含设备证据)\n");
    f_printf(seq, "  tcap                      触摸事件抓包(诊断用)\n");
    f_printf(seq, "  tslock <n>                按索引锁定触摸屏(可靠兜底)\n");
    f_printf(seq, "  tsname <名字>             按设备名锁定触摸屏\n");
    f_printf(seq, "  grab on|off|stat          槽位抢夺开关/统计\n");
    f_printf(seq, "  slotbase <n>              虚拟手指起始槽位(0..9)\n");
    f_printf(seq, "  tdown <x> <y>             注入按下(自动挑空闲槽)\n");
    f_printf(seq, "  tmove <x> <y>             注入移动\n");
    f_printf(seq, "  tup                       注入抬起\n");
    f_printf(seq, "  tstat                     注入状态统计\n");
    f_printf(seq, "  tslots <n>                手动设定总槽位数(1..256)\n");
    f_printf(seq, "  scheme                    各功能面当前方案与降级次数\n");
    f_printf(seq, "  scheme demote <域>        手动降一档\n");
    f_printf(seq, "  scheme force <域> <3|4|5|6>  强制指定世代(0=自动)\n");
    f_printf(seq, "  bpstat                    断点能力与占用\n");
    f_printf(seq, "  devinfo reset|add <k=v>|show\n");
    f_printf(seq, "  guard on|off|status       防格机\n");
    f_printf(seq, "  unlock [seconds]          开解锁窗口(默认300s)\n");
    f_printf(seq, "  lock                      立即结束窗口\n");

    f_printf(seq, "\n[note]\n");
    f_printf(seq, "  写权限 0644，需 root。命令与 prctl/supercall 通道共用\n");
    f_printf(seq, "  同一套分发逻辑，不再依赖用户态 HuanyuD 程序。\n");
    f_printf(seq, "  若读写异常，加载参数加 nowproc=1 可强制只读隔离。\n");
    return 0;
}

/* ==================== 对外接口 ==================== */

/*
 * 创建可写 /proc/HuanyuD。
 * 返回不透明指针；失败返回 NULL，调用方回退到只读页。
 */
void *hy_dbgfs_create(void)
{
    void **p;
    int i;

    if (g_entry) return (void *)g_entry;

    /* 隔离开关：nowproc=1 强制只读 */
    if (hy_opt_nowproc) {
        HY_LOG("dbgfs: nowproc=1 -> skip writable (forced read-only)\n");
        return NULL;
    }

    /* 版本闸门：proc_ops 是 5.6 才引入的 */
    if (kver < HY_VER_5_6) {
        HY_LOG("dbgfs: kver=0x%x < 5.6 -> skip writable (layout differs)\n",
               (unsigned int)kver);
        return NULL;
    }

    f_create        = (dbgfs_create_t)hy_lookup_generic("proc_create");
    f_remove        = (dbgfs_remove_t)hy_lookup_generic("proc_remove");
    f_printf        = (dbgfs_printf_t)hy_lookup_generic("seq_printf");
    f_single_open   = (dbgfs_single_open_t)hy_lookup_generic("single_open");
    f_seq_read      = (void *)hy_lookup_generic("seq_read");
    f_seq_lseek     = (void *)hy_lookup_generic("seq_lseek");
    f_single_release = (void *)hy_lookup_generic("single_release");

    if (!f_create || !f_remove || !f_printf || !f_single_open ||
        !f_seq_read || !f_seq_lseek || !f_single_release) {
        HY_LOG("dbgfs: symbol missing (create=%d remove=%d printf=%d "
               "sopen=%d read=%d lseek=%d rel=%d) -> fallback read-only\n",
               !!f_create, !!f_remove, !!f_printf, !!f_single_open,
               !!f_seq_read, !!f_seq_lseek, !!f_single_release);
        f_create = NULL; f_remove = NULL; f_printf = NULL;
        f_single_open = NULL;
        f_seq_read = NULL; f_seq_lseek = NULL; f_single_release = NULL;
        return NULL;
    }

    if (!hy_f_copy_from_user) {
        HY_LOG("dbgfs: copy_from_user missing -> fallback read-only\n");
        return NULL;
    }

    /*
     * 构造 proc_ops。
     * 全部槽位先清零，再按【当前内核的真实布局】逐个填。
     *
     * v1.53 的致命错误就是用了 5.6~5.10 的旧布局（没有 proc_read_iter），
     * 在 5.11+ 内核上导致 write/lseek/release 全部错位一格而炸内核。
     * 现在按 kver 选布局，两套都对。
     */
    p = (void **)g_ops;
    for (i = 0; i < DBGFS_OPS_SLOTS; i++) p[i] = NULL;

    p[DBGFS_OP_FLAGS] = NULL;                   /* proc_flags = 0 */
    p[DBGFS_OP_OPEN]  = (void *)dbgfs_open;
    p[DBGFS_OP_READ]  = f_seq_read;

    if (dbgfs_has_read_iter()) {
        /* 5.11+：[3] 是 proc_read_iter，必须留 NULL */
        p[DBGFS_OP_READIT]   = NULL;
        p[DBGFS_OP_WRITE]    = (void *)dbgfs_write;
        p[DBGFS_OP_LSEEK]    = f_seq_lseek;
        p[DBGFS_OP_RELEASE]  = f_single_release;
        p[DBGFS_OP_POLL]     = NULL;
    } else {
        /* 5.6~5.10：没有 read_iter，[3] 就是 write */
        p[DBGFS_OP_READIT]   = (void *)dbgfs_write;
        p[DBGFS_OP_WRITE]    = f_seq_lseek;
        p[DBGFS_OP_LSEEK]    = f_single_release;
        p[DBGFS_OP_RELEASE]  = NULL;
    }

    HY_LOG("dbgfs: layout=%s open=[%d]=%px read=[%d]=%px write=[%d]=%px "
           "lseek=[%d]=%px release=[%d]=%px\n",
           dbgfs_has_read_iter() ? "5.11+(read_iter)" : "5.6-5.10",
           DBGFS_OP_OPEN, p[DBGFS_OP_OPEN],
           DBGFS_OP_READ, p[DBGFS_OP_READ],
           dbgfs_has_read_iter() ? DBGFS_OP_WRITE : DBGFS_OP_READIT,
           dbgfs_has_read_iter() ? p[DBGFS_OP_WRITE] : p[DBGFS_OP_READIT],
           dbgfs_has_read_iter() ? DBGFS_OP_LSEEK : DBGFS_OP_WRITE,
           dbgfs_has_read_iter() ? p[DBGFS_OP_LSEEK] : p[DBGFS_OP_WRITE],
           dbgfs_has_read_iter() ? DBGFS_OP_RELEASE : DBGFS_OP_LSEEK,
           dbgfs_has_read_iter() ? p[DBGFS_OP_RELEASE] : p[DBGFS_OP_LSEEK]);

    g_entry = f_create("HuanyuD", 0644, NULL, (const void *)g_ops);
    if (!g_entry) {
        HY_LOG("dbgfs: proc_create returned NULL -> fallback read-only\n");
        return NULL;
    }

    HY_LOG("dbgfs: /proc/HuanyuD created WRITABLE (mode 0644, entry=%px)\n",
           (void *)g_entry);
    return (void *)g_entry;
}

void hy_dbgfs_remove(void *entry)
{
    if (!entry) return;
    if (!f_remove) return;
    f_remove((struct hy_dbgfs_pde *)entry);
    HY_LOG("dbgfs: /proc/HuanyuD removed\n");
    g_entry = NULL;
}
