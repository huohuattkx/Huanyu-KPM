/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_main.c —— KPM 入口
 *
 * 所有功能实现都在各自模块里，这里只负责：
 *   1. init 阶段按序初始化（任一环节失败只降级，不致命）
 *   2. CTL0 转发到 hy_ctl.c
 *
 * 【降级原则】这是从 wxshadow 事故里得到的最重要一条：
 *   wxshadow 在 6.12 上"加载即炸"，panic 后 dmesg 全丢，
 *   导致无法判断崩在哪一步、排查成本极高。
 *   本模块保证 init **一定返回 0**，让 APatch 认为加载成功，
 *   能力缺失通过日志和 BP_GET_CAPS 上报。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <kallsyms.h>
#include "hy.h"
#include "hy_scheme.h"

/* v1.42.0：触摸自动识别总开关，需在使用点之前定义 */
int hy_opt_touch = 0;

/* v1.51.0: anti-wipe guard master switch. Default ON. */
int hy_opt_noguard = 0;

/* v1.54.0: nowproc=1 强制 /proc/HuanyuD 只读，用于隔离可写接口风险 */
int hy_opt_nowproc = 0;

/* v1.60.0: nokma=1 彻底关闭 KMA 后端，一个符号都不解析 */
int hy_opt_nokma = 0;

/* v1.18.0 ls 移植模块 */
extern int  hy_sysmon_init(void);
extern void hy_sysmon_exit(void);
extern int  hy_cntvct_init(void);
extern void hy_cntvct_exit(void);
extern int  hy_gnss_init(void);
extern void hy_gnss_exit(void);
extern int  hy_lsx_init(void);
extern void hy_lsx_exit(void);

/* 自己实现：KP 未导出 strstr，不能引用不存在的符号 */
static const char *hy_lstrstr(const char *hay, const char *needle)
{
    int i;
    if (!hay || !needle || !needle[0]) return NULL;
    for (; *hay; hay++) {
        for (i = 0; needle[i] && hay[i] == needle[i]; i++) ;
        if (!needle[i]) return hay;
    }
    return NULL;
}


KPM_NAME("huanyu");
KPM_VERSION(HY_VERSION_STRING);

/*
 * 【v1.40.0】设备信息采集（devinfo / [device] 段）已整体移除。
 *
 *   该功能是 v1.35 引入的，连续四版造成加载即炸：内核态没有
 *   struct file 布局，无论 filp_open+kernel_read 还是只读全局标量，
 *   都属于"新增的、未被长期验证的 init 路径代码"。
 *   设备信息本就属于用户态范畴（getprop / /proc/version），
 *   内核态不做这件事。移除后 init 路径更短、更可预测。
 */
KPM_LICENSE("GPL v2");
KPM_AUTHOR("huanyu");
KPM_DESCRIPTION("Huanyu driver: memory r/w, breakpoints (SW/PTE/HW), hiding");

/* ============================ 全局 ============================ */

u32 hy_default_mode = HY_BP_MODE_AUTO;
bool hy_ready = false;
void *hy_brk_hook_registered = NULL;

/* ============================ 生命周期 ============================ */

/*
 * v1.66.0 阶段闸门。
 *
 * 崩溃后 dmesg 随重启清空，定位只能靠"控制 init 走到第几步"。
 * sstage=N 时只执行前 N 个阶段，之后立即 return 0 —— 模块算加载成功
 * （不会让 KP 报失败），但后续子系统完全不初始化。
 * 用户把 N 从 1 往上逐个试，第一次炸的那个 N 就是崩点所在阶段。
 */
#define HY_STAGE(n) do {                                      \
    if (hy_opt_sstage && (n) > hy_opt_sstage) {               \
        HY_LOG("[STEP] STOP before stage %d (sstage=%d)\n",   \
               (n), hy_opt_sstage);                           \
        hy_ready = false;                                     \
        return 0;                                             \
    }                                                         \
} while (0)

static long huanyu_init(const char *args, const char *event, void *reserved)
{
    int fails;

    (void)reserved;
    (void)args;    /* 不解析加载参数：任何值都不改变行为，避免误触发逻辑 */
    (void)event;

    /*
     * 打印 args 时必须截断：调用方传来的字符串若未以 '\0' 结尾，
     * printk 的 %s 会一直读下去，跨页即崩溃。
     * 这里手工复制到定长缓冲并强制收尾。
     */
    {
        char abuf[32];
        int i = 0;
        if (args) {
            for (i = 0; i < (int)sizeof(abuf) - 1 && args[i]; i++)
                abuf[i] = args[i];
        }
        abuf[i] = '\0';
        HY_LOG("init begin args=\"%s\" kver=0x%x\n", abuf, kver);
    }

    /*
     * v1.24.0：必须在【任何子系统 init 之前】解析开关。
     * 这些开关控制 hy_pt_init / hy_bp_init 里的危险操作，
     * 若放在后面解析就完全来不及了。
     */
    if (args) {
        if (hy_lstrstr(args, "hwclear=1")) hy_opt_hwclear = 1;
        if (hy_lstrstr(args, "ptcheck=1")) hy_opt_ptcheck = 1;
        if (hy_lstrstr(args, "tscan=1"))   hy_opt_tscan = 1;
        if (hy_lstrstr(args, "noowndev=1")) hy_opt_noowndev = 1;
        if (hy_lstrstr(args, "probe=1"))   hy_opt_probe = 1;
        if (hy_lstrstr(args, "probe=0"))   hy_opt_probe = 0;   /* v1.76.0：可显式关 */
        if (hy_lstrstr(args, "safe=1"))    hy_opt_safe = 1;
        /* v1.42.0：三项行为判据(EV_ABS+BTN_TOUCH+MT)的自动识别默认关闭，
         * 需 touch=1 显式开启。此前默认开启时反复导致加载/运行期崩溃。 */
        if (hy_lstrstr(args, "touch=1"))    hy_opt_touch = 1;
        if (hy_lstrstr(args, "grab=1"))     hy_opt_grab  = 1;
        /* v1.51.0 防格机 */
        if (hy_lstrstr(args, "noguard=1"))  hy_opt_noguard = 1;
        /* v1.54.0 /proc/HuanyuD 可写接口隔离开关 */
        if (hy_lstrstr(args, "nowproc=1"))  hy_opt_nowproc = 1;
        /* v1.60.0 KMA 后端隔离开关 */
        if (hy_lstrstr(args, "nokma=1"))    hy_opt_nokma = 1;
        /* v1.66.0 二分定位三件套 */
        if (hy_lstrstr(args, "noscheme=1")) hy_opt_noscheme = 1;
        if (hy_lstrstr(args, "nopick=1"))   hy_opt_nopick = 1;
        {
            /* sstage=<n>：只跑前 n 个阶段。手写成数字解析，
             * 不引 strtol —— KPM 里没有标准库。 */
            const char *p = hy_lstrstr(args, "sstage=");
            if (p) {
                int n = 0;
                p += 7;
                while (*p >= '0' && *p <= '9') {
                    n = n * 10 + (*p - '0');
                    if (n > 99) { n = 99; break; }
                    p++;
                }
                hy_opt_sstage = n;
            }
        }
        if (hy_lstrstr(args, "gdeep=1"))    hy_guard_set_deep(1);
        if (hy_lstrstr(args, "allowmod=1")) hy_guard_allow_mod(1);
        /* 细粒度二分开关 */

        /* 用一个位图收集，写法统一 */
        {
            if (hy_lstrstr(args, "nobp=1"))     hy_skip_mask |= 1u << 0;
            if (hy_lstrstr(args, "noinput=1"))  hy_skip_mask |= 1u << 1;
            if (hy_lstrstr(args, "nohide=1"))   hy_skip_mask |= 1u << 2;
            if (hy_lstrstr(args, "noextra=1"))  hy_skip_mask |= 1u << 3;
            if (hy_lstrstr(args, "noprocfs=1")) hy_skip_mask |= 1u << 4;
            if (hy_lstrstr(args, "nosshm=1"))   hy_skip_mask |= 1u << 5;
            if (hy_lstrstr(args, "noshm=1"))    hy_skip_mask |= 1u << 5;
            if (hy_lstrstr(args, "noprctl=1"))  hy_skip_mask |= 1u << 6;
            if (hy_lstrstr(args, "notramp=1"))  hy_skip_mask |= 1u << 7;
            if (hy_lstrstr(args, "notask=1"))   hy_skip_mask |= 1u << 8;
            if (hy_lstrstr(args, "nols=1"))     hy_skip_mask |= 1u << 9;
            if (hy_lstrstr(args, "nosysmon=1")) hy_skip_mask |= 1u << 10;
            if (hy_lstrstr(args, "nocntvct=1"))hy_skip_mask |= 1u << 11;
            if (hy_lstrstr(args, "nogclk=1"))   hy_skip_mask |= 1u << 12;
        }
        if (hy_opt_safe)
            hy_skip_mask = 0xFFFFu;   /* 最小模式：只留核心 */
    }
    /* touch=1 时联动打开触摸所需的两个开关 */
    if (hy_opt_touch) { hy_opt_tscan = 1; hy_opt_probe = 1; }

    HY_LOG("opts: hwclear=%d ptcheck=%d tscan=%d safe=%d skip=0x%x\n",
           hy_opt_hwclear, hy_opt_ptcheck, hy_opt_tscan,
           hy_opt_safe, hy_skip_mask);
    HY_LOG("opts: hwclear=%d ptcheck=%d tscan=%d\n",
           hy_opt_hwclear, hy_opt_ptcheck, hy_opt_tscan);

    HY_STAGE(1);
    HY_LOG("[STEP] -> symbols\n");
    /* 1) 符号解析 */
    fails = hy_resolve_symbols();
    hy_report_symbols();
    HY_LOG("[STEP] symbols done, failures=%d\n", fails);

    HY_STAGE(2);
    HY_LOG("[STEP] -> discover\n");
    /* 1.5) 内核布局自发现：优先 KP 偏移，逐个校验，失败才自扫描 */
    if (hy_discover_init() != 0) {
        HY_LOG("[STEP] discover FAILED (non-fatal, offsets unavailable)\n");
    } else {
        hy_discover_report();
        HY_LOG("[STEP] discover OK\n");
    }

    /*
     * 1.8) 方案选择（v1.64.0）
     * 必须在 pt 之前：pt 的两套参数（页表级数、线性映射偏移）由它选定。
     * 符号已解析完，physvirt / pgtable / sym / memread / kernrw 五域在这里定档。
     */
    HY_STAGE(3);
    HY_LOG("[STEP] -> scheme\n");
    hy_scheme_init();

    HY_STAGE(4);
    HY_LOG("[STEP] -> pt\n");
    /* 2) 地址换算（含往返自测）—— 失败则内存与断点功能不可用 */
    if (hy_pt_init() != 0) {
        HY_LOG("[STEP] pt init FAILED - loading without memory/bp support\n");
        hy_ready = false;
        return 0;
    }
    HY_LOG("[STEP] pt init OK\n");

    HY_STAGE(5);
    HY_LOG("[STEP] -> bp\n");
    /* 3) 断点子系统 */
    if (HY_SKIP(0)) {
        HY_LOG("[STEP] bp SKIPPED (nobp=1)\n");
    } else if (hy_bp_init() != 0) {
        HY_LOG("[STEP] bp init FAILED (non-fatal)\n");
    } else {
        HY_LOG("[STEP] bp init OK\n");
    }

    /* 节能模式（独立于 bp，v1.29.0 修：原来被误包进 bp 的 else 里） */
    hy_pm_init();
    HY_LOG("[STEP] pm init OK\n");

    HY_STAGE(6);
    /* 4) 进程/内存辅助 */
    if (hy_mem_init() != 0) {
        HY_LOG("[STEP] mem init FAILED (non-fatal)\n");
    } else {
        HY_LOG("[STEP] mem init OK\n");
    }

    HY_STAGE(7);
    HY_LOG("[STEP] -> input\n");
    /* 5) 输入设备（触摸/陀螺仪） */
    if (HY_SKIP(1)) {
        HY_LOG("[STEP] input SKIPPED (noinput=1)\n");
    } else if (hy_input_init() != 0) {
        HY_LOG("[STEP] input init FAILED (non-fatal)\n");
    } else {
        HY_LOG("[STEP] input init OK\n");
    }

    HY_STAGE(8);
    HY_LOG("[STEP] -> hide\n");
    /* 6) 隐藏 */
    if (HY_SKIP(2)) HY_LOG("[STEP] hide SKIPPED (nohide=1)\n");
    else hy_hide_init();
    HY_LOG("[STEP] hide init done\n");

    /*
     * 6.25) 防格机（v1.51.0）
     * 越早越好：装好后立刻挡住块设备写打开与擦除 ioctl。
     * 回调内部检查 hy_ready，因此 init 期间不会误拦任何东西。
     */
    HY_STAGE(9);
    HY_LOG("[STEP] -> guard\n");
    if (hy_opt_noguard) {
        HY_LOG("[STEP] guard SKIPPED (noguard=1)\n");
    } else if (hy_guard_init() != 0) {
        HY_LOG("[STEP] guard init FAILED (non-fatal)\n");
    } else {
        HY_LOG("[STEP] guard init OK hooks=%d\n", hy_guard_hooks());
    }

    /*
     * 6.28) 方案选择收尾（v1.64.0）
     * bp 域要读 hy_bp_caps()，input 域要读 hook 目标指针，
     * 两者都得等各自子系统 init 完才有意义，所以放到这里。
     */
    HY_STAGE(10);
    HY_LOG("[STEP] -> scheme late\n");
    hy_scheme_init_late();

    HY_STAGE(11);
    HY_LOG("[STEP] -> extra\n");
    /* 6.3) 扩展能力 */
    if (HY_SKIP(3)) HY_LOG("[STEP] extra SKIPPED (noextra=1)\n");
    else hy_extra_init();
    HY_LOG("[STEP] extra init done\n");


    /* 6.35) 设备信息内核自采（CPU 数 / 内存，失败即 unknown） */
    HY_STAGE(12);
    HY_LOG("[STEP] -> devinfo\n");
    hy_devinfo_autofill();
    HY_LOG("[STEP] devinfo autofill done\n");

    HY_STAGE(13);
    HY_LOG("[STEP] -> procfs\n");
    /* 6.4) /proc/huanyu —— 真实 procfs 文件 */
    if (HY_SKIP(4)) HY_LOG("[STEP] procfs SKIPPED (noprocfs=1)\n");
    else if (hy_procfs_init() != 0)
        HY_LOG("[STEP] procfs init FAILED (non-fatal)\n");
    else
        HY_LOG("[STEP] /proc/huanyu created\n");

    HY_STAGE(14);
    HY_LOG("[STEP] -> shm\n");
    /* 6.42) 共享内存通道（lsdriver 风格） */
    if (HY_SKIP(5)) HY_LOG("[STEP] shm SKIPPED (noshm=1)\n");
    else hy_shm_init();
    {
        /* 支持加载参数 shm_name=xxx 指定目标进程名 */
        const char *p = args ? hy_lstrstr(args, "shm_name=") : NULL;
        if (p) {
            char nm[16];
            int i = 0;
            p += 9;
            while (*p && *p != ' ' && *p != ',' && i < 15) nm[i++] = *p++;
            nm[i] = 0;
            if (i > 0) hy_shm_set_name(nm);
        }
    }
    {
        const char *q = args ? hy_lstrstr(args, "shmscan=") : NULL;
        if (q) {
            hy_shm_set_magic_scan(q[8] == '1' ? 1 : 0);
        }
    }

    HY_LOG("[STEP] shm channel init done\n");

    HY_STAGE(15);
    HY_LOG("[STEP] -> prctl\n");
    /* 6.45) prctl 免鉴权通道 */
    if (HY_SKIP(6)) HY_LOG("[STEP] prctl SKIPPED (noprctl=1)\n");
    else if (hy_prctl_init() != 0)
        HY_LOG("[STEP] prctl channel FAILED (non-fatal)\n");
    else
        HY_LOG("[STEP] prctl channel ready\n");

    HY_STAGE(16);
    HY_LOG("[STEP] -> tramp\n");
    /* 6.5) 蹦床 */
    if (HY_SKIP(7)) HY_LOG("[STEP] tramp SKIPPED (notramp=1)\n");
    else hy_tramp_init();
    HY_LOG("[STEP] tramp init done\n");

    HY_STAGE(17);
    HY_LOG("[STEP] -> task\n");
    /* 7) TLS / PACGA */
    if (HY_SKIP(8)) {
        HY_LOG("[STEP] task SKIPPED (notask=1)\n");
    } else if (hy_task_init() != 0) {
        HY_LOG("[STEP] task init FAILED (non-fatal)\n");
    } else {
        HY_LOG("[STEP] task init OK\n");
    }

    /*
     * 6.6) KMA 读取后端（v1.60.0）
     * 放在 pt 之后：它依赖 hy_virt_to_phys / hy_walk_pgtable。
     * 默认只是把窗口页准备好，不改动任何页表内容 ——
     * 真正改 PTE 只发生在用户把模式切到 KMA 之后的读取调用里。
     */
    HY_STAGE(18);
    HY_LOG("[STEP] -> kma\n");
    hy_kma_init();
    HY_LOG("[STEP] kma init done (avail=%d)\n", hy_kma_available());

    /*
     * 6.7) 压力测试（v1.60.0）
     * 只解析符号、准备状态，不启动任何线程。
     * 必须等用户下命令才跑，加载阶段绝不自动开始。
     */
    HY_STAGE(19);
    HY_LOG("[STEP] -> stress\n");
    hy_stress_init();
    HY_LOG("[STEP] stress init done\n");

    /*
     * 6.8) 网络访问预留（v1.60.0）
     * 只注册 ABI 与能力声明，不开任何 socket、不解析任何网络符号。
     */
    HY_LOG("[STEP] -> net\n");
    hy_net_init();
    HY_LOG("[STEP] net init done\n");

    HY_LOG("[STEP] -> ls-port\n");
    /* 8) 【v1.18.0】ls 移植能力 */
    if (HY_SKIP(9)) {
        HY_LOG("[STEP] ls-port SKIPPED (nols=1)\n");
    } else if (hy_sysmon_init() != 0)
        HY_LOG("[STEP] sysmon init FAILED (non-fatal)\n");
    else
        HY_LOG("[STEP] sysmon init OK\n");

    if (HY_SKIP(11)) {
        HY_LOG("[STEP] cntvct SKIPPED (nocntvct=1)\n");
    } else if (hy_cntvct_init() != 0)
        HY_LOG("[STEP] cntvct init: unavailable (needs do_el0 handler)\n");
    else
        HY_LOG("[STEP] cntvct init OK\n");

    if (!HY_SKIP(9)) {
        hy_gnss_init();
        hy_lsx_init();
    }
    HY_LOG("[STEP] ls-port init done (sysmon/cntvct/gnss/dpt/step/kgsl)\n");

    hy_ready = true;
    HY_LOG("init done, ready=1 caps=0x%x\n", hy_bp_caps());
    return 0;
}

int hy_opt_hwclear = 0;
int hy_opt_ptcheck = 0;
int hy_opt_tscan = 0;   /* v1.42.0 默认关：随 touch=1 联动开启 */
int hy_opt_noowndev = 0;
/*
 * 【v1.76.0】默认开。
 *
 * probe 只是给 input_event 挂一个只读 before 回调 —— 不创建设备、不改
 * 能力位、不生成任何手指，唯一作用是"看见"真实触摸屏（认设备、学分辨
 * 率和槽位数）。不开的话用户每次加载都得手动 probe on，还常常忘记，
 * 于是 devices seen=0、found=0，后面全链路都跑不动。
 *
 * 注意这与"注入"是两回事：手指只在显式调用 down 时才出现，见
 * hy_ti_set_inject_allowed()。
 */
int hy_opt_probe = 1;
int hy_opt_grab  = 0;   /* v1.46.0 槽位抢占：需 grab=1（默认关） */
int hy_opt_safe = 0;
unsigned int hy_skip_mask = 0;
/* v1.66.0 二分定位：见 hy.h 的说明 */
int hy_opt_sstage = 0;    /* 0 = 不限制，全跑 */
int hy_opt_noscheme = 0;
int hy_opt_nopick = 0;

static long huanyu_exit(void *reserved)
{
    (void)reserved;
    hy_ready = false;

    /*
     * 【退出顺序】/proc/huanyu 最先摘除。
     * 让对外接口在第一时间消失，之后才清理 hook 与断点。
     * 这样即便后续清理耗时，也不会有新的用户访问进来。
     */
    hy_procfs_exit();
    hy_prctl_exit();
    hy_shm_exit();

    /*
     * 【v1.60.0】压力测试必须最先停。
     * 工作线程的代码在模块镜像内，一旦镜像被卸载还在跑就是 UAF。
     * KMA 紧随其后：它持有唯一一页改过 PTE 的窗口，必须在
     * 页表相关清理之前把窗口释放掉。
     */
    hy_stress_exit();
    hy_kma_exit();

    /*
     * 【v1.18.0】ls 移植模块的清理。
     * 顺序：先摘 hook（阻断新回调），再还原状态。
     * cntvct 尤其危险 —— 必须在还原 CNTKCTL 之前摘掉 __switch_to hook，
     * 否则残留 hook 会再次清掉 EL0VCTEN，目标进程读 CNTVCT 就 SIGILL。
     */
    hy_sysmon_exit();
    hy_cntvct_exit();
    hy_gnss_exit();
    hy_lsx_exit();

    hy_input_exit();
    hy_guard_exit();
    hy_hide_exit();
    hy_tramp_exit();
    hy_bp_exit();
    hy_pm_exit();
    HY_LOG("exit\n");
    return 0;
}


static long huanyu_ctl0(const char *args, char *out_msg, int out_len)
{
    return hy_ctl_dispatch(args, out_msg, out_len);
}

KPM_INIT(huanyu_init);
KPM_EXIT(huanyu_exit);
KPM_CTL0(huanyu_ctl0);
