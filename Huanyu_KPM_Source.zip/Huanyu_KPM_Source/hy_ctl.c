/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_ctl.c —— CTL0 完整命令分发
 *
 * 帧格式：[u8 tag[4]='H',0,0,0][u32 nr][u32 rsv][payload...]
 * payload 与用户态 ioctl 结构体字节一致、不重排。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>

#include "hy.h"
#include "hy_scheme.h"

/* v1.18.0 ls 移植模块的对外接口 */
extern int  hy_sysmon_set(s32 pid, u32 enable);
extern int  hy_sysmon_read(struct hy_sysmon_read *req);
extern int  hy_cntvct_set(s32 pid, u32 enable);
extern int  hy_cntvct_read(struct hy_cntvct_read *req);
extern int  hy_gnss_set(s32 lat_e7, s32 lon_e7, u32 enable);
extern int  hy_enum_segments(struct hy_enum_segs_req *req);
extern int  hy_enum_regions(struct hy_enum_regions_req *req);
extern int  hy_stepbp_set(s32 pid, u64 addr, u32 enable);
extern int  hy_dpt_set(s32 pid, u64 addr, u32 enable);
extern int  hy_hwcap2(struct hy_hwcap2 *c);
extern int  hy_kgsl_set(u32 enable);
extern int  hy_env_params(struct hy_env_params *ep);
extern int  hy_ls_status(struct hy_ls_status *st);
extern int  hy_input_touch_move(int slot, int x, int y);

#include "hy_shm.h"
/*
 * v1.23.0：hy_strcmp / hy_strlen 已移到 hy.h（零依赖 inline）。
 * 这里只保留带上限的 hy_ctl_strlen —— 用户态传来的字符串可能没有 '\0'，
 * 必须限长，否则会跨页缺页崩溃。
 */
#define HY_STR_MAX 1024

static size_t hy_ctl_strlen(const char *s)
{
    size_t n = 0;
    if (!s) return 0;
    while (s[n] && n < HY_STR_MAX) n++;
    return n;
}

/*
 * 极简格式化：手写拼接，不用 va_arg。
 *
 * 【为什么不用 variadic】
 *   1) KP 环境没有 vsnprintf
 *   2) 自己写 variadic 会让编译器生成对 memcpy 的隐式调用，
 *      而 KP 只导出 kf_memcpy，裸 memcpy 会成为未定义符号
 *      —— 之前就是这么踩到的。
 */
/*
 * v1.46.0：十进制字符串转整数（slotbase <n> 用）。
 * 内核态没有 strtol/atoi，手写一份最小实现：
 *   可选负号 + 连续数字，遇到非数字即停，无数字返回 -1。
 */
static int hy_atoi(const char *s)
{
    int sign = 1, n = 0, digits = 0;
    if (!s) return -1;
    if (*s == '-') { sign = -1; s++; }
    while (*s >= '0' && *s <= '9') {
        if (n > 100000000) break;      /* 防溢出 */
        n = n * 10 + (*s - '0');
        s++;
        digits++;
    }
    if (!digits) return -1;
    return sign * n;
}

/*
 * v1.58.0：从 "500 1000" 这样的串里解析两个整数（tdown/tmove 用）。
 * 同样手写，不依赖 libc。成功返回 0。
 */
static int dbg_parse_n(const char *s, int *v, int max)
{
    int k = 0, sign = 1, started = 0, i;
    if (!s || !v || max <= 0) return 0;
    for (i = 0; i < max; i++) v[i] = 0;
    for (i = 0; s[i] && k < max; i++) {
        char c = s[i];
        if (c == '-' && !started) { sign = -1; continue; }
        if (c >= '0' && c <= '9') {
            if (v[k] < 100000000) v[k] = v[k] * 10 + (c - '0');
            started = 1;
            continue;
        }
        if (started) { v[k] *= sign; k++; sign = 1; started = 0; }
    }
    if (started) { v[k] *= sign; k++; }
    return k;
}

static int dbg_parse4(const char *s, int *a, int *b, int *c, int *d)
{
    int val[4], k = 0, sign = 1, started = 0, i;
    if (!s || !a || !b || !c || !d) return -1;
    val[0] = 0; val[1] = 0; val[2] = 0; val[3] = 0;
    for (i = 0; s[i] && k < 4; i++) {
        char ch = s[i];
        if (ch == '-' && !started) { sign = -1; continue; }
        if (ch >= '0' && ch <= '9') {
            if (val[k] < 100000000) val[k] = val[k] * 10 + (ch - '0');
            started = 1;
            continue;
        }
        if (started) { val[k] *= sign; k++; sign = 1; started = 0; }
    }
    if (started) { val[k] *= sign; k++; }
    if (k < 4) return -1;
    *a = val[0];
    *b = val[1];
    *c = val[2];
    *d = val[3];
    return 0;
}

static void hy_puts(char *buf, int size, int *pos, const char *s)
{
    while (*s && *pos < size - 1) buf[(*pos)++] = *s++;
    buf[*pos] = 0;
}

static void hy_putu(char *buf, int size, int *pos, unsigned long long v)
{
    char tmp[24];
    int k = 0, j;

    if (v == 0) tmp[k++] = '0';
    while (v && k < 20) {
        tmp[k++] = (char)('0' + (unsigned)(v % 10ULL));
        v /= 10ULL;
    }
    for (j = k - 1; j >= 0 && *pos < size - 1; j--) buf[(*pos)++] = tmp[j];
    buf[*pos] = 0;
}

/*
 * 用户态指针合法性校验。
 *
 * 【为什么必须有】
 *   APatch 的"调节内核模块"是一个文本输入框。用户往里输入任意字符串，
 *   内核侧原样收到。若按二进制帧解析，文本字节会被当成命令号和用户态
 *   指针 —— 一旦拿去 copy_to_user 就是往野地址写，直接 panic。
 *   所以每个来自 payload 的指针都必须过这一关。
 *
 * 【界限怎么定的】
 *   arm64 用户空间地址都远小于 0x0000800000000000；
 *   内核地址（ffffff...）以及文本字节拼出的垃圾值都会落在界限外。
 */
#define HY_USER_PTR_MAX 0x0000800000000000ULL

static bool hy_user_ptr_ok(u64 p, u64 len)
{
    if (p == 0) return false;
    if (p >= HY_USER_PTR_MAX) return false;
    if (len > (1ULL << 24)) return false;          /* 单次上限 16MB */
    if (p + len < p) return false;                 /* 溢出 */
    if (p + len > HY_USER_PTR_MAX) return false;
    return true;
}

/*
 * 从 payload 逐字节读取 32/64 位。
 * 不用 memcpy：payload 可能未对齐，且会引入未定义符号。
 */
static u32 hy_get_u32(const u8 *p)
{
    return ((u32)p[0]) | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}

static u64 hy_get_u64(const u8 *p)
{
    return ((u64)hy_get_u32(p)) | ((u64)hy_get_u32(p + 4) << 32);
}
static int hy_frame_validate(const struct hy_ctl_frame *f, size_t alen)
{
    u32 nr = f->nr;

    /*
     * 最小长度：头部 + 该命令所需的结构体。
     * 必须是 static const —— 若写成局部非 const 数组，编译器会生成
     * 从 .rodata 到栈的 memcpy 调用，而 KP 没有裸 memcpy 可解析。
     */
    static const struct { u32 nr; size_t need; } minlen[] = {
        { HY_NR_GET_PID,           HY_CTL_HDR + sizeof(struct hy_request) },
        { HY_NR_MODULE_BASE,       HY_CTL_HDR + sizeof(struct hy_request) },
        { HY_NR_MODULE_BSS,        HY_CTL_HDR + sizeof(struct hy_request) },
        { HY_NR_READ_MEM,          HY_CTL_HDR + sizeof(struct hy_request) },
        { HY_NR_READ_MEM_V2,       HY_CTL_HDR + sizeof(struct hy_request) },
        { HY_NR_WRITE_MEM,         HY_CTL_HDR + sizeof(struct hy_request) },
        { HY_NR_GET_THREAD_TLS,    HY_CTL_HDR + sizeof(struct hy_tls_request) },
        { HY_NR_EXEC_PACGA,        HY_CTL_HDR + sizeof(struct hy_pacga_request) },
        { HY_NR_FILE_HIDE_SET,     HY_CTL_HDR + sizeof(struct hy_file_hide_config) },
        { HY_NR_FILE_HIDE_STATUS,  HY_CTL_HDR + sizeof(struct hy_file_hide_status) },
        { HY_NR_BP_GET_CAPS,       HY_CTL_HDR + sizeof(struct hy_bp_caps) },
        { HY_NR_BP_SET_MODE,       HY_CTL_HDR + sizeof(struct hy_bp_mode_config) },
        { HY_NR_BP_GET_MODE,       HY_CTL_HDR + sizeof(struct hy_bp_mode_config) },
        { HY_NR_BP_INST,           HY_CTL_HDR + sizeof(struct hy_bp_inst_args) },
        { HY_NR_BP_MODIFY,         HY_CTL_HDR + sizeof(struct hy_bp_modify_args) },
        { HY_NR_BP_GET_HIT_COUNT,  HY_CTL_HDR + sizeof(struct hy_bp_get_hit_count_arg) },
        { HY_NR_BP_GET_HIT_ITEMS,  HY_CTL_HDR + sizeof(struct hy_bp_get_hit_items_args) },
        { HY_NR_ENUM_MODULES,      HY_CTL_HDR + sizeof(struct hy_enum_mods_req) },
        { HY_NR_ENUM_PROCESSES,    HY_CTL_HDR + sizeof(struct hy_enum_procs_req) },
        { HY_NR_ENUM_THREADS,      HY_CTL_HDR + sizeof(struct hy_enum_threads_req) },
        { HY_NR_TOUCH_SET_NAME,  HY_CTL_HDR + sizeof(struct hy_touch_name) },
        { HY_NR_TOUCH_RESCAN,    HY_CTL_HDR },
        { HY_NR_KERNEL_RW,         HY_CTL_HDR + sizeof(struct hy_kern_rw_req) },
        { HY_NR_PHYS_RW,           HY_CTL_HDR + sizeof(struct hy_kern_rw_req) },
        { HY_NR_BP_LIST,           HY_CTL_HDR + sizeof(struct hy_bp_list_req) },
        { HY_NR_HWCAP,             HY_CTL_HDR + sizeof(struct hy_hwcap) },
        { HY_NR_STATS,             HY_CTL_HDR + sizeof(struct hy_stats) },
        { HY_NR_STRESS,            HY_CTL_HDR + sizeof(struct hy_dbg_req) },
        { HY_NR_RWMODE_SET,        HY_CTL_HDR + sizeof(struct hy_rw_mode) },
        { HY_NR_RWMODE_GET,        HY_CTL_HDR + sizeof(struct hy_rw_mode) },
        { HY_NR_NET_CAP,           HY_CTL_HDR + sizeof(struct hy_dbg_req) },
        { HY_NR_NET_FETCH,         HY_CTL_HDR + sizeof(struct hy_dbg_req) },
        { HY_NR_NET_STATUS,        HY_CTL_HDR + sizeof(struct hy_dbg_req) },
        { HY_NR_MEMCACHE_SET,      HY_CTL_HDR + sizeof(struct hy_mem_cache_mode) },
        { HY_NR_MEMCACHE_GET,      HY_CTL_HDR + sizeof(struct hy_mem_cache_mode) },
        /*
         * 【v1.72.1】补上这两个。
         *   它们是闸门 hy_gate_allow() 无条件放行的命令（未握手也能调），
         *   却缺失长度校验：内核会分别写 16 字节（VERSION）和
         *   sizeof(hy_handshake_req)=316 字节（HANDSHAKE）回 payload。
         *   调用方若只给了头部 12 字节，内核就越界写 —— 轻则污染相邻数据，
         *   重则写进未映射页直接 oops。任何进程都能触发，必须补。
         */
        { HY_NR_VERSION,           HY_CTL_HDR + 4u * sizeof(u32) },
        { HY_NR_HANDSHAKE,         HY_CTL_HDR + sizeof(struct hy_handshake_req) },
        /* v1.73.0 触摸：secure touch inject */
        { HY_NR_TI_DOWN,           HY_CTL_HDR + sizeof(struct hy_touch_event_base) },
        { HY_NR_TI_MOVE,           HY_CTL_HDR + sizeof(struct hy_touch_event_base) },
        { HY_NR_TI_UP,             HY_CTL_HDR },
        { HY_NR_TI_STATUS,         HY_CTL_HDR + sizeof(struct hy_ti_stat) },
        { HY_NR_TI_SET_SLOTS,      HY_CTL_HDR + sizeof(struct hy_ti_range) },
        { HY_NR_TI_SET_RANGE,      HY_CTL_HDR + sizeof(struct hy_ti_range) },
        { HY_NR_TI_GET_RANGE,      HY_CTL_HDR + sizeof(struct hy_ti_range) },
        { HY_NR_TI_CLEAR,          HY_CTL_HDR },
        { HY_NR_TI_INJECT_GATE,   HY_CTL_HDR + sizeof(struct hy_ti_range) },
        /* v1.76.0 多指 */
        { HY_NR_TI_DOWN_ID,        HY_CTL_HDR + sizeof(struct hy_ti_finger_op) },
        { HY_NR_TI_MOVE_ID,        HY_CTL_HDR + sizeof(struct hy_ti_finger_op) },
        { HY_NR_TI_UP_ID,          HY_CTL_HDR + sizeof(struct hy_ti_finger_op) },
        { HY_NR_TI_UP_ALL,         HY_CTL_HDR },
        { HY_NR_TI_CAPACITY,       HY_CTL_HDR + sizeof(struct hy_ti_cap) },
    };
    int i;

    for (i = 0; i < (int)(sizeof(minlen) / sizeof(minlen[0])); i++) {
        if (minlen[i].nr == nr) {
            if (alen < minlen[i].need) return -EINVAL;
            break;
        }
    }

    /* 逐命令检查用户态指针 */
    switch (nr) {

    case HY_NR_GET_PID:
    case HY_NR_MODULE_BASE:
    case HY_NR_MODULE_BSS: {
        struct hy_request *r = (struct hy_request *)(f->payload);
        /* 传名字：内核读用户缓冲，长度给 256 足够 */
        if (!hy_user_ptr_ok(r->buffer, 256)) return -EFAULT;
        break;
    }

    case HY_NR_READ_MEM:
    case HY_NR_READ_MEM_V2:
    case HY_NR_WRITE_MEM: {
        struct hy_request *r = (struct hy_request *)(f->payload);
        if (r->size == 0 || r->size > (1ULL << 20)) return -EINVAL;
        if (!hy_user_ptr_ok(r->buffer, r->size)) return -EFAULT;
        break;
    }

    case HY_NR_BP_INST: {
        struct hy_bp_inst_args *a = (struct hy_bp_inst_args *)(f->payload);
        if (a->regs_to_set_ptr &&
            !hy_user_ptr_ok(a->regs_to_set_ptr,
                            sizeof(struct hy_bp_user_pt_regs)))
            return -EFAULT;
        break;
    }

    case HY_NR_BP_MODIFY: {
        struct hy_bp_modify_args *m = (struct hy_bp_modify_args *)(f->payload);
        if (m->regs_to_set_ptr &&
            !hy_user_ptr_ok(m->regs_to_set_ptr,
                            sizeof(struct hy_bp_user_pt_regs)))
            return -EFAULT;
        break;
    }

    case HY_NR_BP_GET_HIT_ITEMS: {
        struct hy_bp_get_hit_items_args *g =
            (struct hy_bp_get_hit_items_args *)(f->payload);
        if (g->max_bytes == 0) return -EINVAL;
        if (!hy_user_ptr_ok(g->user_buffer_ptr, g->max_bytes)) return -EFAULT;
        break;
    }

    case HY_NR_ENUM_MODULES: {
        struct hy_enum_mods_req *q = (struct hy_enum_mods_req *)(f->payload);
        if (q->max_count == 0 || q->max_count > 512) return -EINVAL;
        if (!hy_user_ptr_ok(q->buf_ptr,
                            (u64)q->max_count * sizeof(struct hy_mod_info)))
            return -EFAULT;
        break;
    }

    case HY_NR_ENUM_PROCESSES: {
        struct hy_enum_procs_req *q = (struct hy_enum_procs_req *)(f->payload);
        if (q->max_count == 0 || q->max_count > 512) return -EINVAL;
        if (!hy_user_ptr_ok(q->buf_ptr,
                            (u64)q->max_count * sizeof(struct hy_proc_info)))
            return -EFAULT;
        break;
    }

    case HY_NR_ENUM_THREADS: {
        struct hy_enum_threads_req *q = (struct hy_enum_threads_req *)(f->payload);
        if (q->max_count == 0 || q->max_count > 512) return -EINVAL;
        if (!hy_user_ptr_ok(q->buf_ptr,
                            (u64)q->max_count * sizeof(struct hy_proc_info)))
            return -EFAULT;
        break;
    }

    case HY_NR_KERNEL_RW:
    case HY_NR_PHYS_RW: {
        struct hy_kern_rw_req *q = (struct hy_kern_rw_req *)(f->payload);
        if (q->size == 0 || q->size > 4096) return -EINVAL;
        if (!hy_user_ptr_ok(q->buf_ptr, q->size)) return -EFAULT;
        break;
    }

    case HY_NR_BP_LIST: {
        struct hy_bp_list_req *q = (struct hy_bp_list_req *)(f->payload);
        if (q->max_count == 0 || q->max_count > 128) return -EINVAL;
        if (!hy_user_ptr_ok(q->buf_ptr,
                            (u64)q->max_count * sizeof(struct hy_bp_item)))
            return -EFAULT;
        break;
    }

    default:
        break;   /* 不含用户指针的命令 */
    }

    return 0;
}

/* 文本命令：给 APatch 输入框用。只读、安全、绝不解引用任何指针。 */
static int hy_text_cmd(const char *args, char *out_msg, int out_len)
{
    int pos = 0;
    struct hy_stats st;

    if (!args || !out_msg || out_len <= 0) return -EINVAL;
    out_msg[0] = 0;

    if (hy_strcmp(args, "help") == 0) {
        hy_puts(out_msg, out_len, &pos,
            "huanyu commands:\n"
            "  status   version & ready\n"
            "  caps     breakpoint caps\n"
            "  stats    runtime stats\n"
            "  bps      bp slot counts\n"
            "  proc     /proc/huanyu state\n"
            "  syms     symbol failures\n");
        return 0;
    }
    if (hy_strcmp(args, "status") == 0) {
        hy_puts(out_msg, out_len, &pos, "ready=");
        hy_putu(out_msg, out_len, &pos, hy_ready ? 1 : 0);
        hy_puts(out_msg, out_len, &pos, " mode=");
        hy_putu(out_msg, out_len, &pos, hy_default_mode);
        hy_puts(out_msg, out_len, &pos, " caps=0x");
        hy_putu(out_msg, out_len, &pos, hy_bp_caps());
        hy_puts(out_msg, out_len, &pos, " symfail=");
        hy_putu(out_msg, out_len, &pos, (unsigned long long)hy_sym_failures());
        hy_puts(out_msg, out_len, &pos, "\n");
        return 0;
    }
    if (hy_strcmp(args, "caps") == 0) {
        hy_puts(out_msg, out_len, &pos, "caps=0x");
        hy_putu(out_msg, out_len, &pos, hy_bp_caps());
        hy_puts(out_msg, out_len, &pos, " brps=");
        hy_putu(out_msg, out_len, &pos, (unsigned long long)hy_bp_num_brps());
        hy_puts(out_msg, out_len, &pos, " wrps=");
        hy_putu(out_msg, out_len, &pos, (unsigned long long)hy_bp_num_wrps());
        hy_puts(out_msg, out_len, &pos, "\n");
        return 0;
    }
    if (hy_strcmp(args, "stats") == 0) {
        hy_stats(&st);
        hy_puts(out_msg, out_len, &pos, "hits=");
        hy_putu(out_msg, out_len, &pos, st.cache_hits);
        hy_puts(out_msg, out_len, &pos, " miss=");
        hy_putu(out_msg, out_len, &pos, st.cache_miss);
        hy_puts(out_msg, out_len, &pos, " bp=");
        hy_putu(out_msg, out_len, &pos, st.bp_active);
        hy_puts(out_msg, out_len, &pos, " total=");
        hy_putu(out_msg, out_len, &pos, st.hit_total);
        hy_puts(out_msg, out_len, &pos, "\n");
        return 0;
    }
    if (hy_strcmp(args, "bps") == 0) {
        hy_puts(out_msg, out_len, &pos, "brps=");
        hy_putu(out_msg, out_len, &pos, (unsigned long long)hy_bp_num_brps());
        hy_puts(out_msg, out_len, &pos, " wrps=");
        hy_putu(out_msg, out_len, &pos, (unsigned long long)hy_bp_num_wrps());
        hy_puts(out_msg, out_len, &pos, "\n");
        return 0;
    }
    if (hy_strcmp(args, "proc") == 0) {
        hy_puts(out_msg, out_len, &pos, "/proc/huanyu: ");
        hy_puts(out_msg, out_len, &pos,
                hy_procfs_created() ? "created" : "absent");
        hy_puts(out_msg, out_len, &pos, "\n");
        return 0;
    }
    if (hy_strcmp(args, "syms") == 0) {
        hy_puts(out_msg, out_len, &pos, "symbol failures=");
        hy_putu(out_msg, out_len, &pos, (unsigned long long)hy_sym_failures());
        hy_puts(out_msg, out_len, &pos, "\n");
        return 0;
    }

    /*
     * 【任何未识别的输入都返回成功】
     *
     * 场景：APatch 内核管理器的模块参数输入框。
     * 用户可能随手输入 "1"、"0"、任意文本。
     * 这里绝不返回错误码 —— 某些管理器在收到负返回值时
     * 会执行"卸载并重新加载"，而重载路径一旦有残留 hook 就是瞬间重启。
     *
     * 所以：不管输入什么，都回一段文本并返回 0。
     * 不解析、不执行、不产生任何副作用。
     */
    hy_puts(out_msg, out_len, &pos, "huanyu: received \"");
    hy_puts(out_msg, out_len, &pos, args);
    hy_puts(out_msg, out_len, &pos, "\" (len=");
    hy_putu(out_msg, out_len, &pos, (unsigned long long)hy_ctl_strlen(args));
    hy_puts(out_msg, out_len, &pos, ")\n");

    hy_puts(out_msg, out_len, &pos, "ok, no action\n");
    hy_puts(out_msg, out_len, &pos, "commands: help status caps stats bps proc syms\n");
    return 0;
}

int hy_ctl_dispatch(const char *args, char *out_msg, int out_len)
{
    const struct hy_ctl_frame *f;
    size_t alen;

    /* 【顺序】先校验参数本身，再碰内容 */
    if (!args || out_len <= 0) return -EINVAL;
    if (out_msg) out_msg[0] = 0;

    alen = hy_ctl_strlen(args);

    /*
     * 【双模解析】
     *   A) 二进制帧：首字节 'H' 且长度 >= 12  -> 程序通过 sc_kpm_control 调用
     *   B) 文本命令：其余一切              -> APatch 输入框 / 手动 echo
     *
     * 之前只实现了 A，导致 APatch 里输入任何文本都会把字符串当命令号+指针解析。
     */
    if (!(alen >= HY_CTL_HDR && (unsigned char)args[0] == HY_CTL_TAG0)) {
        HY_LOG("ctl: text mode (len=%zu) args=\"%s\"\n", alen, args);
        return hy_text_cmd(args, out_msg, out_len);
    }

    /* 帧完整性：至少要有头部，长度不足直接拒绝，绝不越界读 */
    if (alen < HY_CTL_HDR) return -EINVAL;

    f = (const struct hy_ctl_frame *)(args + 4);

    /* 先校验帧内容，不合法直接拒绝 */
    {
        int rc = hy_frame_validate(f, alen);
        if (rc != 0) {
            HY_LOG("ctl: frame rejected nr=%u len=%zu rc=%d\n", f->nr, alen, rc);
            return rc;
        }
    }

    hy_usage_set_channel(2);   /* ctl0 / supercall */
    return hy_ctl_switch(f->nr, (void *)f->payload);
}

/*
 * 纯二进制分发：命令号 + payload 指针。
 *
 * 抽出来是为了让两条通道共用：
 *   A) supercall / CTL0（需要 superkey 鉴权）
 *   B) prctl 魔法通道（免鉴权，见 hy_prctl.c）
 * 原先只有 A，而 A 在 root shell 下常常过不了鉴权（见 README）。
 */
/* ==========================================================================
 * 使用追踪（供 /proc/huanyu 诊断）
 *
 * 记录：谁在用、用了多少次、最后一次是什么命令、走了哪条通道。
 * 全静态，无 kmalloc。
 * ========================================================================== */

#define HY_USAGE_SLOTS 16

struct hy_usage_slot {
    int  pid;
    u64  count;
    u64  last_nr;
};

static struct hy_usage_slot g_usage[HY_USAGE_SLOTS];
static u64  g_cmd_total;
static u64  g_cmd_prctl;
static u64  g_cmd_ctl0;
static u64  g_cmd_shm;
static u64  g_cmd_errors;
static unsigned int g_last_nr;
static int  g_last_pid;
static u32  g_cur_channel;   /* 1=prctl 2=ctl0 3=shm */

void hy_usage_set_channel(u32 ch) { g_cur_channel = ch; }

static void usage_record(unsigned int nr)
{
    int pid = 0;
    int i, free_idx = -1;

    /*
     * 读 current->pid。
     * 用 hy_pid_offset()（自发现过的偏移）+ hy_current_task() 取 task 指针，
     * 不依赖 task_struct 头文件。拿不到就记 0，不影响其他统计。
     */
    {
        void *cur = hy_current_task();
        int off = hy_pid_offset();
        if (cur && off > 0) {
            int v = *(int *)((unsigned long)cur + (unsigned long)off);
            if (v > 0 && v < 0x80000) pid = v;
        }
    }

    g_cmd_total++;
    g_last_nr = nr;
    g_last_pid = pid;

    switch (g_cur_channel) {
    case 1: g_cmd_prctl++; break;
    case 2: g_cmd_ctl0++;  break;
    case 3: g_cmd_shm++;   break;
    default: break;
    }

    for (i = 0; i < HY_USAGE_SLOTS; i++) {
        if (g_usage[i].pid == pid && pid != 0) {
            g_usage[i].count++;
            g_usage[i].last_nr = nr;
            return;
        }
        if (free_idx < 0 && g_usage[i].pid == 0) free_idx = i;
    }
    if (free_idx >= 0 && pid != 0) {
        g_usage[free_idx].pid = pid;
        g_usage[free_idx].count = 1;
        g_usage[free_idx].last_nr = nr;
    }
}

void hy_usage_error(void) { g_cmd_errors++; }

void hy_usage_diag(u64 *total, u64 *prctl, u64 *ctl0, u64 *shm,
                   u64 *errors, unsigned int *last_nr, int *last_pid,
                   int *out_pids, u64 *out_counts, int max_pids, int *n_pids)
{
    int i, n = 0;
    if (total)   *total   = g_cmd_total;
    if (prctl)   *prctl   = g_cmd_prctl;
    if (ctl0)    *ctl0    = g_cmd_ctl0;
    if (shm)     *shm     = g_cmd_shm;
    if (errors)  *errors  = g_cmd_errors;
    if (last_nr) *last_nr = g_last_nr;
    if (last_pid)*last_pid= g_last_pid;

    for (i = 0; i < HY_USAGE_SLOTS && n < max_pids; i++) {
        if (g_usage[i].pid == 0) continue;
        if (out_pids)   out_pids[n]   = g_usage[i].pid;
        if (out_counts) out_counts[n] = g_usage[i].count;
        n++;
    }
    if (n_pids) *n_pids = n;
}

/* ==================== v1.42.0 调试命令分发 ==================== */
/*
 * 供用户态 HuanyuD 程序（对应 /proc/HuanyuD）下发文本命令。
 * 只做字符串解析，不碰任何结构体布局。
 */

static unsigned long dbg_len(const char *s)
{
    unsigned long n = 0;
    if (!s) return 0;
    while (s[n]) n++;
    return n;
}

static void dbg_copy(char *dst, const char *src, unsigned long cap)
{
    unsigned long i = 0;
    if (!dst || cap == 0) return;
    if (src) { while (src[i] && i + 1 < cap) { dst[i] = src[i]; i++; } }
    dst[i] = 0;
}

static int dbg_reply(struct hy_dbg_req *q, const char *s)
{
    dbg_copy(q->out, s, sizeof(q->out));
    q->out_len = (u32)dbg_len(s);
    return 0;
}

/* 带整数格式化参数的回复（本地实现，不依赖任何 snprintf 符号） */

/* v1.73.1：dbg_puts 定义在下面，dbg_reply_int 的 %s 分支要用，先声明 */
static void dbg_puts(char *b, unsigned long *pos, unsigned long cap,
                     const char *s);

static void dbg_putn(char *b, unsigned long *pos, unsigned long cap,
                     unsigned long v, int hex)
{
    char tmp[24];
    int n = 0, i;

    if (!v) tmp[n++] = '0';
    while (v && n < (int)sizeof(tmp) - 1) {
        unsigned long d = v % (hex ? 16u : 10u);
        tmp[n++] = (char)(d < 10 ? ('0' + d) : ('a' + (d - 10)));
        v /= (hex ? 16u : 10u);
    }
    for (i = n - 1; i >= 0; i--) {
        if (*pos + 1 >= cap) return;
        b[(*pos)++] = tmp[i];
    }
    b[*pos] = 0;
}

/*
 * 【v1.73.1】极简格式化输出。支持 %d / %u / %x / %s / %ld / %lu / %lx。
 *
 * 修掉的坑：
 *
 *  1) 原来 args 只有 4 个槽，而 tstat 传了 8 个参数 —— 第 5 个往后全
 *     按 0 输出。命令行看到的统计数字是假的。
 *  2) 原来根本没有 %s 分支。遇到 %s 会把 '%' 和 's' 当普通字符原样
 *     吐出来，还白白吃掉一个参数槽，导致后面所有字段整体错位一位。
 *  3) 原来负数取绝对值输出、不带负号，-1 显示成 1。
 *  4) 原来不认 %lu。rwmode stat 那行三个 %lu 全被当普通字符原样打印，
 *     用户看到的是 "reads=%lu" 这种字面量，真实数字一个都出不来。
 *  5) 原来无条件 va_arg 8 次。调用方只传 2 个参数时多读 6 次属于越界
 *     读取（AAPCS64 下侥幸只是读到脏寄存器，换个 ABI 就可能踩栈）。
 *     现在先数一遍格式串里到底有几个占位符，只读那么多个。
 *
 * 统一按 unsigned long 取值：AAPCS64 下不足 8 字节的整型会被零/符号
 * 扩展进 8 字节槽，指针同为 8 字节，所以这样取是安全的。%d/%ld 时再
 * 转回 long 判符号，避免负数被当成巨大的无符号数。
 */

/*
 * 【v1.73.1】先扫一遍格式串，把每个占位符的"种类"记下来。
 *
 * 这么做是为了后面 va_arg 能用**和实参真实类型一致**的类型去取：
 *
 *   %d/%u/%x  → 实参是 int / unsigned int，按 unsigned int 取
 *   %ld/%lu/%lx → 实参是 long / unsigned long，按 unsigned long 取
 *   %s        → 实参是指针，按 void* 取
 *
 * 别用"统一按 unsigned long 取"那套写法。它依赖"调用方把不足 8 字节的
 * 整型符号/零扩展到 8 字节槽"——AArch64 上主流编译器碰巧这么做，但 ABI
 * 并不保证，x86-64 上就没有：传 int -1 时高 32 位是脏的，读出来是
 * 4294967295，显示成 "-4294967295" 或直接是个天文数字。
 *
 * kinds: 0=%d 1=%u 2=%x 3=%s 4=%ld 5=%lu 6=%lx
 */
#define DBG_MAX_ARGS 12

static int dbg_scan_specs(const char *fmt, int *kinds, int max)
{
    unsigned long i = 0;
    int n = 0;

    if (!fmt) return 0;
    while (fmt[i] && n < max) {
        if (fmt[i] == '%') {
            char c = fmt[i + 1];
            if (c == 'l' && (fmt[i + 2] == 'd' || fmt[i + 2] == 'u' ||
                             fmt[i + 2] == 'x')) {
                kinds[n++] = (fmt[i + 2] == 'd') ? 4
                           : ((fmt[i + 2] == 'u') ? 5 : 6);
                i += 3;
                continue;
            }
            if (c == 'd' || c == 'u' || c == 'x' || c == 's') {
                kinds[n++] = (c == 'd') ? 0 : ((c == 'u') ? 1
                           : ((c == 'x') ? 2 : 3));
                i += 2;
                continue;
            }
        }
        i++;
    }
    return n;
}

static int dbg_reply_int(struct hy_dbg_req *q, const char *fmt, ...)
{
    char out[256];
    unsigned long pos = 0, i = 0;
    unsigned long args[DBG_MAX_ARGS];
    int kinds[DBG_MAX_ARGS];
    int nargs = 0, nxt = 0, k;

    if (!fmt) return dbg_reply(q, "");

    for (k = 0; k < DBG_MAX_ARGS; k++) { args[k] = 0; kinds[k] = 0; }
    nargs = dbg_scan_specs(fmt, kinds, DBG_MAX_ARGS);

    {
        __builtin_va_list ap;
        __builtin_va_start(ap, fmt);
        for (k = 0; k < nargs; k++) {
            switch (kinds[k]) {
            case 0: { int v = __builtin_va_arg(ap, int);
                      args[k] = (unsigned long)(long)v; break; }
            case 1:
            case 2: { unsigned int v = __builtin_va_arg(ap, unsigned int);
                      args[k] = (unsigned long)v; break; }
            case 3: { void *v = __builtin_va_arg(ap, void *);
                      args[k] = (unsigned long)v; break; }
            case 4: { long v = __builtin_va_arg(ap, long);
                      args[k] = (unsigned long)v; break; }
            default:{ unsigned long v = __builtin_va_arg(ap, unsigned long);
                      args[k] = v; break; }
            }
        }
        __builtin_va_end(ap);
    }

    out[0] = 0;
    while (fmt[i] && pos + 1 < sizeof(out)) {
        char c = fmt[i + 1];
        int islong = 0;

        if (fmt[i] == '%' && c == 'l' &&
            (fmt[i + 2] == 'd' || fmt[i + 2] == 'u' || fmt[i + 2] == 'x')) {
            islong = 1;
            c = fmt[i + 2];
        }

        if (fmt[i] == '%' && (c == 'd' || c == 'u' || c == 'x' || c == 's')) {
            unsigned long v;
            if (c == 's') {
                const char *s;
                v = (nxt < nargs) ? args[nxt++] : 0;
                s = (const char *)v;
                dbg_puts(out, &pos, sizeof(out), s ? s : "(null)");
                i += 2;
                continue;
            }
            v = (nxt < nargs) ? args[nxt++] : 0;
            if (c == 'd' && (long)v < 0) {
                if (pos + 1 < sizeof(out)) out[pos++] = '-';
                v = (unsigned long)(-(long)v);
            }
            dbg_putn(out, &pos, sizeof(out), v, (c == 'x'));
            i += islong ? 3 : 2;
            continue;
        }
        out[pos++] = fmt[i++];
    }
    out[pos] = 0;
    return dbg_reply(q, out);
}

static int dbg_help(struct hy_dbg_req *q)
{
    dbg_copy(q->out,
        "HuanyuD <cmd> [args]\n"
        "  help / version\n"
        "  handshake                 版本/密钥握手状态(只显示版本号)\n"
        "  touch on|off              触摸总开关(probe+tscan)\n"
        "  probe on|off              事件探测(安全,摸屏才识别)\n"
        "  tscan on|off              主动枚举设备(历史崩点,单试)\n"
        "  touchstat                 触摸详细状态\n"
        /* v1.73.1：这几条 v1.58 就有，之前一直没进 help，等于没有 */
        "  tdown [<id>] <x> <y>      注入按下(多指,自动挑空闲槽)\n"
        "  tmove [<id>] <x> <y>      注入移动(多指)\n"
        "  tup [<id>]                注入抬起(不带id=全部)\n"
        "  tfinger                   列出各虚拟手指与动态容量\n"
        "  tclear                    强制清除残留手指(不看keep)\n"
        "  ti on|off                 注入总闸(off时禁止生成手指)\n"
        "  tstat                     注入统计(含 protect 与坐标范围)\n"
        "  tslots <n>                手动设总槽位数\n"
        "  trange [<a> <b> <c> <d>]  读/设坐标范围(不传参=只读)\n"
        "  tcap                      触摸事件抓包(诊断用)\n"
        "  grab on|off|stat / slotbase <n>\n"
        "  bpstat\n"
        "  devinfo reset|add <k=v>|show\n"
        "  guard on|off|status\n"
        "  unlock [seconds] / lock\n"
        "see also: cat /proc/HuanyuD\n",
        sizeof(q->out));
    q->out_len = (u32)dbg_len(q->out);
    return 0;
}

static void dbg_puts(char *b, unsigned long *pos, unsigned long cap,
                     const char *s)
{
    unsigned long i = 0;
    if (!b || !s) return;
    while (s[i] && *pos + 1 < cap) b[(*pos)++] = s[i++];
    b[*pos] = 0;
}

/*
 * 【v1.53.0】touchstat —— 触摸详细状态
 * 现在重心在触摸，单靠 /proc/Huanyu 的 [input] 段不够细，
 * 把抢夺、自学习分辨率、真实设备名一次打全。
 */
static int dbg_touchstat(struct hy_dbg_req *q)
{
    int real_found = 0, own_ok = 0, down = 0, probe_on = 0, mx = 0, my = 0;
    int dropped = 0, lx = 0, ly = 0;
    unsigned long pos = 0;
    const char *nm;

    hy_input_status(&real_found, &own_ok, &down, &probe_on, &mx, &my);
    hy_input_grab_status(&dropped, &lx, &ly);

    q->out[0] = 0;
    dbg_puts(q->out, &pos, sizeof(q->out), "touch=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)(hy_opt_touch ? 1 : 0), 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " real=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)real_found, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " own=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)own_ok, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " down=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)down, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " probe=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)probe_on, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " scr=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)mx, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), "x");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)my, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " base=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)hy_input_slot_base(), 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " maxdrv=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)hy_input_max_drv_slot(), 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " dropped=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)dropped, 0);
    /* v1.77.0：多点协议。A = 老屏(无 ABS_MT_SLOT)，B = 有槽位协议 */
    dbg_puts(q->out, &pos, sizeof(q->out), " proto=");
    dbg_puts(q->out, &pos, sizeof(q->out),
             hy_input_mt_proto() == 1 ? "A" : "B");

    /*
     * 【v1.57.0】把已登记设备清单和三项证据明细一并输出。
     * 之前只能看到 seen/found 两个数字，锁不上时完全不知道卡在哪 ——
     * 加上这段之后，一眼就能看出是 BTN_TOUCH 恒 0 还是压根没收到事件。
     */
    {
        char sbuf[512];
        int n = hy_input_seen_dump(sbuf, sizeof(sbuf));
        if (n > 0) {
            int k;
            dbg_puts(q->out, &pos, sizeof(q->out), "\nseen:\n");
            for (k = 0; k < n && pos < sizeof(q->out) - 2; k++)
                q->out[pos++] = sbuf[k];
            q->out[pos] = 0;
        }
    }
    dbg_puts(q->out, &pos, sizeof(q->out), "\nlock: tslock <idx>");
    dbg_puts(q->out, &pos, sizeof(q->out), " learn=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)lx, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), "x");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)ly, 0);
    dbg_puts(q->out, &pos, sizeof(q->out), " seen=");
    dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)hy_input_seen_count(), 0);
    nm = hy_input_active_name();
    dbg_puts(q->out, &pos, sizeof(q->out), " dev=");
    dbg_puts(q->out, &pos, sizeof(q->out), (nm && nm[0]) ? nm : "(none)");

    /*
     * 【v1.74.0】直接回答"到底哪个 event 是我的屏幕"。
     * 内核态拿不到 /dev/input/eventN 编号，但 /proc/bus/input/devices
     * 里每个设备都同时有 P: Phys= 和 H: Handlers=eventN ——
     * 上面 seen 行已经打出 phys，拿它去 grep 就能对上号。
     */
    dbg_puts(q->out, &pos, sizeof(q->out),
             "\nhint: 用 cat /proc/bus/input/devices 对照 phys 查 H: Handlers=eventN");
    q->out_len = (u32)dbg_len(q->out);
    return 0;
}


/*
 * v1.64.0：方案选择器命令的输出拼接。
 * dbg_reply_int 只吃整数（%d/%u/%x），方案名是字符串，只能自己拼。
 */
static void scheme_append(char *buf, unsigned long *pos, unsigned long cap,
                          const char *s)
{
    while (*s && *pos + 1 < cap) buf[(*pos)++] = *s++;
    buf[*pos] = 0;
}

static int scheme_dom_of(const char *s)
{
    static const char *const doms[HY_SC_COUNT] = {
        "physvirt", "pgtable", "memread", "kernrw", "bp", "input", "sym"
    };
    int d;
    if (!s) return -1;
    for (d = 0; d < HY_SC_COUNT; d++)
        if (!hy_strncmp(s, doms[d], hy_strlen(doms[d]))) return d;
    return -1;
}

static int dbg_cmd_scheme(struct hy_dbg_req *q, const char *arg)
{
    char rep[192];
    unsigned long pos = 0;
    int d, dom;
    const char *p = arg;

    rep[0] = 0;

    /* 无子命令：列出全部域当前档位 */
    if (!p || !p[0]) {
        for (d = 0; d < HY_SC_COUNT; d++) {
            if (d) scheme_append(rep, &pos, sizeof(rep), " ");
            scheme_append(rep, &pos, sizeof(rep), hy_scheme_dom_name(d));
            scheme_append(rep, &pos, sizeof(rep), "=g");
            if (pos + 1 < sizeof(rep)) {
                int g = hy_scheme_gen_of(d);
                rep[pos++] = (char)('0' + ((g >= 0 && g <= 9) ? g : 0));
                rep[pos] = 0;
            }
            scheme_append(rep, &pos, sizeof(rep), ":");
            scheme_append(rep, &pos, sizeof(rep), hy_scheme_name(d));
        }
        return dbg_reply(q, rep);
    }

    if (!hy_strncmp(p, "demote", 6))       p += 6;
    else if (!hy_strncmp(p, "force", 5))   p += 5;
    else return dbg_reply(q, "usage: scheme | scheme demote <dom> | scheme force <dom> <3|4|5|6|0>");

    while (*p == ' ') p++;
    dom = scheme_dom_of(p);
    if (dom < 0)
        return dbg_reply(q, "bad dom (physvirt|pgtable|memread|kernrw|bp|input|sym)");

    if (!hy_strncmp(arg, "force", 5)) {
        const char *g = p + hy_strlen(hy_scheme_dom_name(dom));
        int gen;
        while (*g == ' ') g++;
        gen = *g ? hy_atoi(g) : -1;
        if (gen < 0 || gen > 6)
            return dbg_reply(q, "bad gen (0=auto 3|4|5|6)");
        if (hy_scheme_force(dom, gen) < 0)
            return dbg_reply(q, "no usable scheme at that gen");
    } else {
        if (hy_scheme_demote(dom) < 0)
            return dbg_reply(q, "already at lowest gen");
    }

    scheme_append(rep, &pos, sizeof(rep), hy_scheme_dom_name(dom));
    scheme_append(rep, &pos, sizeof(rep), " -> g");
    if (pos + 1 < sizeof(rep)) {
        int g = hy_scheme_gen_of(dom);
        rep[pos++] = (char)('0' + ((g >= 0 && g <= 9) ? g : 0));
        rep[pos] = 0;
    }
    scheme_append(rep, &pos, sizeof(rep), ":");
    scheme_append(rep, &pos, sizeof(rep), hy_scheme_name(dom));
    return dbg_reply(q, rep);
}

int hy_dbg_cmd_dispatch(struct hy_dbg_req *q)
{
    char *cmd, *arg;

    if (!q) return -EINVAL;

    /*
     * v1.55.0：任何调试命令都算一次活动，立即退出节能模式。
     * 之前只有 hy_ctl_switch() 会调 hy_pm_touch()，而 echo 到
     * /proc/HuanyuD 走的是另一条路径 —— 于是 [power save] 一直
     * 停在 SAVING，扫描被跳过（日志里 saved scans 一直涨）。
     */
    hy_pm_touch();
    q->cmd[sizeof(q->cmd) - 1] = 0;
    q->out[0] = 0;
    q->out_len = 0;

    cmd = q->cmd;
    while (*cmd == ' ' || *cmd == '\t') cmd++;
    if (!*cmd) return dbg_help(q);

    /* 以第一个空白切分命令与参数 */
    arg = cmd;
    while (*arg && *arg != ' ' && *arg != '\t' && *arg != '\n' && *arg != '\r') arg++;
    if (*arg) { *arg = 0; arg++; while (*arg == ' ' || *arg == '\t') arg++; }
    else arg = NULL;

    if (!hy_strncmp(cmd, "help", 4) || !hy_strncmp(cmd, "?", 1))
        return dbg_help(q);

    if (!hy_strncmp(cmd, "version", 7)) {
        dbg_copy(q->out, HY_VERSION_STRING, sizeof(q->out));
        q->out_len = (u32)dbg_len(q->out);
        return 0;
    }

    /*
     * 【v1.67.0】握手状态查询。
     *
     * echo 这条文本调试通道本身 **不受闸门拦截**（它走 dbg_cmd_dispatch，
     * 不是 hy_ctl_switch），所以模块加载后仍能用它排障 —— 否则一旦
     * 用户态对接文件版本对不上，连问一句"内核到底是什么版本"都做不到。
     *
     * 真正被闸门拦住的是 prctl / supercall / 共享内存三条用户态 API 通道，
     * 那才是用户态对接文件实际走的路。
     *
     * 输出只含状态与版本号，不含密钥的任何字符。
     */
    if (!hy_strncmp(cmd, "handshake", 9)) {
        char gt[192];
        hy_memset(gt, 0, sizeof(gt));
        hy_gate_text(gt, sizeof(gt));
        dbg_copy(q->out, gt, sizeof(q->out));
        q->out_len = (u32)dbg_len(q->out);
        return 0;
    }

    /*
     * v1.55.0 触摸分级开关。
     *
     * 【顺序很重要】"touchstat" 必须以 9 字符先匹配，否则会被下面的
     * "touch" 前缀判断提前吃掉。
     *
     *   probe on|off    只装/卸 input_event 探测 hook（安全，摸屏才识别）
     *   tscan on|off    主动枚举 input_class 下所有设备（历史崩点，单试）
     *   touch on|off    两者一起开/关
     *   touchstat       看当前真实状态
     */
    if (!hy_strncmp(cmd, "touchstat", 9))
        return dbg_touchstat(q);   /* v1.53.0 已有的详细状态，直接复用 */

    /*
     * 【v1.59.0】tcap —— 触摸事件抓包。
     * 锁不上触摸屏时，先别急着改判据：把两个观察点各自的命中数、
     * 事件 type 分布、最近 8 条原始 (dev,type,code,value) 打出来，
     * 一看就知道是"hook 没挂到触摸屏路径"还是"判据太严"。
     */
    if (!hy_strncmp(cmd, "tcap", 4)) {
        char sbuf[768];
        int n;
        /*
         * 【v1.77.0】抓包默认是关的（省 CPU）。第一次 tcap 打开开关，
         * 但此刻缓冲还是空的 —— 所以提示再敲一次。记满 8192 条会自动停，
         * 不存在"诊断一次之后长期烧 CPU"的问题。
         */
        if (!hy_input_ie_trace(-1)) {
            hy_input_ie_trace(1);
            return dbg_reply(q, "tcap: trace ON, 再敲一次 tcap 看结果");
        }
        n = hy_input_tcap_dump(sbuf, sizeof(sbuf));
        if (n <= 0) return dbg_reply(q, "tcap: no event yet");
        return dbg_reply(q, sbuf);
    }

    /*
     * 【v1.57.0】手动锁定触摸屏 —— 自动判据锁不上时的可靠兜底。
     *
     *   tslock <n>      按 seen 表索引锁定（n 从 touchstat 列表里读）
     *   tslock name     清空手动锁定，回到自动识别
     *   tsname <名字>   按设备名锁定（名字从 /proc/bus/input/devices 读）
     *
     * tslock 走的是 g_seen[].dev —— 这些指针全部来自真实 input_event
     * 回调的第一个参数，内核亲手传入，绝对有效。比 tscan 枚举安全得多。
     */
    if (!hy_strncmp(cmd, "tslock", 6)) {
        int n, rc;
        if (!arg) return dbg_reply(q, "usage: tslock <index>|name");
        if (!hy_strncmp(arg, "name", 4))
            return dbg_reply(q, "usage: tslock <index> (see touchstat)");
        n = hy_atoi(arg);
        rc = hy_input_lock_index(n);
        if (rc != 0)
            return dbg_reply(q, "tslock bad index (see touchstat)");
        {
            int rf = 0, ow = 0, dn = 0, pb = 0, mx = 0, my = 0;
            hy_input_status(&rf, &ow, &dn, &pb, &mx, &my);
            return dbg_reply_int(q, "locked idx=%d real=%d scr=%d",
                                 n, rf, 0);
        }
    }

    if (!hy_strncmp(cmd, "tsname", 6)) {
        if (!arg) return dbg_reply(q, "usage: tsname <name>");
        hy_touch_set_name(arg);
        {
            int rf = 0, ow = 0, dn = 0, pb = 0, mx = 0, my = 0;
            hy_input_status(&rf, &ow, &dn, &pb, &mx, &my);
            return dbg_reply_int(q, "tsname set real=%d", rf, 0);
        }
    }

    if (!hy_strncmp(cmd, "probe", 5)) {
        int on = arg && !hy_strncmp(arg, "on", 2);
        int p = 0, t = 0, h = 0, seen = 0, found = 0;
        hy_input_runtime_enable(on ? 1 : 0, -1);   /* -1 = tscan 保持不变 */
        hy_input_runtime_state(&p, &t, &h, &seen, &found);
        (void)t; (void)seen; (void)found;
        return dbg_reply_int(q, "probe=%d hooked=%d", p, h);
    }

    if (!hy_strncmp(cmd, "tscan", 5)) {
        int on = arg && !hy_strncmp(arg, "on", 2);
        int p = 0, t = 0, h = 0, seen = 0, found = 0;
        hy_input_runtime_enable(-1, on ? 1 : 0);
        hy_input_runtime_state(&p, &t, &h, &seen, &found);
        return dbg_reply_int(q, "tscan=%d seen=%d found=%d",
                             t, seen, found);
    }

    if (!hy_strncmp(cmd, "touch", 5)) {
        int on = arg && !hy_strncmp(arg, "on", 2);
        int p = 0, t = 0, h = 0, seen = 0, found = 0;
        hy_opt_touch = on ? 1 : 0;
        /*
         * v1.55.0：这里曾经只改变量、不装 hook —— 命令回 OK 但实际
         * 什么都没发生。现在直接调 runtime_enable 真正装/卸。
         */
        hy_input_runtime_enable(on ? 1 : 0, on ? 1 : 0);
        hy_input_runtime_state(&p, &t, &h, &seen, &found);
        (void)seen; (void)found;
        return dbg_reply_int(q, "touch=%d probe=%d tscan=%d hooked=%d",
                             on ? 1 : 0, p, t, h);
    }

    /* ---- v1.43.0 设备信息（用户态采集，内核只缓存）----
     *   HuanyuD devinfo reset
     *   HuanyuD devinfo add <key>=<value>
     */
    if (!hy_strncmp(cmd, "devinfo", 7)) {
        if (!arg || !hy_strncmp(arg, "reset", 5)) {
            hy_devinfo_reset();
            return dbg_reply(q, "devinfo reset");
        }
        if (!hy_strncmp(arg, "add ", 4) || !hy_strncmp(arg, "add	", 4)) {
            const char *line = arg + 4;
            int rc = hy_devinfo_add(line);
            return dbg_reply(q, rc == 0 ? "ok" : (rc == -ENOSPC ? "full" : "bad"));
        }
        if (!hy_strncmp(arg, "show", 4)) {
            const char *t = hy_devinfo_text();
            return dbg_reply(q, (t && t[0]) ? t : "(empty)");
        }
        return dbg_reply(q, "usage: devinfo reset|add <k=v>|show");
    }

    /* ---- v1.46.0 触摸抢夺 ----
     *   HuanyuD grab on|off       槽位抢占（拦掉物理驱动对我们槽位的事件）
     *   HuanyuD slotbase <n>      虚拟手指起始槽位
     *   HuanyuD grabstat          抢夺统计（丢弃数 / 自学习分辨率）
     */
    if (!hy_strncmp(cmd, "grab", 4)) {
        if (arg && !hy_strncmp(arg, "stat", 4)) {
            int dropped = 0, lx = 0, ly = 0;
            hy_input_grab_status(&dropped, &lx, &ly);
            return dbg_reply_int(q, "grab dropped=%d learn=%dx%d base=%d maxdrv=%d",
                                 dropped, lx, ly, hy_input_slot_base(),
                                 hy_input_max_drv_slot());
        }
        {
            int on = arg && !hy_strncmp(arg, "on", 2);
            hy_opt_grab = on ? 1 : 0;
            hy_input_set_grab(on);
            return dbg_reply(q, on ? "grab=on" : "grab=off");
        }
    }

    if (!hy_strncmp(cmd, "slotbase", 8)) {
        int n = arg ? hy_atoi(arg) : -1;
        int rc = hy_input_set_slot_base(n);
        return dbg_reply(q, rc == 0 ? "slotbase ok" : "slotbase bad (0..9)");
    }

    /* ---- v1.58.0 secure touch inject ----
     *   tdown <x> <y>   按下（自动挑真手指没在用的空槽，槽位满则丢弃）
     *   tmove <x> <y>   移动
     *   tup             抬起
     *   tstat           注入状态统计
     *   tslots <n>      手动设定总槽位数（自学习不可靠时用）
     * 不创建设备、不改能力位、不抢真手指 —— 系统看到的是正常多点触摸。
     */
    /*
     * 【v1.76.0 多指】
     *   tdown <x> <y>         按下（自动分配一个空闲手指 id）
     *   tdown <id> <x> <y>    按下指定手指
     *   tmove <x> <y>         移动最近操作的那根
     *   tmove <id> <x> <y>    移动指定手指
     */
    if (!hy_strncmp(cmd, "tdown", 5) || !hy_strncmp(cmd, "tmove", 5)) {
        int v[3], n, id = -1, x = 0, y = 0, rc;
        unsigned long pos = 0;

        n = dbg_parse_n(arg, v, 3);
        if (n == 3)      { id = v[0]; x = v[1]; y = v[2]; }
        else if (n == 2) { x = v[0]; y = v[1]; }
        else return dbg_reply(q, cmd[1] == 'd' ? "usage: tdown [<id>] <x> <y>"
                                               : "usage: tmove [<id>] <x> <y>");

        if (cmd[1] == 'd')
            rc = (id >= 0) ? hy_ti_down_id(id, x, y) : hy_ti_down(x, y);
        else
            rc = (id >= 0) ? hy_ti_move_id(id, x, y) : hy_ti_move(x, y);

        if (rc == 0) {
            int fid = (id >= 0) ? id : hy_ti_last_finger();
            int slot = hy_ti_finger_slot(fid);
            q->out[0] = 0;
            dbg_puts(q->out, &pos, sizeof(q->out),
                     cmd[1] == 'd' ? "tdown ok id=" : "tmove ok id=");
            dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)fid, 0);
            dbg_puts(q->out, &pos, sizeof(q->out), " slot=");
            dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)slot, 0);
            dbg_puts(q->out, &pos, sizeof(q->out), " active=");
            dbg_putn(q->out, &pos, sizeof(q->out),
                     (unsigned long)hy_ti_active_count(), 0);
            /*
             * 【v1.78.0】cap 口径修正。
             *
             * 原先打印 capacity() + active_count()，而 capacity() 本身已是
             * "虚拟手指总配额"（总槽位 - 真手指占用），再加一次 active 就
             * 变成 "总槽位 - 真手指 + 虚拟手指"，属重复计算 —— 于是出现
             * slot=9/10 与 cap=11 并存的自相矛盾输出，让人误以为分配越界。
             *
             * 统一为纯总配额，与 tfinger 的 cap= 口径一致。
             */
            dbg_puts(q->out, &pos, sizeof(q->out), "/cap=");
            dbg_putn(q->out, &pos, sizeof(q->out),
                     (unsigned long)hy_ti_capacity(), 0);
            q->out[pos] = 0;
            q->out_len = (u32)dbg_len(q->out);
            return 0;
        }
        if (rc == -EBUSY) return dbg_reply(q, "busy (no free slot / capacity full)");
        if (rc == -ECANCELED) return dbg_reply(q, "canceled (slot conflict)");
        if (rc == -EINVAL) return dbg_reply(q, "no active finger");
        if (rc == -EACCES) return dbg_reply(q, "inject disabled (ti off)");
        return dbg_reply(q, "touch not ready (probe on + touch screen first)");
    }
    /*
     * 【v1.76.0 多指】
     *   tup         抬起全部虚拟手指
     *   tup <id>    只抬起指定手指
     */
    if (!hy_strncmp(cmd, "tup", 3)) {
        int v[2], rc, n = 0;
        if (arg) n = dbg_parse_n(arg, v, 1);
        rc = (n == 1) ? hy_ti_up_id(v[0]) : hy_ti_up();
        if (rc == 0) return dbg_reply(q, n == 1 ? "tup ok (one)" : "tup ok (all)");
        if (rc == -EACCES) return dbg_reply(q, "inject disabled (ti off)");
        if (rc == -ECANCELED) return dbg_reply(q, "canceled (slot conflict)");
        if (rc == -EINVAL) return dbg_reply(q, "no active finger");
        return dbg_reply(q, "touch not ready");
    }
    /*
     * 【v1.76.0】tfinger —— 列出每根虚拟手指的状态。
     * 多指调试时最需要看的就是：哪几根在按、各占哪个槽、还能再按几根。
     */
    if (!hy_strncmp(cmd, "tfinger", 7)) {
        int i, cap = hy_ti_capacity(), act = hy_ti_active_count();
        unsigned long pos = 0;
        q->out[0] = 0;
        dbg_puts(q->out, &pos, sizeof(q->out), "fingers=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)act, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " cap=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)cap, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " slots=");
        dbg_putn(q->out, &pos, sizeof(q->out),
                 (unsigned long)hy_ti_max_slots_for_cap(), 0);
        for (i = 0; i < 16; i++) {
            int sl = hy_ti_finger_slot(i);
            if (sl < 0) continue;
            dbg_puts(q->out, &pos, sizeof(q->out), " [");
            dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)i, 0);
            dbg_puts(q->out, &pos, sizeof(q->out), "]s=");
            dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)sl, 0);
        }
        q->out[pos] = 0;
        q->out_len = (u32)dbg_len(q->out);
        return 0;
    }
    /*
     * 【v1.75.0】tclear —— 强制清除残留手指。
     *
     * 这是"手指按下后一直不消失"的兜底解法。tup 靠位图判断 keep 才
     * 决定要不要发 BTN_TOUCH=0，位图一旦有残留就不发，上层收不到
     * "触摸结束"信号，圆点就永久留在屏上。tclear 不看 keep，无条件
     * 发完整抬起序列并清空位图。
     *
     * tclear 不受注入总闸限制 —— 它就是用来收拾残局的，被禁用时更要用。
     */
    if (!hy_strncmp(cmd, "tclear", 6)) {
        int rc = hy_ti_force_clear();
        if (rc == 0) return dbg_reply(q, "tclear ok (finger cleared)");
        return dbg_reply(q, "touch not ready");
    }
    /*
     * 【v1.75.0】ti on|off —— 注入总闸。
     *
     * 触摸探测（probe）是只读的，默认开且无害；"生成手指"则必须显式
     * 调用。这道闸门再兜一层：关掉后 down/move/up 一律拒绝，用户态
     * 调用也不放行，确保没有任何自动生成手指的路径。
     */
    if (!hy_strncmp(cmd, "ti", 2) && (cmd[2] == ' ' || cmd[2] == '\0')) {
        const char *a = cmd + 2;
        while (*a == ' ') a++;
        if (!hy_strncmp(a, "on", 2)) {
            hy_ti_set_inject_allowed(1);
            return dbg_reply(q, "inject allowed (ti on)");
        }
        if (!hy_strncmp(a, "off", 3)) {
            hy_ti_force_clear();
            hy_ti_set_inject_allowed(0);
            return dbg_reply(q, "inject disabled + finger cleared (ti off)");
        }
        return dbg_reply(q, hy_ti_get_inject_allowed()
                            ? "inject=on  (usage: ti on|off)"
                            : "inject=off (usage: ti on|off)");
    }
    if (!hy_strncmp(cmd, "tstat", 5)) {
        /*
         * 【v1.73.1】手工拼，不用 dbg_reply_int。
         *
         * 两个原因：一是字段有 13 个，超过它 8 个槽的上限；二是这里要
         * 输出状态名字符串。改用 dbg_puts/dbg_putn 逐段拼，和
         * dbg_touchstat 一个路子。
         *
         * 补上了 protects（拦下的"抹除虚拟手指"事件数，判断注入后手指
         * 一闪就没有没有修好的直接证据）和坐标范围 —— 这两个之前在命令
         * 行完全看不到，只能盲猜。
         */
        struct hy_ti_stat st;
        struct hy_ti_range rg;
        unsigned long pos = 0;
        static const char *nm[3] = { "IDLE", "ACTIVE", "CONFLICTED" };

        hy_ti_stat_fill(&st);
        hy_ti_get_range(&rg);
        if (st.state < 0 || st.state > 2) st.state = 0;

        q->out[0] = 0;
        dbg_puts(q->out, &pos, sizeof(q->out), "state=");
        dbg_puts(q->out, &pos, sizeof(q->out), nm[st.state]);
        dbg_puts(q->out, &pos, sizeof(q->out), " slot=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.inj_slot, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " slots=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.max_slots, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " down=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.downs, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " move=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.moves, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " up=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.ups, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " busy=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.busy, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " conflict=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.conflicts, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " protect=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)st.protects, 0);
        /* v1.76.0 多指：当前按着几根 / 还能再按几根 */
        dbg_puts(q->out, &pos, sizeof(q->out), " fingers=");
        dbg_putn(q->out, &pos, sizeof(q->out),
                 (unsigned long)hy_ti_active_count(), 0);
        dbg_puts(q->out, &pos, sizeof(q->out), "/cap=");
        dbg_putn(q->out, &pos, sizeof(q->out),
                 (unsigned long)(hy_ti_capacity() + hy_ti_active_count()), 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " range=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.min_x, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), "..");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.max_x, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " x ");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.min_y, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), "..");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.max_y, 0);
        q->out[pos] = 0;
        q->out_len = (u32)dbg_len(q->out);
        return 0;
    }
    /* v1.73.1：trange —— 读/设坐标范围 */
    if (!hy_strncmp(cmd, "trange", 6)) {
        struct hy_ti_range rg;
        unsigned long pos = 0;
        int a = 0, b = 0, c = 0, d = 0;
        if (arg && dbg_parse4(arg, &a, &b, &c, &d) == 0) {
            if (hy_ti_set_range(a, b, c, d) != 0)
                return dbg_reply(q, "trange bad");
        } else if (arg) {
            return dbg_reply(q, "usage: trange [<minx> <maxx> <miny> <maxy>]");
        }
        hy_ti_get_range(&rg);
        q->out[0] = 0;
        dbg_puts(q->out, &pos, sizeof(q->out), "range=");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.min_x, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), "..");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.max_x, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), " x ");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.min_y, 0);
        dbg_puts(q->out, &pos, sizeof(q->out), "..");
        dbg_putn(q->out, &pos, sizeof(q->out), (unsigned long)rg.max_y, 0);
        q->out[pos] = 0;
        q->out_len = (u32)dbg_len(q->out);
        return 0;
    }
    if (!hy_strncmp(cmd, "tslots", 6)) {
        int n = arg ? hy_atoi(arg) : -1;
        return dbg_reply(q, hy_ti_set_slots(n) == 0 ? "tslots ok" : "tslots bad (1..256)");
    }

    /* ---- v1.64.0 方案选择器 ----
     *   scheme                      列出各功能面当前档位
     *   scheme demote <域>          手动降一档
     *   scheme force <域> <3|4|5|6|0>  强制指定世代（0 = 恢复自动）
     */
    if (!hy_strncmp(cmd, "scheme", 6))
        return dbg_cmd_scheme(q, arg);

    /* ---- v1.60.0 压力测试 ----
     *   stress <时长><单位> <all|cpu|mem|storage> [档位1..15] [存储路径]
     *   stress off      中止
     *   stress stat     看进度
     * 默认全面关闭，只有下命令才启动；到点自动结束。
     */
    if (!hy_strncmp(cmd, "stress", 6)) {
        char rep[160];
        (void)hy_stress_cmd(arg, rep, sizeof(rep));
        return dbg_reply(q, rep);
    }

    /* ---- v1.60.0 读取后端选择 ----
     *   rwmode 0|1|stat
     * 0 = 内核级读取（默认）；1 = KMA 硬件级读取。
     * KMA 只对内核虚拟地址与物理地址生效，用户态进程内存自动回落内核级。
     */
    if (!hy_strncmp(cmd, "rwmode", 6)) {
        if (arg && !hy_strncmp(arg, "stat", 4)) {
            unsigned long r = 0, f = 0, e = 0;
            hy_kma_stats(&r, &f, &e);
            return dbg_reply_int(q, "rwmode=%d avail=%d reads=%lu fallback=%lu err=%lu",
                                 hy_kma_mode(), hy_kma_available(), r, f, e);
        }
        {
            int m = arg ? hy_atoi(arg) : -1;
            if (m != 0 && m != 1)
                return dbg_reply(q, "usage: rwmode 0|1|stat");
            hy_kma_set_mode(m);
            if (m == 1 && !hy_kma_available())
                return dbg_reply(q, "rwmode=1 but KMA unavailable -> auto fallback to kernel");
            return dbg_reply_int(q, "rwmode=%d avail=%d", hy_kma_mode(),
                                 hy_kma_available());
        }
    }

    /* ---- v1.51.0 顶级防格机 ----
     *   HuanyuD guard on|off|status
     *   HuanyuD unlock [seconds]   开解锁窗口，默认 300 秒（窗口内放行一切）
     *   HuanyuD lock               立即结束窗口
     */
    if (!hy_strncmp(cmd, "unlock", 6)) {
        char rep[160];
        hy_guard_cmd("unlock", arg, rep, sizeof(rep));
        return dbg_reply(q, rep);
    }
    if (!hy_strncmp(cmd, "lock", 4)) {
        char rep[160];
        hy_guard_cmd("lock", NULL, rep, sizeof(rep));
        return dbg_reply(q, rep);
    }
    if (!hy_strncmp(cmd, "guard", 5)) {
        char rep[160];
        hy_guard_cmd(arg ? arg : "status", NULL, rep, sizeof(rep));
        return dbg_reply(q, rep);
    }

    if (!hy_strncmp(cmd, "touchstat", 9))
        return dbg_touchstat(q);

    if (!hy_strncmp(cmd, "bpstat", 6)) {
        struct hy_bp_caps c;
        (void)hy_bp_get_caps(&c);
        return dbg_reply_int(q, "bp caps=0x%x brps=%u wrps=%u active=%d",
                             c.supported, c.num_brps, c.num_wrps,
                             hy_bp_active_count());
    }

    return dbg_reply(q, "unknown command; try: HuanyuD help");
}

int hy_ctl_switch(unsigned int nr, void *payload)
{
    /*
     * 【v1.67.0 握手闸门】
     *
     * 放在最开头，且排在 hy_pm_touch() 之前：
     *   1. 拦下的命令不该算作"活动信号"，否则未握手也能把省电唤醒，
     *      等于绕过了闸门的一半意义。
     *   2. prctl / supercall / 共享内存三条通道最终都汇入这里，
     *      所以这一道就能覆盖所有入口，不必在每个通道各写一遍。
     *
     * 只放行 HY_NR_VERSION（问版本）与 HY_NR_HANDSHAKE（重试握手）。
     */
    if (!hy_gate_allow(nr))
        return -EACCES;

    /*
     * 命令入口 = 活动信号。
     * prctl / supercall / 共享内存三条通道最终都汇入这里，
     * 所以在这里 touch 就能覆盖所有使用情况。
     */
    hy_pm_touch();

    usage_record(nr);

    switch (nr) {
    /* ---------------- 进程 / 模块 ---------------- */
    case HY_NR_GET_PID: {
        struct hy_request *r = (struct hy_request *)(payload);
        int pid = hy_get_pid_by_name((char *)(unsigned long)r->buffer);
        if (pid < 0) return -ESRCH;
        r->pid = pid;
        return 0;
    }

    case HY_NR_MODULE_BASE: {
        const struct hy_request *r = (const struct hy_request *)(payload);
        struct hy_request *w = (struct hy_request *)(payload);
        int base = hy_get_module_base(r);
        if (base < 0) return -EINVAL;
        w->addr = (u64)base;
        return 0;
    }

    case HY_NR_MODULE_BSS: {
        const struct hy_request *r = (const struct hy_request *)(payload);
        struct hy_request *w = (struct hy_request *)(payload);
        int bss = hy_get_module_bss(r);
        if (bss < 0) return -EINVAL;
        w->addr = (u64)bss;
        return 0;
    }

    /* ---------------- 内存 ---------------- */
    /*
     * READ_MEM   : 标准路径，先做 VMA 存在性检查再读
     * READ_MEM_V2: 快速路径，跳过检查直接走页表（用于已知合法的地址）
     */
    case HY_NR_READ_MEM: {
        const struct hy_request *r = (const struct hy_request *)(payload);
        return hy_mem_rw_ex_checked(r, false) > 0 ? 0 : -EFAULT;
    }

    case HY_NR_READ_MEM_V2: {
        const struct hy_request *r = (const struct hy_request *)(payload);
        return hy_mem_rw_ex(r, false) > 0 ? 0 : -EFAULT;
    }

    case HY_NR_WRITE_MEM: {
        const struct hy_request *r = (const struct hy_request *)(payload);
        return hy_mem_rw_ex_checked(r, true) > 0 ? 0 : -EFAULT;
    }

    /* ---------------- 触摸 / 陀螺仪 ---------------- */
    /*
     * v1.22.0：按名字锁定真实触摸屏 / 重新扫描
     * 参考 hy_input.c 中 hy_ie_probe_before 的说明。
     */
    case HY_NR_TOUCH_SET_NAME: {
        const struct hy_touch_name *n =
            (const struct hy_touch_name *)(payload);
        return hy_touch_set_name(n->name);
    }
    case HY_NR_TOUCH_RESCAN:
        return hy_touch_rescan();

    case HY_NR_TOUCH_INIT: {
        const struct hy_touch_event_base *t =
            (const struct hy_touch_event_base *)(payload);
        return hy_touch_init(t->slot);
    }

    case HY_NR_TOUCH_DOWN: {
        const struct hy_touch_event_base *t =
            (const struct hy_touch_event_base *)(payload);
        return hy_touch_down(t->slot, t->x, t->y);
    }

    case HY_NR_TOUCH_UP: {
        const struct hy_touch_event_base *t =
            (const struct hy_touch_event_base *)(payload);
        return hy_touch_up(t->slot);
    }

    case HY_NR_GYRO_INIT: {
        int method;
        method = (int)hy_get_u32(payload);
        return hy_gyro_init(method);
    }

    case HY_NR_GYRO_CONFIG: {
        const struct hy_gyro_config *c = (const struct hy_gyro_config *)(payload);
        return hy_gyro_config(c);
    }

    /* ---------------- TLS / PACGA ---------------- */
    case HY_NR_GET_THREAD_TLS: {
        struct hy_tls_request *r = (struct hy_tls_request *)(payload);
        return hy_get_thread_tls(r);
    }

    case HY_NR_EXEC_PACGA: {
        struct hy_pacga_request *r = (struct hy_pacga_request *)(payload);
        return hy_exec_pacga(r);
    }

    /* ---------------- 文件隐藏 ---------------- */
    case HY_NR_FILE_HIDE_INIT:
        return hy_file_hide_init();

    case HY_NR_FILE_HIDE_SET: {
        const struct hy_file_hide_config *c =
            (const struct hy_file_hide_config *)(payload);
        return hy_file_hide_set(c);
    }

    case HY_NR_FILE_HIDE_CLEAR:
        return hy_file_hide_clear();

    case HY_NR_FILE_HIDE_STATUS: {
        struct hy_file_hide_status *s = (struct hy_file_hide_status *)(payload);
        return hy_file_hide_status(s);
    }

    /* ---------------- 断点 ---------------- */
    case HY_NR_BP_GET_CAPS: {
        struct hy_bp_caps *caps = (struct hy_bp_caps *)(payload);
        /*
         * 【修复 v1.19.0】原来 num_brps / num_wrps 硬编码返回 0。
         * 用户态据此判断"硬件断点能用几个"，拿到 0 就以为不支持硬件断点，
         * 于是永远不去用 HW 方案 —— 白白浪费最隐蔽最快的一种。
         */
        caps->supported = hy_bp_caps();
        caps->num_brps = hy_bp_num_brps();
        caps->num_wrps = hy_bp_num_wrps();
        caps->reserved = 0;
        return (int)sizeof(*caps);
    }

    case HY_NR_BP_SET_MODE: {
        const struct hy_bp_mode_config *cfg =
            (const struct hy_bp_mode_config *)(payload);
        if (cfg->mode >= HY_BP_MODE_MAX) return -EINVAL;
        hy_default_mode = cfg->mode;
        HY_LOG("ctl: mode -> %u\n", hy_default_mode);
        return 0;
    }

    case HY_NR_BP_GET_MODE: {
        struct hy_bp_mode_config *cfg = (struct hy_bp_mode_config *)(payload);
        cfg->mode = hy_default_mode;
        cfg->flags = 0;
        return (int)sizeof(*cfg);
    }

    case HY_NR_BP_GET_NUM_BRPS:
    case HY_NR_BP_GET_NUM_WRPS: {
        /* 槽位数：从 ID_AA64DFR0 读，这里返回缓存值 */
        u32 *n = (u32 *)(payload);
        *n = (nr == HY_NR_BP_GET_NUM_BRPS) ? hy_bp_num_brps() : hy_bp_num_wrps();
        return (int)sizeof(*n);
    }

    case HY_NR_BP_INST: {
        const struct hy_bp_inst_args *a = (const struct hy_bp_inst_args *)(payload);
        u64 h = hy_bp_install(a);
        if (!h) return -EINVAL;
        {
            struct hy_bp_inst_args *w = (struct hy_bp_inst_args *)(payload);
            w->addr = h;    /* 回填 handle */
        }
        return 0;
    }

    case HY_NR_BP_UNINST: {
        u64 h;
        h = hy_get_u64(payload);
        return hy_bp_uninstall(h);
    }

    case HY_NR_BP_SUSPEND: {
        u64 h;
        h = hy_get_u64(payload);
        return hy_bp_suspend(h);
    }

    case HY_NR_BP_RESUME: {
        u64 h;
        h = hy_get_u64(payload);
        return hy_bp_resume(h);
    }

    case HY_NR_BP_MODIFY: {
        const struct hy_bp_modify_args *a =
            (const struct hy_bp_modify_args *)(payload);
        return hy_bp_modify(a);
    }

    case HY_NR_BP_GET_HIT_COUNT: {
        struct hy_bp_get_hit_count_arg *a =
            (struct hy_bp_get_hit_count_arg *)(payload);
        return hy_bp_get_hit_count(a);
    }

    case HY_NR_BP_GET_HIT_ITEMS: {
        struct hy_bp_get_hit_items_args *a =
            (struct hy_bp_get_hit_items_args *)(payload);
        return hy_bp_get_hit_items(a);
    }

    case HY_NR_BP_CHECK_INITED:
    case HY_NR_BP_INIT_CMD:
        return hy_ready ? 0 : -ENODEV;

    /* ---------------- 扩展能力 ---------------- */
    case HY_NR_ENUM_MODULES:
        return hy_enum_modules((struct hy_enum_mods_req *)(payload));

    case HY_NR_ENUM_PROCESSES:
        return hy_enum_processes((struct hy_enum_procs_req *)(payload));

    case HY_NR_ENUM_THREADS:
        return hy_enum_threads((struct hy_enum_threads_req *)(payload));

    case HY_NR_KERNEL_RW:
        return hy_kernel_rw((struct hy_kern_rw_req *)(payload));

    case HY_NR_PHYS_RW:
        return hy_phys_rw((struct hy_kern_rw_req *)(payload));

    case HY_NR_PROTECT:
        return hy_protect((struct hy_protect_req *)(payload));

    case HY_NR_CACHE_FLUSH:
        return hy_cache_flush((struct hy_flush_req *)(payload));

    case HY_NR_BP_LIST:
        return hy_bp_list((struct hy_bp_list_req *)(payload));

    case HY_NR_BP_CLEAR_HITS: {
        u64 h;
        h = hy_get_u64(payload);
        return hy_bp_clear_hits(h);
    }

    case HY_NR_HWCAP:
        return hy_hwcap((struct hy_hwcap *)(payload));

    case HY_NR_STATS:
        return hy_stats((struct hy_stats *)(payload));

    case HY_NR_SHM_REGISTER:
        return hy_shm_register((struct hy_shm_register *)(payload));

    case HY_NR_SHM_STATUS:
        return hy_shm_status((struct hy_shm_status *)(payload));

    case HY_NR_VERSION: {
        u32 *v = (u32 *)(payload);
        v[0] = HY_MAGIC;
        v[1] = HY_VER_MAJOR;
        v[2] = HY_VER_MINOR;
        v[3] = hy_bp_caps();
        /*
         * 返回值约定与其他命令一致：0 = 成功。
         * 之前返回 16（payload 字节数），调用方按 ==0 判断会误判失败。
         */
        return 0;
    }

    /*
     * 【v1.71.0】握手：两步挑战-响应。用户态先自报版本号取挑战密文，
     * 本地用五层密钥解开后送回明文，内核与原文比对一致才放行。
     * 闸门本身在 hy_ctl_switch 开头（hy_gate_allow），这里只处理握手命令。
     */
    case HY_NR_HANDSHAKE:
        return hy_gate_handshake((struct hy_handshake_req *)(payload));

    /* ==================================================================
     * 【v1.18.0】ls 移植能力
     * ================================================================== */

    /* ---- syscall 监控 ---- */
    case HY_NR_SYSMON_SET: {
        struct hy_sysmon_req *r = (struct hy_sysmon_req *)(payload);
        return hy_sysmon_set(r->pid, r->enable);
    }

    case HY_NR_SYSMON_REMOVE: {
        struct hy_sysmon_req *r = (struct hy_sysmon_req *)(payload);
        return hy_sysmon_set(r->pid, 0);
    }

    case HY_NR_SYSMON_READ:
        return hy_sysmon_read((struct hy_sysmon_read *)(payload));

    /* ---- CNTVCT 监控 ---- */
    case HY_NR_CNTVCT_SET: {
        struct hy_cntvct_req *r = (struct hy_cntvct_req *)(payload);
        return hy_cntvct_set(r->pid, r->enable);
    }

    case HY_NR_CNTVCT_REMOVE: {
        struct hy_cntvct_req *r = (struct hy_cntvct_req *)(payload);
        return hy_cntvct_set(r->pid, 0);
    }

    case HY_NR_CNTVCT_READ:
        return hy_cntvct_read((struct hy_cntvct_read *)(payload));

    /* ---- 虚拟定位 ---- */
    case HY_NR_GNSS_INIT:
    case HY_NR_GNSS_REPORT: {
        struct hy_gnss_req *r = (struct hy_gnss_req *)(payload);
        return hy_gnss_set(r->latitude_e7, r->longitude_e7, r->enable);
    }

    case HY_NR_GNSS_STOP:
        return hy_gnss_set(0, 0, 0);

    /* ---- 增强枚举 ---- */
    case HY_NR_ENUM_SEGMENTS:
        return hy_enum_segments((struct hy_enum_segs_req *)(payload));

    case HY_NR_ENUM_REGIONS:
        return hy_enum_regions((struct hy_enum_regions_req *)(payload));

    /* ---- 单步断点 ---- */
    case HY_NR_STEPBP_SET: {
        struct hy_stepbp_req *r = (struct hy_stepbp_req *)(payload);
        return hy_stepbp_set(r->pid, r->addr, r->enable);
    }

    case HY_NR_STEPBP_REMOVE: {
        struct hy_stepbp_req *r = (struct hy_stepbp_req *)(payload);
        return hy_stepbp_set(r->pid, r->addr, 0);
    }

    /* ---- DPT 主线程影子页 ---- */
    case HY_NR_DPT_SET: {
        struct hy_dpt_req *r = (struct hy_dpt_req *)(payload);
        return hy_dpt_set(r->pid, r->addr, r->enable);
    }

    case HY_NR_DPT_REMOVE: {
        struct hy_dpt_req *r = (struct hy_dpt_req *)(payload);
        return hy_dpt_set(r->pid, r->addr, 0);
    }

    /* ---- 扩展能力 ---- */
    case HY_NR_HWCAP2:
        return hy_hwcap2((struct hy_hwcap2 *)(payload));

    /* ---- v1.64.0 方案选择 ---- */
    case HY_NR_SCHEME_SET: {
        struct hy_scheme_req *r = (struct hy_scheme_req *)(payload);
        int ok;
        if (r->gen != HY_SCHEME_AUTO && r->gen != HY_SCHEME_GEN3 &&
            r->gen != HY_SCHEME_GEN4 && r->gen != HY_SCHEME_GEN5 &&
            r->gen != HY_SCHEME_GEN6)
            return -EINVAL;
        ok = hy_scheme_force((int)r->dom, (int)r->gen);
        if (ok < 0) return -EINVAL;
        r->chosen  = (u32)(ok & 0x7fffffff);
        r->cur_gen = (u32)hy_scheme_gen_of((int)r->dom);
        return 0;
    }
    case HY_NR_SCHEME_GET: {
        struct hy_scheme_req *r = (struct hy_scheme_req *)(payload);
        int i = hy_scheme_chosen((int)r->dom);
        r->chosen  = (u32)(i < 0 ? 0xffffffffu : (u32)i);
        r->cur_gen = (u32)hy_scheme_gen_of((int)r->dom);
        return 0;
    }

    /* ---- v1.73.0 secure touch inject：全量暴露给用户态 ----
     *
     * 之前只在内核里，用户态根本调不到。这里一次补齐：
     * down / move / up / 状态 / 槽位数 / 坐标范围。
     */
    case HY_NR_TI_DOWN: {
        const struct hy_touch_event_base *t =
            (const struct hy_touch_event_base *)(payload);
        return hy_ti_down(t->x, t->y);
    }
    case HY_NR_TI_MOVE: {
        const struct hy_touch_event_base *t =
            (const struct hy_touch_event_base *)(payload);
        return hy_ti_move(t->x, t->y);
    }
    case HY_NR_TI_UP:
        return hy_ti_up();

    case HY_NR_TI_STATUS: {
        struct hy_ti_stat *st = (struct hy_ti_stat *)(payload);
        hy_ti_stat_fill(st);
        return 0;
    }
    case HY_NR_TI_SET_SLOTS: {
        const struct hy_ti_range *r = (const struct hy_ti_range *)(payload);
        return hy_ti_set_slots((int)r->min_x);
    }
    case HY_NR_TI_SET_RANGE: {
        const struct hy_ti_range *r = (const struct hy_ti_range *)(payload);
        return hy_ti_set_range(r->min_x, r->max_x, r->min_y, r->max_y);
    }
    /* v1.73.1：读回坐标范围（诊断：内核自学到了什么分辨率） */
    case HY_NR_TI_GET_RANGE: {
        struct hy_ti_range *r = (struct hy_ti_range *)(payload);
        hy_ti_get_range(r);
        return 0;
    }

    /* v1.75.0：强制清除残留手指（不看 keep，无条件发完整抬起序列） */
    case HY_NR_TI_CLEAR:
        return hy_ti_force_clear();

    /* v1.75.0：注入总闸。r->min_x: 0=关 1=开 其他=仅查询 */
    case HY_NR_TI_INJECT_GATE: {
        const struct hy_ti_range *r =
            (const struct hy_ti_range *)(payload);
        if (r->min_x == 0) { hy_ti_force_clear(); hy_ti_set_inject_allowed(0); }
        else if (r->min_x == 1) { hy_ti_set_inject_allowed(1); }
        return hy_ti_get_inject_allowed();
    }

    /* ---- v1.76.0：多指 ---- */
    case HY_NR_TI_DOWN_ID: {
        const struct hy_ti_finger_op *o =
            (const struct hy_ti_finger_op *)(payload);
        return hy_ti_down_id((int)o->id, (int)o->x, (int)o->y);
    }
    case HY_NR_TI_MOVE_ID: {
        const struct hy_ti_finger_op *o =
            (const struct hy_ti_finger_op *)(payload);
        return hy_ti_move_id((int)o->id, (int)o->x, (int)o->y);
    }
    case HY_NR_TI_UP_ID: {
        const struct hy_ti_finger_op *o =
            (const struct hy_ti_finger_op *)(payload);
        return hy_ti_up_id((int)o->id);
    }
    case HY_NR_TI_UP_ALL:
        return hy_ti_up();

    case HY_NR_TI_CAPACITY: {
        struct hy_ti_cap *c = (struct hy_ti_cap *)(payload);
        if (!c) return -EINVAL;
        c->capacity    = hy_ti_capacity();
        c->active      = hy_ti_active_count();
        c->total_slots = hy_ti_max_slots_for_cap();
        c->real        = c->total_slots - c->capacity;
        return 0;
    }

    /* ---- GPU 隐藏 ---- */
    case HY_NR_KGSL_HIDE_SET: {
        struct hy_kgsl_req *r = (struct hy_kgsl_req *)(payload);
        return hy_kgsl_set(r->enable);
    }

    case HY_NR_KGSL_HIDE_CLEAR:
        return hy_kgsl_set(0);

    /* ---- 触摸移动（补齐 ls 的 touch_move）---- */
    case HY_NR_TOUCH_MOVE: {
        struct hy_touch_event_base *t = (struct hy_touch_event_base *)(payload);
        return hy_input_touch_move(t->slot, t->x, t->y);
    }

    /* ---- 触摸配置：屏幕范围 + 虚拟槽位基址 ---- */
    case HY_NR_TOUCH_SETUP: {
        const struct hy_touch_setup *ts =
            (const struct hy_touch_setup *)(payload);
        return hy_touch_setup(ts->max_x, ts->max_y, ts->slot_base);
    }

    /* ---- 陀螺仪（新 ABI：mrad/s，走 sendto hook 改写 ASensorEvent）---- */
    case HY_NR_GYRO_SET: {
        const struct hy_gyro_vec *v = (const struct hy_gyro_vec *)(payload);
        return hy_gyro_set(v->x, v->y, v->z);
    }

    /* ---- ghost region 状态（KPM 下恒不可用，如实上报）---- */
    case HY_NR_GHOST_STATUS: {
        u32 *v = (u32 *)(payload);
        v[0] = 0;    /* 不可用：需要 struct page + 页重定位 */
        return 0;
    }

    /* ---- 进程环境参数 ---- */
    case HY_NR_ENV_PARAMS:
        return hy_env_params((struct hy_env_params *)(payload));

    /* ---- 综合状态 ---- */
    /*
     * GUP 读取隐藏开关（v1.21.0 新增）
     * hy_hide_set_enabled() 此前零调用点，运行期无法开/关。
     * 条件不满足时内核明确返回 -ENOTSUPP / -ENODEV，不静默失败。
     */
    case HY_NR_HIDE_GUP_SET: {
        u32 on = hy_get_u32(payload);
        return hy_hide_set_enabled(on != 0);
    }

    case HY_NR_LS_STATUS:
        return hy_ls_status((struct hy_ls_status *)(payload));

    /* ---- v1.42.0 统一调试命令通道 ---- */
    case HY_NR_DBG_CMD:
        return hy_dbg_cmd_dispatch((struct hy_dbg_req *)(payload));

    /* ---- v1.60.0 压力测试 ---- */
    case HY_NR_STRESS: {
        struct hy_dbg_req *r = (struct hy_dbg_req *)payload;
        char rep[160];
        int rc;

        if (!r) return -EINVAL;
        r->cmd[sizeof(r->cmd) - 1] = 0;
        rc = hy_stress_cmd(r->cmd, rep, sizeof(rep));
        hy_strscpy(r->out, rep, sizeof(r->out));
        r->out_len = (u32)dbg_len(rep);
        return rc;
    }

    /* ---- v1.60.0 读取后端选择 ---- */
    case HY_NR_RWMODE_SET: {
        struct hy_rw_mode *m = (struct hy_rw_mode *)payload;
        if (!m) return -EINVAL;
        if (m->mode != HY_RW_MODE_KERNEL && m->mode != HY_RW_MODE_KMA)
            return -EINVAL;
        hy_kma_set_mode((int)m->mode);
        return 0;
    }
    case HY_NR_RWMODE_GET: {
        struct hy_rw_mode *m = (struct hy_rw_mode *)payload;
        if (!m) return -EINVAL;
        m->mode = (u32)hy_kma_mode();
        m->reserved = hy_kma_available() ? 1u : 0u;
        return 0;
    }

    /* ---- v1.63.0 读取缓存开关 ---- */
    case HY_NR_MEMCACHE_SET: {
        struct hy_mem_cache_mode *m = (struct hy_mem_cache_mode *)payload;
        if (!m) return -EINVAL;
        if (m->mode != HY_MEM_CACHE_DEFAULT &&
            m->mode != HY_MEM_CACHE_ON &&
            m->mode != HY_MEM_CACHE_OFF)
            return -EINVAL;
        hy_mem_cache_set(m->mode);
        return 0;
    }
    case HY_NR_MEMCACHE_GET: {
        struct hy_mem_cache_mode *m = (struct hy_mem_cache_mode *)payload;
        if (!m) return -EINVAL;
        m->mode = hy_mem_cache_mode();
        m->reserved = hy_mem_cache_enabled() ? 1u : 0u;
        return 0;
    }


    /* ---- v1.60.0 网络访问预留 ----
     * 三个号都走文本通道（hy_dbg_req），与 /proc/HuanyuD 的 `net` 命令
     * 共用同一套解析，避免再维护一份结构体语义。
     * CAP / FETCH / STATUS 在内核侧都不发包：CAP 回能力，FETCH 只登记
     * 意图，STATUS 回最近一次记录。真实收发必须由用户态完成。
     */
    case HY_NR_NET_CAP:
    case HY_NR_NET_FETCH:
    case HY_NR_NET_STATUS: {
        struct hy_dbg_req *r = (struct hy_dbg_req *)payload;

        if (!r) return -EINVAL;
        r->cmd[sizeof(r->cmd) - 1] = 0;

        if (nr == HY_NR_NET_CAP)
            hy_strscpy(r->cmd, "net cap", sizeof(r->cmd));
        else if (nr == HY_NR_NET_STATUS)
            hy_strscpy(r->cmd, "net stat", sizeof(r->cmd));

        return hy_dbg_cmd_dispatch(r);
    }

    default:
        break;
    }

    HY_LOG("ctl: unhandled nr=%u\n", nr);
    hy_usage_error();
    return -EINVAL;
}