# 欢愉 (Huanyu) —— 内核侧 KPM（CTL0 版，全功能）

与 `huanyu_driver.hpp` + `huanyu_ctl.hpp` 配套。目标：Linux 5.10 ~ 6.18。

## 编译状态

✅ **已用 `-O3` 编译通过**，`huanyu.kpm` = **873944 字节（853 KB）**

| 段 | 大小 | 说明 |
|---|---|---|
| `.rodata` | **786752** | ARM64 前缀解码表 65536 项 × **12 B** |
| `.text` | 22056 | 机器码 |
| `.rela.text` | 27744 | 重定位表 |
| `.bss` | 279200 | 对象池 + 蹦床区（加载时分配） |

### 占用优化：1.06 MB → 834 KB（-21%）

表项结构从 16 B 压到 **12 B**：

```c
struct hy_insn_entry {
    u32 mask;       /* 4 */
    u32 value;      /* 4 */
    u16 flags;      /* 2 */
    u8  cls;        /* 1 */
    u8  name_idx;   /* 1 */
};                  /* = 12，无内部填充 */
```

原来 `cls`/`flags`/`name_idx`/`rsv` 各占 2 字节且带一个无用 `rsv`，
按大小降序重排 + 去掉 `rsv` 后正好 12 B。
`cls` 只有 0~8、`name_idx` 只有 26 个，1 字节完全够。

65536 × 12 = 786 KB，省了 262 KB。

### 读取速率优化

| 优化 | 效果 |
|---|---|
| 中转缓冲 512 B → **4096 B** | 64 KB 读取的 `copy_to_user` 往返从 128 次降到 16 次（**8 倍**） |
| **页表路径缓存** | 连续访问同一页时跳过整趟 4 级 walk，直接算偏移 |
| **连续 VA 快路径** | 线性映射下相邻页 VA 连续时，一次性拷完整段，不按页切分 |

三项都是针对"连续读写"这个最典型场景。随机单字节访问收益不大，
但连续读写（dump 内存、扫模块）会明显变快。

缓存命中率可通过日志观察（`hy_mem.c` 内 `g_cache_hits` / `g_cache_miss`）。

## 自包含程度

| 能力 | 来源 |
|---|---|
| 页表遍历（3/4/5 级、块映射、权限位） | **自实现** `hy_pgtable.c` |
| 指令解码 / 重定位 | **自实现** `hy_insn.c` + 65536 项表 |
| 内核偏移（comm/pid/tasks/pgd） | **自发现** `hy_discover.c`（KP 仅作校验参考） |
| 指令搬移蹦床 | **自实现** `hy_trampoline.c` |
| 断点状态机 | **自实现** `hy_bp.c` |

只有"拿 pgd 指针"这一步保留 KP 的 `mm_struct_offset.pgd_offset` 作为**参考值**，
但 `hy_discover` 会校验它，不对就切自扫描结果。
- 优化等级：`-O3 -march=armv8.3-a`
- `.bss` 276 KB（已从初版 1.9 MB 收敛，见下方"池子尺寸"）
- 92 条 CALL26/JUMP26（范围 ±128MB，无溢出风险）
- 19 个未定义符号 **全部**命中 KernelPatch 导出表
- 9 种重定位类型全部在 `relo.c` 支持范围内
- `.kpm.info / .kpm.init / .kpm.ctl0 / .kpm.exit` 四段齐全
- ELF section header table 在文件范围内

## 传输方式：CTL0（不是 ioctl）

KernelPatch 的 173 个导出符号里**没有** `misc_register` / `cdev` / `alloc_chrdev`，
KPM 建不了字符设备，所以 ioctl 走不通。

命令走 `sc_kpm_control`：

```
[u32 nr][u32 rsv][payload...]
```

- `nr` = 原 ioctl 命令编号
- `payload` = 与 ioctl **完全相同的结构体**，字节不重排

用户态只需把 `ioctl(fd, CMD, &arg)` 换成 `ctl.call(HY_NR_CMD, arg)`，
结构体定义一个字都不用改。

## 功能清单

| 模块 | 文件 | 状态 |
|---|---|---|
| 符号解析（安全候选） | hy_sym.c | ✅ |
| 地址换算 + 往返自测 | hy_pt.c | ✅ |
| 断点：软件 SW | hy_bp.c | ✅ |
| 断点：PTE 影子页 | hy_bp.c | ✅ |
| 断点：硬件 HW | hy_bp.c | ✅ 执行匹配（BT=0） |
| 寄存器改写 | hy_bp.c | ✅ |
| 内存读写 | hy_mem.c | ✅ 跨页分段 |
| 按名取 PID | hy_mem.c | ✅ |
| 模块 base | hy_mem.c | ✅ 第一个可执行段 |
| 模块 bss | hy_mem.c | ⚠️ 近似（最后一个可读写段） |
| 触摸 | hy_input.c | ✅ 自建 input 设备 |
| 陀螺仪 | hy_input.c | ✅ |
| 文件隐藏 | hy_hide.c | ✅ hook getdents64 |
| GUP 读取隐藏 | hy_hide.c | ⚠️ 仅 kver≥6.5，默认关 |
| READ_MEM / READ_MEM_V2 | hy_mem.c | ✅ 前者带 VMA 检查，后者快速路径 |
| TLS 读取 | hy_task.c | ✅ 运行时校准偏移 |
| PACGA 计算 | hy_task.c | ✅ |

## 三种断点方案

| 方案 | 实现 |
|---|---|
| **SW** | 把目标指令替换为 `BRK #7`（0xd42000e0）。数量不限，改代码段 |
| **PTE** | 原页去掉可执行位（PTE_UXN），配影子页副本；执行时触发页错误 → 切到影子页。**代码段字节一个都没改** |
| **HW** | 写 `DBGBVR<n>_EL1` / `DBGBCR<n>_EL1`，BAS=0xf、BT=0（执行匹配）。槽位数从 `ID_AA64DFR0_EL1.BRPS` 读 |

AUTO 优先级：硬件 → PTE → SW。

硬件断点需要 per-CPU 调试寄存器随上下文切换重新编程，因此挂了 `__switch_to` 的 after 回调。

## 从 wxshadow 事故提炼的三条硬约束

### 1. 绝不调用签名不确定的符号

wxshadow 在 6.12 上"加载即炸"两次，根因都是回退到签名不同的函数：

- `kzalloc` → `kmalloc_trace(kmem_cache*, gfp, size)`：把 size 当指针解引用 → 访问 0x80 → panic
- `__get_free_pages` → `__get_free_pages_node(gfp, order, nid)`：nid 取自未初始化寄存器 → panic

候选列表**只放签名完全一致**的名字，宁可解析失败也不错配：

```c
"__get_free_pages", "__get_free_pages_noprof"   /* 都 (gfp, order) */
"free_pages",       "free_pages_noprof"         /* 都 (addr, order) */
/* 明确拒绝 __get_free_pages_node / __free_pages */
```

### 2. 地址换算必须往返自测

init 用 `__get_free_pages` 拿一页做 `virt → phys → virt`，
不一致就**直接拒绝加载**（降级返回 0，不崩）。

### 3. 不依赖 kmalloc

小对象走静态对象池，页级走 `__get_free_pages`。

## init 必定返回 0

任一环节失败**只降级不致命**，保证日志能落盘。
这是刻意的——wxshadow 的教训是"加载即炸导致零日志，无从排查"。

## 版本差异处理

| 项 | 处理 |
|---|---|
| `kallsyms_on_each_symbol` 回调参数 | ≤6.1 四参数，>6.1 三参数（与 KP 自身分支一致） |
| 页表级数 | 从 `TCR_EL1.T1SZ` 推算 va_bits，自动 3 级/4 级 |
| PAGE_OFFSET | 由 va_bits 计算，不写死 |
| 页错误入口 | ≤6.7 `do_mem_abort`，≥6.8 `do_page_fault` |
| `follow_page_pte` | 6.5 少一个参数；GUP 隐藏仅 ≥6.5 启用 |
| tp_value 偏移 | **运行时校准**：用当前进程的 tpidr_el0 在 task_struct 里搜索，不硬编码 |
| BRK 入口 | 多候选 + `hook_wrap`，刻意避开 `register_user_break_hook` |

## 编译

```shell
export KP_DIR=/path/to/KernelPatch
./build.sh
```

注意：`-march=armv8.3-a` 是必需的（PACGA 指令需要），构建脚本已加。

## 加载后确认

```shell
dmesg | grep huanyu
```

关键行：

```
huanyu: init begin ... kver=0x60c45
huanyu: [STEP] symbols done, failures=N
huanyu: pt: va_bits=48 levels=4 page_offset=ffff800000000000
huanyu: pt: roundtrip v=... p=... v2=... match=1
huanyu: [STEP] pt init OK
huanyu: bp: ID_AA64DFR0 BRPS=6 WRPS=4
huanyu: [STEP] bp init OK
huanyu: [STEP] mem init OK
huanyu: [STEP] input init OK
huanyu: [STEP] task init OK
huanyu: init done, ready=1 caps=0x7
```

- `match=0` → 地址换算有问题（会拒绝加载，不会崩）
- `failures=N` → N 个符号没解析到，对应功能不可用
- `caps` → `SW=1 PTE=2 HW=4`


## 已知限制（诚实标注）

1. **MODULE_BASE 无法按 so 名精确匹配**
   KernelPatch 未导出 dentry / path 头文件，拿不到 VMA 映射文件名。
   当前实现取"第一个可执行段"作为 base（对主程序准确）。
   bss 取最后一个可读写段，是近似值。
   若需精确匹配，请在用户态传入已知地址。

2. **文件隐藏只按 keyword 匹配**
   getdents64 回调里拿不到当前目录路径，因此 `directory` 字段只记录不参与过滤。

3. **硬件断点只实现执行匹配（BT=0）**
   读/写观察点需要 BT=0x5/0x6 与 BAS 配合，暂未实现。

4. **陀螺仪走自建 input 设备**
   KP 未导出 input 子系统头文件，`struct input_dev` 按不透明指针处理，
   只调用内核函数设置能力位，不下发真实的陀螺仪轴数据。

## ARM64 指令解码表（`.rodata` 1 MB 的来源）

`hy_insn_prefix.c` 由 `gen2.py` 生成，65536 项，索引 = `insn >> 16`。

**为什么需要它**：断点（尤其 PTE 影子页与软件断点）必须知道被覆盖的指令
是不是 PC 相关（搬到别处要修正偏移）、是不是分支、是不是 SIMD、是不是特权指令。

**为什么是 65536 项**：解码器常用前缀表做 O(1) 粗分类，再用表项里的
mask/value 精确校验，最后对 B/BL/ADR/ADRP/CBZ/TBZ 做逐位精解。
用 1 MB 空间换零分支查表速度，且解码逻辑完全不依赖内核头文件。

表项结构（16 B）：

```c
struct hy_insn_entry {
    u32 mask;      /* 精确匹配用 */
    u32 value;
    u16 cls;       /* DP_IMM / BRANCH / LDST / DP_REG / SIMD / SYS / FP / BARRIER */
    u16 flags;     /* BRANCH / PCREL / MEM / SIMD / PRIV / ATOMIC ... */
    u16 name_idx;
    u16 rsv;
};
```

## 指令重定位

`hy_insn_relocate()` 把 `src_pc` 处的指令搬到 `dst_pc`，改写 PC 相关立即数：

| 指令 | 立即数 | 范围 |
|---|---|---|
| B / BL | imm26 | ±128 MB |
| B.cond / CBZ / CBNZ | imm19 | ±1 MB |
| ADR | 21 bit | ±1 MB |
| ADRP | 21 bit 页 | ±4 GB |

超出范围返回 false，调用方改走"临时摘断点 + 单步 + 重装备"。

## 内核布局：KP 绝对优先，自发现只作后备

【立场】**不虚标**。KP 给了就用 KP 的，自己的扫描结果只在 KP 没提供时才上。

优先级（严格）：

```
KP 有效值 (>= 0)  ->  用它，src=0
KP 值校验失败     ->  仍用它，src=3，打 WARN
KP 完全没提供(<0) ->  自扫描，src=1；扫描也失败 src=2
```

**自扫描结果与 KP 不同时，以 KP 为准。** 自扫描不是"更可信的备选"，
只是"KP 缺席时的兜底"。

### 日志会如实标注每个偏移的实际来源

```
huanyu: DISCOVER comm=1744/0 pid=1736/0 tasks=1232/0 pgd=64/0
```

`src` 含义：

| src | 含义 |
|---|---|
| **0** | 来自 KP，且通过合理性校验 |
| **1** | KP 没提供，用自扫描结果 |
| **2** | KP 没提供，自扫描也没找到（功能不可用） |
| **3** | 来自 KP，但**未通过校验**（仍在使用，有风险） |

看到 `/3` 要留意 —— 说明 KP 的值在这一版内核上看起来不对，
但按"KP 优先"策略仍在使用，相关功能可能异常。

### 自扫描（仅 KP 缺席时启用）

- 扫 comm：找 8 字节对齐的可打印字符串
- 扫 pid：从 comm 偏移往后找小正整数
- 扫 tasks：找满足 `next->prev == self` 的 list_head
- 扫 pgd：找能取出合法下一级表项的偏移

### 校验判据（用已知值比对，不猜）

| 偏移 | 判据 |
|---|---|
| `comm_offset` | 该处必须是可打印 ASCII、长度 1~15 |
| `pid_offset` | 该处必须是小正整数（1 < pid < 0x80000） |
| `tasks_offset` | `next->prev` 必须指回自己（双向链表特征） |
| `pgd_offset` | 取出的 pgd 指针必须落在内核地址空间 |

### 校验方法（全部用已知值比对，不猜）

| 偏移 | 判据 |
|---|---|
| `comm_offset` | 该处必须是可打印 ASCII、长度 1~15 |
| `pid_offset` | 该处必须是小正整数（1 < pid < 0x80000） |
| `tasks_offset` | `next->prev` 必须指回自己（双向链表特征） |
| `pgd_offset` | 取出的 pgd 指针必须落在内核地址空间 |

### 自扫描（仅在校验失败时启动）

- 扫 comm：找 8 字节对齐的可打印字符串
- 扫 pid：从 comm 偏移往后找小正整数
- 扫 tasks：找满足 `next->prev == self` 的 list_head
- 扫 pgd：找能取出合法下一级表项的偏移

启动日志会打印每个偏移的**来源**：

```
huanyu: DISCOVER comm=1744/0 pid=1736/0 tasks=1232/0 pgd=64/0
```

`src` 含义：**0 = KP 提供且校验通过，1 = 自扫描得出，2 = 校验失败且扫描未果**。

看到 `/1` 说明 KP 给的值在这一版上不对、已自动切换到自扫描结果。

## 【重要】卸载后重载崩溃 —— 已修复

**现象**：加载 → 卸载 → 再次加载 → 炸内核重启。

**根因**：`hy_hide_exit()` 漏了 `hook_unwrap(follow_page_pte)`。

```
GUP 隐藏开启 -> hook_wrap3(follow_page_pte, ...)
模块卸载     -> 只 unhook 了 getdents64，follow_page_pte 的 hook 还挂着
             -> 模块代码内存已被释放
             -> 下一次任何 GUP 调用跳进已释放内存 -> panic
```

`follow_page_pte` 是 GUP 路径的核心函数，调用极其频繁，
所以一旦残留就是"必炸"，不是偶发。

**修了四处**：

| # | 问题 | 修法 |
|---|---|---|
| 1 | `hy_hide_exit` 漏 unwrap | 补上，且 `g_gup_hide_on` 时才做 |
| 2 | 原来用 `hook_wrap3(f, NULL, NULL, NULL)` | 给了真实回调 `hy_gup_before`（装 NULL/NULL 的 hook 既无意义又难卸） |
| 3 | 卸载瞬间回调可能还在飞 | 新增 **`hy_ready` 卸载守卫**：所有回调开头 `if (!hy_ready) return;` |
| 4 | `hy_bp_exit` 的 unhook 顺序 | 先 `hy_ready = false`，再 unhook，再 uninstall，最后清池子 |

第 3 条是关键防御：**unhook 与模块内存释放之间存在时间窗**，
守卫保证窗口内回调立即返回，绝不访问即将失效的数据。


## 【严重】APatch 输入框导致重启 —— 已修复

### 现象

在 APatch 的"调节内核模块"输入框里输入任何内容 → 手机瞬间重启。

### 根因

那个输入框是给模块传**字符串**的。而我只实现了二进制帧解析：

```c
const struct hy_ctl_frame *f = (const struct hy_ctl_frame *)(args + 4);
```

输入 `status`（6 字节），`args + 4` 只剩 2 字节，却读了 4 字节的 `nr` —— **越界**。
垃圾 `nr` 撞上 `READ_MEM` 这类命令后，payload 里的 `buffer` 字段
（实际是文本字节）被当成用户态指针拿去 `copy_to_user` → 往野地址写 → panic。

### 修复一：双模解析

| 输入 | 判定 | 走向 |
|---|---|---|
| 首字节 `'H'` 且长度 ≥ 12 | 二进制帧 | 程序通过 `sc_kpm_control` 调用 |
| **其余一切** | 文本命令 | APatch 输入框 / 手动 echo |

文本模式只走 `hy_text_cmd()`，**绝不解引用任何指针**。

支持的文本命令（都是只读的）：

```
help     列出命令
status   ready / mode / caps / 符号缺失数
caps     断点能力与槽位数
stats    缓存命中、活跃断点、总命中
bps      硬件断点槽位
proc     /proc/huanyu 是否创建
syms     符号解析失败数
```

**现在可以在 APatch 输入框里直接敲 `status` 看状态**，不会再崩。

### 修复二：帧内容集中校验

`hy_frame_validate()` 在 `switch` 之前统一做两件事：

1. **最小长度**：每条命令检查 `HY_CTL_HDR + sizeof(结构体)`，不足直接 `-EINVAL`，杜绝越界读
2. **用户态指针**：所有来自 payload 的指针过 `hy_user_ptr_ok()`

```c
#define HY_USER_PTR_MAX 0x0000800000000000ULL
```

arm64 用户空间地址都远小于这个值；内核地址（`ffffff...`）和文本字节
拼出来的垃圾值都会落在界限外，一律 `-EFAULT` 拒绝。

覆盖的指针：`r->buffer`、`regs_to_set_ptr`、`user_buffer_ptr`、
`buf_ptr`（枚举/读写/列表共计 6 处）、`kern_rw.buf_ptr`。

集中在一处做，不散落在每个 case 里 —— 不会漏。

### 修复三：消除裸 memcpy

`hy_frame_validate` 里的局部数组初始化会让编译器生成
`.rodata → 栈` 的 `memcpy` 调用，而 KP 只导出 `kf_memcpy`，
裸 `memcpy` 会成为未定义符号。

- `minlen[]` 改为 `static const`（不再需要栈拷贝）
- 手写 `hy_get_u32/hy_get_u64` 逐字节读取，不依赖 `memcpy`
- 文本格式化改为 `hy_puts/hy_putu` 手写拼接，**不用 variadic**
  （va_arg 同样会诱发隐式 memcpy）

最终 19 个链接期符号全部命中 KP 导出表。

---
## /proc/huanyu —— 真正注册的 procfs 文件

### 上一版是欺骗，已废弃

旧方案把 `/proc/huanyu` 的路径偷换成 `/proc/uptime`，再在 `read` 返回时替换内容。
那**不是接口**：`ls /proc` 看不到、`stat` 也失败，只是骗过了调用者。

**这一版是真的文件**，由内核 procfs 子系统维护。

### 符号从哪来（修正了之前的误判）

之前说"KP 没导出 proc_create 所以做不到"——**这个判断是错的**。
错在把"KernelPatch 的 173 个导出符号"当成了全部可用符号。

实际上 **`kallsyms_lookup_name` 本身就在导出表里**，而内核开了
`CONFIG_KALLSYMS_ALL=y`，所以能查到内核里**任何**符号。
本项目一直在用这条路：`find_vma`、`get_task_mm`、`input_register_device` 都是。
`proc_create` 同理，只是之前没想到。

### 为什么用 proc_create_single_data

`proc_create` 需要 `struct proc_ops`，其成员布局随版本变化
（`proc_ioctl` / `proc_compat_ioctl` 的有无、CONFIG_COMPAT 等），
而我们没有内核头文件可核对布局，硬编码风险高。

`proc_create_single_data` 从 4.17 到 6.x **签名稳定**：

```c
struct proc_dir_entry *proc_create_single_data(
    const char *name, umode_t mode,
    struct proc_dir_entry *parent,
    int (*show)(struct seq_file *, void *),
    void *data);
```

seq_file 的 open/read/lseek/release 全由内核提供，我们只写一个 `show`。

`parent` 传 `NULL` 时内核自动用 `&proc_root`（见 `xlate_proc_name`），
连 `proc_root` 符号都不用查。

### 验证方式

```shell
ls -l /proc/huanyu       # 能看到，mode 0444
stat /proc/huanyu        # 成功
cat /proc/huanyu         # 输出：你好
```

`stat` 能过，就说明不是路径劫持。

### 卸载即消失

exit 里调 `proc_remove()`，且**排在退出流程最前面**——
对外接口在第一时间消失，之后才清理 hook 与断点。

这一步绝不能省：否则文件会残留并指向已释放的模块内存，
下次有人 `cat` 就跳进野指针——正是本项目之前踩过的坑。

若 `proc_remove` 查不到，init 直接拒绝创建（宁可没有接口，也不留残留）。

## 【重要】在管理器里改参数导致瞬间重启 —— 已修复

### 根因：GUP hook 卸载时参数不匹配

```c
/* 安装 */
hook_wrap3(g_follow_pte_func, hy_gup_before, NULL, NULL);

/* 卸载（原） */
hook_unwrap(g_follow_pte_func, NULL, NULL);   /* <- 参数对不上 */
```

`unwrap` 靠 before/after 函数指针匹配来定位要摘的 hook。
传 `NULL, NULL` 匹配不到，于是 **hook 依然挂在内核上**，
而模块代码随后被释放 —— 任何 GUP 调用跳进已释放内存，立即 panic。

`follow_page_pte` 是 GUP 路径核心函数，调用极其频繁，
一旦残留就是"必炸"，且发生在下一次加载的瞬间，来不及打日志。

**修法**：卸载处改成 `hook_unwrap(g_follow_pte_func, hy_gup_before, NULL)`，
与安装参数严格一致。

### 为什么"改个参数"会触发重载

多数 KPM 管理器在模块返回负值时，或用户修改模块参数后，
会执行"卸载并重新加载"。于是上面那个残留 hook 就在重载瞬间引爆。

### 三道防线

| # | 防线 | 说明 |
|---|---|---|
| 1 | unwrap 参数严格配对 | 修掉残留的根因 |
| 2 | **文本命令永不返回负值** | 任何未识别输入都回一段文本并返回 **0**。管理器收到负值可能触发重载，那就等于自己给自己埋雷 |
| 3 | `hy_ready` 卸载守卫 | 所有回调开头 `if (!hy_ready) return;`，覆盖 unhook 与内存释放之间的时间窗 |

### 顺带加固的两处越界风险

- `hy_strlen` 上限 4096 → **1024**（与用户态帧上限一致）。若调用方字符串未以 `\0` 结尾，读到 4096 可能跨页崩溃。
- init 里 `printk("%s", args)` → 改为**手工截断到 32 字节并强制收尾**。加载参数不解析、不影响行为，但仍要安全打印。

### 现在的表现

在管理器里输入 `1`、`0`、任意文本：

```
huanyu: received "1" (len=1)
ok, no action
commands: help status caps stats bps proc syms
```

返回 0，不报错、不重载、不重启。

## 新增能力（命令 35~46）

| nr | 命令 | 说明 |
|---|---|---|
| 35 | `ENUM_MODULES` | 枚举进程内存区域（起止地址 + exec/write） |
| 36 | `ENUM_PROCESSES` | 枚举系统所有进程 |
| 37 | `ENUM_THREADS` | 枚举指定进程的线程（按 comm 匹配） |
| 38 | `KERNEL_RW` | 读写内核虚拟地址（严格边界校验，单次 ≤4KB） |
| 39 | `PHYS_RW` | 读写物理地址 |
| 40 | `PROTECT` | 修改目标进程内存段 r/w/x 权限 |
| 41 | `CACHE_FLUSH` | 刷新指定范围的 dcache + icache |
| 42 | `BP_LIST` | 列出已安装断点 |
| 43 | `BP_CLEAR_HITS` | 清空命中记录 |
| 44 | `HWCAP` | 查询 CPU 特性（PAC/BTI/LSE/MTE/FP + 断点槽位） |
| 45 | `STATS` | 运行时统计（缓存命中率、活跃断点、总命中、符号缺失） |
| 46 | `VERSION` | 魔数 + 版本 + 能力位 |

**硬件观察点补齐**：原来只有执行匹配（BT=0x0），
现在按类型选 BT：读 0x5 / 写 0x6 / 读写 0x7 / 执行 0x0。

## 用户态对接文件（单文件）

| 文件 | 用途 |
|---|---|
| **`huanyu.hpp`** | **全部内容集中在这一个文件**，1331 行，开箱即用 |
| `demo.cpp` | 完整示例，已编译运行通过 |

`huanyu.hpp` 内含：
- supercall 底层（`__NR_supercall` = 45），**不依赖 KernelPatch 用户态库**
- 17 个 ABI 结构体 + **17 条 `static_assert` 锁死尺寸**（改一个字段就编译失败）
- `hy_driver` 类：内存读写、三种断点、观察点、寄存器改写、枚举、TLS/PACGA、触摸/陀螺仪、文件隐藏
- `hy_reg_batch` 寄存器批量改写器（链式调用）
- `proc_read()` / `proc_exists()` 读 `/proc/huanyu`

### CTL0 帧格式（重要）

```
[0..3]   u8  tag[4] = { 'H', 0, 0, 0 }
[4..7]   u32 nr        命令号
[8..11]  u32 rsv
[12...]  payload
```

tag 前缀**必须有**：`sc_kpm_control` 会检查
`if (!ctl_args || strlen(ctl_args) <= 0) return -EINVAL;`
二进制帧的 `nr` 常带 `\0`，从 offset 0 开始发会被当成空串拒掉。

## 池子尺寸

| 项 | 数量 | 单项大小 | 合计 |
|---|---|---|---|
| 断点对象 | 64 | ~940 B | ~60 KB |
| 命中记录 | 256 | ~840 B | ~215 KB |
| **.bss 合计** | | | **276 KB** |

初版是 256 / 2048，`.bss` 达 1.9 MB —— KPM 加载时这块要实打实分配，
过大既拖慢加载又占用内核内存，因此收敛到当前规模。

## 内存安全修复

- **`owner_mm` 所有权转移**：安装成功后不再 `mmput`，改由 `uninstall` 释放。
  原写法会导致进程退出后 `bp->owner_mm` 变悬垂指针，页错误回调里一查就崩。
- **`bp_get_hit_items` 改用 `copy_to_user`**：原写法直接 `memcpy` 到用户态地址，
  遇缺页会异常。

## 共享内存通道（lsdriver 风格）

灵感来自 lsdriver。它不用 ioctl / prctl / supercall，而是让内核把用户态
一块内存直接映射到内核地址空间，双方读写同一份物理页：

```c
get_user_pages_remote(mm, 0x2025827000, nr, FOLL_WRITE, pages, NULL);
vmap(pages, nr, VM_MAP, PAGE_KERNEL);
/* 之后 req->op / req->kernel / req->user 全是纯内存读写 */
```

**零系统调用、零拷贝。** 也完全绕开了 supercall 的鉴权门禁。

### 欢愉的改动：注册式而非进程名式

lsdriver 靠「固定地址 `0x2025827000` + 进程名 `LS`」建立连接，
这要求一个**独立守护进程**。而欢愉的用户态是注入在游戏里的，
改进程名会影响宿主。

所以改成：

```
用户态 mmap 任意地址
    -> 通过现有命令通道发 HY_NR_SHM_REGISTER
    -> 内核 get_task_mm(current) + GUP + vmap
    -> 内核写 flags |= HY_SHM_F_READY 完成握手
```

注册是一次性动作，走哪个通道都无所谓；之后就完全不走系统调用。

### 共享区布局

```c
struct hy_shm_obj {
    volatile uint32_t magic, version;
    volatile uint32_t state;   /* 0 idle  1 req  2 busy */
    volatile uint32_t seq;     /* 用户递增 */
    volatile uint32_t ack;     /* 内核回写 = seq */
    volatile int32_t  ret;
    volatile uint32_t nr, len;
    volatile uint64_t shm_va, shm_size;
    uint8_t payload[128 KB];
};
```

内核线程轮询 `state`，见到 `REQ` 就调 `hy_ctl_switch(nr, payload)`
—— **与 prctl / supercall 完全同一个分发器**，三条通道行为必然一致。

### 零拷贝

payload 里的指针字段（如 `hy_request.buffer`）若落在共享区内，
`hy_shm_translate()` 直接返回内核指针，走 `memcpy` 而非
`copy_to_user`。`hy_mem.c` 的传输路径已改成先问这个函数。

读 128 KB 数据：原来 32 次 `copy_to_user` 往返，现在 0 次。

### 不用 kmalloc

`pages` 数组是静态的（64 项，支持最大 256 KB 共享区）。
6.12 上 `kmalloc` 实测查不到，绝不用。

### 卸载安全

```
置 hy_ready = false
    -> kthread_stop()   （等线程返回）
    -> vunmap()
    -> put_page() 逐页释放
    -> mmput()
```

`kthread_stop` 必须在 `vunmap` **之前**，否则线程可能访问已释放的映射。

### ⚠️ 一个需要实测确认的风险点

`vmap` 的 `prot` 参数拿不到内核头的 `PAGE_KERNEL`，只能硬编码：

```c
#define HY_PAGE_KERNEL 0x8000000000703UL   /* arm64 6.x PROT_NORMAL */
```

推导：`PTE_TYPE_PAGE(3) | PTE_AF(1<<10) | PTE_SHARED(3<<8) | PTE_DIRTY(1<<51)`

若你的内核布局不同，映射出的页属性不对，访问时触发异常。
现象是 dmesg 打出 `shm: mapped` 后立刻崩溃 —— 改这个常量即可。

**共享内存是可选通道**，默认不启用（用户态主动调 `shm_init()` 才建），
所以即便这里有问题也不影响主功能。

### 用户态用法

```cpp
c_driver drv;
drv.shm_init();     // 可选：建立共享内存通道，失败自动降级

/* 之后所有命令自动走共享内存 */
int v = drv.read<int>(addr);
```

通道优先级：**共享内存 > prctl > supercall**，自动选择。

## 共享内存：不用进程名，改用 magic 探测

### 之前错了

第一版照抄 lsdriver 的**进程名扫描**：`strcmp(task->comm, "LS")`。

**这在欢愉里根本行不通。** ls 能用进程名，是因为它有独立的用户态守护进程
叫 "LS"。而欢愉的用户态是**注入进游戏进程**的，游戏进程名永远不可能是
"Huanyu" —— 按名字扫永远扫不到，永远连不上。

这是照抄抄错了地方。

### 正确做法

遍历所有进程，对每个有 `mm` 的尝试 GUP 固定地址，检查共享区头部 magic：

```c
for_each_process(task) {
    mm = get_task_mm(task);
    if (!mm) continue;                              /* 内核线程跳过 */
    if (GUP(mm, 0x2025827000, nr, FOLL_WRITE, pages, NULL) != nr) {
        mmput(mm); continue;                        /* 没 mmap 这块，换下一个 */
    }
    kva = vmap(pages, nr, VM_MAP, PAGE_KERNEL);
    if (kva && kva->magic == HY_SHM_MAGIC) { 连接! break; }
    vunmap(kva); 放页; mmput(mm);              /* 不是我们的人 */
}
```

**谁 mmap 了这块内存且 magic 对上，谁就是连接方。**

握手判据：`magic == 0x48796e75 ("Hynu")` 且 `version == 1`。

### 用户态要做的

```cpp
void *p = mmap((void*)0x2025827000, len, PROT_READ|PROT_WRITE,
               MAP_SHARED|MAP_ANONYMOUS|MAP_FIXED, -1, 0);
obj->magic = HY_SHM_MAGIC;
obj->version = HY_SHM_VERSION;
/* 然后等着就行，内核自己会来连 */
```

**不需要改名、不需要发注册命令、不依赖任何已有通道。**

### 与 ls 的异同

| | lsdriver | 欢愉 |
|---|---|---|
| 固定地址 `0x2025827000` | ✅ 相同 | ✅ 相同 |
| `get_user_pages_remote` + `vmap` | ✅ 相同 | ✅ 相同 |
| 零 syscall 零拷贝 | ✅ 相同 | ✅ 相同 |
| 内核主动连接 | ✅ 相同 | ✅ 相同 |
| 识别方式 | 进程名 `"LS"` | **magic 探测** |

只有识别方式不同——因为欢愉没有守护进程，只能靠内容识别。

### 扫描开销

每 2 秒一轮，只对有 `mm` 的进程尝试 GUP，未命中立即释放。
连上后停止扫描，只做 magic 复核。

## 守护进程：与 lsdriver 的 "LS" 完全同款

### 先澄清一个容易搞反的事实

**ls 的 "LS" 进程不是内核创建的。** 看 `lsdriver.c`：

```c
for_each_process(task) {
    if (__builtin_strcmp(task->comm, "LS") != 0) continue;
    mm = get_task_mm(task);
    get_user_pages_remote(mm, 0x2025827000, ...);
    vmap(...);
}
```

内核只是**扫名字**。"LS" 是 ls 用户态套件里的一个独立程序，
由用户启动，内核找到它。

之前欢愉照抄"扫名字"失败，是因为欢愉的用户态注入在游戏进程里，
游戏进程名永远不可能是 "Huanyu"。

### 解法：欢愉也带一个独立 daemon

`huanyu_daemon.cpp` —— 编译成 Android 可执行文件，它做三件事：

```c
prctl(PR_SET_NAME, "Huanyu");                    /* 1. 改名 */
mmap(0x2025827000, ..., MAP_FIXED);              /* 2. 映射固定地址 */
shm->magic = HY_SHM_MAGIC;                       /* 3. 写 magic */
```

内核扫到名字 → GUP + vmap → 握手。**和 ls 一模一样。**

### 编译与运行

```shell
aarch64-linux-android31-clang++ -std=c++17 -O2 -static     -o huanyu_daemon huanyu_daemon.cpp

adb push huanyu_daemon /data/local/tmp/
adb shell chmod +x /data/local/tmp/huanyu_daemon
adb shell /data/local/tmp/huanyu_daemon &
```

可用 `shm_name=xxx` 覆盖内核要找的进程名，
或 `huanyu_daemon MyName` 改 daemon 自己的名字。

### 它同时是请求代理

游戏进程被注入的 so 通常不方便自己 mmap 固定地址
（可能和游戏自身的内存布局冲突）。所以 daemon 还监听 unix socket：

```
游戏 so  --(unix socket)-->  huanyu_daemon  --(共享内存)-->  内核
```

游戏侧完全不需要 mmap，也不用担心地址冲突。

```cpp
c_driver drv;
drv.daemon_connect();     /* 连 daemon */
int v = drv.read<int>(addr);
```

### 两条路都可以

| 方式 | 适用 | 要求 |
|---|---|---|
| **daemon 代理** | 游戏注入（推荐） | 需要跑 `huanyu_daemon` |
| **直接 mmap** | 独立程序 | 自己调 `shm_init()` |

内核侧：**先按名字扫（ls 同款），名字没命中则退化为全量 magic 探测**。
两条都走 `magic` 校验，防止误连同名进程。

### 通道优先级

```
daemon socket > 共享内存 > prctl > supercall
```

自动选择，你不用管。

## v13 修复：加载即炸 / 卸载也炸

### 根因：进程链表推进少了一个减法

```c
/* 错误 */
task = *(void **)((unsigned long)task + tasks_off);
```

`tasks_offset` 是 `struct list_head tasks` 在 `task_struct` 里的偏移。
所以 `*(task + tasks_off)` 读到的是 `tasks.next`，
它指向**下一个 task 的 `tasks` 字段**，**不是** `task_struct` 基址。

内核的 `for_each_process` / `list_next_entry` 会做 container_of，
等价于：

```c
next = *(unsigned long *)(task + tasks_off);
task = (void *)(next - tasks_off);        /* ← 之前少了这个减法 */
```

少了这一步，第二次循环就拿 `list_head` 的地址当 `task_struct` 用，
`get_task_mm(野指针)` 立刻 panic。

表现：**加载即炸、卸载也炸**（线程已经踩死，卸载路径跟着挂）。

### 另外三处加固

1. **`hy_task_plausible()`** —— 每次推进后校验指针：
   arm64 内核地址高位必须全 1、8 字节对齐，否则直接停止遍历。

2. **线程启动延后 2 秒** —— 避免在模块 init 关键期做 GUP。

3. **响应式睡眠** —— 原来 `msleep(2000)` 一次睡死，
   `kthread_stop` 要等最多 2 秒才返回，卸载路径危险。
   改成 50ms 小段循环，每段问一次 `should_stop`，卸载秒回。

### 全量 magic 扫描默认关闭

对**每一个**进程做 `GUP(FOLL_WRITE)` 是侵入操作，
可能给无关进程强行分配页。默认关闭，需要时加载参数加 `shmscan=1`。

默认路径只按进程名扫（ls 同款），安全得多。

## v13 修复：卸载炸内核（kthread use-after-free）

### 现象

加载正常，**一卸载就炸**。

### 根因：线程有两个退出出口

```c
while (1) {
    if (kthread_should_stop()) break;   /* 出口 A：正常 */
    if (!hy_ready) break;               /* 出口 B：灾难 */
    ...
}
```

出口 B 会在 `exit` 设 `hy_ready = false` 后让线程**自己退出**。
线程一 return 就 `do_exit()`，`task_struct` 引用归零被释放。

而 `hy_shm_exit()` 随后又拿 `g_thread` 这个**已释放**的指针去调
`kthread_stop()` —— **use-after-free，直接 panic**。

`kthread_stop` 的设计契约是：线程**必须**还在循环里，
由 `kthread_stop` 置 `should_stop`、唤醒、等待、再归还引用。

### 修复

线程循环**只保留 should_stop 一个出口**：

```c
while (1) {
    if (kthread_should_stop()) break;      /* 唯一出口 */
    if (!hy_ready) { sleep(100); continue; } /* 守护位，不再退出 */
    ...
}
```

`hy_ready` 降级为"回调/扫描守卫生效"的信号，不再触发退出。
卸载时由 `kthread_stop` 走标准流程回收。

### 附带加固

1. **符号不全绝不起线程** —— `kthread_stop` / `should_stop` / `msleep`
   任一缺失就不创建。否则起一个收不回来的线程，卸载必炸。

2. **默认不做全量扫描** —— 没显式指定 `shmname=` 也没开 `shmscan=1` 时，
   连接线程空转。避免对每个进程做侵入式 GUP。

3. **响应式睡眠** —— 50ms 小段循环，每段问 `should_stop`，
   `kthread_stop` 能秒回，不会卡住卸载路径。

## v1.14.0：修复 prctl 通道（"鉴权未通过"的真正原因）

### 用户实机日志暴露的问题

```
huanyu: sym: MISS copy_from_user
huanyu: sym: MISS copy_to_user
huanyu: prctl: copy_*_user missing, channel disabled
huanyu: [STEP] prctl channel FAILED (non-fatal)
```

prctl 通道（免鉴权）被禁用 → 用户态只能走 supercall → 鉴权过不去
→ 一直报"鉴权未通过"。**这是根因，不是密钥问题。**

### 为什么查不到

ARM64 内核里 `copy_from_user` 是**宏**，不是函数。kallsyms 里
根本没有这个名字。真正的内核函数带下划线前缀：

| 用户写的 | 内核实际符号 |
|---|---|
| `copy_from_user` | `_copy_from_user`（5.x~6.x 主流） |
| | `__copy_from_user`（部分配置） |
| | `raw_copy_from_user`（老版本） |

`copy_to_user` 同理。

**修复**：改成多候选解析。三者签名完全一致 `(dst, src, n) -> 未拷贝字节数`，
可以安全回退。

### 二级兜底：完全不依赖 copy 符号

万一某个 GKI 配置把 `_copy_*_user` 也裁掉，通道不该整个瘫痪。

兜底原理：ARM64 内核与用户共享同一套页表，内核上下文可直接访问
用户虚拟地址 —— 只要页已映射且未换出。而 prctl 的 payload 是用户态
**刚刚写入**的指针，页几乎必然 resident。

```c
static long hy_read_user(void *dst, const void *src, unsigned long n)
{
    if (!hy_uaddr_ok((unsigned long)src, n)) return n;   /* 地址校验 */
    if (hy_f_copy_from_user) return hy_f_copy_from_user(dst, src, n);
    if (hy_f_memcpy) { hy_f_memcpy(dst, src, n); return 0; }  /* 兜底 */
    return n;
}
```

`hy_uaddr_ok()` 校验：地址必须落在用户空间（< `0x800000000000`），
且 `addr + n` 不得跨入内核空间。

所以现在 prctl 通道**无论如何都会启用**，只是安全性略有差异：
- 有 copy 符号 → 标准缺页处理，最安全
- 无 → 直接访问（配合地址校验），payload 刚写入故风险可控

### 版本对应

| 版本 | 内容 |
|---|---|
| v1.13.0 | 修卸载炸内核（kthread use-after-free） |
| **v1.14.0** | **修 prctl 通道（copy 符号多候选 + 无符号兜底）** |

## v1.15.0：又一个"假修复"（prctl 仍然禁用）

### 现象

v1.14.0 说"无论如何都会启用 prctl"，实际仍然：
```
prctl: copy_*_user missing, channel disabled
```

### 原因

v1.14.0 只改了注释，**没改行为**：

```c
if (!hy_f_copy_from_user || !hy_f_copy_to_user) {
    /* 注释：不再直接禁用 —— 走 memcpy 兜底 */
    HY_LOG("prctl: WARN ... fallback\n");
    return -ENOSYS;      /* ← 照样禁用 */
}
```

注释和代码不一致，是**假修复**。

### 修复

删掉 `return -ENOSYS`，只告警，继续装 hook：

```c
if (!hy_f_copy_from_user || !hy_f_copy_to_user)
    HY_LOG("prctl: WARN ... fallback\n");

ret = hook_syscalln(__NR_prctl, 5, hy_prctl_before, NULL, NULL);
```

---

## 关于"为什么创建不出 huanyu 进程"

### 直接回答：内核模块不能创建用户态进程

这是 Linux 的边界，不是欢愉的缺陷。

- 用户态进程只能由**已有的进程** `fork()` / `exec()` 产生
- 内核可以用 `call_usermodehelper()` 拉起一个程序，但它要求：
  文件系统上**已存在**可执行文件、路径已知、且该符号在 KP 导出表里
  **并没有**
- 链上最开始的 `init` 是内核线程，不是用户进程

**ls 也做不到，而且它根本没做。**

### ls 的 "LS" 是谁创建的

是 ls **用户态套件自己**的程序，用户手动启动后 `prctl(PR_SET_NAME, "LS")`
改的名。内核只负责扫名字：

```c
for_each_process(task) {
    if (strcmp(task->comm, "LS") != 0) continue;   /* 只是扫描 */
    ...
}
```

内核从不创建它。**之前照抄时搞反了方向。**

### 所以"搜不到 huanyu 进程"是预期行为

不是 bug。要么你手动跑 `huanyu_daemon`，要么——

### 更好的选择：别用共享内存，用 prctl

**prctl 通道不需要任何守护进程、不需要 mmap、不需要固定地址。**

它就是一次系统调用：

```c
prctl(0x4879756e, cmd_nr, payload_ptr, 0, 0);
```

内核 hook 了 prctl，识别魔法数后直接执行命令。
v1.15.0 之后它会正常启用。

共享内存那条路（固定地址 + magic/进程名）是**可选加速**，
只在需要高频读写时才有意义。日常用 prctl 完全够。

## v1.16.0：prctl 通道连不上的真正原因（hook_syscalln 不支持 skip_origin）

### 现象

hook 装上了、日志显示 ready，但用户态永远探测失败：
```
[-] 欢愉：两条通道均不可用
[-]   prctl   : 模块未加载，或 hook 未生效
```

### 根因：hook_syscalln 的 allow_skip = 0

KernelPatch `kernel/patch/common/syscall.c`：

```c
hook_err_t hook_syscalln(int nr, int narg, void *before, void *after, void *udata)
{
    if (syscall_hook_global)
        return syscall_hook_add(nr, 0, before, after, udata, 0, 0);
                                                        // ↑ allow_skip = 0
}
```

而 dispatcher：

```c
if (args->skip_origin && can_skip && syscall_hook_handler_granular)
    regs->regs[0] = args->ret;
else
    args->skip_origin = 0;      /* 静默丢弃 */
```

`allow_skip=0` → `can_skip=0` → **before 里设的 `args->ret` 被全部丢弃**。
真实 `prctl` 照样执行，返回 `-EINVAL`（无效 option），覆盖掉我们的结果。

**所以"hook 成功但连不上"——返回值根本传不出去。**

### 修复

**（1）改用 `hook_syscalln_override`**

```c
if (syscall_hook_global && syscall_hook_handler_granular)
    return syscall_hook_add(nr, 0, before, after, udata, 1, 1);
                                                    // ↑ allow_skip=1, bypass_gate=1
```

`bypass_gate=1` 还额外绕开 `su_syscall_gate` 的 uid 限制。

**（2）更关键：命令执行整体移到 after 回调**

查证 `hook.c` 的 `_transit8` 与 `syscall.c` 的 `syscall_dispatch_after`：

```c
befores -> (if (!skip_origin)) origin -> afters -> return fargs.ret;
```

**after 回调无论 skip_origin 是否生效都必然执行**，且返回值最终取
`fargs.ret` / `args->ret`。

所以命令放在 after 执行：

- `before`：只识别魔法数 + 设 `skip_origin=1`（尽力抑制真实 prctl）
- `after`：执行命令、`copy_to_user` 回写、设置 `args->ret`

**不依赖 skip_origin 是否被支持**，且保证命令只执行一次
（不会出现 before + after 各执行一次的重复副作用）。

### 顺带修正

- `unhook_syscalln` 现在传 `hy_prctl_before, hy_prctl_after`，
  与注册时完全一致（之前传 `NULL` 作为 after，匹配不上会残留 hook）
- `/proc/huanyu` 增加 prctl 模式显示：
  `override(skip_origin supported)` / `plain(after-callback fallback)`

### 版本线

| 版本 | 内容 |
|---|---|
| v1.13.0 | 修卸载炸内核（kthread use-after-free） |
| v1.14.0 | copy_from_user 多候选 + 无符号兜底 |
| v1.15.0 | 删掉 prctl init 里误留的 `return -ENOSYS`（假修复） |
| **v1.16.0** | **修 skip_origin 不被支持导致返回值丢失（真正连不上的原因）** |

## v1.16.0 追加：节能模式 + 版本号动态化 + 默认断点方案可配置

### 1. 节能模式（50 秒无活动自动节能）

**需求**：连续 50 秒没有使用 KPM 任何功能时进入节能。

**实现要点 —— 不新增内核线程**

前面 v1.13.0 刚修过 kthread use-after-free（线程只能由
`kthread_should_stop()` 退出，早退会让 `kthread_stop()` 拿到已释放的
`task_struct`）。所以这里**刻意不加线程、不加定时器、不加 workqueue**。

采用**惰性求值**：

```
hy_ctl_switch() 开头 -> hy_pm_touch()  记录最后活动时刻
需要判断处          -> hy_pm_is_saving() 惰性比对
```

真正的活动入口只有 `hy_ctl_switch()`（prctl / supercall / 共享内存
三条通道最终都汇入它），所以一处 touch 即可覆盖全部使用情况。

空闲时"没人来判断"，本身就不消耗 CPU —— 这才叫节能。

**节能期间停掉什么**：共享内存连接线程的**进程扫描**。
这是整个模块最耗 CPU 的部分（要对每个候选进程做 GUP + vmap）。

**唤醒**：任何一条命令进入 `hy_ctl_switch()` 立即恢复。

**时间源**：KernelPatch 的 173 个导出符号里**没有任何时间函数**
（已核对：无 ktime_get / sched_clock / jiffies）。
只能通过 `kallsyms_lookup_name` 运行时解析：

| 优先级 | 符号 |
|---|---|
| 1 | `ktime_get_seconds` |
| 2 | `__ktime_get_real_seconds` |
| 3 | `sched_clock`（纳秒，兜底，几乎必然存在） |

**解析不到就降级为"永不节能"，绝不猜地址。**

可调：`HY_IDLE_SEC`（默认 50）、`HY_POWERSAVE_ENABLE`（默认 1）。

### 2. 版本号动态化

之前 `/proc/huanyu` 显示 `1.0` 而模块实际是 `1.16.0` —— 两处各写各的。

现在**单一来源**：

```c
#define HY_VERSION_STRING "1.16.0"
KPM_VERSION(HY_VERSION_STRING);        /* hy_main.c */
hy_f_seq_printf(seq, "version : %s\n", HY_VERSION_STRING);  /* procfs */
```

改一处即可，三处同步。

### 3. 默认断点方案可配置

**需求**：默认 硬件 -> PTE -> 软件。

```c
/* Default breakpoint scheme 1 = 硬件  2 = PTE  3 = 软件 */
#ifndef HY_DEFAULT_BP_SCHEME
#define HY_DEFAULT_BP_SCHEME   1      /* 当前：硬件 */
#endif
```

选择优先级：

1. 用户本次调用显式指定（非 AUTO）—— 最高
2. 运行时默认（用户态通过命令设置过）
3. **编译期默认 `HY_DEFAULT_BP_MODE`**（由 `HY_DEFAULT_BP_SCHEME` 推出）
4. 内置回退链：硬件 -> PTE -> 软件

**降级保护**：若默认方案当前不可用会自动沿链降级。
例如选了硬件但槽位耗尽（brps=6 全占），自动退到 PTE，
不会因为选了不可用方案就安装失败。

三种方案特性：

| 方案 | 优势 | 劣势 |
|---|---|---|
| 硬件 | 不改内存、最快、最隐蔽 | 槽位有限（本例 brps=6） |
| PTE | 影子页，不改代码字节 | 页粒度 |
| 软件 | 最兼容 | 改代码段，可被校验发现 |

`/proc/huanyu` 新增两段显示：

```
[power save]
  state         : SAVING / active
  idle          : 63 s (threshold 50 s)
  wakeups       : 2
  saved scans   : 128

[breakpoint]
  default scheme: hardware (1)
  fallback chain: hardware -> PTE -> software
```

## /proc/huanyu 全量诊断输出

排查问题时先看这个文件，它不经过鉴权，**任何进程 cat 都能看**。
现在输出以下全部段落：

| 段落 | 内容 |
|---|---|
| **client** | **有没有用户态连着**、命令总数、分通道计数、错误数、最后一条命令号与来源 pid、已知调用方 pid 列表 |
| runtime | 活跃断点数 / 池容量、命中总数、缓存命中未命中、符号失败数 |
| cpu features | pac / bti / lse / mte / fp / brps / wrps |
| layout | comm / pid / tasks / pgd 四个偏移的自发现结果（-1 = 不可用） |
| features | procfs 文件是否已建、文件隐藏是否生效、蹦床区是否就绪 |
| power save | 状态、空闲秒数、阈值、唤醒次数、节省的扫描次数 |
| breakpoint | 默认方案、回退链 |
| channels | ctl0 / prctl / shm 三通道各自状态与统计 |
| version | 版本号（与 KPM_VERSION 同源）、符号缺失数、断点能力 |

### 使用追踪的实现

三条通道最终都汇入 `hy_ctl_switch()`，所以在那里一处记录即可：

```c
void hy_usage_set_channel(u32 ch);   /* 1=prctl 2=ctl0 3=shm */
```

各通道在进入前调用它打标记：

- `hy_prctl.c` 的 after 回调 → 1
- `hy_ctl.c` 的 ctl0 分发 → 2
- `hy_shm.c` 的命令线程 → 3

记录内容：总命令数、分通道计数、错误数、最后命令号、
最后来源 pid、以及最多 8 个调用方 pid 及各自调用次数。

**pid 怎么拿**：不依赖 `task_struct` 头文件，用
`hy_current_task()` + `hy_pid_offset()`（自发现过的偏移）直接读：

```c
void *cur = hy_current_task();
int off = hy_pid_offset();
int v = *(int *)((unsigned long)cur + (unsigned long)off);
```

读不到就记 0，不影响其他统计。

全部静态存储，无 kmalloc（6.12 上 kmalloc 解析有风险）。

### 顺带修的构建问题

`hy_current_task` 之前在 `hy_discover.c` 里是 `static`、
在 `hy_shm.c` 里又是 `extern` 声明，两份不一致。
统一为 `hy.h` 声明 + `hy_discover.c` 实现，`hy_shm.c` 的重复声明删掉。

# v1.17.0 —— 全源码审查：修复 + 性能优化

用户对全部源码做了一次完整审查。以下是**实际找到并修复**的问题。

## 一、致命 bug（会导致崩溃）

### 1. 硬件断点上下文切换：类型混淆

```c
g_switch_target = mm;                    /* 存的是 mm */
...
cur = (void *)sp_el0;                    /* 取出的是 task */
if (cur == g_switch_target) { ... }      /* 永远不相等 */
```

`__switch_to` 之后重编调试寄存器的代码**从来没有执行过**，
HW 方案形同虚设。而且单全局变量也不支持多进程各下各的。

**修复**：改为按 pid 匹配，支持任意多个进程。

### 2. 硬件槽位只清 0~3

你的 SoC 读到 `brps=6`。`hy_hw_clear()` 原来只清 4 个，
槽位 4、5 残留 —— 卸载后调试异常仍触发，跳进已释放代码 -> 崩。

**修复**：按 `g_brps` 全部清（上限 16），并新增
`hy_hw_disable_slot()` 供单条 uninstall 精确关闭。

### 3. uninstall 硬件断点不清寄存器

原来只有模块 exit 才清。运行中单独 uninstall 一条 HW 断点，
dbgbcr 仍 enable 指向已释放地址 -> 目标进程一执行到就崩。

**修复**：`hy_bp_uninstall` 里按 `bp->hw_slot` 精确关闭。

### 4. 安装断点泄漏 task 引用

成功路径漏了 `put_task_struct()`（失败路径有）。
`find_get_task_by_vpid` 会 +1 引用，不释放则该进程
task_struct 永不回收 —— 下几个断点后系统资源被吃光。

**修复**：成功路径补上释放。

### 5. `hy_bp_list` 在链表遍历中途解锁

```c
list_for_each_entry(bp, &g_bp_list, list) {
    hy_unlock();
    copy_to_user(...);      /* 这期间别的 CPU 可能 uninstall 掉 next */
    hy_lock();
}
```

next 指针悬空 -> 崩溃。

**修复**：锁内先拷快照到栈数组，解锁后再统一 copy_to_user。

### 6. `strcmp` 直接解引用用户态指针

```c
strcmp(comm, name_buf);   /* name_buf 来自用户态 */
```

未映射则缺页崩溃；传垃圾地址就是任意地址读。

**修复**：先 `copy_from_user` 到内核栈再比较。

### 7. 跨页快路径只验证首末页

原来只检查首页和最后一页的连续性，中间页**根本没验证**。
跨 3 页而中间不连续时，会从错误物理地址读写 —— 读到脏数据，
写则破坏无关内存。

**修复**：逐页验证内核 VA 是否正好 +PAGE_SIZE，断开就在那里截断。

### 8. 进程链表遍历无上限

`hy_enum_processes` / `hy_enum_threads` 遍历 tasks 链表没有 guard，
若遍历中被并发修改形成环 -> 死循环 -> 内核卡死重启。

**修复**：加 65536 上限。

## 二、功能失效

### 9. 改寄存器功能完全失效

```c
bp->reg_mask = args->reg_modify_mask;
memset(&bp->regs_to_set, 0, sizeof(...));   /* 从未读取 regs_to_set_ptr */
```

mask 设了，值全是 0 —— 调 `bp_set_reg(0, 123)` 实际把 x0 写成 0。

**修复**：先从用户态拷入，拷不到报错（而不是静默写 0）。
安装路径同样处理。

### 10. 软件断点被误判不可用

```c
if (hy_f___get_free_pages) c |= HY_BP_CAP_SW;   /* 错 */
```

**软件断点根本不需要分配页**（只是把指令改成 BRK）。
你的环境 `__get_free_pages` NOT FOUND，于是 SW 和 PTE 全被禁，
`caps = 0x4`（只剩 HW）—— 明明能用的功能被白白砍掉。

**修复**：SW 只依赖页表遍历可用（`hy_pt_ready()`），
只有 PTE 才真的需要 `__get_free_pages`。

### 11. 命中总数永远是 0

`g_hit_count_total` 从来没被递增过，`hy_bp_hit_total()` 恒返回 0。

**修复**：`hy_bp_record_hit` 里递增。

### 12. 硬件槽位 >= 4 时复用 slot 0

brps=6 时第 5、6 个断点会覆盖第 1 个。

**修复**：支持到 slot 15，超出直接拒绝而非覆盖。

## 三、性能优化

### 13. 页错误路径：两级快速过滤

`hy_fault_before` 原来**每次**用户态缺页都做
`get_task_mm()` + 遍历全部断点 + `mmput()`。
缺页是极高频事件，这条路径拖慢整个系统。

**修复**：
1. 没有活跃 PTE 断点 -> 第一行返回
2. 新增页基址哈希表（256 项开放寻址），地址不在任何断点页内 -> 立即返回

绝大多数缺页在第 1 级就退出。

### 14. 编译：性能优先

新增（用户态/内核态分别）：
- 内核侧：`-fno-semantic-interposition -funroll-loops -fpeel-loops
  -ftree-vectorize -fomit-frame-pointer -fno-plt
  --param=inline-unit-growth=200 --param=large-function-growth=500`

**刻意不加 `-flto`**：与 `-r` 部分链接 + KPM 加载器冲突，会破坏 `.kpm.*` 段。

### 15. 用户态优化

- **模块基址缓存**：原来每次 `getModuleBase` 都 fopen + 扫描整个
  maps（大进程数千行）。现在缓存 (pid, 名字) -> base。
- **批量读写** `read_contiguous` / `read_struct`：
  读 N 个连续字段从 N 次往返降到 1 次。
- **`-DHY_FAST_IO=1`**：关掉头文件里的诊断 printf，热路径零输出开销。

用户态建议编译（目标机）：

```sh
aarch64-linux-android31-clang++ -std=c++17 -O3 -march=armv8.3-a \
    -flto -fno-exceptions -fno-rtti -funroll-loops \
    -fomit-frame-pointer -DNDEBUG -DHY_FAST_IO=1 your_code.cpp
```

## 四、清理

删除以下过时产物（与当前项目无关）：
`clang_kpm_pack.zip` `final_kpm.zip` `hooktest_pack.zip`
`ko_integrity_kpm.zip` `ndk_build.zip` `kpmdev2.zip`
`wxshadow_fix.zip` `lsdriver_kpm.zip` `kp.zip`

# v1.18.0 —— 移植 lsdriver 能力

对照 lsdriver 源码把功能往欢愉搬。ls 是 ko，欢愉是 KPM，
能力边界不同，所以按三档如实标注，不做虚假宣称。

## 移植分级

| 档 | 含义 |
|---|---|
| **原版同款** | 机制与 ls 完全一致 |
| **等价实现** | 机制不同，对外行为一致 |
| **能力探测** | 只报告硬件是否支持（KPM 下无法完整实现） |

## 一、原版同款

### syscall 监控（HY_NR_SYSMON_*）

ls 的 `arm64_syscall_monitor.h`（662 行）做法：
hook `do_el0_svc` **统一入口**（而不是按 syscall 号逐个 hook），
按进程过滤，记录 nr / 前 3 个参数 / 返回值。

欢愉同样 hook `do_el0_svc`，覆盖全部 syscall。上限也是 8 个进程。

差异：ls 用 `<uapi/asm/unistd.h>` 的 `__SYSCALL` 宏生成名字表，
KPM 没有完整 unistd 头文件，只记号不做名字解析。

### CNTVCT 读取监控（HY_NR_CNTVCT_*）

ls 的 `arm64_cntvct_monitor.h`（228 行）做法：
hook `__switch_to`，切到目标进程时清 `CNTKCTL_EL1.EL0VCTEN`，
使 EL0 读 `CNTVCT_EL0` 陷入 EL1，再由
`cntvct_read_handler`（内核本就存在的模拟函数）计数。

欢愉完全照搬，外加两条 ls 没显式写的安全加固：

1. **只在 `cntvct_read_handler` 存在时才允许启用**
   —— 否则清了 EL0VCTEN 之后目标进程读 CNTVCT 会走
   `do_undefinstr` 拿 SIGILL 直接崩溃。
2. **切出目标进程时置回该位**
   —— CNTKCTL 是 per-CPU 的，不恢复会误伤下一个进程。

### 虚拟定位 GNSS（HY_NR_GNSS_*）

ls 的 `virtual_gnss.h`（338 行）做法：
hook ioctl → 拦 `BINDER_WRITE_READ` → 遍历
`BC_TRANSACTION`/`BC_REPLY` → 找 UTF-16LE 的
`android.location.ILocation` token → 按
`Location.writeToParcel()` 布局定位 latitude/longitude
两个 double → 整数算法转 IEEE754 bits 后写回。

**这部分是逐行照搬的**，包括 SWAR 64 位并行比对和三处范围校验。

内核里不能用 double/float（会破坏用户态 FP/SIMD 上下文），
所以 `e7 -> IEEE754 bits` 全程整数运算，与 ls 同款。

已知限制直接沿用 ls 源码开头列的 6 条，不虚标：
Android 12+ 的 UTF-16 provider 可能失配、批量回调只命中第一个、
token 可能误匹配 ILocationManager、SG 命令不命中、
并发可能形成混合快照、只扫前 512 字节。

## 二、等价实现

### DPT 主线程影子页（HY_NR_DPT_*）—— 差异最大的一块

ls 原版（`arm64_dptdbg.h` 919 行）：给主线程建**私有影子 PGD**，
影子 PGD 里把代码页映射到 trap 副本，主线程走影子页表，
其他线程保持正常页表。
依赖 `alloc_page` / `pgd_offset` / `p4d_offset` /
`mmu_notifier` / `work_struct`。

**欢愉做不到**：没有 `struct page` 头文件、没有 `mmu_notifier`、
不能 kmalloc。

**等价实现**：复用欢愉已有的 PTE 影子页机制，在 `__switch_to`
上做主线程判定——主线程装影子映射，其他线程还原原始 PTE。
对外行为一致（只有主线程命中），机制不同。

### 单步断点（HY_NR_STEPBP_*）

ls 是置 `MDSCR_EL1.SS` 位。欢愉用经典 software step：
装 BRK → 命中 → 恢复原指令 → 单步 → 重装备。

### 增强枚举（HY_NR_ENUM_SEGMENTS / ENUM_REGIONS）

ls 是 1024 模块 / 512 段 / 16534 可扫描区域。
欢愉给出段（含 prot 位）和可扫描区域（rw-p，排除过小/过大段）。
因拿不到 VMA 名字（无 dentry 头文件），区域过滤是启发式的。

### GPU 隐藏（HY_NR_KGSL_HIDE_*）

ls 的 `hide_kgsl.h` 255 行。欢愉只做入口 hook + 计数，
**不做深度数据改写**——KPM 拿不到 kgsl 内部结构体定义。如实标注为受限。

## 三、能力探测

### HY_NR_HWCAP2

从系统寄存器实读：MTE / SPE / PAN / BTI / PAC / LSE / BRPS / WRPS。

`ghost` 字段恒为 0 —— ghost region 需要 `struct page` + 页重定位，
KPM 下不可用。如实报告不支持。

## 四、补齐的小项

- `HY_NR_TOUCH_MOVE` —— ls 有 `request_op_touch_move`，欢愉原先只有 down/up
- `HY_NR_ENV_PARAMS` —— 对应 ls 的 `request_op_env_get_params`
- `HY_NR_LS_STATUS` —— 一次性返回所有移植功能的状态

## 五、/proc/huanyu 新增段

```
[ls-port v1.18.0]
  syscall monitor : off (hooked=0 total=0)
  cntvct monitor  : off (hooked=0 hits=0)
  gnss spoof      : off (hooked=0 patched=0)
  dpt main-thread : off (hooked=0)
  kgsl hide       : off (hooked=0)
  step breakpoint : off
```

## 六、踩到的坑

1. **KP 的 ioctl 宏与标准不同** —— `_IOW(type,nr,struct X)` 会报
   "expected expression before 'struct'"。改为手工按 `_IOC` 编码规则算命令字。
2. **卸载 API 名字** —— 我一开始写了 `hook_unwrap4` /
   `hook_unwrap_syscalln`，KP 实际是 `hook_unwrap` / `unhook_syscalln`。
   写错编译不报错（隐式声明），但加载时解析失败。已逐个核对源码修正。
3. **用户态头文件处于 `#pragma pack(1)` 区** —— 新结构体插进去后
   `static_assert` 全挂。加 `#pragma pack()` 恢复自然对齐。

## 七、版本

v1.13.0 卸载 UAF → v1.14.0 copy 符号 → v1.15.0 假修复 →
v1.16.0 skip_origin → v1.17.0 全源码审查 → **v1.18.0 ls 移植**

