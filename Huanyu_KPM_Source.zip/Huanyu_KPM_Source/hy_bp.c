/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_bp.c —— 断点核心：软件 / PTE 影子页 / 硬件 三种方案
 *
 * 方案选择（用户可切，见 huanyu_driver.hpp）：
 *   SW  —— 把目标指令替换成 BRK #7。数量不限，但改了代码段，
 *          会被 CRC 校验发现。
 *   PTE —— W^X 影子页：目标页保持只读（原始内容），另配一份可执行影子页，
 *          命中后单步走影子页。代码段字节不变，最难被检测。
 *   HW  —— ARM64 DBGBVR/DBGBCR 调试寄存器。不改内存，性能最好，
 *          但槽位极少（ID_AA64DFR0.BRPS，通常 4~16）。
 *
 * 内存分配一律走静态对象池，不碰 kmalloc。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <hook.h>
#include <ksyms.h>
#include <kallsyms.h>
#include <asm/current.h>
#include "hy.h"
#include "hy_scheme.h"

extern void *(*hy_f_find_get_task_by_vpid)(int pid);
extern void *(*hy_f_get_task_mm)(void *task);
extern void (*hy_f_mmput)(void *mm);
extern void (*hy_f_put_task_struct)(void *task);
extern unsigned long (*hy_f___get_free_pages)(unsigned int gfp, unsigned int order);
extern void (*hy_f_free_pages)(unsigned long addr, unsigned int order);
extern void (*hy_f_user_enable_single_step)(void *task);
extern void (*hy_f_user_disable_single_step)(void *task);
extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);
#ifndef ENOENT
#define ENOENT 2
#endif
#ifndef EFAULT
#define EFAULT 14
#endif
#ifndef EINVAL
#define EINVAL 22
#endif
extern void *(*hy_f_do_mem_abort)(unsigned long addr, unsigned int esr, void *regs);
extern void *(*hy_f_do_page_fault)(unsigned long addr, unsigned int esr, void *regs);

/* 前向声明：定义在文件后半部分，但 hy_bp_init / hy_bp_exit 里要用 */
static void hy_fault_before(hook_fargs4_t *args, void *udata);
static void hy_hw_clear(void);
static void hy_hw_disable_slot(int slot);   /* v1.19.0: hy_bp_rollback 需要提前引用 */
static void hy_bp_rollback(struct hy_breakpoint *bp, void *mm);
static void hy_switch_after(hook_fargs4_t *args, void *udata);
/*
 * 【修复 v1.17.0】原来这里存的是 mm 指针，但 hy_switch_after 里比较的是
 * task 指针（sp_el0），两者永远不相等 —— 硬件断点在上下文切换后
 * 永远不会被重新编程，等于 HW 方案形同虚设。
 * 而且单个全局变量也不支持多进程同时下硬件断点。
 * 现在改成：按 pid 匹配，支持任意多个进程各下各的。
 */
static void *g_switch_target;   /* 保留以兼容，实际改用 pid 匹配 */

/* ============================ 静态对象池 ============================ */

/*
 * 池子尺寸：直接决定 .bss 大小（KPM 加载时实打实分配）。
 *   hy_breakpoint  ≈ 940 B（内含 800 B 的 regs_to_set）
 *   hy_hit_record  ≈ 840 B（内含 832 B 的 hy_bp_hit_item）
 * 256 × 940 + 2048 × 840 ≈ 1.9 MB —— 太大，会拖慢加载并占用内核内存。
 * 收敛到 64 + 256 ≈ 275 KB，对绝大多数场景够用。
 */
#ifndef HY_POOL_BP
#define HY_POOL_BP   64
#endif
#ifndef HY_POOL_HIT
#define HY_POOL_HIT  256
#endif

static struct hy_breakpoint g_bp_pool[HY_POOL_BP];
static bool g_bp_used[HY_POOL_BP];

static struct hy_hit_record g_hit_pool[HY_POOL_HIT];
static u32 g_hit_head;
static u32 g_hit_count_total;

static u64 g_next_handle = 0x1000;

static struct list_head g_bp_list;
static u32 g_brps;      /* 硬件执行断点槽位数 */
static bool g_hw_any_active;
/*
 * 是否有活跃的 PTE 断点（页错误路径的快速过滤）。
 * 没有的话缺页回调在第一行就返回，几乎零开销。
 */
static bool g_pte_any_active;

/*
 * 【v1.19.0】是否有任何"走调试异常路径"的断点（SW / PTE）。
 * do_debug_exception 与页错误都是高频入口，没有断点时必须在第一行退出。
 * 原来只有 g_pte_any_active / g_hw_any_active，BRK 回调没有任何快速过滤，
 * 每次调试异常都要 get_task_mm + 遍历链表 —— 白白拖慢系统。
 */
static bool g_bp_any_active;

/* 正在走退出流程：跳过单条卸载时的整体重编，避免清了又装 */
static bool g_exiting;

/*
 * 三个标志统一由这个函数重算，避免"某条路径忘了更新"导致
 * 快速过滤误判（漏掉命中 = 功能失效，或永远不退出 = 性能问题）。
 */
static void hy_bp_flags_refresh(void)
{
    struct hy_breakpoint *bp;
    bool any = false, pte = false, hw = false;

    list_for_each_entry(bp, &g_bp_list, list) {
        if (!bp->active) continue;
        any = true;
        if (bp->mode == HY_BP_MODE_PTE) pte = true;
        if (bp->mode == HY_BP_MODE_HW)  hw  = true;
    }
    g_bp_any_active  = any;
    g_pte_any_active = pte;
    g_hw_any_active  = hw;
}

/*
 * 断点页基址的快速索引。
 * 用一个小开放寻址哈希表存"页基址"，命中才去走慢路径
 * （get_task_mm + 链表遍历）。避免每次缺页都遍历链表。
 */
#define HY_BPPAGE_BITS 8
#define HY_BPPAGE_SIZE (1u << HY_BPPAGE_BITS)
#define HY_BPPAGE_MASK (HY_BPPAGE_SIZE - 1u)
static unsigned long g_bp_page[HY_BPPAGE_SIZE];

/*
 * 【修复 v1.19.0】墓碑值：开放寻址删除不能直接清 0。
 * 查找时"遇到 0 就停止"，删除中间槽位会截断探测链，
 * 使排在其后的条目永远查不到 —— 表现是
 * "卸掉一个断点后，另一个断点突然不再命中"。
 * 用墓碑标记"这里曾有条目"，查找继续、插入可复用。
 */
#define HY_BPPAGE_TOMB  1UL

static void hy_bp_page_add(unsigned long page_base)
{
    u32 h = (u32)((page_base >> 12) & HY_BPPAGE_MASK);
    u32 i;
    u32 first_tomb = HY_BPPAGE_SIZE;
    for (i = 0; i < HY_BPPAGE_SIZE; i++) {
        u32 idx = (h + i) & HY_BPPAGE_MASK;
        if (g_bp_page[idx] == page_base) return;          /* 已存在 */
        if (g_bp_page[idx] == HY_BPPAGE_TOMB) {
            if (first_tomb == HY_BPPAGE_SIZE) first_tomb = idx;
            continue;
        }
        if (g_bp_page[idx] == 0) { g_bp_page[idx] = page_base; return; }
    }
    /* 全满但有墓碑：复用第一个墓碑位 */
    if (first_tomb != HY_BPPAGE_SIZE) g_bp_page[first_tomb] = page_base;
}

static void hy_bp_page_del(unsigned long page_base)
{
    u32 h = (u32)((page_base >> 12) & HY_BPPAGE_MASK);
    u32 i;
    for (i = 0; i < HY_BPPAGE_SIZE; i++) {
        u32 idx = (h + i) & HY_BPPAGE_MASK;
        if (g_bp_page[idx] == page_base) { g_bp_page[idx] = HY_BPPAGE_TOMB; return; }
        if (g_bp_page[idx] == 0) return;
    }
}

static void hy_bp_page_reset(void)
{
    hy_memset(g_bp_page, 0, sizeof(g_bp_page));
}

/* 该地址所在页是否可能是某个断点的目标页 */
static bool hy_bp_page_may_hit(unsigned long addr)
{
    unsigned long base = addr & HY_PAGE_MASK;
    u32 h = (u32)((base >> 12) & HY_BPPAGE_MASK);
    u32 i;
    for (i = 0; i < HY_BPPAGE_SIZE; i++) {
        u32 idx = (h + i) & HY_BPPAGE_MASK;
        if (g_bp_page[idx] == 0) return false;            /* 探测链终止 */
        if (g_bp_page[idx] == base) return true;
        /* HY_BPPAGE_TOMB 继续往后探测 */
    }
    return false;
}   /* 是否有活跃硬件断点（__switch_to 快速过滤） */
static u32 g_wrps;      /* 硬件观察点槽位数 */

/*
 * 【修复 v1.19.0】自旋锁必须关中断。
 *
 * 原来的实现只是一个不关中断的自旋锁。如果同一 CPU 上
 * 在持锁期间被中断打断，而中断路径也调用 hy_lock（页错误回调、
 * 命中记账、对象池分配都可能走到），就会**自己等自己** —— 死锁，
 * 表现是整只手机硬卡死，只能强制重启。
 *
 * 现在成对使用 daifset/daifclr 关开 IRQ，并保存/恢复原 DAIF，
 * 这样嵌套调用（hy_bp_install 内部已持锁再调 refresh）也不会出错。
 */
static volatile u32 g_lock;
static u64 g_lock_flags;

/*
 * 注意：g_lock_flags 只在**拿到锁之后**才写。
 * 如果在自旋之前写，多个 CPU 会互相覆盖各自的 DAIF，
 * 解锁时恢复成别人的中断状态 —— 可能造成中断永久关闭（设备假死）
 * 或在本该关中断的上下文被错误打开。
 * 拿到锁后再写，写操作天然互斥。
 *
 * 约束：本锁不可重入（同一 CPU 不可嵌套调用）。
 * 当前所有调用点都是 lock/unlock 成对且不嵌套。
 */
static inline void hy_lock(void)
{
    u64 daif;
    u32 tmp;

    asm volatile("mrs %0, daif" : "=r"(daif));
    asm volatile("msr daifset, #2" ::: "memory");   /* 关 IRQ，防同 CPU 重入死锁 */

    asm volatile(
        "1: ldaxr %w0, [%1]\n"
        "   cbnz  %w0, 1b\n"
        "   stxr  %w0, %w2, [%1]\n"
        "   cbnz  %w0, 1b\n"
        : "=&r"(tmp) : "r"(&g_lock), "r"(1) : "memory");

    g_lock_flags = daif;      /* 获得锁后才记录，互斥写 */
}

static inline void hy_unlock(void)
{
    u64 daif = g_lock_flags;

    asm volatile("stlr %w1, [%0]" :: "r"(&g_lock), "r"(0) : "memory");
    asm volatile("msr daif, %0" :: "r"(daif) : "memory");
}

void *hy_obj_alloc(void)
{
    int i;
    void *p = NULL;
    hy_lock();
    for (i = 0; i < HY_POOL_BP; i++) {
        if (!g_bp_used[i]) { g_bp_used[i] = true; p = &g_bp_pool[i]; break; }
    }
    hy_unlock();
    if (p) hy_memset(p, 0, sizeof(struct hy_breakpoint));
    return p;
}

void hy_obj_free(void *p)
{
    int idx;
    if (!p) return;
    idx = (int)((struct hy_breakpoint *)p - g_bp_pool);
    if (idx < 0 || idx >= HY_POOL_BP) return;
    hy_lock();
    g_bp_used[idx] = false;
    hy_unlock();
}

/* ============================ 影子页 ============================
 *
 * 【v1.27.0 重写】不再依赖 __get_free_pages。
 *
 * 现象：日志里 __get_free_pages NOT FOUND，导致
 *       caps 里 PTE 位恒为 0 —— PTE 断点整个不可用。
 *       即便后来把 caps 判定放宽，真正安装时仍会因分配失败而返回 -1。
 *
 * 原因：KPM 是内核模块，页分配器符号在某些 GKI 配置下不导出，
 *       而且用 kmalloc 还有 6.12 上解析到 kmalloc_trace 的崩溃先例。
 *
 * 修法：改用**静态影子页池**。
 *   - 在 .bss 里预留固定数量的页，按 4096 对齐
 *   - 分配 = 从池里取一页；释放 = 归还
 *   - 零外部符号依赖、零分配失败、无释放后重加载风险
 * 代价：并发 PTE 断点数量有上限（HY_SHADOW_PAGES），
 *       但断点池本身也只有 64 个，实际足够。
 * ========================================================================== */

/*
 * 池大小 == 断点池大小（HY_POOL_BP）。
 * 【关于"静态池会不会造成无效断点"】
 *   不会。池里每一页都是普通的可写内存，virt_to_phys 换算正确即可，
 *   与从页分配器拿到的页在页表层面没有任何区别。
 *   唯一风险是"池满"—— 那时 hy_shadow_alloc 返回 -3，
 *   调用方会按回退链降级到软件断点，【不会】装上一个不生效的断点。
 *   把池开到与断点池同宽（64），就保证了：
 *       任意时刻，每个断点都拿得到影子页，永不因池满而降级。
 *   代价是 256 KB .bss —— 换来 PTE 方案在任何配置下都可用，值得。
 */
#ifndef HY_SHADOW_PAGES
#define HY_SHADOW_PAGES 256   /* v1.33.0 用户要求：24 -> 256 */
#endif

static u8 g_shadow_pool[HY_SHADOW_PAGES][HY_PAGE_SIZE]
    __attribute__((aligned(HY_PAGE_SIZE)));
static volatile bool g_shadow_used[HY_SHADOW_PAGES];

/* 池是否已通过 virt_to_phys 自检（保证线性映射可用） */
static int g_shadow_pool_ok = 0;

static void hy_shadow_pool_init(void)
{
    unsigned long v = (unsigned long)&g_shadow_pool[0][0];
    unsigned long p = hy_virt_to_phys(v);

    hy_memset(g_shadow_used, 0, sizeof(g_shadow_used));

    if (p == v || p == 0) {
        HY_LOG("bp: shadow pool disabled (virt_to_phys failed)\n");
        g_shadow_pool_ok = 0;
        return;
    }
    g_shadow_pool_ok = 1;
    HY_LOG("bp: shadow pool %d pages (%lu KB) ok -- every breakpoint can get one\n",
           HY_SHADOW_PAGES, (unsigned long)(sizeof(g_shadow_pool) / 1024));
}

static int hy_shadow_alloc(struct hy_breakpoint *bp)
{
    int i;
    unsigned long v;

    if (!g_shadow_pool_ok) {
        /* 池不可用时，若恰好有页分配器仍可回退 */
        if (!hy_f___get_free_pages) return -1;
        v = hy_f___get_free_pages(0xcc0, 0);
        if (!v) return -1;
        bp->shadow_kva = (void *)v;
        bp->shadow_phys = hy_virt_to_phys(v);
        if (bp->shadow_phys == v) {
            hy_f_free_pages(v, 0);
            bp->shadow_kva = NULL;
            return -2;
        }
        return 0;
    }

    for (i = 0; i < HY_SHADOW_PAGES; i++) {
        if (g_shadow_used[i]) continue;
        g_shadow_used[i] = true;
        v = (unsigned long)&g_shadow_pool[i][0];
        bp->shadow_kva = (void *)v;
        bp->shadow_phys = hy_virt_to_phys(v);
        hy_memset(bp->shadow_kva, 0, HY_PAGE_SIZE);
        return 0;
    }
    HY_LOG("bp: shadow pool full (%d/%d)\n", i, HY_SHADOW_PAGES);
    return -3;   /* 池满 */
}

static void hy_shadow_free(struct hy_breakpoint *bp)
{
    int i;

    if (!bp->shadow_kva) return;

    /* 判断这一页是否来自静态池 */
    if ((unsigned long)bp->shadow_kva >= (unsigned long)&g_shadow_pool[0][0] &&
        (unsigned long)bp->shadow_kva <  (unsigned long)&g_shadow_pool[0][0] +
                                          sizeof(g_shadow_pool)) {
        unsigned long off = (unsigned long)bp->shadow_kva -
                            (unsigned long)&g_shadow_pool[0][0];
        i = (int)(off / HY_PAGE_SIZE);
        if (i >= 0 && i < HY_SHADOW_PAGES) g_shadow_used[i] = false;
    } else if (hy_f_free_pages) {
        hy_f_free_pages((unsigned long)bp->shadow_kva, 0);
    }
    bp->shadow_kva = NULL;
    bp->shadow_phys = 0;
}

/* 供 caps 判定使用：影子页是否可获得 */
int hy_bp_shadow_available(void)
{
    if (g_shadow_pool_ok) return 1;
    return hy_f___get_free_pages ? 1 : 0;
}

/* ============================ BRK 处理 ============================ */

static void *g_brk_target;
/*
 * 【记录 hook 目标，供 exit 精确卸载】
 *   页错误 hook 挂在 do_page_fault / do_mem_abort 上，
 *   __switch_to hook 挂在上下文切换上 —— 这两个在模块卸载后
 *   如果还挂着，任何进程缺页或进程切换都会跳进已释放的模块代码，
 *   立刻 panic。这是"卸载后再次加载炸内核"的直接原因。
 */
static void *g_fault_target;
static void *g_switch_fn;

/*
 * 定位 BRK 异常处理入口。arm64 上不同版本名字不同，
 * 只做地址解析，hook 由 KP 的 hook_wrap 完成，不碰结构体布局
 * （register_user_break_hook 需要模块内结构体与内核完全一致，
 *  在 6.12 上是 wxshadow 的可疑崩溃点之一，这里刻意避开）。
 */
unsigned long hy_lookup_brk_handler(void)
{
    static const char *const cands[] = {
        /*
         * 【修复 v1.19.0】优先级调整：do_debug_exception 必须在 brk_handler 之前。
         *
         * brk_handler 只处理 BRK 一种异常，收不到单步完成事件；
         * 而 do_debug_exception 是 el0_dbg 的统一入口，
         * BRK 与 single-step 都会经过它。
         * SW 断点要"命中后装回原指令 -> 单步 -> 重新装 BRK"，
         * 必须能收到单步完成，否则断点只能生效一次。
         */
        "do_debug_exception",
        "brk_handler",
        "el0_dbg",
        "el0_ia",
    };
    int i;
    for (i = 0; i < 4; i++) {
        unsigned long a = kallsyms_lookup_name ? kallsyms_lookup_name(cands[i]) : 0;
        if (a && ((a & 0xffffff0000000000UL) == 0xffffff0000000000UL)) {
            HY_LOG("bp: brk entry %s @ %lx\n", cands[i], a);
            return a;
        }
    }
    return 0;
}

/* ============================ 命中定位 ============================ */

/*
 * 按**精确地址**（而非页基址）找断点。
 * BRK 命中时 regs->pc 就是断点地址本身，必须精确匹配，
 * 否则同一页内任意一条指令都能误触发。
 */
struct hy_breakpoint *hy_bp_find_exact(void *mm, unsigned long addr)
{
    struct hy_breakpoint *bp;

    list_for_each_entry(bp, &g_bp_list, list) {
        if (!bp->active || bp->suspended) continue;
        if (bp->mode == HY_BP_MODE_HW) continue;   /* HW 不走 BRK 路径 */
        if (bp->owner_mm == mm && bp->addr == addr) return bp;
    }
    return NULL;
}

/*
 * 找"正在单步收尾"的断点。
 * 单步完成时 regs->pc 已经是**下一条**指令，按地址找不到断点，
 * 所以只能靠 stepping 标志 + mm 归属来定位。
 */
struct hy_breakpoint *hy_bp_find_stepping(void *mm)
{
    struct hy_breakpoint *bp;

    list_for_each_entry(bp, &g_bp_list, list) {
        if (bp->stepping && bp->owner_mm == mm) return bp;
    }
    return NULL;
}

int hy_bp_step_supported(void)
{
    return hy_f_user_enable_single_step && hy_f_user_disable_single_step ? 1 : 0;
}

static void hy_step_on(void *task)
{
    if (hy_f_user_enable_single_step) hy_f_user_enable_single_step(task);
}

static void hy_step_off(void *task)
{
    if (hy_f_user_disable_single_step) hy_f_user_disable_single_step(task);
}

/* 把断点地址处的 4 字节写成指定指令（走页表 + 线性映射，不用 GUP） */
static void hy_poke_insn(void *mm, unsigned long addr, u32 insn)
{
    u64 *ptep = hy_find_user_pte(mm, addr, &(int){0});
    void *kva;
    u32 *p;

    if (!ptep) return;
    kva = hy_phys_to_virt(HY_ENTRY_PHYS(*ptep));
    if (!kva) return;
    p = (u32 *)((unsigned long)kva + (addr & (HY_PAGE_SIZE - 1)));
    *p = insn;
    hy_flush_tlb_range(mm, addr, addr + 4);
}

/*
 * 命中后临时撤掉断点，让原指令能被真正执行一条。
 *
 * SW : 把原指令写回（覆盖 BRK）
 * PTE: 把 PTE 切回"可执行"状态（影子页里是原指令副本，不含 BRK）
 */
void hy_bp_disarm_for_step(struct hy_breakpoint *bp, void *mm, void *task)
{
    if (bp->mode == HY_BP_MODE_SW) {
        hy_poke_insn(mm, bp->addr, bp->orig_insn);
        bp->insn_patched = false;
    } else if (bp->mode == HY_BP_MODE_PTE) {
        /*
         * PTE 方案撤断点：把**影子页**里那个 BRK 写回原指令。
         * 注意不是切回原页 —— 原页整页不可执行，
         * 切回去会立刻再次缺页，形成死循环。
         * 影子页是完整副本，进程可以正常继续执行页内其他指令。
         */
        if (bp->shadow_kva) {
            unsigned long off = bp->addr - bp->page_addr;
            u32 *insn = (u32 *)((unsigned long)bp->shadow_kva + off);
            *insn = bp->orig_insn;
        }
    }

    /*
     * 没有单步能力就不设 stepping：宁可让断点只生效一次，
     * 也不要留下一个永远等不到收尾的状态（那样断点会一直停在这里）。
     */
    if (hy_bp_step_supported()) {
        bp->stepping = 1;
        hy_step_on(task);
    }
}

/*
 * 单步收尾：原指令已经执行完，重新武装断点，关掉单步。
 */
void hy_bp_rearm(struct hy_breakpoint *bp, void *mm)
{
    if (bp->mode == HY_BP_MODE_SW) {
        hy_poke_insn(mm, bp->addr, HY_BRK_INSN);
        bp->insn_patched = true;
    } else if (bp->mode == HY_BP_MODE_PTE) {
        /*
         * 重新在影子页的断点地址写回 BRK。
         * 不再切回原页：影子页常驻到 uninstall 为止，
         * 这样进程每次执行到断点地址都会再次命中（持续生效）。
         */
        if (bp->shadow_kva) {
            unsigned long off = bp->addr - bp->page_addr;
            u32 *insn = (u32 *)((unsigned long)bp->shadow_kva + off);
            *insn = HY_BRK_INSN;
        }
    }
    bp->stepping = 0;
}

static void hy_brk_before(hook_fargs4_t *args, void *udata)
{
    void *regs;
    unsigned long pc;
    unsigned long sp_el0;
    void *task = NULL;
    void *mm = NULL;
    struct hy_breakpoint *bp = NULL;

    (void)udata;

    /*
     * 【卸载守卫】模块正在退出时，任何回调都必须立刻返回。
     * 原因：unhook 与模块内存释放之间存在时间窗，
     *       若此时回调仍继续执行，就会访问已释放的模块数据 -> 崩溃。
     *       这正是"加载 -> 卸载 -> 再加载炸内核"的根因之一。
     */
    if (!hy_ready) return;

    /* 没有任何 SW/PTE 断点时零开销退出（do_debug_exception 不太热，但仍值得） */
    if (!g_bp_any_active) return;

    regs = (void *)(unsigned long)args->arg2;
    if (!regs) return;

    /*
     * 【修复 v1.19.0】原来这个回调是**空的**，什么都不做。
     *
     * 后果极其严重：SW 方案把目标指令改成 BRK #7，
     * 进程执行到必然触发调试异常进入这里 ——
     * 而我们既不记账、也不恢复、也不阻止内核处理，
     * 于是内核正常投递 SIGTRAP，**目标进程当场被杀**。
     * 也就是说 SW 命中一次就崩，等同于完全不可用。
     *
     * 现在完整实现四件事：
     *   1) 从 pt_regs 取 pc，精确定位断点
     *   2) 记账 + 应用寄存器改写
     *   3) 临时撤掉断点 + 开单步，让原指令真正执行一条
     *   4) 设 skip_origin，阻止内核投递 SIGTRAP
     *
     * 关于 skip_origin：kernel/base/hook.c 的 _transit4() 里是
     *   if (!fargs.skip_origin) origin_func(...);
     * 普通函数 hook 支持它（syscall hook 才有 can_skip 的额外门槛），
     * 所以这里设 1 能真正拦住内核的 BRK 处理。
     */
    pc = ((u64 *)regs)[32];      /* pt_regs: x0..x30(0..30), sp(31), pc(32) */

    if (sp_el0_is_current) {
        asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));
        task = (void *)sp_el0;
    }
    if (!task) return;
    if (hy_f_get_task_mm) mm = hy_f_get_task_mm(task);
    if (!mm) return;

    /* 先看是不是单步收尾：此时 pc 已是下一条指令，按地址找不到 */
    bp = hy_bp_find_stepping(mm);
    if (bp) {
        hy_bp_rearm(bp, mm);
        hy_step_off(task);
        args->skip_origin = 1;
        goto done;
    }

    bp = hy_bp_find_exact(mm, pc);
    if (!bp) goto done;      /* 不是我们的断点，原样交给内核 */

    hy_bp_record_hit(bp, task, regs);
    hy_bp_apply_regs(bp, regs);
    hy_bp_disarm_for_step(bp, mm, task);

    /* 阻止内核继续处理（否则 SIGTRAP 杀进程） */
    args->skip_origin = 1;

done:
    if (mm && hy_f_mmput) hy_f_mmput(mm);
}

/*
 * 撤销一次失败的方案尝试留下的副作用。
 * 没有它，链式降级时前一次尝试写进去的 BRK / 改过的 PTE /
 * 分配掉的影子页 / 占用的硬件槽位都会残留 —— 表现是
 * "装 PTE 失败改走 SW，结果目标进程的页权限还被改着"。
 */
static void hy_bp_rollback(struct hy_breakpoint *bp, void *mm)
{
    if (bp->insn_patched && mm) {
        hy_poke_insn(mm, bp->addr, bp->orig_insn);
        bp->insn_patched = false;
    }
    if (bp->shadow_kva) {
        hy_shadow_free(bp);
        bp->shadow_phys = 0;
    }
    if (bp->orig_pte && mm) {
        u64 *ptep = hy_find_user_pte(mm, bp->page_addr, &(int){0});
        if (ptep) {
            hy_set_user_pte(mm, bp->page_addr, ptep, bp->orig_pte);
            hy_flush_tlb_range(mm, bp->page_addr, bp->page_addr + HY_PAGE_SIZE);
        }
    }
    if (bp->hw_slot >= 0) {
        hy_hw_disable_slot(bp->hw_slot);
        bp->hw_slot = -1;
    }
    bp->orig_pte = 0;
    bp->mode = 0;
    bp->state = 0;
    bp->stepping = 0;
}

int hy_bp_init(void)
{
    u64 dfr0;
    int i;

    INIT_LIST_HEAD(&g_bp_list);
    g_hit_head = 0;
    g_hit_count_total = 0;
    g_lock = 0;

    for (i = 0; i < HY_POOL_BP; i++) g_bp_used[i] = false;

    /* 影子页静态池（v1.27.0）：不依赖页分配器符号 */
    hy_shadow_pool_init();

    /* 读 ID_AA64DFR0_EL1 的 BRPS 字段（bit 12..15），0 表示不支持硬件断点 */
    asm volatile("mrs %0, ID_AA64DFR0_EL1" : "=r"(dfr0));
    g_brps = (u32)((dfr0 >> 12) & 0xf) + 1;   /* 编码值 +1 = 实际槽位数 */
    g_wrps = (u32)((dfr0 >> 20) & 0xf) + 1;
    HY_LOG("bp: ID_AA64DFR0 BRPS=%u WRPS=%u\n", g_brps, g_wrps);

    /*
     * 【修复 v1.21.0】上一版这里写的是 (void)hy_hw_clear;
     * —— 取函数地址后丢弃，【根本没调用】。
     *
     * 后果：模块加载时不会清除上一次残留的 DBGBCR。
     * 若上次卸载没清干净（或别的模块用过调试寄存器），
     * 新模块一加载，目标进程执行到旧断点地址就触发调试异常，
     * 跳进我们的 brk handler —— 而此时断点表是空的，处理逻辑
     * 找不到 bp 就会走异常分支。这正是"卸载后重载炸内核"的一类诱因。
     *
     * g_brps 已在上一行算出，此时调用时机正确。
     */
    /*
     * v1.24.0：默认不再无条件写 DBGBCR。
     * 见 hy.h 中 hy_opt_hwclear 的说明 —— 用加载参数 hwclear=1 开启。
     */
    if (hy_opt_hwclear) {
        hy_hw_clear();
        HY_LOG("bp: hw_clear done (slots=%u)\n", g_brps);
    } else {
        HY_LOG("bp: hw_clear skipped (add hwclear=1 to enable)\n");
    }

    g_brk_target = (void *)hy_lookup_brk_handler();
    if (g_brk_target) {
        int ret = hook_wrap4(g_brk_target, hy_brk_before, NULL, (void *)0);
        if (ret == 0) {
            HY_LOG("bp: hooked brk handler @ %px\n", g_brk_target);
        } else {
            HY_LOG("bp: hook brk failed err=%d (non-fatal)\n", ret);
            g_brk_target = NULL;
        }
    } else {
        HY_LOG("bp: brk handler not found (SW/PTE modes need it)\n");
    }

    /* 挂页错误入口，驱动 PTE 影子页方案 */
    {
        void *fault = (void *)(hy_f_do_page_fault ? (unsigned long)hy_f_do_page_fault
                                                  : (unsigned long)hy_f_do_mem_abort);
        if (fault) {
            int ret = hook_wrap4(fault, hy_fault_before, NULL, NULL);
            if (ret == 0) {
                g_fault_target = fault;
                HY_LOG("bp: hooked fault entry @ %px\n", fault);
            } else {
                HY_LOG("bp: hook fault entry failed err=%d (PTE mode degraded)\n", ret);
            }
        }
    }

    HY_LOG("bp: init done caps=0x%x\n", hy_bp_caps());
    return 0;
}

/*
 * 【卸载顺序至关重要】
 *   1) 先卸所有 hook —— 阻断新的命中
 *   2) 清硬件断点寄存器 —— 否则 dbgbcr 还 enable，指向已释放地址
 *   3) 再逐条 uninstall —— 恢复 PTE 与原指令
 *   4) 最后重置全部全局状态 —— 保证能再次加载
 *
 *   顺序颠倒（比如先卸断点再卸 hook）会在窗口期内产生命中，
 *   跳进正在被拆除的模块代码。
 */
void hy_bp_exit(void)
{
    struct hy_breakpoint *bp, *tmp;

    HY_LOG("bp: exit begin\n");

    /*
     * 【关键顺序】先把 hy_ready 置 false，再 unhook。
     * 这样在 unhook 完成前若还有回调在飞，它们会立刻返回，
     * 不会访问即将被释放的模块内存。
     */
    hy_ready = false;

    /* 1) 卸载所有 hook */
    if (g_brk_target) {
        hook_unwrap(g_brk_target, hy_brk_before, NULL);
        HY_LOG("bp: unwrapped brk @ %px\n", g_brk_target);
        g_brk_target = NULL;
    }
    if (g_fault_target) {
        hook_unwrap(g_fault_target, hy_fault_before, NULL);
        HY_LOG("bp: unwrapped fault @ %px\n", g_fault_target);
        g_fault_target = NULL;
    }
    if (g_switch_fn) {
        hook_unwrap(g_switch_fn, NULL, hy_switch_after);
        HY_LOG("bp: unwrapped __switch_to @ %px\n", g_switch_fn);
        g_switch_fn = NULL;
        g_switch_target = NULL;
    }

    /* 2) 清硬件断点寄存器 */
    hy_hw_clear();
    HY_LOG("bp: hw regs cleared\n");

    /* 3) 逐条 uninstall（恢复 PTE / 原指令 / 释放 mm） */
    {
        int n = 0;
        /*
         * 退出流程已经清过寄存器，这里不需要每条都触发一次
         * "整体重编"（那会把刚清掉的槽位又装回去，且拖慢卸载）。
         */
        g_exiting = true;
        list_for_each_entry_safe(bp, tmp, &g_bp_list, list) {
            hy_bp_uninstall(bp->handle);
            n++;
        }
        HY_LOG("bp: uninstalled %d breakpoints\n", n);
    }

    /* 4) 重置全局状态，为再次加载做准备 */
    g_exiting = false;
    g_brps = 0;
    g_wrps = 0;
    g_next_handle = 0x1000;   /* 与 hy_bp_init 保持一致（原来 init 是 0x1000，exit 却写 1） */
    hy_pool_reset();
    INIT_LIST_HEAD(&g_bp_list);
    HY_LOG("bp: exit done\n");
}

/*
 * 重置所有池子与链表。
 * 模块卸载后内核会释放整个 .bss，但为了"再次加载"能干净启动，
 * 必须在 exit 里显式清零 —— 万一加载器复用了同一块内存。
 */
void hy_pool_reset(void)
{
    hy_memset(g_bp_pool, 0, sizeof(g_bp_pool));
    hy_memset(g_bp_used, 0, sizeof(g_bp_used));
    hy_memset(g_hit_pool, 0, sizeof(g_hit_pool));
    hy_bp_page_reset();
    g_pte_any_active = false;
    g_hw_any_active = false;
    INIT_LIST_HEAD(&g_bp_list);
    HY_LOG("bp: pools reset\n");
}

u32 hy_bp_num_brps(void) { return g_brps; }
u32 hy_bp_num_wrps(void) { return g_wrps; }

/* v1.46.0：一次性取回能力位图 + 槽位数，供 /proc/HuanyuD 的 bpstat 用 */
int hy_bp_get_caps(struct hy_bp_caps *c)
{
    if (!c) return -1;
    c->supported = hy_bp_caps();
    c->num_brps  = g_brps;
    c->num_wrps  = g_wrps;
    c->reserved  = 0;
    return 0;
}

/*
 * 【修复 v1.17.0】原来把 SW 和 PTE 都绑在 __get_free_pages 上。
 * 但**软件断点根本不需要分配页** —— 它只是把目标指令改成 BRK，
 * 只需要页表遍历 + 线性映射可用。
 *
 * 你的日志里 __get_free_pages NOT FOUND，于是
 *   caps = 0x4（只有 HW），SW 和 PTE 全被误判为不可用 ——
 *   明明能用的功能被白白禁掉了。
 *
 * 现在：
 *   SW  <- 页表遍历可用（hy_pt 初始化成功）即可
 *   PTE <- 才真的需要 __get_free_pages（影子页）
 *   HW  <- 有硬件槽位
 */
/*
 * v1.64.0：方案选择器选定的"默认断点方案"。
 *
 * 只在用户传 AUTO 时才起作用 —— 用户显式指定某个模式时，
 * 那个模式排在最前面，本变量不参与。它的价值是：当首选方案在这台
 * 机器上装不上（硬件槽位耗尽、影子页池满），后面的候选链由
 * hy_scheme 决定接谁，而不是写死的顺序。
 */
static int g_bp_prefer = HY_BP_MODE_AUTO;

int hy_bp_apply_prefer(int mode)
{
    if (mode != HY_BP_MODE_SW && mode != HY_BP_MODE_PTE &&
        mode != HY_BP_MODE_HW && mode != HY_BP_MODE_AUTO)
        return -1;
    g_bp_prefer = mode;
    return 0;
}

int hy_bp_prefer_mode(void) { return g_bp_prefer; }

u32 hy_bp_caps(void)
{
    u32 c = 0;
    if (hy_pt_ready()) c |= HY_BP_CAP_SW;
    if (hy_pt_ready() && hy_bp_shadow_available() && hy_f_find_get_task_by_vpid)
        c |= HY_BP_CAP_PTE;
    if (g_brps > 0) c |= HY_BP_CAP_HW;
    return c;
}

/* ============================ 安装 ============================ */

static int hy_bp_install_sw(struct hy_breakpoint *bp, void *mm)
{
    u64 *ptep;
    int level;
    void *kva;
    u32 *insn;

    ptep = hy_find_user_pte(mm, bp->addr, &level);
    if (!ptep || level != 1) return -1;

    kva = hy_phys_to_virt(HY_ENTRY_PHYS(*ptep));
    if (!kva) return -2;

    insn = (u32 *)((unsigned long)kva + (bp->addr & (HY_PAGE_SIZE - 1)));
    bp->orig_insn = *insn;
    *insn = HY_BRK_INSN;
    bp->insn_patched = true;
    bp->mode = HY_BP_MODE_SW;

    hy_flush_tlb_range(mm, bp->addr, bp->addr + 4);
    return 0;
}

static int hy_bp_install_pte(struct hy_breakpoint *bp, void *mm)
{
    u64 *ptep;
    int level;
    u64 pte;

    if (hy_shadow_alloc(bp) != 0) return -1;

    ptep = hy_find_user_pte(mm, bp->addr, &level);
    if (!ptep || level != 1) { hy_shadow_free(bp); return -2; }

    /* 影子页拷入原始页内容 */
    {
        void *orig_kva = hy_phys_to_virt(HY_ENTRY_PHYS(*ptep));
        if (orig_kva) hy_memcpy(bp->shadow_kva, orig_kva, HY_PAGE_SIZE);
    }

    bp->orig_pte = *ptep;
    bp->orig_phys = HY_ENTRY_PHYS(*ptep);
    bp->owner_mm = mm;

    /*
     * 原页：去掉用户可执行位（PTE_UXN），保留可读可写。
     * 命中执行 -> 触发页错误 -> 在 hy_bp_on_fault 里切到影子页。
     * 这样目标进程的**代码段字节一个都没改**，是最难被检测的方案。
     */
    pte = bp->orig_pte | HY_PTE_UXN;

    /* 影子页：把原页内容拷过去，并在断点地址写 BRK #7 */
    {
        unsigned long off = bp->addr - bp->page_addr;
        u32 *insn = (u32 *)((unsigned long)bp->shadow_kva + off);
        *insn = HY_BRK_INSN;
    }

    hy_set_user_pte(mm, bp->addr, ptep, pte);

    bp->mode = HY_BP_MODE_PTE;
    bp->state = 1;
    g_pte_any_active = true;
    hy_bp_page_add(bp->page_addr);
    hy_flush_tlb_range(mm, bp->page_addr, bp->page_addr + HY_PAGE_SIZE);
    return 0;
}

/*
 * ARM64 调试寄存器：
 *   DBGBVR<n>_EL1 —— 断点地址
 *   DBGBCR<n>_EL1 —— 控制（bit0=E enable, bit5..8=BAS, bit16..20=BT）
 * 这些寄存器是 per-CPU 且随上下文切换被内核保存/恢复，
 * 因此在 __switch_to 之后写入才能让目标进程生效。
 */
static int hy_hw_slot_of(struct hy_breakpoint *bp)
{
    struct hy_breakpoint *e;
    int slot = 0;
    list_for_each_entry(e, &g_bp_list, list) {
        if (e == bp) return slot;
        if (e->mode == HY_BP_MODE_HW && e->active) slot++;
    }
    return -1;
}

static void hy_hw_program(struct hy_breakpoint *bp)
{
    int slot = hy_hw_slot_of(bp);
    u64 bcr;

    if (slot < 0 || slot > 15 || (u32)slot >= g_brps) return;

    /*
     * BT=0x0 表示 unlinked 执行匹配（address match on execution）。
     * 这里只用执行断点，读/写断点需要 BT=0x5/0x6 和BAS 配合，
     * 为了稳妥起见暂只实现执行匹配。
     */
    bcr = 1UL;                    /* E = 1 */
    bcr |= (0xfUL << 5);          /* BAS = 0xf，匹配全部字节 */
    /*
     * BT（bit 16..19）：按断点类型选
     *   执行 X  -> 0x0
     *   读   R  -> 0x5
     *   写   W  -> 0x6
     *   读写 RW -> 0x7
     * 原来只实现了 0x0（执行），现在补齐读/写/读写观察点。
     */
    {
        u32 bt = 0x0;
        if (bp->type == 1) bt = 0x5;        /* HW_BREAKPOINT_R */
        else if (bp->type == 2) bt = 0x6;   /* HW_BREAKPOINT_W */
        else if (bp->type == 3) bt = 0x7;   /* HW_BREAKPOINT_RW */
        else bt = 0x0;                         /* HW_BREAKPOINT_X */
        bcr |= ((u64)bt << 16);
    }

    /*
     * 【修复 v1.17.0】原来 default 分支复用 slot 0 ——
     * 你的 SoC 有 6 个槽位，第 5、6 个断点会覆盖第 1 个，
     * 互相打架。现在支持到 15，超出才拒绝。
     */
    switch (slot) {
#define HY_HWCASE(n) \
    case n: asm volatile("msr dbgbvr" #n "_el1, %0" :: "r"(bp->addr)); \
            asm volatile("msr dbgbcr" #n "_el1, %0" :: "r"(bcr)); \
            break;
    HY_HWCASE(0)  HY_HWCASE(1)  HY_HWCASE(2)  HY_HWCASE(3)
    HY_HWCASE(4)  HY_HWCASE(5)  HY_HWCASE(6)  HY_HWCASE(7)
    HY_HWCASE(8)  HY_HWCASE(9)  HY_HWCASE(10) HY_HWCASE(11)
    HY_HWCASE(12) HY_HWCASE(13) HY_HWCASE(14) HY_HWCASE(15)
#undef HY_HWCASE
    default:
        return;   /* 槽位耗尽，不覆盖别人的 */
    }
    bp->hw_slot = (s8)slot;
    asm volatile("isb" ::: "memory");
}

/*
 * 清硬件断点寄存器。
 *
 * 【修复 v1.17.0】原来只清 0~3。你的 SoC 读到 brps=6，
 * 意味着槽位 4、5 是真实存在的 —— 卸载时它们没被清，
 * 调试异常仍会触发并跳进已释放的模块代码 -> 崩。
 * 现在按 g_brps 全部清（上限 16，ARMv8 架构上限）。
 */
static void hy_hw_clear(void)
{
    u64 zero = 0;
    u32 n = g_brps > 16 ? 16 : g_brps;

    if (n > 0) asm volatile("msr dbgbcr0_el1, %0" :: "r"(zero));
    if (n > 1) asm volatile("msr dbgbcr1_el1, %0" :: "r"(zero));
    if (n > 2) asm volatile("msr dbgbcr2_el1, %0" :: "r"(zero));
    if (n > 3) asm volatile("msr dbgbcr3_el1, %0" :: "r"(zero));
    if (n > 4) asm volatile("msr dbgbcr4_el1, %0" :: "r"(zero));
    if (n > 5) asm volatile("msr dbgbcr5_el1, %0" :: "r"(zero));
    if (n > 6) asm volatile("msr dbgbcr6_el1, %0" :: "r"(zero));
    if (n > 7) asm volatile("msr dbgbcr7_el1, %0" :: "r"(zero));
    if (n > 8) asm volatile("msr dbgbcr8_el1, %0" :: "r"(zero));
    if (n > 9) asm volatile("msr dbgbcr9_el1, %0" :: "r"(zero));
    if (n > 10) asm volatile("msr dbgbcr10_el1, %0" :: "r"(zero));
    if (n > 11) asm volatile("msr dbgbcr11_el1, %0" :: "r"(zero));
    if (n > 12) asm volatile("msr dbgbcr12_el1, %0" :: "r"(zero));
    if (n > 13) asm volatile("msr dbgbcr13_el1, %0" :: "r"(zero));
    if (n > 14) asm volatile("msr dbgbcr14_el1, %0" :: "r"(zero));
    if (n > 15) asm volatile("msr dbgbcr15_el1, %0" :: "r"(zero));
    asm volatile("isb" ::: "memory");
    g_hw_any_active = false;
}

/*
 * 关掉单个槽位（uninstall 一条 HW 断点时用）。
 * 【修复 v1.17.0】原来 uninstall 完全不清寄存器 ——
 * 卸掉断点后 dbgbcr 仍 enable，目标进程一执行到那个地址
 * 就触发调试异常跳进已释放的模块代码。运行时必崩。
 */
static void hy_hw_disable_slot(int slot)
{
    u64 zero = 0;
    switch (slot) {
    case 0:  asm volatile("msr dbgbcr0_el1, %0" :: "r"(zero)); break;
    case 1:  asm volatile("msr dbgbcr1_el1, %0" :: "r"(zero)); break;
    case 2:  asm volatile("msr dbgbcr2_el1, %0" :: "r"(zero)); break;
    case 3:  asm volatile("msr dbgbcr3_el1, %0" :: "r"(zero)); break;
    case 4:  asm volatile("msr dbgbcr4_el1, %0" :: "r"(zero)); break;
    case 5:  asm volatile("msr dbgbcr5_el1, %0" :: "r"(zero)); break;
    case 6:  asm volatile("msr dbgbcr6_el1, %0" :: "r"(zero)); break;
    case 7:  asm volatile("msr dbgbcr7_el1, %0" :: "r"(zero)); break;
    case 8:  asm volatile("msr dbgbcr8_el1, %0" :: "r"(zero)); break;
    case 9:  asm volatile("msr dbgbcr9_el1, %0" :: "r"(zero)); break;
    case 10: asm volatile("msr dbgbcr10_el1, %0" :: "r"(zero)); break;
    case 11: asm volatile("msr dbgbcr11_el1, %0" :: "r"(zero)); break;
    case 12: asm volatile("msr dbgbcr12_el1, %0" :: "r"(zero)); break;
    case 13: asm volatile("msr dbgbcr13_el1, %0" :: "r"(zero)); break;
    case 14: asm volatile("msr dbgbcr14_el1, %0" :: "r"(zero)); break;
    case 15: asm volatile("msr dbgbcr15_el1, %0" :: "r"(zero)); break;
    default: break;
    }
    asm volatile("isb" ::: "memory");
}

/*
 * 把所有活跃硬件断点整体重编一遍。
 *
 * 【修复 v1.19.0】槽位是按"链表里排在我前面有几个 HW 断点"算出来的，
 * 因此 uninstall 掉中间一条之后，后面所有断点的槽位索引都会前移，
 * 但寄存器里还留着旧槽位的值 ——
 * 结果要么两个断点抢同一个物理槽位（后者覆盖前者，前者静默失效），
 * 要么某个槽位仍 enable 而指向已 uninstall 的地址。
 * 所以每次卸掉 HW 断点后必须整体重算。
 */
static void hy_hw_reprogram_all(void)
{
    struct hy_breakpoint *bp;

    hy_hw_clear();          /* 先全部关掉，避免残留 */

    list_for_each_entry(bp, &g_bp_list, list) {
        if (bp->mode == HY_BP_MODE_HW && bp->active && !bp->suspended) {
            bp->hw_slot = -1;
            hy_hw_program(bp);
        }
    }
}

/* 上下文切换后重编硬件断点 */


/*
 * 当前进程的 pid。
 * 用 hy_discover 自发现过的 pid 偏移读 task_struct->pid，
 * 不依赖 task_struct 头文件。拿不到返回 -1。
 */
static int hy_cur_pid(void)
{
    unsigned long sp_el0;
    void *cur = NULL;
    int off;

    if (!sp_el0_is_current) return -1;
    asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));
    if (!sp_el0) return -1;
    cur = (void *)sp_el0;

    off = hy_pid_offset();
    if (off < 0) return -1;

    {
        int v = *(int *)((unsigned long)cur + (unsigned long)off);
        if (v > 0 && v < 0x80000) return v;
    }
    return -1;
}

static void hy_switch_after(hook_fargs4_t *args, void *udata)
{
    struct hy_breakpoint *bp;
    int pid;

    (void)args; (void)udata;
    /* 卸载守卫 */
    if (!hy_ready) return;

    /*
     * 【快速过滤】没有任何活跃硬件断点就直接返回。
     * __switch_to 是极热路径（每次进程切换都走），
     * 这里多一次判断能省掉后面的链表遍历。
     */
    if (!g_hw_any_active) return;

    pid = hy_cur_pid();
    if (pid < 0) return;

    list_for_each_entry(bp, &g_bp_list, list) {
        if (bp->mode == HY_BP_MODE_HW && bp->active && !bp->suspended &&
            bp->pid == pid) {
            hy_hw_program(bp);
        }
    }
}

static int hy_bp_install_hw(struct hy_breakpoint *bp, void *mm)
{
    (void)mm;
    if (g_brps == 0) return -1;

    /*
     * 【修复 v1.19.0】__switch_to hook 失败必须当成 HW 方案失败。
     * 调试寄存器是 per-CPU 的，切到目标进程时必须重新编程；
     * 没有这个 hook，hy_hw_program 只会写到**当前** CPU 上，
     * 目标进程一旦被调度到别的 CPU，断点就静默失效 ——
     * 用户拿到 handle 却永远命中不了，比直接报错更难排查。
     */
    if (!g_switch_target) {
        void *sw = (void *)hy_lookup_generic("__switch_to");
        if (!sw) return -2;
        {
            int ret = hook_wrap4(sw, NULL, hy_switch_after, NULL);
            if (ret != 0) {
                HY_LOG("bp: hook __switch_to failed err=%d\n", ret);
                return -3;
            }
            g_switch_fn = sw;
            g_switch_target = (void *)1;  /* 仅作为"已挂 hook"的标记 */
            HY_LOG("bp: hooked __switch_to @ %px\n", sw);
        }
    }

    bp->mode = HY_BP_MODE_HW;
    bp->owner_mm = mm;

    hy_hw_program(bp);

    /*
     * 【修复 v1.19.0】原来无论槽位是否真的拿到都返回 0。
     * 槽位耗尽时 hy_hw_program 会直接 return，hw_slot 保持 -1，
     * 于是"安装成功但断点不生效"—— 用户完全无从察觉。
     * 现在以 hw_slot 是否真的分配到为准，失败就让候选链降级到 PTE/SW。
     */
    if (bp->hw_slot < 0) {
        HY_LOG("bp: HW slots exhausted (brps=%u)\n", g_brps);
        return -4;
    }

    HY_LOG("bp: HW installed handle=%llx addr=%llx slot=%d\n",
           bp->handle, bp->addr, bp->hw_slot);
    return 0;
}

/*
 * v1.63.0 断点隐蔽性默认开关。
 * 默认开：SW 断点自动改用 PTE 影子页（不改代码字节，内存扫描不可见）。
 * 调用方可通过 flags 覆盖：
 *   HY_BP_FLAG_STEALTH   显式开启
 *   HY_BP_FLAG_NOSTEALTH 显式关闭（优先级最高）
 */
static int  g_bp_stealth_default = 1;
static int  bp_stealth_upgraded;   /* 本次安装是否发生了 SW->PTE 升级 */

int hy_bp_stealth_enabled(u32 flags)
{
    if (flags & HY_BP_FLAG_NOSTEALTH) return 0;
    if (flags & HY_BP_FLAG_STEALTH)   return 1;
    return g_bp_stealth_default;
}

void hy_bp_set_stealth_default(int on)
{
    g_bp_stealth_default = on ? 1 : 0;
}

int hy_bp_stealth_default(void) { return g_bp_stealth_default; }

u64 hy_bp_install(const struct hy_bp_inst_args *args)
{
    struct hy_breakpoint *bp;
    void *task, *mm = NULL;
    u32 mode = args->mode;
    u32 mode_chain = 0;    /* 高 8 位=候选数，其后依次是每个候选 */
    int ret;

    if (!args) return 0;

    /*
     * 方案选择优先级：
     *   1) 用户本次调用显式指定（非 AUTO）—— 最高
     *   2) 运行时默认（用户态通过命令设置过）
     *   3) 编译期默认 HY_DEFAULT_BP_MODE（由 HY_DEFAULT_BP_SCHEME 推出）
     *   4) 内置回退链：硬件 -> PTE -> 软件
     *
     * 内置链顺序说明：
     *   硬件 —— 不改内存、最快、最隐蔽，但槽位有限（本例 brps=6）
     *   PTE  —— 影子页，不改代码字节，隐蔽性好，页粒度
     *   软件 —— 替换指令为 BRK，最兼容，但会改代码段、可被校验发现
     *
     * 若默认方案当前不可用（例如硬件槽位耗尽），会自动沿链降级，
     * 不会因为选了不可用方案就安装失败。
     */
    /*
     * 【重构 v1.19.0】候选链 + 实际安装重试。
     *
     * 原实现的问题：
     *   1) 只是在"选模式"时做一次静态可用性判断，
     *      判断通过但实际安装失败（例如硬件槽位已占满、
     *      __switch_to hook 失败、影子页分配不到）就直接返回失败，
     *      **不会去试下一个方案** —— 用户拿到的是安装失败，
     *      而明明 PTE 或 SW 是可用的。
     *   2) 硬件槽位耗尽时 hy_bp_install_hw 照样返回成功，
     *      断点实际没生效，用户却拿到了 handle，以为装好了。
     *
     * 现在：先按优先级排出候选链，然后**逐个真实安装**，
     * 第一个成功的即为最终方案（记在 bp->mode，用户可从命中项读回）。
     *
     * 优先级：用户本次显式指定 > 运行时默认 > 编译期默认 > 硬件 > PTE > 软件
     */
    {
        static const u32 order[3] = { HY_BP_MODE_HW, HY_BP_MODE_PTE,
                                      HY_BP_MODE_SW };
        u32 chain[4];
        int nchain = 0;
        int i, j;

        /*
         * 【v1.63.0 隐蔽升级：SW -> PTE 影子页】
         *   SW 断点要把目标指令替换成 BRK，等于**改了代码段字节**，
         *   对 text 做 CRC / 哈希的自检一扫一个准。
         *   PTE 影子页一个代码字节都不改（动的是页表），内存扫描看不见。
         *
         *   所以这里把 SW 的**落地方式**换成 PTE，而不是改掉用户选的方案：
         *   用户要的仍是"在这个地址下断"，只是用更难被发现的方式实现。
         *
         *   三个前提，缺一就不动（保持 SW，绝不静默变成别的语义）：
         *     1) 非 STRICT —— 用户显式要求严格单方案时，尊重用户
         *     2) 平台支持 PTE（caps），否则装不上
         *     3) 没被用户用 HY_BP_FLAG_NOSTEALTH 明确关掉
         *   影子页池若满了导致 PTE 装不上，后面的候选链会自动退回 SW，
         *   功能不受影响，只是这一颗退化为普通 SW。
         */
        if (mode == HY_BP_MODE_SW &&
            !(args->flags & HY_BP_FLAG_STRICT) &&
            hy_bp_stealth_enabled(args->flags) &&
            (hy_bp_caps() & HY_BP_CAP_PTE)) {
            mode = HY_BP_MODE_PTE;
            bp_stealth_upgraded = 1;
            /* 刻意不打印：日志策略保持原样，不新增任何输出 */
        }

        /*
         * 【单方案严格模式】
         * 用户置了 HY_BP_FLAG_STRICT 且明确给了方案：
         * 候选链只放这一个，不追加默认也不追加回退链。
         * 该方案不可用就直接失败，不静默降级成别的方案。
         */
        if ((args->flags & HY_BP_FLAG_STRICT) && mode != HY_BP_MODE_AUTO) {
            chain[nchain++] = mode;
            mode_chain = chain[0];
            mode_chain |= ((u32)nchain << 24);
            goto chain_done;
        }

        if (mode != HY_BP_MODE_AUTO)
            chain[nchain++] = mode;             /* 用户显式指定最优先 */

        {
            u32 d = hy_default_mode;            /* 运行时默认 */
            if (d == HY_BP_MODE_AUTO)
                d = (u32)g_bp_prefer;           /* 方案选择器选中的默认档 */
            if (d == HY_BP_MODE_AUTO)
                d = (u32)HY_DEFAULT_BP_MODE;    /* 编译期默认 */
            if (d != HY_BP_MODE_AUTO)
                chain[nchain++] = d;
        }

        /* 补齐 硬件 -> PTE -> 软件，去重 */
        for (i = 0; i < 3 && nchain < 4; i++) {
            int dup = 0;
            for (j = 0; j < nchain; j++)
                if (chain[j] == order[i]) { dup = 1; break; }
            if (!dup) chain[nchain++] = order[i];
        }

        mode_chain = chain[0];
        for (i = 1; i < nchain; i++)
            mode_chain = (mode_chain << 8) | (chain[i] & 0xff);
        mode_chain |= ((u32)nchain << 24);
chain_done: ;
    }

    bp = (struct hy_breakpoint *)hy_obj_alloc();
    if (!bp) { HY_LOG("bp: pool exhausted\n"); return 0; }

    bp->handle = g_next_handle++;
    bp->pid = args->pid;
    bp->addr = args->addr;
    bp->page_addr = args->addr & HY_PAGE_MASK;
    bp->len = args->bp_len;
    bp->type = args->bp_type;
    bp->flags = args->flags;
    bp->reg_mask = args->reg_modify_mask;
    bp->fp_mask = args->fp_reg_modify_mask;
    /*
     * 【修复 v1.17.0】安装时也要把用户传的寄存器值取进来。
     * 原来只存了 mask，regs_to_set 全 0 —— 命中后会把寄存器写成 0。
     */
    if ((args->reg_modify_mask || args->fp_reg_modify_mask) &&
        args->regs_to_set_ptr) {
        void __user *src = (void __user *)(unsigned long)args->regs_to_set_ptr;
        if (hy_f_copy_from_user) {
            if (hy_f_copy_from_user(&bp->regs_to_set, src,
                                    sizeof(bp->regs_to_set)) != 0) {
                bp->reg_mask = 0;
                bp->fp_mask = 0;
            }
        } else if (hy_uaddr_ok((unsigned long)src, sizeof(bp->regs_to_set))) {
            hy_memcpy(&bp->regs_to_set, src, sizeof(bp->regs_to_set));
        }
    }
    bp->active = true;
    bp->hit_count = 0;
    bp->hw_slot = -1;

    task = hy_f_find_get_task_by_vpid ? hy_f_find_get_task_by_vpid(args->pid) : NULL;
    if (task && hy_f_get_task_mm) mm = hy_f_get_task_mm(task);

    /*
     * 【修复 v1.19.0】必须先入链再安装。
     * 硬件断点的槽位由 hy_hw_slot_of() 遍历链表数出来，
     * 而 bp 不在链表里时该函数返回 -1（找不到自己），
     * 于是 hy_hw_program() 直接 return，hw_slot 永远是 -1 ——
     * **硬件断点从来没有真正生效过**。
     */
    hy_lock();
    list_add_tail(&bp->list, &g_bp_list);
    hy_unlock();

    /*
     * 目标进程必须存在：SW/PTE 需要 mm 去遍历页表，
     * 传 NULL 进去会在 hy_find_user_pte 里解引用空指针。
     */
    if (!mm) {
        hy_lock();
        list_del(&bp->list);
        hy_unlock();
        HY_LOG("bp: install failed, pid %d has no mm\n", args->pid);
        if (task && hy_f_put_task_struct) hy_f_put_task_struct(task);
        hy_obj_free(bp);
        return 0;
    }

    /* 逐个候选真实安装，第一个成功即用之 */
    {
        int nchain = (int)((mode_chain >> 24) & 0xf);
        int i;

        ret = -9;
        for (i = 0; i < nchain; i++) {
            u32 cand = (mode_chain >> (8 * (nchain - 1 - i))) & 0xff;

            /* 上一次尝试可能已经改过内存/PTE/影子页，先彻底回滚 */
            hy_bp_rollback(bp, mm);

            switch (cand) {
            case HY_BP_MODE_SW:  ret = hy_bp_install_sw(bp, mm);  break;
            case HY_BP_MODE_PTE: ret = hy_bp_install_pte(bp, mm); break;
            case HY_BP_MODE_HW:  ret = hy_bp_install_hw(bp, mm);  break;
            default:             ret = -9; break;
            }

            if (ret == 0) {
                if (cand != ((mode_chain >> (8 * (nchain - 1))) & 0xff))
                    HY_LOG("bp: fell back to scheme %u\n", cand);
                break;
            }
        }
    }

    /*
     * 【重要】mm 的所有权转移给 bp：
     *   安装成功 -> 不 mmput，由 uninstall 负责释放。
     *   安装失败 -> 立刻 mmput。
     * 原因：bp->owner_mm 会被页错误回调用来查找断点，
     *       若这里就 mmput，进程退出后 owner_mm 变悬垂指针 -> 崩溃。
     */
    if (ret != 0) {
        hy_bp_rollback(bp, mm);
        hy_lock();
        list_del(&bp->list);
        hy_bp_flags_refresh();
        hy_unlock();
        if (mm && hy_f_mmput) hy_f_mmput(mm);
        HY_LOG("bp: install failed ret=%d (all schemes tried)\n", ret);
        hy_obj_free(bp);
        if (task && hy_f_put_task_struct) hy_f_put_task_struct(task);
        return 0;
    }

    hy_lock();
    hy_bp_flags_refresh();
    hy_unlock();

    /*
     * 【修复 v1.17.0】原来成功路径漏了 put_task_struct。
     * find_get_task_by_vpid 会 +1 引用，不释放的话
     * 该进程的 task_struct 永远无法回收 —— 进程"僵尸化"，
     * 下几个断点后系统资源就被吃光。失败路径有释放，成功路径没有。
     */
    if (task && hy_f_put_task_struct) hy_f_put_task_struct(task);

    HY_LOG("bp: installed handle=%llx addr=%llx mode=%u\n",
           bp->handle, bp->addr, bp->mode);
    return bp->handle;
}

static struct hy_breakpoint *hy_bp_find(u64 handle)
{
    struct hy_breakpoint *bp;
    list_for_each_entry(bp, &g_bp_list, list) {
        if (bp->handle == handle) return bp;
    }
    return NULL;
}

struct hy_breakpoint *hy_bp_find_by_addr(void *mm, unsigned long addr)
{
    struct hy_breakpoint *bp;
    list_for_each_entry(bp, &g_bp_list, list) {
        if (bp->active && !bp->suspended && bp->owner_mm == mm &&
            bp->page_addr == (addr & HY_PAGE_MASK))
            return bp;
    }
    return NULL;
}

int hy_bp_uninstall(u64 handle)
{
    struct hy_breakpoint *bp = hy_bp_find(handle);
    void *mm;
    int was_hw;
    if (!bp) return -1;

    mm = bp->owner_mm;
    was_hw = (bp->mode == HY_BP_MODE_HW);

    if (bp->insn_patched && mm) {
        u64 *ptep = hy_find_user_pte(mm, bp->addr, &(int){0});
        if (ptep) {
            void *kva = hy_phys_to_virt(HY_ENTRY_PHYS(*ptep));
            if (kva) {
                u32 *insn = (u32 *)((unsigned long)kva + (bp->addr & (HY_PAGE_SIZE - 1)));
                *insn = bp->orig_insn;
                hy_flush_tlb_range(mm, bp->addr, bp->addr + 4);
            }
        }
    }

    /*
     * 【修复 v1.21.0】hy_tramp_release_by_handle() 全文零调用点。
     * 断点占用了蹦床槽位却从不归还，装够 HY_TRAMP_SLOTS(32) 条之后
     * 后续断点永远拿不到槽位。卸载时必须按 handle 归还。
     */
    hy_tramp_release_by_handle(bp->handle);

    if (bp->mode == HY_BP_MODE_PTE) {
        hy_bp_page_del(bp->page_addr);
        if (mm && bp->orig_pte) {
            u64 *ptep = hy_find_user_pte(mm, bp->addr, &(int){0});
            if (ptep) {
                hy_set_user_pte(mm, bp->addr, ptep, bp->orig_pte);
                hy_flush_tlb_range(mm, bp->page_addr, bp->page_addr + HY_PAGE_SIZE);
            }
        }
        hy_shadow_free(bp);
    }

    /*
     * 【修复 v1.17.0】HW 断点必须在这里关掉它占用的槽位。
     * 原来只有 hy_bp_exit 会清，运行中单独 uninstall 一条时不关，
     * 于是 dbgbcr 仍 enable 指向已释放地址，
     * 目标进程一执行到就触发调试异常 -> 跳进无效代码 -> 崩。
     */
    if (bp->mode == HY_BP_MODE_HW && bp->hw_slot >= 0) {
        hy_hw_disable_slot(bp->hw_slot);
        bp->hw_slot = -1;
    }

    /*
     * 【修复 v1.19.0】若在单步途中被卸载，目标进程的单步标志还留着，
     * 之后它每执行一条指令都会触发一次调试异常 ——
     * 表现是进程突然变得极慢，几乎卡死，而且极难定位。
     * 卸载时必须显式关掉。
     */
    if (bp->stepping) {
        void *t = hy_f_find_get_task_by_vpid ? hy_f_find_get_task_by_vpid(bp->pid)
                                             : NULL;
        if (t) {
            if (hy_f_user_disable_single_step) hy_f_user_disable_single_step(t);
            if (hy_f_put_task_struct) hy_f_put_task_struct(t);
        }
    }

    /* 释放 install 时转移过来的 mm 引用 */
    if (mm && hy_f_mmput) hy_f_mmput(mm);
    bp->owner_mm = NULL;

    bp->stepping = 0;
    bp->active = false;

    hy_lock();
    list_del(&bp->list);
    hy_unlock();

    /* 槽位索引整体前移，必须重编（见 hy_hw_reprogram_all 的说明） */
    if (was_hw && !g_exiting)
        hy_hw_reprogram_all();

    hy_lock();
    hy_bp_flags_refresh();
    hy_unlock();

    hy_obj_free(bp);
    return 0;
}

int hy_bp_suspend(u64 handle)
{
    struct hy_breakpoint *bp = hy_bp_find(handle);
    if (!bp) return -1;
    bp->suspended = true;
    return 0;
}

int hy_bp_resume(u64 handle)
{
    struct hy_breakpoint *bp = hy_bp_find(handle);
    if (!bp) return -1;
    bp->suspended = false;
    return 0;
}

/*
 * 【修复 v1.17.0】原来这里只是把 regs_to_set 清零，
 * 却**从来没有读取** args->regs_to_set_ptr 指向的用户态数据。
 * 结果：mask 被设了，但要写入的值全是 0 ——
 * 用户调 bp_set_reg(0, 123) 实际会把 x0 写成 0。
 * 整个"命中改寄存器"功能完全失效。
 *
 * 现在：先从用户态拷入，拷不到就报错（而不是静默写 0）。
 */
int hy_bp_modify(const struct hy_bp_modify_args *args)
{
    struct hy_breakpoint *bp;
    void __user *src;

    if (!args) return -EINVAL;

    bp = hy_bp_find(args->handle);
    if (!bp) return -ENOENT;

    bp->reg_mask = args->reg_modify_mask;
    bp->fp_mask  = args->fp_reg_modify_mask;
    hy_memset(&bp->regs_to_set, 0, sizeof(bp->regs_to_set));

    /* 没有要改的东西就到此为止 */
    if (args->reg_modify_mask == 0 && args->fp_reg_modify_mask == 0)
        return 0;

    src = (void __user *)(unsigned long)args->regs_to_set_ptr;
    if (!src) return -EINVAL;

    if (!hy_f_copy_from_user) {
        /*
         * 没有 copy_from_user 时退回直接读（ARM64 内核/用户共享页表，
         * 且这是用户刚写入的指针，页必然 resident）。
         */
        if (!hy_uaddr_ok((unsigned long)src, sizeof(bp->regs_to_set)))
            return -EFAULT;
        hy_memcpy(&bp->regs_to_set, src, sizeof(bp->regs_to_set));
    } else {
        if (hy_f_copy_from_user(&bp->regs_to_set, src,
                                sizeof(bp->regs_to_set)) != 0)
            return -EFAULT;
    }

    HY_LOG("bp: modify handle=%llx reg_mask=%llx fp_mask=%llx\n",
           args->handle, (unsigned long long)args->reg_modify_mask,
           (unsigned long long)args->fp_reg_modify_mask);
    return 0;
}

/* ============================ 页错误：PTE 方案命中 ============================ */

static void hy_fault_before(hook_fargs4_t *args, void *udata)
{
    unsigned long addr;

    /* 卸载守卫：见 hy_brk_before 的说明 */
    if (!hy_ready) return;

    void *mm = NULL;
    struct hy_breakpoint *bp;
    unsigned long sp_el0;
    void *task = NULL;

    (void)udata;

    /* 第 1 个参数是 addr，第 3 个是 regs */
    addr = (unsigned long)args->arg0;

    /*
     * 【性能修复 v1.17.0】原来**每一次**用户态缺页都要做
     *   get_task_mm() + 遍历全部断点链表 + mmput()
     * 缺页是极高频事件（任何进程访问新页都会触发），
     * 这条路径会把整个系统拖慢。
     *
     * 现在加两级快速过滤：
     *   1) 没有任何 PTE 断点 —— 直接返回（绝大多数情况下就在这里退出）
     *   2) 全局页基址位图：此地址所在页不在任何一个断点页内 —— 直接返回
     */
    if (!g_pte_any_active) return;
    if (!hy_bp_page_may_hit(addr)) return;

    asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));
    if (sp_el0_is_current) task = (void *)sp_el0;
    if (!task) return;

    if (hy_f_get_task_mm) mm = hy_f_get_task_mm(task);
    if (!mm) return;

    bp = hy_bp_find_by_addr(mm, addr);
    if (!bp || bp->mode != HY_BP_MODE_PTE) goto out;

    /*
     * 【修复 v1.19.0】这里**不再记账**。
     *
     * 原实现在权限缺页时就记账，但 PTE 方案的语义是：
     *   执行原页 -> 权限缺页(这里) -> 切到影子页 -> 执行到断点地址的 BRK
     *   -> 才在 hy_brk_before 里记账。
     * 在缺页处记账会导致：页内**任意**一条指令首次执行都记一次命中，
     * 命中数暴涨（一条热点路径能记几百次），且拿到的寄存器是缺页时刻的，
     * 并不是断点地址处的现场 —— 数据完全不对。
     *
     * 现在这里只负责"放行到影子页"这一件事。
     */
    {
        u64 *ptep = hy_find_user_pte(mm, bp->page_addr, &(int){0});
        if (ptep) {
            /*
             * 【修复 v1.21.0】原来这里手写地址替换，写错了：
             *     (orig_pte & ~HY_ENTRY_PHYS(orig_pte)) | (shadow_phys & ...)
             * HY_ENTRY_PHYS() 返回的是【已屏蔽的物理地址值】，不是掩码，
             * 对它取反得到一个错误掩码 —— 结果原物理位与影子物理位被
             * OR 在一起，切过去的是个拼接出来的野地址。
             *
             * hy_pte_replace_phys() 本来就是干这个的（用 HY_PTE_ADDR_MASK
             * 正确屏蔽），但它全文零调用点，所以没人发现这里写错了。
             * 现在改用统一封装。
             */
            u64 shadow_pte = hy_pte_replace_phys(bp->orig_pte, bp->shadow_phys);
            shadow_pte = hy_pte_set_exec(shadow_pte);
            hy_set_user_pte(mm, bp->page_addr, ptep, shadow_pte);
            hy_flush_tlb_range(mm, bp->page_addr, bp->page_addr + HY_PAGE_SIZE);
            bp->state = 2;
            /*
             * 必须阻止内核继续处理：内核已经把这个缺页判定为权限错误，
             * 不拦住就会投递 SIGSEGV 杀掉目标进程。
             * 拦住之后返回用户态重新取指，这次 PTE 已是影子页（可执行）。
             */
            args->skip_origin = 1;
        }
    }

out:
    if (mm && hy_f_mmput) hy_f_mmput(mm);
}

/* ============================ 命中 ============================ */

void hy_bp_apply_regs(struct hy_breakpoint *bp, void *regs)
{
    u64 *r = (u64 *)regs;
    int i;
    if (!bp || !regs) return;

    /* pt_regs 布局：x0..x30 连续，然后 sp, pc, pstate */
    for (i = 0; i < 31; i++) {
        if (bp->reg_mask & (1ULL << i))
            r[i] = bp->regs_to_set.regs[i];
    }
    if (bp->reg_mask & HY_REG_MODIFY_SP)
        r[31] = bp->regs_to_set.sp;
    if (bp->reg_mask & HY_REG_MODIFY_PC)
        r[32] = bp->regs_to_set.pc;
    if (bp->reg_mask & HY_REG_MODIFY_PSTATE)
        r[33] = bp->regs_to_set.pstate;
}

void hy_bp_record_hit(struct hy_breakpoint *bp, void *task, void *regs)
{
    struct hy_hit_record *rec;
    u64 *r = (u64 *)regs;
    u32 idx;

    if (!bp) return;
    bp->hit_count++;
    /*
     * 【修复 v1.17.0】g_hit_count_total 从来没被加过，
     * 于是 hy_bp_hit_total() 永远返回 0，
     * /proc/huanyu 里的 "bp hit total" 也永远是 0。
     */
    g_hit_count_total++;

    hy_lock();
    idx = g_hit_head;
    g_hit_head = (g_hit_head + 1) % HY_POOL_HIT;
    hy_unlock();

    rec = &g_hit_pool[idx];
    rec->handle = bp->handle;
    rec->item.task_id = (u64)(unsigned long)task;
    rec->item.hit_addr = bp->addr;
    rec->item.hit_time = hy_now_sec();   /* v1.19.0: 原来是恒 0 */
    rec->item.resolved_mode = bp->mode;
    rec->item.reserved = 0;

    if (r) {
        hy_memcpy(&rec->item.regs_info.regs[0], r, 31 * sizeof(u64));
        rec->item.regs_info.sp = r[31];
        rec->item.regs_info.pc = r[32];
        rec->item.regs_info.pstate = r[33];
    }
}

int hy_bp_get_hit_count(struct hy_bp_get_hit_count_arg *arg)
{
    struct hy_breakpoint *bp = hy_bp_find(arg->handle);
    u32 i, n = 0;
    if (!bp) return -1;

    for (i = 0; i < HY_POOL_HIT; i++) {
        if (g_hit_pool[i].handle == arg->handle) n++;
    }
    arg->hit_total_count = bp->hit_count;
    arg->hit_item_arr_count = n;
    return 0;
}

int hy_bp_get_hit_items(struct hy_bp_get_hit_items_args *args)
{
    u32 i, copied = 0;
    u64 max = args->max_bytes / sizeof(struct hy_bp_hit_item);

    if (!hy_f_copy_to_user) return -ENODEV;

    for (i = 0; i < HY_POOL_HIT && copied < max; i++) {
        void __user *dst;
        if (g_hit_pool[i].handle != args->handle) continue;
        dst = (void __user *)(unsigned long)(args->user_buffer_ptr +
                                             copied * sizeof(struct hy_bp_hit_item));
        if (hy_f_copy_to_user(dst, &g_hit_pool[i].item, sizeof(struct hy_bp_hit_item)) != 0)
            break;
        copied++;
    }
    args->items_copied = copied;
    return 0;
}

/* 供 hy_extra.c 的 STATS 使用 */
u64 hy_bp_hit_total(void) { return g_hit_count_total; }
u32 hy_bp_active_count(void)
{
    struct hy_breakpoint *bp;
    u32 n = 0;
    list_for_each_entry(bp, &g_bp_list, list) {
        if (bp->active) n++;
    }
    return n;
}

/* ============================ 列表与清空（供 hy_extra） ============================ */

int hy_bp_list(struct hy_bp_list_req *req)
{
    struct hy_breakpoint *bp;
    struct hy_bp_item it;
    u32 n = 0;
    u32 max;
    u32 i;

    if (!req || !req->buf_ptr || req->max_count == 0) return -EINVAL;
    if (!hy_f_copy_to_user) return -ENODEV;

    max = req->max_count > 128 ? 128 : req->max_count;

    /*
     * 【修复 v1.17.0】原来在链表遍历**中间**反复解锁去 copy_to_user。
     * 解锁期间另一个 CPU 可能 uninstall 掉当前节点的下一个节点，
     * list_for_each_entry 持有的 next 指针就悬空了 -> 崩溃。
     *
     * 现在：先在锁内把快照拷到栈上数组，解锁后再统一 copy_to_user。
     */
    {
        struct hy_bp_item snap[128];

        hy_lock();
        list_for_each_entry(bp, &g_bp_list, list) {
            if (n >= max) break;
            hy_memset(&snap[n], 0, sizeof(snap[n]));
            snap[n].handle = bp->handle;
            snap[n].pid = bp->pid;
            snap[n].mode = bp->mode;
            snap[n].addr = bp->addr;
            snap[n].hit_count = bp->hit_count;
            snap[n].active = bp->active ? 1 : 0;
            snap[n].suspended = bp->suspended ? 1 : 0;
            n++;
        }
        hy_unlock();

        for (i = 0; i < n; i++) {
            if (hy_f_copy_to_user(
                    (void __user *)(unsigned long)(req->buf_ptr + i * sizeof(it)),
                    &snap[i], sizeof(it)) != 0)
                return (int)i;
        }
        return (int)n;
    }
}

int hy_bp_clear_hits(u64 handle)
{
    int i;
    int n = 0;

    hy_lock();
    for (i = 0; i < HY_POOL_HIT; i++) {
        if (handle == 0 || g_hit_pool[i].handle == handle) {
            if (g_hit_pool[i].handle != 0) {
                g_hit_pool[i].handle = 0;
                n++;
            }
        }
    }
    if (handle == 0) g_hit_count_total = 0;
    hy_unlock();
    return n;
}
