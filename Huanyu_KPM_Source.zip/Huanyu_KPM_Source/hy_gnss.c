/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_gnss.c —— 虚拟定位（Binder Parcel 层坐标改写）
 *
 * 【移植来源】lsdriver 的 virtual_gnss.h（338 行）
 *
 * ls 原版做法（这里**原样照搬**核心逻辑）：
 *   1) hook ioctl 系统调用
 *   2) 拦截 BINDER_WRITE_READ
 *   3) 遍历 write buffer 里的 BC_TRANSACTION / BC_REPLY
 *   4) 在 Parcel 里找 "android.location.ILocation" token（UTF-16LE）
 *   5) 按 Location.writeToParcel() 的布局定位 latitude/longitude 两个 double
 *   6) 用整数算法把 e7 定点数转成 IEEE754 double bits，写回用户空间
 *
 * 为什么在 Binder Parcel 层做而不是拦 GNSS 硬件节点：
 *   不依赖进程名、不依赖具体 HAL，只按接口 token 和数据布局做特征识别，
 *   通用性最好。ls 源码里这段注释写得很清楚，这里沿用。
 *
 * 【与 ls 的差异（受 KPM 限制）】
 *   - ls 用 inline hook 挂 __arm64_sys_ioctl；
 *     KPM 用 hook_syscalln(29)。效果一样：在 before 里改掉用户态 buffer，
 *     然后真实的 ioctl 照常执行，读到的就是改过的数据。
 *     这样**不需要 skip_origin**，也就不受 v1.16.0 那个 allow_skip=0 的限制。
 *   - ls 用 copy_{from,to}_user_inatomic_nofault（不会睡眠/补页）；
 *     KPM 用 hy_f_copy_{from,to}_user，拿不到 inatomic 变体。
 *     风险：ioctl 路径上理论上允许睡眠，风险可控。
 *   - ls 用 DEFINE_MUTEX；KPM 用自实现的自旋锁。
 *
 * 【已知限制】直接沿用 ls 源码开头列的 6 条待修复问题，不做虚假宣称：
 *   1. Android 12+ 的 provider 用 UTF-16 String16，按 String8 解析可能失配
 *   2. 批量回调（List<Location>）只命中第一个
 *   3. token 只匹配 ILocation 前缀，可能误匹配 ILocationManager
 *   4. BC_*_SG 用的是基础 transaction 结构，SG 命令不命中
 *   5. 并发重复上报可能形成"新纬度 + 旧经度"混合
 *   6. 只扫前 512 字节，复杂 Parcel 可能漏检
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <hook.h>
/*
 * 【v1.19.0】hook_syscalln / unhook_syscalln 声明在 syscall.h，
 * 不在 hook.h。原先缺这个 include，编译器按隐式声明处理 ——
 * 在 arm64 上隐式声明的函数会被假定为 int 返回、参数走通用寄存器，
 * 与实际签名不一致时调用结果错误且不报错。
 */
#include <syscall.h>
#include <ksyms.h>
#include <kallsyms.h>
#include <asm/current.h>
#include "hy.h"

extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);

/* ============================ Binder ABI ============================ */

/*
 * 与 ls 完全一致的宏定义。
 *   BINDER_WRITE_READ   = _IOWR('b', 1, struct binder_write_read)
 *   BC_TRANSACTION      = _IOW ('c', 0, struct binder_transaction_data)
 */
/*
 * 【为什么不用 _IOW/_IOWR 宏】
 *   KernelPatch 提供的 linux/ioctl.h 里这些宏的实现与标准不同，
 *   传 struct 类型名会报 "expected expression before 'struct'"。
 *   所以这里手工按 _IOC 编码规则算出命令字，并在编译期静态校验。
 *
 *   _IOC(dir, type, nr, size) =
 *       (dir << 30) | (size << 16) | (type << 8) | nr
 *
 *   BINDER_WRITE_READ = _IOWR('b', 1, struct binder_write_read)
 *       dir=3(DIR_READ|DIR_WRITE) size=32 type=0x62 nr=1
 *     = 0xC0206201
 *   BC_TRANSACTION = _IOW('c', 0, struct binder_transaction_data)
 *       dir=1(WRITE) size=64 type=0x63 nr=0
 *     = 0x40406300
 */
#define HY_IOC_NRBITS   8
#define HY_IOC_TYPEBITS 8
#define HY_IOC_SIZEBITS 14
#define HY_IOC_DIRBITS  2

#define HY_IOC_NRSHIFT   0
#define HY_IOC_TYPESHIFT (HY_IOC_NRSHIFT + HY_IOC_NRBITS)
#define HY_IOC_SIZESHIFT (HY_IOC_TYPESHIFT + HY_IOC_TYPEBITS)
#define HY_IOC_DIRSHIFT  (HY_IOC_SIZESHIFT + HY_IOC_SIZEBITS)

#define HY_IOC_NONE  0U
#define HY_IOC_WRITE 1U
#define HY_IOC_READ  2U

#define HY_IOC(dir, type, nr, size) \
    (((dir)  << HY_IOC_DIRSHIFT)  | \
     ((type) << HY_IOC_TYPESHIFT) | \
     ((nr)   << HY_IOC_NRSHIFT)   | \
     ((size) << HY_IOC_SIZESHIFT))

#define HY_IOC_SIZE(cmd) (((cmd) >> HY_IOC_SIZESHIFT) & \
                          ((1U << HY_IOC_SIZEBITS) - 1))

#define HY_BINDER_WRITE_READ \
    HY_IOC(HY_IOC_READ | HY_IOC_WRITE, 'b', 1, sizeof(struct hy_binder_write_read))
#define HY_BC_TRANSACTION \
    HY_IOC(HY_IOC_WRITE, 'c', 0,  sizeof(struct hy_binder_transaction_data))
#define HY_BC_REPLY \
    HY_IOC(HY_IOC_WRITE, 'c', 1,  sizeof(struct hy_binder_transaction_data))
#define HY_BC_TRANSACTION_SG \
    HY_IOC(HY_IOC_WRITE, 'c', 17, sizeof(struct hy_binder_transaction_data))
#define HY_BC_REPLY_SG \
    HY_IOC(HY_IOC_WRITE, 'c', 18, sizeof(struct hy_binder_transaction_data))

typedef uint64_t hy_binder_uintptr_t;
typedef uint64_t hy_binder_size_t;

struct hy_binder_write_read {
    hy_binder_size_t    write_size;
    hy_binder_size_t    write_consumed;
    hy_binder_uintptr_t write_buffer;
    hy_binder_size_t    read_size;
    hy_binder_size_t    read_consumed;
    hy_binder_uintptr_t read_buffer;
};

struct hy_binder_transaction_data {
    union {
        uint32_t             handle;
        hy_binder_uintptr_t  ptr;
    } target;
    hy_binder_uintptr_t cookie;
    uint32_t code;
    uint32_t flags;
    int32_t  sender_pid;
    int32_t  sender_euid;
    hy_binder_size_t data_size;
    hy_binder_size_t offsets_size;
    union {
        struct {
            hy_binder_uintptr_t buffer;
            hy_binder_uintptr_t offsets;
        } ptr;
        uint8_t buf[8];
    } data;
};

/* arm64 上 ioctl 是 29 号 */
#ifndef __NR_ioctl
#define __NR_ioctl 29
#endif

/* ============================ 常量（与 ls 一致）============================ */

#define HY_GNSS_SCALE_E7         10000000ULL
#define HY_GNSS_PROBE_SIZE       512
#define HY_GNSS_TOKEN_BYTE_LEN   68      /* 34 个 UTF-16 字符 */

#define HY_GNSS_ABS_LAT_90       0x4056800000000000ULL
#define HY_GNSS_ABS_LON_180      0x4066800000000000ULL
#define HY_GNSS_EXP_MASK         0x7ff0000000000000ULL
#define HY_GNSS_ABS_MASK         0x7fffffffffffffffULL

/* ============================ 状态 ============================ */

static bool g_gnss_active;
static s32  g_lat_e7;
static s32  g_lon_e7;
static u64  g_patches;
static bool g_hooked;

static volatile u32 g_lock;

static inline void gn_lock(void)
{
    u32 tmp;
    asm volatile(
        "1: ldaxr %w0, [%1]\n"
        "   cbnz  %w0, 1b\n"
        "   stxr  %w0, %w2, [%1]\n"
        "   cbnz  %w0, 1b\n"
        : "=&r"(tmp) : "r"(&g_lock), "r"(1) : "memory");
}

static inline void gn_unlock(void)
{
    asm volatile("stlr %w1, [%0]" :: "r"(&g_lock), "r"(0) : "memory");
}

/* ============================ 整数版 e7 -> IEEE754 double ============================ */

/*
 * 内核里不能用 double/float。
 * 原因（ls 源码注释写得很清楚）：内核不会为每段代码自动保存/恢复
 * FP/SIMD 寄存器状态，用了会破坏当前进程的用户态浮点上下文。
 * 所以这里全程整数运算，与 ls 的 vgnss_e7_to_double_bits 同款。
 */
static u64 hy_gnss_e7_to_bits(int value)
{
    u64 sign, mag, fixed;
    int top, exp;
    u64 mant;

    if (!value) return 0;

    sign = (value < 0) ? 0x8000000000000000ULL : 0;
    mag  = (value < 0) ? (u64)(-(s64)value) : (u64)value;

    fixed = ((mag << 32) + (HY_GNSS_SCALE_E7 / 2)) / HY_GNSS_SCALE_E7;
    if (!fixed) return sign;

    top = 63;
    while (top >= 0 && !((fixed >> top) & 1ULL)) top--;
    if (top < 0) return sign;

    exp = top - 32 + 1023;
    if (exp <= 0) return sign;
    if (exp >= 2047) return sign | HY_GNSS_EXP_MASK;

    mant = (top > 52) ? (fixed >> (top - 52)) : (fixed << (52 - top));
    return sign | ((u64)exp << 52) | (mant & 0x000fffffffffffffULL);
}

/* ============================ Parcel 解析（原样移植）============================ */

/*
 * SWAR 64 位并行比对，匹配 "android.location.ILocation"（UTF-16LE）
 *   "andr" -> 0x00720064006e0061
 *   "loca" -> 0x00610063006f006c
 *   ".ILo" -> 0x006f004c0049002e
 */
static inline bool hy_gnss_is_location_token(const char *p)
{
    const u64 *w = (const u64 *)p;
    return (w[0] == 0x00720064006e0061ULL &&
            w[2] == 0x00610063006f006cULL &&
            w[4] == 0x006f004c0049002eULL);
}

/* 校验并就地 patch 用户空间 16 字节 */
static bool hy_gnss_try_patch(char *buf, size_t probe_len, size_t start,
                              char __user *u_base, u64 lat_bits, u64 lon_bits)
{
    s32 prov_len;
    size_t pos;
    u32 fields;
    u64 time_ms, elapsed_ns, lat, lon;
    u64 patch_data[2];

    if (start + 4 > probe_len) return false;

    prov_len = *(s32 *)(buf + start);
    if (prov_len < -1 || prov_len > 64) return false;

    pos = start + 4;
    if (prov_len >= 0) {
        if (pos + (size_t)prov_len + 1 > probe_len) return false;
        if (buf[pos + prov_len] != 0) return false;
        pos = (pos + (size_t)prov_len + 4) & ~3UL;
    }

    if (pos + 4 + 8 * 4 > probe_len) return false;

    fields = *(u32 *)(buf + pos);
    if (fields & ~0x7ffU) return false;

    pos += 4;
    time_ms    = *(u64 *)(buf + pos);
    elapsed_ns = *(u64 *)(buf + pos + 8);
    if (!time_ms || !elapsed_ns || time_ms > 4102444800000ULL) return false;

    pos += 16 + ((fields & (1U << 8)) ? 8 : 0);
    if (pos + 16 > probe_len) return false;

    lat = *(u64 *)(buf + pos);
    lon = *(u64 *)(buf + pos + 8);

    if ((lat & HY_GNSS_ABS_MASK) > HY_GNSS_ABS_LAT_90)  return false;
    if ((lon & HY_GNSS_ABS_MASK) > HY_GNSS_ABS_LON_180) return false;

    patch_data[0] = lat_bits;
    patch_data[1] = lon_bits;

    if (!hy_f_copy_to_user) return false;
    if (hy_f_copy_to_user((void __user *)(u_base + pos), patch_data,
                          sizeof(patch_data)) != 0)
        return false;

    gn_lock();
    g_patches++;
    gn_unlock();
    return true;
}

/* 栈上扫描整个 parcel 探针区，零堆分配 */
static void hy_gnss_inspect_parcel(char __user *u_buf, size_t size,
                                   u64 lat_bits, u64 lon_bits)
{
    char stack_buf[HY_GNSS_PROBE_SIZE];
    size_t probe_len;
    size_t i;

    if (size < 128 || !u_buf) return;
    if (!hy_f_copy_from_user) return;

    probe_len = size < sizeof(stack_buf) ? size : sizeof(stack_buf);
    if (hy_f_copy_from_user(stack_buf, u_buf, probe_len) != 0) return;

    for (i = 0; i + HY_GNSS_TOKEN_BYTE_LEN <= probe_len; i += 4) {
        if (!hy_gnss_is_location_token(stack_buf + i)) continue;
        {
            size_t token_end = (i + HY_GNSS_TOKEN_BYTE_LEN + 3) & ~3UL;
            size_t pos;
            for (pos = token_end; pos + 32 <= probe_len; pos += 4) {
                if (hy_gnss_try_patch(stack_buf, probe_len, pos, u_buf,
                                      lat_bits, lon_bits))
                    return;
            }
        }
        break;
    }
}

/* 遍历 binder write buffer 的命令序列 */
static void hy_gnss_process_write(const char __user *u_write_buf, size_t write_size,
                                  u64 lat_bits, u64 lon_bits)
{
    size_t pos = 0;

    if (!hy_f_copy_from_user) return;

    while (pos + sizeof(u32) <= write_size) {
        u32 cmd;
        size_t payload_size;

        if (hy_f_copy_from_user(&cmd, u_write_buf + pos, sizeof(cmd)) != 0) break;

        payload_size = HY_IOC_SIZE(cmd);
        pos += sizeof(u32);
        if (payload_size > write_size - pos) break;

        if (cmd == HY_BC_TRANSACTION || cmd == HY_BC_REPLY ||
            cmd == HY_BC_TRANSACTION_SG || cmd == HY_BC_REPLY_SG) {
            struct hy_binder_transaction_data tr;

            if (payload_size >= sizeof(tr) &&
                hy_f_copy_from_user(&tr, u_write_buf + pos, sizeof(tr)) == 0) {
                hy_gnss_inspect_parcel(
                    (char __user *)(unsigned long)tr.data.ptr.buffer,
                    (size_t)tr.data_size, lat_bits, lon_bits);
            }
        }
        pos += payload_size;
    }
}

/* ============================ ioctl hook ============================ */

static void hy_gnss_ioctl_before(hook_fargs4_t *args, void *udata)
{
    struct hy_binder_write_read bwr;
    u32 cmd;
    u64 lat_bits, lon_bits;
    s32 lat, lon;

    (void)udata;
    if (!hy_ready) return;

    /*
     * 【v1.44.0 性能修正】
     *   ioctl 是全系统最热的系统调用之一（GPU/音频/传感器/binder 都走它），
     *   hook 之后每一次 ioctl 都会进这个回调。原来的顺序是「先加自旋锁
     *   读 g_gnss_active，再判 cmd」，等于让所有 ioctl 都抢一次锁。
     *
     *   现在改成：先用无锁方式判 cmd，不匹配立即返回（占绝大多数），
     *   只有确实命中 BINDER_WRITE_READ 才去读状态、加锁。
     *   自旋锁开销从「每次 ioctl」降到「每次 binder 写」。
     */
    cmd = (u32)args->arg1;
    if (cmd != HY_BINDER_WRITE_READ) return;
    if (!args->arg2) return;

    gn_lock();
    if (!g_gnss_active) { gn_unlock(); return; }
    lat = g_lat_e7;
    lon = g_lon_e7;
    gn_unlock();

    if (!hy_f_copy_from_user) return;
    if (hy_f_copy_from_user(&bwr, (void __user *)(unsigned long)args->arg2,
                            sizeof(bwr)) != 0)
        return;

    if (!bwr.write_buffer || bwr.write_size == 0) return;
    if (bwr.write_size > 1024 * 1024) return;   /* 异常大，跳过 */

    lat_bits = hy_gnss_e7_to_bits(lat);
    lon_bits = hy_gnss_e7_to_bits(lon);

    hy_gnss_process_write((const char __user *)(unsigned long)bwr.write_buffer,
                          (size_t)bwr.write_size, lat_bits, lon_bits);
}

/* ============================ 对外接口 ============================ */

int hy_gnss_init(void)
{
    g_gnss_active = false;
    g_lat_e7 = 0;
    g_lon_e7 = 0;
    g_patches = 0;
    return 0;
}

void hy_gnss_exit(void)
{
    g_gnss_active = false;
    if (g_hooked) {
        unhook_syscalln(__NR_ioctl, hy_gnss_ioctl_before, NULL);
        g_hooked = false;
        HY_LOG("gnss: unhooked ioctl\n");
    }
}

int hy_gnss_set(s32 lat_e7, s32 lon_e7, u32 enable)
{
    if (!enable) {
        gn_lock();
        g_gnss_active = false;
        gn_unlock();
        if (g_hooked) {
            unhook_syscalln(__NR_ioctl, hy_gnss_ioctl_before, NULL);
            g_hooked = false;
        }
        return 0;
    }

    /* 经纬度范围校验 */
    if (lat_e7 < -900000000 || lat_e7 > 900000000)  return -EINVAL;
    if (lon_e7 < -1800000000 || lon_e7 > 1800000000) return -EINVAL;

    gn_lock();
    g_lat_e7 = lat_e7;
    g_lon_e7 = lon_e7;
    gn_unlock();

    if (!g_hooked) {
        /*
         * hook ioctl 系统调用。
         * 用 hook_syscalln 而非 hook_wrap 某个内核函数：
         * ioctl 的 syscall 入口在所有版本上都稳定，不依赖符号名。
         */
        int ret = hook_syscalln(__NR_ioctl, 3, hy_gnss_ioctl_before, NULL, NULL);
        if (ret != 0) {
            HY_LOG("gnss: hook ioctl failed err=%d\n", ret);
            return -ENODEV;
        }
        g_hooked = true;
        HY_LOG("gnss: hooked ioctl (nr=%d)\n", __NR_ioctl);
    }

    gn_lock();
    g_gnss_active = true;
    gn_unlock();

    HY_LOG("gnss: active lat_e7=%d lon_e7=%d\n", lat_e7, lon_e7);
    return 0;
}

int hy_gnss_status(struct hy_gnss_status *st)
{
    if (!st) return -EINVAL;
    st->active  = g_gnss_active ? 1 : 0;
    st->hooked  = g_hooked ? 1 : 0;
    st->patches = g_patches;
    st->latitude_e7  = g_lat_e7;
    st->longitude_e7 = g_lon_e7;
    return 0;
}

u64 hy_gnss_patches(void) { return g_patches; }
int hy_gnss_is_active(void) { return g_gnss_active ? 1 : 0; }
int hy_gnss_is_hooked(void) { return g_hooked ? 1 : 0; }
