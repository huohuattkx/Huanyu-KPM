#!/usr/bin/env bash
set -u
ZIG=${ZIG:-/data/workspace/.toolchain/ziglang/zig}
export ZIG_LIB_DIR=${ZIG_LIB_DIR:-/data/workspace/.toolchain/ziglang/lib}
export ZIG_LIB_DIR=${ZIG_LIB_DIR:-/data/workspace/.toolchain/ziglang/lib}
KP=${KP_DIR:-/data/workspace/KP139/KernelPatch-0.13.9}
INC="-I. -I$KP/kernel -I$KP/kernel/include -I$KP/kernel/patch/include \
     -I$KP/kernel/linux/include -I$KP/kernel/linux/arch/arm64/include \
     -I$KP/kernel/linux/tools/arch/arm64/include"
# zig cc 兼容 clang 选项；--param=* 是 GCC 专有，去掉
BASE="-target aarch64-freestanding-none \
  -D__KERNEL__ -D__LINUX__ -D__USE_MISC -D_GNU_SOURCE \
  -D__LINUX_ARM_ARCH__=8 -D__aarch64__ \
  -Wall -fno-builtin -std=gnu11 -nostdinc -mgeneral-regs-only -ffixed-x18 \
  -fno-stack-protector -fno-PIC -fno-pie -fno-pic \
  -fvisibility=hidden -fno-addrsig -fno-asynchronous-unwind-tables -fno-unwind-tables \
  -g0 -O3 -fno-semantic-interposition -funroll-loops -fpeel-loops \
  -ftree-vectorize -fomit-frame-pointer -fno-math-errno"
SRCS="hy_gate.c hy_scheme.c hy_main.c hy_sym.c hy_discover.c hy_pt.c hy_bp.c hy_mem.c hy_input.c hy_hide.c hy_guard.c hy_task.c hy_ctl.c hy_insn.c hy_insn_prefix.c hy_pgtable.c hy_trampoline.c hy_extra.c hy_procfs.c hy_dbgfs.c hy_prctl.c hy_shm.c hy_pm.c hy_sysmon.c hy_cntvct.c hy_gnss.c hy_lsx.c hy_devinfo.c hy_stress.c hy_kma.c hy_net.c"
rm -f *.o huanyu.kpm
for s in $SRCS; do
  o="${s%.c}.o"
  # PACGA (hy_task.c) 需要 armv8.3 pauth；apple_a12 = armv8.3-A
  EXTRA=""
  [ "$s" = "hy_task.c" ] && EXTRA="-mcpu=apple_a12"
  echo ">>> $s"
  $ZIG cc $INC $BASE $EXTRA -c -o "$o" "$s" 2>&1 | grep -E "error:" | head -5
  [ -f "$o" ] || { echo "FAILED: $s"; exit 1; }
done
echo "compiled all"
$ZIG ld.lld -r -o huanyu.kpm.tmp *.o 2>&1 | head -5
# 去掉 .eh_frame / .comment / .note.*：KP 的 rewrite_section_headers
# 只处理 alloc 段，多余段虽不致命但白白占空间、且某些版本会报错
llvm-objcopy --remove-section=.eh_frame --remove-section=.rela.eh_frame \
             --remove-section=.comment --remove-section=.note.GNU-stack \
             huanyu.kpm.tmp huanyu.kpm 2>/dev/null || cp huanyu.kpm.tmp huanyu.kpm
rm -f huanyu.kpm.tmp
echo "OK huanyu.kpm=$(stat -c%s huanyu.kpm 2>/dev/null || echo 0)"
