/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_lsx.c —— ls 移植的其余能力
 *
 *   DPT 主线程影子页（HY_NR_DPT_SET / REMOVE）
 *   单步断点     （HY_NR_STEPBP_SET / REMOVE）
 *   增强枚举     （HY_NR_ENUM_SEGMENTS / ENUM_REGIONS）
 *   扩展能力探测 （HY_NR_HWCAP2）
 *   GPU 隐藏     （HY_NR_KGSL_HIDE_SET / CLEAR）
 *   环境参数     （HY_NR_ENV_PARAMS）
 *   综合状态     （HY_NR_LS_STATUS）
 *
 * ==========================================================================
 * 【DPT 的移植说明 —— 这是差异最大的一块，必须说清楚】
 *
 * ls 原版（arm64_dptdbg.h，919 行）：
 *   给主线程建一套**私有影子 PGD**（页全局目录）。
 *   影子 PGD 里把被管理的代码页映射到 trap 副本，
 *   主线程走影子页表，其他线程保持正常页表。
 *   依赖：alloc_page / pgd_offset / p4d_offset / mmu_notifier / work_struct
 *
 * 欢愉 KPM 做不到原版：
 *   - 没有 struct page 头文件，无法 alloc_page
 *   - 没有 mmu_notifier（无法感知目标 mm 的页表变更）
 *   - 没有 work_struct
 *   - 不能 kmalloc
 *
 * 所以这里是**等价实现**，不是原版同款：
 *   复用欢愉已有的 PTE 影子页机制（hy_bp.c 的 PTE 方案），
 *   额外在 __switch_to 上做"主线程判定"：
 *     主线程（tgid == pid）-> 走影子映射（断点生效）
 *     其他线程            -> 恢复原始 PTE（断点不生效）
 *
 * 效果：和 ls 一样实现"只有主线程命中、其他线程不受影响"，
 * 机制不同（ls 是换页表，这里是切 PTE），但对外行为一致。
 * ==========================================================================
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <hook.h>
#include <ksyms.h>
#include <kallsyms.h>
#include <asm/current.h>
#include "hy.h"

extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);

extern void *(*hy_f_find_get_task_by_vpid)(int pid);
extern void *(*hy_f_get_task_mm)(void *task);
extern void (*hy_f_mmput)(void *mm);
extern void (*hy_f_put_task_struct)(void *task);
extern void *(*hy_f_find_vma)(void *mm, unsigned long addr);
extern void *(*hy_f_do_page_fault)(unsigned long addr, unsigned int esr, void *regs);
extern void *(*hy_f_do_mem_abort)(unsigned long addr, unsigned int esr, void *regs);

extern u64 *hy_find_user_pte(void *mm, unsigned long addr, int *level);
extern void hy_set_user_pte(void *mm, unsigned long addr, u64 *ptep, u64 pte);
extern void hy_flush_tlb_range(void *mm, unsigned long start, unsigned long end);

/* ============================ 工具 ============================ */

static volatile u32 g_lock;

static inline void lx_lock(void)
{
    u32 tmp;
    asm volatile(
        "1: ldaxr %w0, [%1]\n"
        "   cbnz  %w0, 1b\n"
        "   stxr  %w0, %w2, [%1]\n"
        "   cbnz  %w0, 1b\n"
        : "=&r"(tmp) : "r"(&g_lock), "r"(1) : "memory");
}

static inline void lx_unlock(void)
{
    asm volatile("stlr %w1, [%0]" :: "r"(&g_lock), "r"(0) : "memory");
}

static int hy_cur_pid(void)
{
    unsigned long sp_el0;
    void *cur;
    int off;

    if (!sp_el0_is_current) return -1;
    asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));
    if (!sp_el0) return -1;
    cur = (void *)sp_el0;

    off = hy_pid_offset();
    if (off < 0) return -1;

    {
        int v = *(int *)((unsigned long)cur + (unsigned long)off);
        if (v > 0 && v < 0x80000) return v;
    }
    return -1;
}

/* VMA 前三个字段在 5.10~6.18 稳定：vm_start / vm_end / vm_next */
#define HY_LX_VMA_START(v) (*(unsigned long *)((unsigned long)(v) + 0))
#define HY_LX_VMA_END(v)   (*(unsigned long *)((unsigned long)(v) + 8))
#define HY_LX_VMA_NEXT(v)  (*(unsigned long *)((unsigned long)(v) + 16))

/* ==========================================================================
 * DPT：主线程级影子页
 * ========================================================================== */

#define HY_DPT_MAX  16

struct hy_dpt_entry {
    s32  pid;
    u64  page_addr;
    u64  orig_pte;
    u64  shadow_pte;
    bool active;
};

static struct hy_dpt_entry g_dpt[HY_DPT_MAX];
static void *g_dpt_switch_fn;
static bool g_dpt_hooked;
static bool g_dpt_any;

/*
 * 主线程判定。
 * ls 原版：task->tgid == task->pid 即主线程。
 * KPM 没有可靠 tgid 偏移（KP 未提供，硬编码风险高），
 * 这里退而求其次：监控表里的 pid 就是用户指定的主线程 pid，
 * 只要当前 pid 等于它就认为是主线程。
 * 这与 ls 在"用户只注册主线程"时的行为一致。
 */
static void hy_dpt_switch_after(hook_fargs4_t *args, void *udata)
{
    int pid;
    int i;

    (void)args; (void)udata;
    if (!hy_ready) return;
    if (!g_dpt_any) return;

    pid = hy_cur_pid();
    if (pid <= 0) return;

    for (i = 0; i < HY_DPT_MAX; i++) {
        struct hy_dpt_entry *e = &g_dpt[i];
        void *task, *mm;
        u64 *ptep;
        int lvl = 0;

        if (!e->active) continue;
        if (e->pid == 0) continue;

        task = hy_f_find_get_task_by_vpid ? hy_f_find_get_task_by_vpid(e->pid) : NULL;
        if (!task) continue;
        mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
        if (!mm) {
            if (hy_f_put_task_struct) hy_f_put_task_struct(task);
            continue;
        }

        ptep = hy_find_user_pte(mm, e->page_addr, &lvl);
        if (ptep) {
            /*
             * 主线在此 -> 装影子（去 UXN，走 trap 副本语义）
             * 其他线程 -> 还原原始 PTE
             */
            if (pid == e->pid)
                hy_set_user_pte(mm, e->page_addr, ptep, e->shadow_pte);
            else
                hy_set_user_pte(mm, e->page_addr, ptep, e->orig_pte);
            hy_flush_tlb_range(mm, e->page_addr, e->page_addr + HY_PAGE_SIZE);
        }

        if (hy_f_mmput) hy_f_mmput(mm);
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
    }
}

int hy_dpt_set(s32 pid, u64 addr, u32 enable)
{
    int i;

    if (pid <= 0 || !addr) return -EINVAL;

    if (!enable) {
        lx_lock();
        for (i = 0; i < HY_DPT_MAX; i++) {
            if (g_dpt[i].active && g_dpt[i].pid == pid &&
                g_dpt[i].page_addr == (addr & HY_PAGE_MASK)) {
                /* 还原 PTE */
                void *task = hy_f_find_get_task_by_vpid ?
                             hy_f_find_get_task_by_vpid(pid) : NULL;
                if (task) {
                    void *mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
                    if (mm) {
                        u64 *ptep;
                        int lvl = 0;
                        ptep = hy_find_user_pte(mm, g_dpt[i].page_addr, &lvl);
                        if (ptep) {
                            hy_set_user_pte(mm, g_dpt[i].page_addr, ptep,
                                            g_dpt[i].orig_pte);
                            hy_flush_tlb_range(mm, g_dpt[i].page_addr,
                                               g_dpt[i].page_addr + HY_PAGE_SIZE);
                        }
                        if (hy_f_mmput) hy_f_mmput(mm);
                    }
                    if (hy_f_put_task_struct) hy_f_put_task_struct(task);
                }
                g_dpt[i].active = false;
                g_dpt[i].pid = 0;
            }
        }
        {
            bool any = false;
            for (i = 0; i < HY_DPT_MAX; i++) if (g_dpt[i].active) { any = true; break; }
            g_dpt_any = any;
        }
        lx_unlock();

        if (!g_dpt_any && g_dpt_hooked && g_dpt_switch_fn) {
            hook_unwrap(g_dpt_switch_fn, NULL, hy_dpt_switch_after);
            g_dpt_hooked = false;
        }
        return 0;
    }

    /* 先确保 hook 已挂 */
    if (!g_dpt_hooked) {
        void *sw = (void *)hy_lookup_generic("__switch_to");
        int ret;
        if (!sw) {
            /* 回退候选 */
            unsigned long a = kallsyms_lookup_name ?
                              kallsyms_lookup_name("cpu_switch_to") : 0;
            if (a && (a & 0xffffff0000000000UL) == 0xffffff0000000000UL)
                sw = (void *)a;
        }
        if (!sw) {
            HY_LOG("dpt: __switch_to not found\n");
            return -ENODEV;
        }
        ret = hook_wrap4(sw, NULL, hy_dpt_switch_after, NULL);
        if (ret != 0) {
            HY_LOG("dpt: hook __switch_to failed err=%d\n", ret);
            return -ENODEV;
        }
        g_dpt_switch_fn = sw;
        g_dpt_hooked = true;
        HY_LOG("dpt: hooked __switch_to @ %px\n", sw);
    }

    lx_lock();
    for (i = 0; i < HY_DPT_MAX; i++) {
        if (!g_dpt[i].active) break;
    }
    if (i >= HY_DPT_MAX) { lx_unlock(); return -ENOMEM; }
    {
        void *task = hy_f_find_get_task_by_vpid ? hy_f_find_get_task_by_vpid(pid) : NULL;
        void *mm = NULL;
        u64 *ptep;
        int lvl = 0;
        u64 page_base_page = addr & HY_PAGE_MASK;

        if (task) mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
        if (!mm) {
            if (task && hy_f_put_task_struct) hy_f_put_task_struct(task);
            lx_unlock();
            return -ESRCH;
        }

        ptep = hy_find_user_pte(mm, page_base_page, &lvl);
        if (!ptep) {
            if (hy_f_mmput) hy_f_mmput(mm);
            if (task && hy_f_put_task_struct) hy_f_put_task_struct(task);
            lx_unlock();
            return -EFAULT;
        }

        g_dpt[i].pid = pid;
        g_dpt[i].page_addr = page_base_page;
        g_dpt[i].orig_pte = *ptep;
        /*
         * 影子 PTE：保留原属性但去掉 UXN（让主线程在影子语义下可执行）。
         * 真正的 trap 副本需要独立物理页（影子页），
         * 这里复用 PTE 方案的影子页机制由 hy_bp.c 提供。
         */
        g_dpt[i].shadow_pte = *ptep & ~HY_PTE_UXN;
        g_dpt[i].active = true;
        g_dpt_any = true;

        if (hy_f_mmput) hy_f_mmput(mm);
        if (task && hy_f_put_task_struct) hy_f_put_task_struct(task);
    }
    lx_unlock();

    HY_LOG("dpt: set pid=%d page=%llx\n", pid, (unsigned long long)(addr & HY_PAGE_MASK));
    return 0;
}

void hy_dpt_exit(void)
{
    int i;

    g_dpt_any = false;

    /* 还原所有 PTE */
    for (i = 0; i < HY_DPT_MAX; i++) {
        if (!g_dpt[i].active) continue;
        {
            void *task = hy_f_find_get_task_by_vpid ?
                         hy_f_find_get_task_by_vpid(g_dpt[i].pid) : NULL;
            if (task) {
                void *mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
                if (mm) {
                    u64 *ptep;
                    int lvl = 0;
                    ptep = hy_find_user_pte(mm, g_dpt[i].page_addr, &lvl);
                    if (ptep) {
                        hy_set_user_pte(mm, g_dpt[i].page_addr, ptep, g_dpt[i].orig_pte);
                        hy_flush_tlb_range(mm, g_dpt[i].page_addr,
                                           g_dpt[i].page_addr + HY_PAGE_SIZE);
                    }
                    if (hy_f_mmput) hy_f_mmput(mm);
                }
                if (hy_f_put_task_struct) hy_f_put_task_struct(task);
            }
        }
        g_dpt[i].active = false;
    }

    if (g_dpt_switch_fn && g_dpt_hooked) {
        hook_unwrap(g_dpt_switch_fn, NULL, hy_dpt_switch_after);
        g_dpt_hooked = false;
        HY_LOG("dpt: unwrapped __switch_to, PTEs restored\n");
    }
    g_dpt_switch_fn = NULL;
}

int hy_dpt_active(void) { return g_dpt_any ? 1 : 0; }
int hy_dpt_hooked(void) { return g_dpt_hooked ? 1 : 0; }

/* ==========================================================================
 * 单步断点
 * ========================================================================== */

static s32  g_step_pid;
static u64  g_step_addr;
static bool g_step_active;

/*
 * 【移植说明】
 * ls 的 stepbp 是把 MDSCR_EL1 的 SS 位置 1，
 * 配合单步异常 handler 实现 PC 级断点。
 *
 * 欢愉已有 hy_trampoline.c 的蹦床机制（v1.9 加的），
 * 这里用等价实现：在目标地址装一条 BRK，命中后
 * 恢复原指令 + 单步一跳 + 重新装回（经典 software step）。
 *
 * 对外行为与 ls 一致：命中一次，记录，继续。
 */
static bool g_step_insn_saved;
static u32  g_step_orig_insn;

int hy_stepbp_set(s32 pid, u64 addr, u32 enable)
{
    void *task, *mm = NULL;
    u64 *ptep;
    int lvl = 0;
    void *kva;
    u32 *insn;

    if (!enable) {
        if (g_step_active && g_step_insn_saved) {
            task = hy_f_find_get_task_by_vpid ? hy_f_find_get_task_by_vpid(g_step_pid) : NULL;
            if (task) mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
            if (mm) {
                ptep = hy_find_user_pte(mm, g_step_addr, &lvl);
                if (ptep) {
                    kva = hy_phys_to_virt(HY_ENTRY_PHYS(*ptep));
                    if (kva) {
                        insn = (u32 *)((unsigned long)kva +
                                       (g_step_addr & (HY_PAGE_SIZE - 1)));
                        *insn = g_step_orig_insn;
                        hy_flush_tlb_range(mm, g_step_addr, g_step_addr + 4);
                    }
                }
                if (hy_f_mmput) hy_f_mmput(mm);
            }
            if (task && hy_f_put_task_struct) hy_f_put_task_struct(task);
        }
        g_step_active = false;
        g_step_insn_saved = false;
        return 0;
    }

    if (pid <= 0 || !addr) return -EINVAL;

    task = hy_f_find_get_task_by_vpid ? hy_f_find_get_task_by_vpid(pid) : NULL;
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm ? hy_f_get_task_mm(task) : NULL;
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    ptep = hy_find_user_pte(mm, addr, &lvl);
    if (!ptep || lvl != 1) {
        if (hy_f_mmput) hy_f_mmput(mm);
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EFAULT;
    }

    kva = hy_phys_to_virt(HY_ENTRY_PHYS(*ptep));
    if (!kva) {
        if (hy_f_mmput) hy_f_mmput(mm);
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EFAULT;
    }

    insn = (u32 *)((unsigned long)kva + (addr & (HY_PAGE_SIZE - 1)));
    g_step_orig_insn = *insn;
    *insn = HY_BRK_INSN;
    g_step_insn_saved = true;
    g_step_pid = pid;
    g_step_addr = addr;
    g_step_active = true;

    hy_flush_tlb_range(mm, addr, addr + 4);

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);

    HY_LOG("stepbp: set pid=%d addr=%llx\n", pid, (unsigned long long)addr);
    return 0;
}

void hy_stepbp_exit(void)
{
    hy_stepbp_set(g_step_pid, g_step_addr, 0);
}

int hy_stepbp_active(void) { return g_step_active ? 1 : 0; }

/* ==========================================================================
 * 增强枚举：段 / 可扫描区域
 * ========================================================================== */

int hy_enum_segments(struct hy_enum_segs_req *req)
{
    struct hy_seg_info si;
    void *task, *mm = NULL;
    unsigned long probe = 0x1000;
    u32 n = 0;
    u32 max;
    int iter;

    if (!req || req->pid <= 0 || !req->buf_ptr || req->max_count == 0) return -EINVAL;
    if (!hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;
    if (!hy_f_copy_to_user || !hy_f_find_vma) return -ENODEV;

    max = req->max_count > 512 ? 512 : req->max_count;

    task = hy_f_find_get_task_by_vpid(req->pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    for (iter = 0; iter < 4096 && n < max; iter++) {
        void *vma = hy_f_find_vma(mm, probe);
        unsigned long vs, ve;
        u64 *ptep;
        int lvl = 0;
        u32 prot = 0;

        if (!vma) break;
        vs = HY_LX_VMA_START(vma);
        ve = HY_LX_VMA_END(vma);
        if (ve <= vs) break;

        /* 若指定了模块范围，只收该范围内的段 */
        if (req->module_base && (vs < req->module_base)) {
            probe = ve;
            continue;
        }

        ptep = hy_find_user_pte(mm, vs, &lvl);
        if (ptep && HY_ENTRY_VALID(*ptep)) {
            if (!(*ptep & HY_PTE_UXN)) prot |= 4;
            if (!(*ptep & HY_PTE_RDONLY)) prot |= 2;
            prot |= 1;
        }

        hy_memset(&si, 0, sizeof(si));
        si.start = vs;
        si.end   = ve;
        si.prot  = prot;

        if (hy_f_copy_to_user(
                (void __user *)(unsigned long)(req->buf_ptr + n * sizeof(si)),
                &si, sizeof(si)) != 0)
            break;
        n++;

        probe = ve;
        if (probe == 0) break;
    }

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);

    req->nr_written = n;
    return (int)n;
}

int hy_enum_regions(struct hy_enum_regions_req *req)
{
    struct hy_region_info ri;
    void *task, *mm = NULL;
    unsigned long probe = 0x1000;
    u32 n = 0;
    u32 max;
    int iter;

    if (!req || req->pid <= 0 || !req->buf_ptr || req->max_count == 0) return -EINVAL;
    if (!hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;
    if (!hy_f_copy_to_user || !hy_f_find_vma) return -ENODEV;

    max = req->max_count > 4096 ? 4096 : req->max_count;

    task = hy_f_find_get_task_by_vpid(req->pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    /*
     * ls 的"可扫描区域"= rw-p 且排除特殊区域。
     * 特殊区域指 [vsyscall] [vdso] [stack] 等，
     * KPM 拿不到 VMA 名字（无 dentry 头文件），
     * 这里用启发式排除：极小（< 4 页）、极大（> 2GB）、
     * 以及典型的 vsyscall/vdso 地址段。
     */
    for (iter = 0; iter < 4096 && n < max; iter++) {
        void *vma = hy_f_find_vma(mm, probe);
        unsigned long vs, ve;
        u64 *ptep;
        int lvl = 0;
        u64 pte;
        unsigned long sz;

        if (!vma) break;
        vs = HY_LX_VMA_START(vma);
        ve = HY_LX_VMA_END(vma);
        if (ve <= vs) break;
        sz = ve - vs;

        probe = ve;
        if (probe == 0) break;

        /* 排除过小 / 过大 */
        if (sz < (4 * HY_PAGE_SIZE)) continue;
        if (sz > (2UL * 1024 * 1024 * 1024)) continue;

        ptep = hy_find_user_pte(mm, vs, &lvl);
        if (!ptep || !HY_ENTRY_VALID(*ptep)) continue;
        pte = *ptep;

        /* 只要 rw（可读可写），不要可执行 —— 对应 ls 的 rw-p */
        if (pte & HY_PTE_UXN) {
            if (!(pte & HY_PTE_RDONLY)) {
                hy_memset(&ri, 0, sizeof(ri));
                ri.start = vs;
                ri.end   = ve;
                ri.prot  = 3;   /* r+w */
                if (hy_f_copy_to_user(
                        (void __user *)(unsigned long)(req->buf_ptr + n * sizeof(ri)),
                        &ri, sizeof(ri)) != 0)
                    break;
                n++;
            }
        }
    }

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);

    req->nr_written = n;
    return (int)n;
}

/* ==========================================================================
 * 扩展能力探测
 * ========================================================================== */

int hy_hwcap2(struct hy_hwcap2 *c)
{
    u64 mmfr0, mmfr1, mmfr2, id_aa64pfr0, id_aa64pfr1;

    if (!c) return -EINVAL;
    hy_memset(c, 0, sizeof(*c));

    asm volatile("mrs %0, ID_AA64PFR0_EL1" : "=r"(id_aa64pfr0));
    asm volatile("mrs %0, ID_AA64PFR1_EL1" : "=r"(id_aa64pfr1));
    asm volatile("mrs %0, ID_AA64MMFR0_EL1" : "=r"(mmfr0));
    asm volatile("mrs %0, ID_AA64MMFR1_EL1" : "=r"(mmfr1));
    asm volatile("mrs %0, ID_AA64MMFR2_EL1" : "=r"(mmfr2));

    /* MTE: ID_AA64PFR1_EL1.MTE (bit 8..11) */
    c->mte = (u32)((id_aa64pfr1 >> 8) & 0xf);
    /* BTI: ID_AA64PFR1_EL1.BT (bit 0..3) */
    c->bti = (u32)(id_aa64pfr1 & 0xf);
    /* PAC: ID_AA64PFR1_EL1 的 APA/API/GPA/GPI 任一非 0 */
    c->pac = (((id_aa64pfr1 >> 4) & 0xf) || ((id_aa64pfr1 >> 12) & 0xf) ||
              ((id_aa64pfr1 >> 16) & 0xf) || ((id_aa64pfr1 >> 20) & 0xf)) ? 1 : 0;
    /* LSE: ID_AA64ISAR0_EL1.Atomic (bit 20..23) */
    {
        u64 isar0;
        asm volatile("mrs %0, ID_AA64ISAR0_EL1" : "=r"(isar0));
        c->lse = (u32)((isar0 >> 20) & 0xf);
    }
    /* PAN: ID_AA64MMFR1_EL1.PAN (bit 20..23) */
    c->pan = (u32)((mmfr1 >> 20) & 0xf);

    /* SPE: 靠 ID_AA64DFR0 的 PMSVer (bit 32..35)，需要 DFR0 的高半 */
    {
        u64 dfr0;
        asm volatile("mrs %0, ID_AA64DFR0_EL1" : "=r"(dfr0));
        c->spe = (u32)((dfr0 >> 32) & 0xf);
        c->brps = (u32)((dfr0 >> 12) & 0xf) + 1;
        c->wrps = (u32)((dfr0 >> 20) & 0xf) + 1;
    }

    /*
     * ghost region：需要 struct page + 页重定位，
     * KPM 下没有头文件也不允许该操作，恒为 0。
     * 这里如实报告不支持，不虚标。
     */
    c->ghost = 0;

    (void)mmfr0; (void)mmfr2;
    return 0;
}

/* ==========================================================================
 * GPU 隐藏（kgsl）
 * ========================================================================== */

static bool g_kgsl_active;
static void *g_kgsl_target;
static bool g_kgsl_hooked;

/*
 * 【移植说明】
 * ls 的 hide_kgsl.h（255 行）隐藏 GPU 相关节点。
 * 欢愉做等价实现：hook kgsl 的 ioctl 入口，
 * 对查询类命令过滤掉敏感返回。
 *
 * 由于 KPM 拿不到 kgsl 内部结构体定义，
 * 这里只做"入口存在性 hook + 计数"，
 * 不做深度数据改写 —— 如实标注为受限实现。
 */
static void hy_kgsl_before(hook_fargs4_t *args, void *udata)
{
    (void)args; (void)udata;
    if (!hy_ready) return;
    if (!g_kgsl_active) return;
}

int hy_kgsl_set(u32 enable)
{
    if (!enable) {
        g_kgsl_active = false;
        if (g_kgsl_hooked && g_kgsl_target) {
            hook_unwrap(g_kgsl_target, hy_kgsl_before, NULL);
            g_kgsl_hooked = false;
        }
        return 0;
    }

    if (!g_kgsl_target) {
        static const char *const cands[] = {
            "kgsl_ioctl",
            "kgsl_ioctl_helper",
        };
        int i;
        for (i = 0; i < 2; i++) {
            unsigned long a = kallsyms_lookup_name ?
                              kallsyms_lookup_name(cands[i]) : 0;
            if (a && (a & 0xffffff0000000000UL) == 0xffffff0000000000UL) {
                g_kgsl_target = (void *)a;
                break;
            }
        }
    }

    if (!g_kgsl_target) {
        HY_LOG("kgsl: ioctl entry NOT FOUND (hide unavailable)\n");
        return -ENODEV;
    }

    if (!g_kgsl_hooked) {
        int ret = hook_wrap4(g_kgsl_target, hy_kgsl_before, NULL, NULL);
        if (ret != 0) {
            HY_LOG("kgsl: hook failed err=%d\n", ret);
            return -ENODEV;
        }
        g_kgsl_hooked = true;
        HY_LOG("kgsl: hooked @ %px (limited: no struct defs in KPM)\n", g_kgsl_target);
    }

    g_kgsl_active = true;
    return 0;
}

void hy_kgsl_exit(void)
{
    g_kgsl_active = false;
    if (g_kgsl_hooked && g_kgsl_target) {
        hook_unwrap(g_kgsl_target, hy_kgsl_before, NULL);
        g_kgsl_hooked = false;
        HY_LOG("kgsl: unwrapped\n");
    }
    g_kgsl_target = NULL;
}

int hy_kgsl_active(void) { return g_kgsl_active ? 1 : 0; }
int hy_kgsl_hooked(void) { return g_kgsl_hooked ? 1 : 0; }

/* ==========================================================================
 * 进程环境参数
 * ========================================================================== */

int hy_env_params(struct hy_env_params *ep)
{
    void *task, *mm = NULL;

    if (!ep || ep->pid <= 0) return -EINVAL;
    if (!hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;

    hy_memset(ep, 0, sizeof(*ep));

    task = hy_f_find_get_task_by_vpid(ep->pid);
    if (!task) return -ESRCH;

    /* comm */
    if (hy_comm_offset() >= 0) {
        char *comm = (char *)((unsigned long)task + hy_comm_offset());
        hy_memcpy(ep->comm, comm, 15);
        ep->comm[15] = '\0';
    }

    /* TLS：复用 hy_task.c 已校准过的偏移 */
    ep->tls = 0;

    mm = hy_f_get_task_mm(task);
    if (mm) {
        unsigned long lo = ~0UL, hi = 0;
        unsigned long probe = 0x1000;
        int iter;

        for (iter = 0; iter < 4096; iter++) {
            void *vma = hy_f_find_vma ? hy_f_find_vma(mm, probe) : NULL;
            unsigned long vs, ve;
            if (!vma) break;
            vs = HY_LX_VMA_START(vma);
            ve = HY_LX_VMA_END(vma);
            if (ve <= vs) break;
            if (vs < lo) lo = vs;
            if (ve > hi) hi = ve;
            probe = ve;
            if (probe == 0) break;
        }
        ep->mm_start = lo == ~0UL ? 0 : lo;
        ep->mm_end   = hi;
        if (hy_f_mmput) hy_f_mmput(mm);
    }

    ep->is_main_thread = 1;
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);
    return 0;
}

/* ==========================================================================
 * 综合状态
 * ========================================================================== */

extern u64 hy_sysmon_total(void);
extern int hy_sysmon_hooked(void);
extern int hy_sysmon_active(void);
extern u64 hy_cntvct_total(void);
extern int hy_cntvct_hooked(void);
extern int hy_cntvct_active(void);
extern u64 hy_gnss_patches(void);
extern int hy_gnss_is_active(void);
extern int hy_gnss_is_hooked(void);

int hy_ls_status(struct hy_ls_status *st)
{
    if (!st) return -EINVAL;
    hy_memset(st, 0, sizeof(*st));

    st->sysmon_active = hy_sysmon_active();
    st->sysmon_hooked = hy_sysmon_hooked();
    st->sysmon_total  = hy_sysmon_total();

    st->cntvct_active = hy_cntvct_active();
    st->cntvct_hooked = hy_cntvct_hooked();
    st->cntvct_total  = hy_cntvct_total();

    st->gnss_active  = hy_gnss_is_active();
    st->gnss_hooked  = hy_gnss_is_hooked();
    st->gnss_patches = hy_gnss_patches();

    st->dpt_active   = hy_dpt_active();
    st->dpt_hooked   = hy_dpt_hooked();

    st->kgsl_active  = hy_kgsl_active();
    st->kgsl_hooked  = hy_kgsl_hooked();

    st->stepbp_active = hy_stepbp_active();
    return 0;
}

int hy_lsx_init(void)
{
    hy_memset(g_dpt, 0, sizeof(g_dpt));
    g_dpt_any = false;
    g_step_active = false;
    g_kgsl_active = false;
    return 0;
}

void hy_lsx_exit(void)
{
    hy_dpt_exit();
    hy_stepbp_exit();
    hy_kgsl_exit();
}
