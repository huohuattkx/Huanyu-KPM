/*
 * 欢愉内核模块 —— 命令行自加载器（aarch64 freestanding，无 libc 依赖）
 *
 * 为什么不能让 .kpm 本身可执行：
 *   KernelPatch 加载时硬性校验 e_type == ET_REL（module.c: elf_header_check），
 *   而 Linux binfmt_elf 执行时硬性要求 e_type == ET_EXEC 或 ET_DYN。
 *   同一个 ELF 头里这两个条件是互斥的，无法共存于一份文件。
 *
 * 本文件的做法（保住 APatch 的加载路径，同时给出命令行路径）：
 *   本程序是一个正常的 aarch64 可执行文件，原始 kpm 原样追加在它尾部。
 *   追加不破坏本文件自身的 ELF 合法性，所以：
 *     - 命令行：./huanyu_v1.69.0.run <superkey> [参数]   → 自己抠出尾巴并加载
 *     - APatch ：用单独的 huanyu_v1.69.0.kpm（ET_REL 原样）→ App 正常加载
 *
 * 尾部布局（footer 固定在文件末尾 20 字节，可流式读取，无需整文件入内存）：
 *     [loader ELF][kpm 原始字节][BLOB_MAGIC 12B][长度 8B 小端]
 *
 * 用法：
 *   ./huanyu.run <superkey> [模块参数...]
 *   ./huanyu.run --kp=0.13.9 <superkey>          显式指定 KernelPatch 版本
 *   ./huanyu.run -o /data/local/tmp/h.kpm <superkey>   指定释放路径
 *   ./huanyu.run --unload <superkey>
 */
#define AT_FDCWD (-100)
#ifndef NULL
#define NULL ((void *)0)
#endif

typedef unsigned long u64;
typedef long i64;
typedef unsigned int u32;
typedef unsigned char u8;

/* ---------- 裸 syscall（arm64） ---------- */
static long sysc6(long n, long a1, long a2, long a3, long a4, long a5, long a6)
{
    register long x8 __asm__("x8") = n;
    register long x0 __asm__("x0") = a1;
    register long x1 __asm__("x1") = a2;
    register long x2 __asm__("x2") = a3;
    register long x3 __asm__("x3") = a4;
    register long x4 __asm__("x4") = a5;
    register long x5 __asm__("x5") = a6;
    __asm__ __volatile__("svc #0"
                         : "+r"(x0)
                         : "r"(x8), "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5)
                         : "memory", "cc");
    return x0;
}
#define SYS_OPENAT 56
#define SYS_CLOSE  57
#define SYS_LSEEK  62
#define SYS_READ   63
#define SYS_WRITE  64
#define SYS_EXIT   93
#define SYS_EXIT_GROUP 94

static long sys_openat(const char *p, int flags, int mode)
{
    return sysc6(SYS_OPENAT, AT_FDCWD, (long)p, flags, mode, 0, 0);
}
static long sys_read(int fd, void *b, u64 n)
{
    return sysc6(SYS_READ, fd, (long)b, (long)n, 0, 0, 0);
}
static long sys_write(int fd, const void *b, u64 n)
{
    return sysc6(SYS_WRITE, fd, (long)b, (long)n, 0, 0, 0);
}
static long sys_lseek(int fd, i64 off, int whence)
{
    return sysc6(SYS_LSEEK, fd, off, whence, 0, 0, 0);
}
static long sys_close(int fd) { return sysc6(SYS_CLOSE, fd, 0, 0, 0, 0, 0); }

/* ---------- 最小字符串/内存 ---------- */
static u64 slen(const char *s) { u64 n = 0; while (s[n]) n++; return n; }
static int scmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (int)((unsigned char)*a) - (int)((unsigned char)*b);
}
static int sncmp(const char *a, const char *b, u64 n)
{
    for (u64 i = 0; i < n; i++) { if (!b[i]) return 0; if (a[i] != b[i]) return 1; }
    return 0;
}
static void *mcpy(void *d, const void *s, u64 n)
{
    u8 *dd = d; const u8 *ss = s;
    for (u64 i = 0; i < n; i++) dd[i] = ss[i];
    return d;
}
static int mcmp(const void *a, const void *b, u64 n)
{
    const u8 *x = a, *y = b;
    for (u64 i = 0; i < n; i++) if (x[i] != y[i]) return x[i] - y[i];
    return 0;
}

/* ---------- 输出（走 write，不用 stdio） ---------- */
static void out(const char *s) { sys_write(1, s, slen(s)); }
static void outn(const char *s, u64 n) { sys_write(1, s, n); }

static u64 u2s(u64 v, char *b)
{
    char t[24]; u64 n = 0;
    if (!v) t[n++] = '0';
    while (v) { t[n++] = (char)('0' + (v % 10)); v /= 10; }
    for (u64 i = 0; i < n; i++) b[i] = t[n - 1 - i];
    return n;
}
static void out_u(const char *pre, u64 v, const char *post)
{
    char b[24];
    if (pre) out(pre);
    outn(b, u2s(v, b));
    if (post) out(post);
}
static void out_i(const char *pre, i64 v, const char *post)
{
    if (pre) out(pre);
    if (v < 0) { out("-"); out_u(NULL, (u64)(-v), NULL); }
    else out_u(NULL, (u64)v, NULL);
    if (post) out(post);
}

/* ---------- supercall ---------- */
#define NR_SUPERCALL          45
#define SUPERCALL_HELLO       0x1000
#define SUPERCALL_KPM_LOAD    0x1020
#define SUPERCALL_KPM_UNLOAD  0x1021

#define DEFAULT_OUT     "/data/local/tmp/huanyu_v1.69.0.kpm"
#define DEFAULT_MODNAME "huanyu"
#define BLOB_MAGIC      "HUANYUKBLOB1"
#define BLOB_MAGIC_LEN  12
#define FOOTER_LEN      (BLOB_MAGIC_LEN + 8)

static int kp_major = 0, kp_minor = 13, kp_patch = 9;

static long ver_and_cmd(long cmd)
{
    long vc = (long)((kp_major << 16) + (kp_minor << 8) + kp_patch);
    return (vc << 32) | (0x1158L << 16) | (cmd & 0xFFFFL);
}

static long sc(long key_ptr, long cmd, long a1, long a2, long a3)
{
    register long x8 __asm__("x8") = NR_SUPERCALL;
    register long x0 __asm__("x0") = key_ptr;
    register long x1 __asm__("x1") = cmd;
    register long x2 __asm__("x2") = a1;
    register long x3 __asm__("x3") = a2;
    register long x4 __asm__("x4") = a3;
    __asm__ __volatile__("svc #0"
                         : "+r"(x0)
                         : "r"(x8), "r"(x1), "r"(x2), "r"(x3), "r"(x4)
                         : "memory", "cc");
    return x0;
}

/* ---------- 从自身尾部取出 kpm（流式，不整读） ---------- */
static i64 self_size(int fd)
{
    i64 end = sys_lseek(fd, 0, 2 /*SEEK_END*/);
    if (end < 0) return -1;
    return end;
}

static int extract_self(const char *out_path, u64 *out_len)
{
    int fd = sys_openat("/proc/self/exe", 0 /*O_RDONLY*/, 0);
    if (fd < 0) { out("打开 /proc/self/exe 失败\n"); return -1; }

    i64 size = self_size(fd);
    if (size < (i64)FOOTER_LEN + 16) {
        out("自身文件过小，不像带内嵌模块的加载器\n");
        sys_close(fd); return -1;
    }

    u8 footer[FOOTER_LEN];
    if (sys_lseek(fd, size - (i64)FOOTER_LEN, 0 /*SEEK_SET*/) < 0) { sys_close(fd); return -1; }
    i64 got = 0;
    while (got < (i64)FOOTER_LEN) {
        long n = sys_read(fd, footer + got, (u64)(FOOTER_LEN - got));
        if (n < 0) { sys_close(fd); return -1; }
        if (n == 0) break;
        got += n;
    }
    if (got != (i64)FOOTER_LEN) { out("尾部标记读取不完整\n"); sys_close(fd); return -1; }

    if (mcmp(footer, BLOB_MAGIC, BLOB_MAGIC_LEN) != 0) {
        out("尾部没找到内嵌模块标记（本文件未附带模块）\n");
        sys_close(fd); return -1;
    }
    u64 klen = 0;
    for (int i = 7; i >= 0; i--) klen = (klen << 8) | footer[BLOB_MAGIC_LEN + i];
    if (klen == 0 || klen > (u64)size - FOOTER_LEN) {
        out("内嵌模块长度非法: ");
        out_u(NULL, klen, "\n");
        sys_close(fd); return -1;
    }

    i64 start = size - (i64)FOOTER_LEN - (i64)klen;
    if (sys_lseek(fd, start, 0) < 0) { sys_close(fd); return -1; }

    int of = sys_openat(out_path, 0101 /*O_WRONLY|O_CREAT*/ | 01000 /*O_TRUNC*/, 0644);
    if (of < 0) { out("写 "); out(out_path); out(" 失败\n"); sys_close(fd); return -1; }

    u8 buf[65536];
    u64 left = klen;
    while (left) {
        u64 want = left > sizeof(buf) ? sizeof(buf) : left;
        long n = sys_read(fd, buf, want);
        if (n < 0) { sys_close(of); sys_close(fd); return -1; }
        if (n == 0) break;
        u64 w = 0;
        while (w < (u64)n) {
            long m = sys_write(of, buf + w, (u64)n - w);
            if (m <= 0) { sys_close(of); sys_close(fd); return -1; }
            w += (u64)m;
        }
        left -= (u64)n;
    }
    sys_close(of);
    sys_close(fd);
    *out_len = klen;
    return 0;
}

static void usage(void)
{
    out("欢愉命令行加载器（内嵌模块）\n"
        "  用法: <本文件> <superkey> [模块参数...]\n"
        "        <本文件> --kp=0.13.9 <superkey>      显式指定 KernelPatch 版本\n"
        "        <本文件> -o <落盘路径> <superkey>     指定模块释放位置\n"
        "        <本文件> --unload <superkey>          卸载模块\n"
        "        <本文件> -x [-o <路径>]                只释放内嵌 .kpm（给 APatch App）\n"
        "  模块参数原样传给内核，例如: \"touch=1 grab=1\"\n");
}

static int parse_ver(const char *s, int *M, int *m, int *p)
{
    int v[3] = {0, 0, 0}, i = 0;
    const char *c = s;
    while (*c && i < 3) {
        if (*c >= '0' && *c <= '9') { v[i] = v[i] * 10 + (*c - '0'); c++; }
        else if (*c == '.') { i++; c++; }
        else return -1;
    }
    if (i != 2) return -1;
    *M = v[0]; *m = v[1]; *p = v[2];
    return 0;
}

/* used：防止 LTO 认为它无人引用而删除（_start 里的 bl 对编译器不可见） */
__attribute__((used)) int real_main(int argc, char **argv)
{
    const char *superkey = NULL;
    const char *out_path = DEFAULT_OUT;
    const char *mod_name = DEFAULT_MODNAME;
    int do_unload = 0;
    int do_extract = 0;
    char args_buf[1024];
    u64 args_len = 0;
    args_buf[0] = 0;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!sncmp(a, "--kp=", 5)) {
            int M, m, p;
            if (parse_ver(a + 5, &M, &m, &p) != 0) { out("--kp 格式应为主.次.补丁\n"); return 2; }
            kp_major = M; kp_minor = m; kp_patch = p;
        } else if (!scmp(a, "-k") || !scmp(a, "--key")) {
            if (++i >= argc) { out("-k 后缺少 superkey\n"); return 2; }
            superkey = argv[i];
        } else if (!scmp(a, "-o") || !scmp(a, "--out")) {
            if (++i >= argc) { out("-o 后缺少路径\n"); return 2; }
            out_path = argv[i];
        } else if (!scmp(a, "--unload")) {
            do_unload = 1;
        } else if (!scmp(a, "--extract") || !scmp(a, "-x")) {
            do_extract = 1;
        } else if (!scmp(a, "-h") || !scmp(a, "--help")) {
            usage(); return 0;
        } else if (!superkey) {
            superkey = a;
        } else {
            u64 al = slen(a);
            if (args_len && args_len + 1 + al + 1 < sizeof(args_buf)) {
                args_buf[args_len++] = ' ';
                mcpy(args_buf + args_len, a, al);
                args_len += al;
                args_buf[args_len] = 0;
            }
        }
    }

    /* 只把内嵌模块释放出来（给 APatch App 用），不需要 superkey */
    if (do_extract) {
        u64 elen = 0;
        if (extract_self(out_path, &elen) != 0) return 1;
        out("已提取模块到 "); out(out_path); out("（");
        out_u(NULL, elen, " 字节）\n");
        out("把这个 .kpm 交给 APatch App 即可加载\n");
        return 0;
    }

    if (!superkey) { usage(); return 2; }

    long hello = sc((long)(u64)(unsigned long)superkey, ver_and_cmd(SUPERCALL_HELLO), 0, 0, 0);
    if (hello < 0) {
        out("supercall 不可用（ret=");
        out_i(NULL, hello, ")\n");
        out("  可能原因：superkey 不对，或 KernelPatch 版本不是 ");
        out_u(NULL, (u64)kp_major, ".");
        out_u(NULL, (u64)kp_minor, ".");
        out_u(NULL, (u64)kp_patch, "\n");
        out("  用 --kp=<主>.<次>.<补丁> 显式指定版本再试\n");
        return 1;
    }
    out("supercall OK（KernelPatch ");
    out_u(NULL, (u64)kp_major, ".");
    out_u(NULL, (u64)kp_minor, ".");
    out_u(NULL, (u64)kp_patch, "）\n");

    if (do_unload) {
        long r = sc((long)(u64)(unsigned long)superkey, ver_and_cmd(SUPERCALL_KPM_UNLOAD),
                    (long)(u64)(unsigned long)mod_name, 0, 0);
        if (r < 0) { out("卸载失败 ret="); out_i(NULL, r, "\n"); return 1; }
        out("已卸载 "); out(mod_name); out("\n");
        return 0;
    }

    u64 klen = 0;
    if (extract_self(out_path, &klen) != 0) return 1;
    out("已释放模块到 "); out(out_path); out("（");
    out_u(NULL, klen, " 字节）\n");

    long r = sc((long)(u64)(unsigned long)superkey, ver_and_cmd(SUPERCALL_KPM_LOAD),
                (long)(u64)(unsigned long)out_path,
                (long)(u64)(unsigned long)args_buf, 0);
    if (r < 0) {
        out("加载失败 ret="); out_i(NULL, r, "\n");
        out("  常见原因：模块已加载（先 --unload）、内核版本不匹配、KP 版本不符\n");
        return 1;
    }
    out("加载成功（ret="); out_i(NULL, r, "）参数：\"");
    out(args_buf); out("\"\n");
    out("查看状态：cat /proc/Huanyu   或   echo 'handshake' > /proc/HuanyuD\n");
    return 0;
}

/*
 * 入口：必须用 naked + 纯汇编取 argc/argv。
 * 若写成普通 C 函数再用内联汇编写 "mov %0, sp"，编译器可能在函数前言里
 * 先压栈/调整 sp，此时读到的就不是内核放置的 argc/argv 了。
 */
__attribute__((naked, noreturn)) void _start(void)
{
    __asm__ __volatile__(
        "mov x9, sp\n"        /* x9 = &argc（内核置栈：argc, argv..., envp, auxv） */
        "ldr w0, [x9]\n"      /* w0 = argc */
        "add x1, x9, #8\n"    /* x1 = argv */
        "bl real_main\n"      /* 返回值落在 x0 */
        "mov x8, #94\n"       /* SYS_exit_group */
        "svc #0\n"
        :
        :
        : "memory");
}
