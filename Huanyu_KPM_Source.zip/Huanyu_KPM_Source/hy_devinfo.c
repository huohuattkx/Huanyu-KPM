/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_devinfo.c —— 设备信息（供 /proc/Huanyu 的 [device] 段显示）
 *
 * 【为什么不放在内核态采集】
 *   v1.35 ~ v1.38 连续四版"加载即炸"，根因都是内核态读文件：
 *   KPM 没有 struct file 布局，filp_open / kernel_read 只能靠
 *   kallsyms 拿地址 + 自己声明原型，ABI 一旦对不上就是 oops。
 *   而且 filp_open 失败返回的是 ERR_PTR(-ENOENT) 这类极小负数，
 *   不是 NULL —— 用 if (!file) 根本拦不住。
 *
 *   设备信息本就属于用户态范畴（getprop / /proc/version / /proc/cpuinfo）。
 *   所以这里改成：
 *     - 内核侧只提供一个纯静态字符缓冲区（零符号、零结构体、零 I/O）
 *     - 用户态 HuanyuD 负责采集，通过调试命令一行一行写进来
 *     - 取不到就显示 unknown，绝不影响加载
 *
 * 【内核自己能给的】只有 kver（KernelPatch 提供的全局变量，不需要解析符号）
 *   和屏幕尺寸（触摸模块已有）。其余一律由用户态补充。
 */
#include <linux/printk.h>
#include <linux/string.h>
#include <kpmodule.h>
#include "hy.h"

/*
 * 【v1.44.0】1024 -> 4096 字节。
 *   HuanyuD devinfo 现在上报约 45 行（机型/版本/SOC/ABI/安全补丁/基带等），
 *   1024 字节装不下，后面的行会被静默丢弃。
 */
#define HY_DEVINFO_CAP    4096
#define HY_DEVINFO_LINE   160

static char g_devinfo[HY_DEVINFO_CAP];

/* ==================== 对外接口 ==================== */

const char *hy_devinfo_text(void)
{
    return g_devinfo;
}

int hy_devinfo_reset(void)
{
    g_devinfo[0] = 0;
    return 0;
}

/*
 * 追加一行。line 里自带或不带 '\n' 都行，这里统一补上。
 * 缓冲区满则丢弃，不做搬移（避免 memmove 类操作引入意外符号）。
 */
int hy_devinfo_add(const char *line)
{
    unsigned long used = 0;
    unsigned long i = 0;

    if (!line || !line[0]) return -EINVAL;

    while (used < HY_DEVINFO_CAP && g_devinfo[used]) used++;

    for (i = 0; line[i]; i++) {
        if (used + 1 >= HY_DEVINFO_CAP - 1) break;
        g_devinfo[used++] = line[i];
    }
    if (used + 1 >= HY_DEVINFO_CAP - 1) {
        g_devinfo[used] = 0;
        return -ENOSPC;
    }
    if (used > 0 && g_devinfo[used - 1] != '\n')
        g_devinfo[used++] = '\n';
    g_devinfo[used] = 0;
    return 0;
}

/* ==================== 内核自采（有防护，失败即 unknown） ==================== */

/*
 * 【v1.44.0】补两个内核能安全给的标量，让用户不跑 HuanyuD 也能看到基本信息。
 *
 * 为什么是这两个：
 *   nr_cpu_ids    —— int 全局变量，内核数据段，只读一个 4 字节
 *   totalram_pages—— unsigned long 全局变量，同理
 *   两者都是"平坦标量"，不涉及任何结构体布局，风险远低于读文件。
 *
 * 三重防护（宁可 unknown 也不冒险）：
 *   1) 符号解析失败 -> 跳过
 *   2) 地址必须落在内核范围（arm64 线性映射区）
 *   3) 值必须落在合理区间（cpu 1~512，ram 1MB~1TB），否则判定为解析错乱
 * 任一不满足就什么都不写，绝不让可疑地址参与解引用。
 */
static unsigned long hy_devinfo_kaddr_ok(unsigned long a)
{
    if (!a) return 0;
    if (a < 0xffffff8000000000UL) return 0;      /* 非 arm64 内核地址 */
    if (a & 7UL) return 0;                        /* 未 8 字节对齐 */
    return 1;
}

static void hy_devinfo_num(char *buf, unsigned long cap, unsigned long v)
{
    char tmp[24];
    unsigned long n = 0, i;

    if (cap == 0) return;
    if (v == 0) { buf[0] = '0'; buf[1] = 0; return; }
    while (v && n < sizeof(tmp) - 1) {
        tmp[n++] = (char)('0' + (int)(v % 10UL));
        v /= 10UL;
    }
    for (i = 0; i < n && i < cap - 1; i++) buf[i] = tmp[n - 1 - i];
    buf[i < cap ? i : cap - 1] = 0;
}

void hy_devinfo_autofill(void)
{
    unsigned long a;
    char line[HY_DEVINFO_LINE];
    unsigned long i, p;

    /* --- CPU 核数 --- */
    a = hy_lookup_generic("nr_cpu_ids");
    if (hy_devinfo_kaddr_ok(a)) {
        unsigned int v = *(volatile unsigned int *)a;
        if (v >= 1 && v <= 512) {
            char num[24];
            hy_devinfo_num(num, sizeof(num), (unsigned long)v);
            p = 0;
            for (i = 0; "cpus="[i]; i++)
                if (p + 1 < sizeof(line)) line[p++] = "cpus="[i];
            for (i = 0; num[i]; i++)
                if (p + 1 < sizeof(line)) line[p++] = num[i];
            line[p] = 0;
            hy_devinfo_add(line);
        }
    }

    /* --- 物理内存总量（页数 -> MB） --- */
    a = hy_lookup_generic("totalram_pages");
    if (hy_devinfo_kaddr_ok(a)) {
        unsigned long pg = *(volatile unsigned long *)a;
        unsigned long mb;
        if (pg >= 256 && pg <= (1UL << 34)) {     /* 1MB ~ 64GB */
            char num[24];
            mb = pg >> 8;                          /* pages * 4K / 1024 / 1024 */
            hy_devinfo_num(num, sizeof(num), mb);
            p = 0;
            for (i = 0; "ram_mb="[i]; i++)
                if (p + 1 < sizeof(line)) line[p++] = "ram_mb="[i];
            for (i = 0; num[i]; i++)
                if (p + 1 < sizeof(line)) line[p++] = num[i];
            line[p] = 0;
            hy_devinfo_add(line);
        }
    }
}

/* ==================== 内核自采（零符号依赖） ==================== */

/*
 * kver 由 KernelPatch 提供，格式 (major<<16)|(minor<<8)|patch。
 * 这里只做解码打印，不解析任何符号。
 */
void hy_devinfo_kernel_ver(char *out, unsigned long cap)
{
    unsigned long major = (kver >> 16) & 0xff;
    unsigned long minor = (kver >> 8) & 0xff;
    unsigned long patch = kver & 0xff;
    unsigned long pos = 0;
    char num[24];
    const char *p;
    unsigned long k;

    if (!out || cap == 0) return;
    out[0] = 0;

    /* 极简 u32 -> 十进制，避免引入 snprintf */
    {
        unsigned long v = major;
        unsigned long n = 0, j;
        char tmp[16];
        if (v == 0) { num[0] = '0'; num[1] = 0; }
        else {
            while (v && n < sizeof(tmp) - 1) {
                tmp[n++] = (char)('0' + (int)(v % 10UL));
                v /= 10UL;
            }
            for (j = 0; j < n; j++) num[j] = tmp[n - 1 - j];
            num[n] = 0;
        }
    }
    for (p = num; *p && pos + 1 < cap; p++) out[pos++] = *p;
    if (pos + 1 < cap) out[pos++] = '.';

    {
        unsigned long v = minor, n = 0, j;
        char tmp[16];
        if (v == 0) { num[0] = '0'; num[1] = 0; }
        else {
            while (v && n < sizeof(tmp) - 1) {
                tmp[n++] = (char)('0' + (int)(v % 10UL));
                v /= 10UL;
            }
            for (j = 0; j < n; j++) num[j] = tmp[n - 1 - j];
            num[n] = 0;
        }
    }
    for (p = num; *p && pos + 1 < cap; p++) out[pos++] = *p;
    if (pos + 1 < cap) out[pos++] = '.';

    {
        unsigned long v = patch, n = 0, j;
        char tmp[16];
        if (v == 0) { num[0] = '0'; num[1] = 0; }
        else {
            while (v && n < sizeof(tmp) - 1) {
                tmp[n++] = (char)('0' + (int)(v % 10UL));
                v /= 10UL;
            }
            for (j = 0; j < n; j++) num[j] = tmp[n - 1 - j];
            num[n] = 0;
        }
    }
    for (p = num; *p && pos + 1 < cap; p++) out[pos++] = *p;

    /* 附原始 hex，便于核对解码是否正确 */
    if (pos + 12 < cap) {
        static const char *hexd = "0123456789abcdef";
        unsigned long v = (unsigned long)kver;
        int s;
        out[pos++] = ' ';
        out[pos++] = '(';
        out[pos++] = '0';
        out[pos++] = 'x';
        for (s = 28; s >= 0; s -= 4) {
            if (pos + 1 < cap) out[pos++] = hexd[(v >> s) & 0xfUL];
        }
        out[pos++] = ')';
    }
    out[pos] = 0;

    (void)k;
}
