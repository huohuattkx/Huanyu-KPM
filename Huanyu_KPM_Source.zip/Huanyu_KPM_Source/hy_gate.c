/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_gate.c —— 版本 / 挑战-响应握手闸门（v1.71.0）
 *
 * ==========================================================================
 * 【要解决什么】
 *   用户态对接文件与内核 kpm 是两个独立分发的产物。一旦版本没同步，
 *   命令号、结构体布局、语义都可能对不上 —— 轻则读到脏数据（比如
 *   之前地址换算差一个页那种），重则把垃圾指针传进内核直接 oops。
 *
 *   所以这里立一道闸门：用户态上来先自报版本号，再完成一轮挑战-响应，
 *   两项都对才放行后续所有命令。
 *
 * 【为什么 v1.71.0 改成挑战-响应】
 *   v1.70.0 是用户态把五层密钥逐层明文送进内核比对。密钥一旦进了内核
 *   缓冲区，下一次加载时若 kpm 被换掉、或握手路径被人在中间插一脚，
 *   整串钥匙就交出去了。
 *
 *   现在反过来：内核 **从不接收密钥**。
 *     内核：造 32 字节随机明文 → 用五层密钥加密 → 把密文发给用户态
 *     用户态：用自己那份五层密钥解开 → 把明文发回来
 *     内核：拿回来的明文和自己那份原文逐字节比对，一致才放行
 *   解对了才可能送对。密钥全程只在各自的内存里参与运算，
 *   一次都没有跨越内核 / 用户态边界。
 *
 * 【加密为什么用这么朴素的算法】
 *   这里的敌人不是密码分析者，而是"密钥没同步"和"拿旧版对接文件连新版
 *   内核"。所以只需要一个可逆、确定、无 libc 依赖、内核侧和用户态侧能
 *   逐字节写出同样结果的变换。刻意不用 AES —— 那要引入真随机源和
 *   更大的查找表，得不偿失，而且安全性依然完全取决于密钥本身。
 *
 * 【真随机源的问题】
 *   KP 只导出有限符号，get_random_bytes / ktime_get_ns 都不保证在表里。
 *   所以这里不引入任何新符号：用 xorshift64 自走，种子取加载期可变量。
 *   这不影响安全性 —— 攻击者即使能预测下一次明文，也必须掌握五层密钥
 *   才能把它从密文里解出来；而"录下一次成功的应答然后重放"也无效，
 *   因为每次握手都是新的明文。
 *
 * 【放行规则】
 *   只有两个命令号无条件放行：
 *     HY_NR_VERSION    —— 让用户态能问出内核到底是什么版本
 *     HY_NR_HANDSHAKE  —— 让用户态能重试握手
 *   其余一律 -EACCES，不执行、不读用户态 payload。
 *
 * 【两条打印纪律】
 *   版本不一致：内核和用户态 **都** 打印双方版本号。
 *     这是"文件没同步"这类工程问题，说清各自是多少就能立刻定位，
 *     而且版本号本来就是公开的，没有保密价值。
 *
 *   密钥不一致：内核 **只说应答不匹配**，一个字符、一位长度都不透露。
 *     dmesg / pstore 是整机可读的公共区域，任何落在那里的字节都等于
 *     公开。内核现在连期望值都不接收了，想说也说不出来 ——
 *     用户态那把钥匙是用户自己的，由用户态打印，内核不代劳。
 *
 * 【为什么比对不用 strlen】
 *   用户态传进来的缓冲区可能没有 '\0'（截断、越界、恶意构造都会）。
 *   一旦 strlen 跨过页边界读到未映射地址，就是在内核里踩空。
 *   挑战明文是二进制数据，中间本来就可能含 0x00，更不能按字符串处理。
 *   所以全部走定长比较：缓冲区多大就比多少。
 * ========================================================================== */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>

#include "hy.h"

/* ---------------------------------------------------------------- 状态 */
static int g_hs_ok;                /* 1 = 两步都过，放行全部命令 */
static unsigned int g_hs_tries;    /* 握手尝试次数（失败也算） */
static int g_ver_bad;              /* 最近一次：版本不一致 */
static int g_key_bad;              /* 最近一次：应答与原文不一致 */
static unsigned int g_hs_step;     /* 最近一次处理到的阶段（1/2） */
static unsigned int g_blocked;     /* 因未握手而被拦掉的命令数 */

/* 最近一次上报来的用户态版本，供 /proc 观察，不参与决策 */
static unsigned int g_uver_major;
static unsigned int g_uver_minor;

/*
 * 挑战-响应的内部状态。
 *
 * g_chal_plain 是内核自己造的原文，永远不出内核；
 * g_chal_valid 表示"当前有一份待应答的挑战"，防止用户态跳过第 1 步
 * 直接交应答，也防止一份挑战被应答两次。
 */
static unsigned char g_chal_plain[HY_CHAL_LEN];
static int g_chal_valid;
static int g_prng_seeded;   /* xorshift 从 0 起会恒为 0，必须播种一次 */

/* xorshift64 状态：只用于造挑战明文，不用于任何安全边界判定 */
static u64 g_chal_prng;

/* ------------------------------------------------------- 挑战明文生成 */

static u64 chal_prng_next(void)
{
    u64 x = g_chal_prng;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    g_chal_prng = x;
    return x;
}

/*
 * 播种。刻意不解析任何内核符号 —— 少一个依赖就少一个失败点。
 * 种子混合：静态变量地址（KASLR 下每次加载都不同）+ 两个奇常数。
 */
static void chal_prng_seed(void)
{
    u64 a = (u64)(unsigned long)&g_chal_plain[0];
    u64 b = (u64)(unsigned long)&g_chal_prng;
    u64 v = a ^ (b << 17) ^ 0x9E3779B97F4A7C15ULL ^ (a >> 13);
    if (v == 0) v = 0xD1B54A32D192ED03ULL;
    g_chal_prng = v;
    /* 先空转几轮，打散地址低位常见的对齐规律 */
    (void)chal_prng_next();
    (void)chal_prng_next();
    (void)chal_prng_next();
}

/* ------------------------------------------------------- 五层加/解密 */

/*
 * 单层正向变换（加密方向）。
 *
 *   buf[i] = rol( buf[i] ^ key[i % klen] ^ prev, rot )
 *   prev 是上一个字节变换后的结果，形成链式扩散 ——
 *   改一个字节会顺着链影响到后面所有字节，避免逐字节独立带来的
 *   "改明文某一位只影响密文同位"的弱点。
 *
 * klen 是这一层密钥的字节数（不含结尾 NUL）。key 只读，永不写出。
 */
static void chal_layer_fwd(unsigned char *buf, unsigned long len,
                           const char *key, unsigned long klen)
{
    unsigned long i;
    unsigned char prev = 0xA5u;
    unsigned int acc = 0u;
    unsigned int rot;

    if (klen == 0) return;
    for (i = 0; i < klen; i++)
        acc = (unsigned int)(acc + (unsigned char)key[i]);
    rot = (acc % 7u) + 1u;          /* 1..7，避开 0 和 8（8 位下等价 0） */

    for (i = 0; i < len; i++) {
        unsigned int v = (unsigned int)buf[i];
        v ^= (unsigned int)(unsigned char)key[i % klen];
        v ^= (unsigned int)prev;
        v &= 0xFFu;
        buf[i] = (unsigned char)((v << rot) | (v >> (8 - rot)));
        prev = buf[i];
    }
}

/*
 * 【解密在哪】
 *   内核只加密、从不解密 —— 它比的是"用户态送回来的明文"和
 *   "自己留的那份原文"，压根不需要把密文解开。
 *   逆向变换（chal_layer_inv）由用户态对接文件实现，
 *   两边算法逐字节对齐，见 huanyu_wanbai.hpp / huanyu.hpp 里的同名函数。
 *
 *   必须 **从后往前** 走：加密时 prev 是"上一个字节变换后"的值，
 *   逆序处理时 buf[j-1] 还没被还原、仍然等于加密后的值 —— 正好就是
 *   当初那个 prev。顺着走反而拿不到。
 */

/* 加密：按 L1 → L2 → L3 → L4 → L5 的顺序逐层正向变换 */
static void chal_encrypt(unsigned char *buf, unsigned long len)
{
    chal_layer_fwd(buf, len, HY_KEY_L1, (unsigned long)HY_KEY_LEN_L1);
    chal_layer_fwd(buf, len, HY_KEY_L2, (unsigned long)HY_KEY_LEN_L2);
    chal_layer_fwd(buf, len, HY_KEY_L3, (unsigned long)HY_KEY_LEN_L3);
    chal_layer_fwd(buf, len, HY_KEY_L4, (unsigned long)HY_KEY_LEN_L4);
    chal_layer_fwd(buf, len, HY_KEY_L5, (unsigned long)HY_KEY_LEN_L5);
}

static int gate_str_eq(const char *a, const char *b, unsigned long n)
{
    unsigned long i;
    for (i = 0; i < n; i++) {
        unsigned char ca = (unsigned char)a[i];
        unsigned char cb = (unsigned char)b[i];
        if (ca != cb) return 1;
        if (ca == 0) return 0;      /* 同时结束，相等 */
    }
    /* 走完 n 字节都没遇到 '\0'：两侧都被截断，视为不相等 */
    return 1;
}

/*
 * 定长复制：把内核版本串写进用户态缓冲区。
 * 只写 cap 字节以内，末尾一定补 '\0'，不依赖源串是否带终止符。
 */
static void gate_put_ver(char *dst, unsigned long cap)
{
    unsigned long i;
    if (!dst || cap == 0) return;
    for (i = 0; i < cap - 1; i++) {
        char c = HY_VERSION_STRING[i];
        dst[i] = c;
        if (c == 0) return;
    }
    dst[cap - 1] = 0;
}

/*
 * 从 magic 里解出阶段号。
 *
 * 阶段号在高 16 位，低 16 位必须仍是 HY_MAGIC 的低半段。
 * 这样 v1.70.0 及更早的用户态（发的是层号 0..4，编码后高半段是 1..5）
 * 只有第 1 层、第 2 层这两档会被误认成 REQ / ANS —— 所以额外规定：
 * REQ 步必须带合法版本串，ANS 步必须已有待应答的挑战。
 * 旧版对接文件即使蒙对阶段号，也过不了这两道。
 */
static int gate_step_of(u32 magic, unsigned int *step)
{
    u32 mark = magic >> 16;
    u32 low  = magic & 0xFFFFu;

    if (low != HY_KEY_MAGIC_LOW) return -1;
    if (mark != (u32)HY_HS_STEP_REQ && mark != (u32)HY_HS_STEP_ANS) return -1;
    *step = (unsigned int)mark;
    return 0;
}

/*
 * 定长二进制比较：只比 len 个字节，不理会中间有没有 0x00。
 * 挑战明文是随机字节流，本来就可能含 0，绝不能按字符串处理。
 *
 * 刻意写成"累加差异"而不是"首次不同就返回"，让比较耗时与
 * "第几个字节开始不同"无关 —— 免得被计时侧信道逐字节试出原文。
 * 挑战明文只在一次握手内有效，实用价值不大，但顺手做到。
 */
static int gate_mem_eq(const unsigned char *a, const unsigned char *b,
                       unsigned long len)
{
    unsigned long i;
    unsigned int diff = 0u;

    for (i = 0; i < len; i++)
        diff |= (unsigned int)(a[i] ^ b[i]);
    return diff == 0u;
}

/*
 * 挑战作废：下次必须重新走 REQ 步。
 * 顺手把原文用随机字节覆盖掉，不留上一轮的痕迹。
 */
static void gate_chal_drop(void)
{
    unsigned long i;

    if (!g_prng_seeded) {
        chal_prng_seed();
        g_prng_seeded = 1;
    }
    for (i = 0; i < HY_CHAL_LEN; i++)
        g_chal_plain[i] = (unsigned char)chal_prng_next();
    g_chal_valid = 0;
}

/* ---------------------------------------------------------------- 查询 */
int hy_gate_state(void)
{
    return g_hs_ok;
}

unsigned int hy_gate_blocked(void)
{
    return g_blocked;
}

/*
 * 命令是否放行。
 * 在 hy_ctl_switch 最开头调用 —— prctl / supercall / 共享内存
 * 三条通道最终都汇入那里，所以这里拦一道就能覆盖全部入口。
 */
int hy_gate_allow(unsigned int nr)
{
    if (g_hs_ok) return 1;
    if (nr == HY_NR_VERSION) return 1;
    if (nr == HY_NR_HANDSHAKE) return 1;

    /* 未握手就被拦下，只计数，不打日志 —— 否则刷屏 */
    g_blocked++;
    return 0;
}

/*
 * 握手处理。
 *
 * payload 完全来自用户态，任何字段都不可信：
 *   - 全部走定长比较，不调 strlen
 *   - 用户态版本字符串只用于打印，长度上限就是结构体里那个 24 字节
 */
int hy_gate_handshake(struct hy_handshake_req *r)
{
    unsigned int step = 0;
    int ver_ok;
    char uver_backup[24];

    if (!r) return -EINVAL;

    g_hs_tries++;
    g_uver_major = r->uver_major;
    g_uver_minor = r->uver_minor;

    /*
     * 先解阶段号 —— magic 在结构体最开头，用户态必然带着，读它永远安全。
     * 阶段号非法（含旧版裸 magic）一律作废挑战，不给任何中间态。
     */
    if (gate_step_of(r->magic, &step) != 0) {
        r->result    = HY_HS_BAD_MAGIC;
        r->lock_ver  = 0;
        r->lock_key  = 0;
        r->locked    = 0;
        /* 不清 g_hs_ok：见 REQ 步注释（v1.72.0，避免踢掉已握手会话） */
        g_key_bad = 1;
        g_hs_step = 0;
        gate_chal_drop();
        gate_put_ver(r->uver_str, sizeof(r->uver_str));
        pr_err("huanyu: 握手失败：阶段号或 magic 不匹配，禁止运行"
               "（请确认用户态对接文件是 v1.71.0 及以上，挑战-响应版）\n");
        return -EINVAL;
    }
    g_hs_step = step;

    /* 先把用户态版本留一份，下面 uver_str 会被内核版本覆写 */
    {
        unsigned long k;
        for (k = 0; k < sizeof(uver_backup) - 1; k++) {
            uver_backup[k] = r->uver_str[k];
            if (uver_backup[k] == 0) break;
        }
        uver_backup[sizeof(uver_backup) - 1] = 0;
    }

    /*
     * 出参：把内核版本串写回 uver_str 这个缓冲区。
     *
     * 【为什么不新增 kver_str 字段】
     *   结构体末尾加字段，内核读写时会越过旧版用户态传来的缓冲区边界 ——
     *   越界读可能踩未映射页直接 oops，越界写会破坏用户态栈帧。
     *   uver_str 是入参、用户态必然带着、固定 24 字节，
     *   复用它做回传零 ABI 变更、零越界风险。比对已做完，覆写无副作用。
     */
    gate_put_ver(r->uver_str, sizeof(r->uver_str));

    ver_ok = (gate_str_eq(uver_backup, HY_VERSION_STRING,
                          sizeof(uver_backup)) == 0);
    g_ver_bad = !ver_ok;

    /* ======================= 第 1 步：请求挑战 ======================= */
    if (step == (unsigned int)HY_HS_STEP_REQ) {
        unsigned long i;

        r->lock_key = 0;
        r->locked   = 0;
        /*
         * 【v1.72.0】这里**刻意不清 g_hs_ok**。
         *
         *   旧实现每次 REQ 都把 g_hs_ok 写 0。于是一个已经握手成功、
         *   正在正常读写的进程，会被另一个进程（或自己的重连、或一次
         *   失败重试）发起的 REQ 顺手踢下线 —— 后续命令全部 -EACCES，
         *   表现为"用着用着突然所有读写失败"，且极难定位。
         *
         *   现在 g_hs_ok 只由 ANS 成功置 1、任何失败路径都不置 0：
         *     首次连接：初始 0，握手不过就一直是 0 —— 拒绝语义不变。
         *     已连接后：别的进程怎么握手都不影响既有会话。
         *   想彻底重置只能重载模块，这符合"验证一次即信任"的语义。
         */
        if (!g_prng_seeded) {
            chal_prng_seed();
            g_prng_seeded = 1;
        }
        gate_chal_drop();

        /*
         * 版本不对就到此为止：不生成挑战、不放行。
         * 宁可让用户态卡在这一步，也不要发出一份注定白费的密文。
         */
        if (!ver_ok) {
            r->result   = HY_HS_BAD_VER;
            r->lock_ver = 0;
            pr_err("huanyu: 版本不一致，禁止运行 —— 内核版本=%s，用户态版本=%s\n",
                   HY_VERSION_STRING, uver_backup);
            return -EACCES;
        }

        /*
         * 先造原文存进内核，再拿同一份内容就地加密 —— 顺序很关键。
         * 密文出去、原文留下，两者一一对应，第 2 步才比得准。
         */
        for (i = 0; i < HY_CHAL_LEN; i++)
            g_chal_plain[i] = (unsigned char)chal_prng_next();

        {
            unsigned char tmp[HY_CHAL_LEN];
            for (i = 0; i < HY_CHAL_LEN; i++)
                tmp[i] = g_chal_plain[i];
            chal_encrypt(tmp, HY_CHAL_LEN);

            /*
             * key[264] 装 32 字节绰绰有余。密文是二进制、可能含 0x00，
             * 所以按字节定长拷，末尾补一个 NUL 方便用户态调试打印。
             * 用户态取用时按 HY_CHAL_LEN 定长读，不依赖这个 NUL。
             */
            for (i = 0; i < HY_CHAL_LEN; i++)
                r->key[i] = (char)tmp[i];
            r->key[HY_CHAL_LEN] = 0;

            /* 密文用完就抹，栈上不留 */
            for (i = 0; i < HY_CHAL_LEN; i++)
                tmp[i] = 0;
        }

        g_chal_valid = 1;
        r->result   = HY_HS_OK;
        r->lock_ver = 1;
        return 0;
    }

    /* ======================= 第 2 步：提交应答 ======================= */
    /*
     * 没有待应答的挑战就先交应答 —— 跳过第 1 步，或者拿一份过期挑战
     * 来蒙。一律拒绝，并作废掉任何残留状态。
     */
    if (!g_chal_valid) {
        r->result   = HY_HS_NO_CHAL;
        r->lock_ver = ver_ok ? 1u : 0u;
        r->lock_key = 0;
        r->locked   = 0;
        /* 同上：不清 g_hs_ok */
        g_key_bad   = 1;
        pr_err("huanyu: 握手失败：尚未请求挑战就提交应答，禁止运行"
               "（必须先走 HY_HS_STEP_REQ）\n");
        return -EACCES;
    }

    {
        unsigned char ans[HY_CHAL_LEN];
        unsigned long i;
        int ans_ok;

        /* 应答是二进制，按定长逐字节取，绝不按字符串 */
        for (i = 0; i < HY_CHAL_LEN; i++)
            ans[i] = (unsigned char)r->key[i];

        ans_ok = gate_mem_eq(ans, g_chal_plain, HY_CHAL_LEN);

        /* 比完立刻作废：一份挑战只允许应答一次，防重放 */
        gate_chal_drop();

        r->lock_key = ans_ok ? 1u : 0u;
        r->lock_ver = ver_ok ? 1u : 0u;

        if (ans_ok && ver_ok) {
            r->result = HY_HS_DONE;
            r->locked = 1;
            g_hs_ok   = 1;
            g_key_bad = 0;
            return 0;
        }

        /*
         * 【v1.72.0】失败路径同样**不清 g_hs_ok**。
         *   已经握手成功的会话是被五层密钥验证过的，不该被一次失败的
         *   重试（或另一个进程的试探）推翻。g_hs_ok 只在上面 ANS 成功
         *   分支置 1；从未握手时它本来就是 0，拒绝语义完全不变。
         */
        r->locked = 0;
        r->result = (!ver_ok && !ans_ok) ? HY_HS_BAD_BOTH
                                         : (ver_ok ? HY_HS_BAD_KEY
                                                   : HY_HS_BAD_VER);
        if (!ver_ok)
            pr_err("huanyu: 版本不一致，禁止运行 —— 内核版本=%s，用户态版本=%s\n",
                   HY_VERSION_STRING, uver_backup);

        /*
         * 应答不一致 = 五层密钥解错了。
         * 只说"不匹配"，不透露原文一个字节、不透露第几位不同。
         * 内核现在连密钥都不接收，想报"第几层错"也报不出来 ——
         * 详情由用户态自己提示（那套钥匙是用户自己的）。
         */
        if (!ans_ok) {
            g_key_bad = 1;
            pr_err("huanyu: 当前用户态key和huanyu不同 —— 禁止运行。"
                   "挑战应答与原文不匹配（五层密钥解错），"
                   "请核对用户态对接文件的 HY_KEY_L1..L5 是否与内核 hy.h 完全一致\n");
        }
        return -EACCES;
    }
}


/*
 * 文本拼接。
 *
 * 【为什么手写】
 *   KP 环境里 vsnprintf 不在导出表，自己写 variadic 又会让编译器生成
 *   对 memcpy 的隐式调用（KP 只导出 kf_memcpy，裸 memcpy 会成为未定义
 *   符号 —— 之前就是这么踩到的）。所以照搬 hy_ctl.c 里那套最小实现。
 */
static void gate_puts(char *buf, unsigned long cap, unsigned long *pos,
                      const char *s)
{
    while (*s && *pos + 1 < cap) buf[(*pos)++] = *s++;
    if (cap) buf[*pos] = 0;
}

static void gate_putu(char *buf, unsigned long cap, unsigned long *pos,
                      unsigned long v)
{
    char tmp[24];
    int k = 0;
    long j;

    if (v == 0) tmp[k++] = '0';
    while (v && k < 20) {
        tmp[k++] = (char)('0' + (unsigned)(v % 10UL));
        v /= 10UL;
    }
    for (j = k - 1; j >= 0 && *pos + 1 < cap; j--) buf[(*pos)++] = tmp[j];
    if (cap) buf[*pos] = 0;
}

static void gate_putyn(char *buf, unsigned long cap, unsigned long *pos,
                       int yes)
{
    gate_puts(buf, cap, pos, yes ? "yes" : "no");
}

/*
 * /proc 观察用：把闸门状态写成一段文本。
 * 只输出状态和版本号，绝不输出密钥的任何字符。
 */
void hy_gate_text(char *out, unsigned long cap)
{
    unsigned long pos = 0;

    if (!out || cap == 0) return;
    out[0] = 0;

    gate_puts(out, cap, &pos, "handshake    : ");

    if (g_hs_ok) {
        gate_puts(out, cap, &pos, "OK (挑战-响应通过)  kernel ver=");
        gate_puts(out, cap, &pos, HY_VERSION_STRING);
        gate_puts(out, cap, &pos, "  blocked=");
        gate_putu(out, cap, &pos, g_blocked);
        return;
    }

    if (g_hs_tries == 0) {
        gate_puts(out, cap, &pos, "NOT DONE  kernel ver=");
        gate_puts(out, cap, &pos, HY_VERSION_STRING);
        gate_puts(out, cap, &pos,
                  "  —— 用户态必须先发 HY_NR_HANDSHAKE："
                  "先 HY_HS_STEP_REQ 自报版本号取挑战密文，"
                  "再用五层密钥解开后以 HY_HS_STEP_ANS 送回明文");
        return;
    }

    gate_puts(out, cap, &pos, "FAILED  tries=");
    gate_putu(out, cap, &pos, g_hs_tries);

    gate_puts(out, cap, &pos, "  【内核版本=");
    gate_puts(out, cap, &pos, HY_VERSION_STRING);
    gate_puts(out, cap, &pos, "】");

    gate_puts(out, cap, &pos, "  【用户态版本=");
    gate_putu(out, cap, &pos, g_uver_major);
    gate_puts(out, cap, &pos, ".");
    gate_putu(out, cap, &pos, g_uver_minor);
    gate_puts(out, cap, &pos, "】");

    gate_puts(out, cap, &pos, "  版本一致=");
    gate_putyn(out, cap, &pos, !g_ver_bad);

    if (g_hs_step) {
        gate_puts(out, cap, &pos, "  上次阶段=");
        gate_putu(out, cap, &pos, g_hs_step);
        gate_puts(out, cap, &pos,
                  (g_hs_step == (unsigned int)HY_HS_STEP_REQ) ? "(REQ)" : "(ANS)");
    }

    if (g_key_bad)
        gate_puts(out, cap, &pos, "  应答不匹配(五层密钥解错)");

    gate_puts(out, cap, &pos, "  blocked=");
    gate_putu(out, cap, &pos, g_blocked);
    gate_puts(out, cap, &pos, "  —— 除版本查询与握手外，全部命令拒绝执行");
}
