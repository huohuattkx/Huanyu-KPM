/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_stress.c —— 硬件压力测试
 *
 * 【必须遵守的五条设计约束】
 *
 *   1. 默认全面关闭。只有用户显式下命令才启动，加载参数里没有任何
 *      自动启动开关，模块加载后不做任何多余动作。
 *   2. 定时自动结束。到点后工作线程自行退出，无需用户干预。
 *   3. 可抢占、有明确退出点。忙循环带时间预算，每轮结束 msleep 让出
 *      CPU，循环条件里同时检查「到点」和「收到停止」。绝不允许出现
 *      没有退出条件的死循环 —— 那只会触发热关机，与压力测试的初衷
 *      完全相反。
 *   4. 卸载安全。工作线程的代码在模块镜像内，模块卸载后绝不能继续跑。
 *      exit 时置停止位并等待线程自报退出（线程退出前把自己从线程表
 *      里摘掉），等待上限 2 秒。
 *   5. 存储只做只读。绝不写任何块设备 —— 那是防格机要拦的东西。
 *
 * 【为什么用 kthread 而不是内核定时器】
 *   timer_list 的布局在 KPM 里拿不到头文件，手工填 struct timer_list
 *   等同猜偏移，是历史上炸内核的老路。kthread 只需要三个函数指针
 *   符号（kthread_create_on_node / wake_up_process / msleep），不碰
 *   任何结构体布局，是这里唯一安全的选择。
 *
 * 【符号缺失即降级】
 *   任何一个必要符号解析不到，stress 直接不可用并明确回报，
 *   绝不尝试"看起来差不多"的替代名字。
 */

#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include "hy.h"

#ifndef EINVAL
#define EINVAL 22
#endif
#ifndef ENOMEM
#define ENOMEM 12
#endif
#ifndef EBUSY
#define EBUSY  16
#endif
#ifndef ENODEV
#define ENODEV 19
#endif
#ifndef ENOTSUP
#define ENOTSUP 524
#endif

/* GFP_KERNEL，与 hy_bp.c 现有用法一致，不要另起一套 */
#define HY_STRESS_GFP        0xcc0u

#define HY_STRESS_LEVEL_MIN  1
#define HY_STRESS_LEVEL_MAX  15
#define HY_STRESS_MAX_NS     (24ULL * 3600ULL * 1000000000ULL)
#define HY_STRESS_PERIOD_MS  100          /* 一轮的基准周期 */
#define HY_STRESS_MAX_THREAD 16
#define HY_STRESS_IO_CHUNK   65536        /* 单次读块大小上限 */

/* ============ 对外可见的符号（hy_sym.c 解析） ============ */
extern unsigned long (*hy_f___get_free_pages)(unsigned int gfp, unsigned int order);
extern void (*hy_f_free_pages)(unsigned long addr, unsigned int order);

/* ============ 本文件私有符号 ============ */
static void *(*f_kthread_create)(int (*threadfn)(void *), void *data,
                                 int node, const char *namefmt, ...);
static int  (*f_wake_up_process)(void *task);
static void (*f_msleep)(unsigned int msecs);
static s64  (*f_ktime_get)(void);

/* 存储只读：struct file 全程不透明，只传指针 */
static void *(*f_filp_open)(const char *name, int flags, unsigned short mode);
static int  (*f_filp_close)(void *filp, void *id);
static long (*f_kernel_read)(void *file, void *buf, unsigned long count,
                             long long *pos);

/* 在线 CPU 数上限（nr_cpu_ids 是导出变量，拿不到就按 1 处理） */
static int  *v_nr_cpu_ids;

/* ============ 目标枚举 ============ */
enum hy_stress_target {
    HY_STRESS_TARGET_ALL = 0,
    HY_STRESS_TARGET_CPU,
    HY_STRESS_TARGET_MEM,
    HY_STRESS_TARGET_STORAGE,
    HY_STRESS_TARGET_COUNT
};

static const char *const hy_stress_target_name[HY_STRESS_TARGET_COUNT] = {
    "all", "cpu", "mem", "storage"
};

/* ============ 运行状态 ============ */
struct hy_stress_state {
    volatile int  active;                       /* 有测试在跑 */
    volatile int  stop;                         /* 请求停止 */
    volatile int  target;
    volatile int  level;
    u64           dur_ns;
    u64           start_ns;
    u64           rounds;
    u64           mem_pages;
    u64           io_bytes;
    u64           mem_errors;
    u64           io_errors;
    int           nthreads;
    void         *threads[HY_STRESS_MAX_THREAD];
    char          io_path[96];
    char          last_err[64];
    u64           fallback_ns;                  /* 无时钟符号时的退化计时 */
};

static struct hy_stress_state g_st;

static int   g_ready;       /* 符号齐备 */
static int   g_cpu_limit = 1;

/* ==================== 时间与工具 ==================== */

static u64 now_ns(void)
{
    if (f_ktime_get) return (u64)f_ktime_get();
    return g_st.fallback_ns;
}

static void hy_stress_msleep(unsigned int ms)
{
    if (!ms) return;
    if (f_msleep) {
        f_msleep(ms);
        g_st.fallback_ns += (u64)ms * 1000000ULL;
        return;
    }
    /* 没有 msleep 时退化为空转一小段，保证循环仍能推进 */
    {
        volatile u64 a = 0;
        unsigned long i;
        for (i = 0; i < ms * 2000UL; i++) a += i;
        g_st.fallback_ns += (u64)ms * 1000000ULL;
    }
}

/*
 * 解析 "60s" / "5min" / "1h" 这类粘连写法。
 * 只接受：数字 + 可选单位后缀；无后缀按秒算。
 * 返回 0 成功，-EINVAL 表示写法不合法。
 */
static int parse_duration(const char *s, u64 *out_ns)
{
    unsigned long v = 0;
    u64 mult = 1000000000ULL;   /* 默认秒 */
    const char *p = s;
    int digits = 0;

    if (!s || !out_ns) return -EINVAL;

    while (*p >= '0' && *p <= '9') {
        /* 防溢出：超过 24h 直接拒 */
        if (v > 1000000UL) return -EINVAL;
        v = v * 10 + (unsigned long)(*p - '0');
        p++;
        digits++;
    }
    if (!digits) return -EINVAL;

    /* 跳过数字与单位之间可能存在的空格 */
    while (*p == ' ' || *p == '\t') p++;

    if (*p) {
        if (!hy_strcmp(p, "s") || !hy_strcmp(p, "sec") ||
            !hy_strcmp(p, "secs") || !hy_strcmp(p, "second") ||
            !hy_strcmp(p, "seconds"))
            mult = 1000000000ULL;
        else if (!hy_strcmp(p, "m") || !hy_strcmp(p, "min") ||
                 !hy_strcmp(p, "mins") || !hy_strcmp(p, "minute") ||
                 !hy_strcmp(p, "minutes"))
            mult = 60ULL * 1000000000ULL;
        else if (!hy_strcmp(p, "h") || !hy_strcmp(p, "hr") ||
                 !hy_strcmp(p, "hrs") || !hy_strcmp(p, "hour") ||
                 !hy_strcmp(p, "hours"))
            mult = 3600ULL * 1000000000ULL;
        else
            return -EINVAL;
    }

    if (v > HY_STRESS_MAX_NS / mult) return -EINVAL;
    *out_ns = (u64)v * mult;
    if (*out_ns == 0 || *out_ns > HY_STRESS_MAX_NS) return -EINVAL;
    return 0;
}

static int parse_int(const char *s, int *out)
{
    int v = 0, neg = 0, digits = 0;

    if (!s || !out) return -EINVAL;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') {
        if (v > 100000000) return -EINVAL;
        v = v * 10 + (*s - '0');
        s++;
        digits++;
    }
    if (!digits || *s) return -EINVAL;
    *out = neg ? -v : v;
    return 0;
}

/* ==================== 三类负载 ==================== */

/*
 * CPU：忙循环预算 busy_ns 后返回。
 * 每 256 次乘加检查一次时间与停止位 —— 既不至于把时间全花在读时钟上，
 * 也能在收到停止后几十微秒内退出。
 */
static void load_cpu(u64 busy_ns)
{
    volatile u64 acc = 1;
    u64 t0 = now_ns();
    unsigned long n = 0;

    for (;;) {
        int i;
        for (i = 0; i < 256; i++)
            acc = acc * 6364136223846793005ULL + 1442695040888963407ULL;
        if (g_st.stop) break;
        if (((++n) & 0x3ff) == 0 && (now_ns() - t0) >= busy_ns) break;
    }
    /* 防止整个循环被优化掉 */
    if (acc == 0xdeadbeefcafebabeULL) g_st.rounds++;
}

/*
 * MEM：分配 -> 写模式 -> 读回校验 -> 释放。
 * 档位同时决定单次分配阶数与轮内迭代次数。
 */
static void load_mem(int level)
{
    unsigned int order = (unsigned int)((level - 1) / 5);   /* 0..2 */
    int iters = 4 + level * 2;                              /* 6..34 */
    unsigned long bytes = HY_PAGE_SIZE << order;
    unsigned long words = bytes / 8;
    u64 pattern = 0x5a5a5a5a5a5a5a5aULL;
    int i;

    if (!hy_f___get_free_pages || !hy_f_free_pages) return;
    if (order > 3) order = 3;

    for (i = 0; i < iters; i++) {
        volatile u64 *p;
        unsigned long va;
        unsigned long k;
        int bad = 0;

        if (g_st.stop) break;

        va = hy_f___get_free_pages(HY_STRESS_GFP, order);
        if (!va) break;

        p = (volatile u64 *)va;
        for (k = 0; k < words; k++) p[k] = pattern + k;
        for (k = 0; k < words; k++) {
            if (p[k] != pattern + k) { bad = 1; break; }
        }

        hy_f_free_pages(va, order);

        g_st.mem_pages += (1ULL << order);
        if (bad) g_st.mem_errors++;
    }
}

/*
 * STORAGE：只读。文件在线程启动时打开，整场复用同一个句柄。
 * 读指针每轮前进一段，超过 256 MB 回绕 —— 设备实际大小未知，
 * 越界读会失败，失败就计入错误并由下一轮的位置自然错开。
 *
 * 缓冲放栈上并分片读取：内核栈只有 16 KB，不能开 64 KB 的局部数组，
 * 更不能让多个线程共享一个静态缓冲。
 */
static void load_storage(int level, void *file, int slot)
{
    u8 buf[2048];
    unsigned long want, done = 0;
    long long pos;
    long rc;

    if (!file || !f_kernel_read) return;

    want = (unsigned long)(4096 + level * 4096);   /* 8..64 KB */
    if (want > HY_STRESS_IO_CHUNK) want = HY_STRESS_IO_CHUNK;

    /*
     * 各线程错开读位置：若都用共享的 rounds，所有线程读同一偏移，
     * 缓存全命中，压力失真。用 slot 拉开距离。
     */
    pos = (long long)(((g_st.rounds + (u64)slot * 128ULL) * want)
                      % (256ULL * 1024 * 1024));

    while (done < want) {
        unsigned long n = want - done;
        if (n > sizeof(buf)) n = sizeof(buf);

        rc = f_kernel_read(file, buf, n, &pos);
        if (rc <= 0) { g_st.io_errors++; break; }
        done += (unsigned long)rc;
    }

    g_st.io_bytes += done;
}

/* ==================== 工作线程 ==================== */

static int hy_stress_thread(void *data)
{
    int slot = (int)(unsigned long)data;
    void *io_file = NULL;
    u64 busy_ns;
    int do_cpu, do_mem, do_storage;

    busy_ns = (u64)((g_st.level * HY_STRESS_PERIOD_MS) / HY_STRESS_LEVEL_MAX)
              * 1000000ULL;

    do_cpu     = (g_st.target == HY_STRESS_TARGET_ALL ||
                  g_st.target == HY_STRESS_TARGET_CPU);
    do_mem     = (g_st.target == HY_STRESS_TARGET_ALL ||
                  g_st.target == HY_STRESS_TARGET_MEM);
    do_storage = (g_st.target == HY_STRESS_TARGET_ALL ||
                  g_st.target == HY_STRESS_TARGET_STORAGE);

    if (do_storage && f_filp_open)
        io_file = f_filp_open(g_st.io_path, 0, 0);   /* flags = O_RDONLY */

    while (!g_st.stop) {
        u64 t0 = now_ns();

        if (now_ns() - g_st.start_ns >= g_st.dur_ns) break;

        if (do_cpu)     load_cpu(busy_ns);
        if (do_mem)     load_mem(g_st.level);
        if (do_storage) load_storage(g_st.level, io_file, slot);

        /* 让出 CPU：只压 CPU 时按占空比休眠，其余场景固定小睡 */
        if (do_cpu && !do_mem && !do_storage) {
            unsigned long used_ms = (unsigned long)((now_ns() - t0) / 1000000ULL);
            if (HY_STRESS_PERIOD_MS > used_ms)
                hy_stress_msleep((unsigned int)(HY_STRESS_PERIOD_MS - used_ms));
        } else {
            hy_stress_msleep(2);
        }

        g_st.rounds++;
    }

    if (io_file && f_filp_close) f_filp_close(io_file, NULL);

    /*
     * 必须先摘线程表再清 active —— 停止流程轮询这张表判断"是否全部退出"，
     * 顺序反了会让轮询方误判。
     */
    g_st.threads[slot] = NULL;
    return 0;
}

/* ==================== 启停 ==================== */

static void hy_stress_stop_wait(void)
{
    int i, guard;

    if (!g_st.active) return;

    g_st.stop = 1;

    for (guard = 0; guard < 200; guard++) {   /* 最多等 2 秒 */
        int live = 0;
        for (i = 0; i < g_st.nthreads; i++)
            if (g_st.threads[i]) live++;
        if (!live) break;
        hy_stress_msleep(10);
    }

    if (g_st.nthreads > 0) {
        int live = 0;
        for (i = 0; i < g_st.nthreads; i++)
            if (g_st.threads[i]) live++;
        if (live)
            HY_LOG("stress: WARNING %d thread(s) did not exit\n", live);
    }

    g_st.active = 0;
    g_st.nthreads = 0;
    g_st.stop = 0;
}

/*
 * 启动。
 * arg 形如： "60s all 1"  |  "5min cpu 8"  |  "1h storage 15 [/dev/block/xxx]"
 */
static int hy_stress_start(const char *arg)
{
    char buf[128];
    char *p, *tok[4];
    int ntok = 0, i, level = 1;
    u64 dur;
    int target = HY_STRESS_TARGET_ALL;

    if (!g_ready) return -ENODEV;
    if (g_st.active) return -EBUSY;

    if (!arg) return -EINVAL;

    hy_strscpy(buf, arg, sizeof(buf));

    p = buf;
    while (*p && ntok < 4) {
        while (*p == ' ' || *p == '\t') p++;
        if (!*p) break;
        tok[ntok++] = p;
        while (*p && *p != ' ' && *p != '\t') p++;
        if (*p) { *p = 0; p++; }
    }
    if (ntok < 2) return -EINVAL;

    if (parse_duration(tok[0], &dur) != 0) return -EINVAL;

    for (i = 0; i < HY_STRESS_TARGET_COUNT; i++) {
        if (!hy_strcmp(tok[1], hy_stress_target_name[i])) { target = i; break; }
    }
    if (i >= HY_STRESS_TARGET_COUNT) return -EINVAL;

    if (ntok >= 3) {
        if (parse_int(tok[2], &level) != 0) return -EINVAL;
        if (level < HY_STRESS_LEVEL_MIN || level > HY_STRESS_LEVEL_MAX)
            return -EINVAL;
    }

    if (target == HY_STRESS_TARGET_STORAGE && !f_filp_open) {
        hy_strscpy(g_st.last_err, "no filp_open", sizeof(g_st.last_err));
        return -ENOTSUP;
    }

    /* 存储路径：第 4 个参数可选，缺省用第一个能打开的候选 */
    if (target == HY_STRESS_TARGET_STORAGE ||
        target == HY_STRESS_TARGET_ALL) {
        if (ntok >= 4) {
            hy_strscpy(g_st.io_path, tok[3], sizeof(g_st.io_path));
        } else {
            static const char *const cands[] = {
                "/dev/block/mmcblk0",
                "/dev/block/sda",
                "/dev/block/by-name/userdata",
                "/dev/block/bootdevice/by-name/userdata",
            };
            int k;
            g_st.io_path[0] = 0;
            for (k = 0; k < 4; k++) {
                void *f = f_filp_open ? f_filp_open(cands[k], 0, 0) : NULL;
                if (f) {
                    if (f_filp_close) f_filp_close(f, NULL);
                    hy_strscpy(g_st.io_path, cands[k], sizeof(g_st.io_path));
                    break;
                }
            }
        }
    }

    /* 线程数：档位 1 -> 1 个，档位 15 -> 满核 */
    {
        int n = 1 + (level - 1) * (g_cpu_limit - 1) / (HY_STRESS_LEVEL_MAX - 1);
        if (n < 1) n = 1;
        if (n > HY_STRESS_MAX_THREAD) n = HY_STRESS_MAX_THREAD;
        g_st.nthreads = n;
    }

    g_st.target = target;
    g_st.level = level;
    g_st.dur_ns = dur;
    g_st.rounds = 0;
    g_st.mem_pages = 0;
    g_st.io_bytes = 0;
    g_st.mem_errors = 0;
    g_st.io_errors = 0;
    g_st.stop = 0;
    g_st.last_err[0] = 0;
    for (i = 0; i < HY_STRESS_MAX_THREAD; i++) g_st.threads[i] = NULL;

    if (f_ktime_get) g_st.start_ns = now_ns();
    else { g_st.fallback_ns = 0; g_st.start_ns = 0; }

    g_st.active = 1;

    if (!f_kthread_create) {
        g_st.active = 0;
        hy_strscpy(g_st.last_err, "no kthread", sizeof(g_st.last_err));
        return -ENOTSUP;
    }

    for (i = 0; i < g_st.nthreads; i++) {
        void *t = f_kthread_create(hy_stress_thread,
                                   (void *)(unsigned long)i, -1, "hy_stress");
        if (!t) {
            HY_LOG("stress: thread %d create failed\n", i);
            break;
        }
        g_st.threads[i] = t;
        if (f_wake_up_process) f_wake_up_process(t);
    }

    if (i == 0) {
        g_st.active = 0;
        hy_strscpy(g_st.last_err, "kthread failed", sizeof(g_st.last_err));
        return -ENOMEM;
    }
    g_st.nthreads = i;

    HY_LOG("stress: start target=%s level=%d dur_ns=%llu threads=%d io=%s\n",
           hy_stress_target_name[target], level, (unsigned long long)dur,
           g_st.nthreads, g_st.io_path[0] ? g_st.io_path : "(none)");
    return 0;
}

/* ==================== 状态输出 ==================== */

static void u64_to_str(char *b, unsigned long cap, unsigned long *pos, u64 v)
{
    char tmp[24];
    int i = 0;

    if (!v) { tmp[i++] = '0'; }
    while (v) { tmp[i++] = (char)('0' + (int)(v % 10)); v /= 10; }
    while (i > 0) {
        if (*pos + 1 < cap) b[(*pos)++] = tmp[--i];
        else break;
    }
}

/*
 * 一行状态，供 /proc/Huanyu 与 stress stat 复用。
 * 保持单一实现，不要在两处各写一份格式化逻辑。
 */
void hy_stress_status_line(char *b, unsigned long cap)
{
    unsigned long pos = 0;
    u64 left_ns = 0;

    if (!b || cap == 0) return;

    if (!g_st.active) {
        const char *s = g_ready ? "off" : "unavailable";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
        b[pos] = 0;
        return;
    }

    {
        u64 el = now_ns() - g_st.start_ns;
        left_ns = (el >= g_st.dur_ns) ? 0 : (g_st.dur_ns - el);
    }

    {
        const char *s = "ON target=";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    {
        const char *s = hy_stress_target_name[g_st.target];
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    {
        const char *s = " lvl=";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    u64_to_str(b, cap, &pos, (u64)g_st.level);
    {
        const char *s = " left=";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    u64_to_str(b, cap, &pos, left_ns / 1000000000ULL);
    {
        const char *s = "s rounds=";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    u64_to_str(b, cap, &pos, g_st.rounds);
    {
        const char *s = " mempg=";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    u64_to_str(b, cap, &pos, g_st.mem_pages);
    {
        const char *s = " io=";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    u64_to_str(b, cap, &pos, g_st.io_bytes / 1024ULL);
    {
        const char *s = "KB err=";
        while (*s && pos + 1 < cap) b[pos++] = *s++;
    }
    u64_to_str(b, cap, &pos, g_st.mem_errors + g_st.io_errors);
    b[pos] = 0;
}

int hy_stress_running(void) { return g_st.active; }

/* ==================== 命令入口 ==================== */

/*
 * 命令字：
 *   stress <时长><单位> <all|cpu|mem|storage> [档位1..15] [存储路径]
 *   stress off
 *   stress stat
 */
int hy_stress_cmd(const char *arg, char *out, unsigned long outsz)
{
    int rc;

    if (!out || outsz == 0) return -EINVAL;

    if (!g_ready) {
        hy_strscpy(out, "stress: unavailable (symbols missing)", outsz);
        return -ENODEV;
    }

    if (arg && !hy_strcmp(arg, "stat")) {
        char line[160];
        hy_stress_status_line(line, sizeof(line));
        hy_strscpy(out, line, outsz);
        return 0;
    }

    if (arg && !hy_strcmp(arg, "off")) {
        if (!g_st.active) { hy_strscpy(out, "stress: not running", outsz); return 0; }
        hy_stress_stop_wait();
        hy_strscpy(out, "stress: stopped", outsz);
        return 0;
    }

    rc = hy_stress_start(arg);
    if (rc != 0) {
        if (rc == -EINVAL) {
            hy_strscpy(out, "usage: stress <n>s|min|h <all|cpu|mem|storage> [1..15] [path]",
                       outsz);
        } else if (rc == -EBUSY) {
            hy_strscpy(out, "stress: already running (stress off first)", outsz);
        } else if (g_st.last_err[0]) {
            hy_strscpy(out, g_st.last_err, outsz);
        } else {
            hy_strscpy(out, "stress: start failed", outsz);
        }
        return rc;
    }

    hy_strscpy(out, "stress: started", outsz);
    return 0;
}

/* ==================== 生命周期 ==================== */

int hy_stress_init(void)
{
    static const char *const ktime_cands[] = {
        "ktime_get_ns", "__ktime_get_ns", "ktime_get",
    };
    int i;

    hy_memset(&g_st, 0, sizeof(g_st));

    f_kthread_create = (void *)hy_lookup_generic("kthread_create_on_node");
    f_wake_up_process = (void *)hy_lookup_generic("wake_up_process");
    f_msleep = (void *)hy_lookup_generic("msleep");
    f_filp_open = (void *)hy_lookup_generic("filp_open");
    f_filp_close = (void *)hy_lookup_generic("filp_close");
    f_kernel_read = (void *)hy_lookup_generic("kernel_read");
    v_nr_cpu_ids = (int *)hy_lookup_generic("nr_cpu_ids");

    for (i = 0; i < 3; i++) {
        unsigned long a = hy_lookup_generic(ktime_cands[i]);
        if (a) { f_ktime_get = (s64(*)(void))a; break; }
    }

    if (v_nr_cpu_ids && *v_nr_cpu_ids > 0) g_cpu_limit = *v_nr_cpu_ids;
    if (g_cpu_limit < 1) g_cpu_limit = 1;
    if (g_cpu_limit > HY_STRESS_MAX_THREAD) g_cpu_limit = HY_STRESS_MAX_THREAD;

    /*
     * 最小可用集：能建线程 + 能睡 + 有时钟。
     * 缺任意一个就不提供压力测试 —— 半个能跑的实现比没有更危险。
     */
    g_ready = (f_kthread_create && f_msleep && f_ktime_get) ? 1 : 0;

    HY_LOG("stress: ready=%d kthread=%d msleep=%d ktime=%d filp=%d cpus=%d\n",
           g_ready, !!f_kthread_create, !!f_msleep, !!f_ktime_get,
           !!f_filp_open, g_cpu_limit);
    return 0;
}

void hy_stress_exit(void)
{
    if (g_st.active) {
        HY_LOG("stress: exit with test running -> stopping\n");
        hy_stress_stop_wait();
    }
    g_ready = 0;
}
