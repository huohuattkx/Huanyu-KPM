# 欢愉 Huanyu KPM 内核模块 — 源码详解

> 版本 **1.80.0** · 产物 `huanyu_v1.80.0.kpm`
> 本文档对应 `Huanyu_KPM_Source/` 目录下的全部源码，逐文件说明职责、关键数据结构、调用链与历史修复点。
> 面向**维护者**：假设你已具备 Linux 内核、ARM64、KernelPatch(KP) 模块开发基础。

---

## 目录

1. [模块总览](#1-模块总览)
2. [文件清单与职责](#2-文件清单与职责)
3. [编译与发布](#3-编译与发布)
4. [分层架构](#4-分层架构)
5. [核心子系统逐个拆解](#5-核心子系统逐个拆解)
   - 5.1 [版本与密钥握手](#51-版本与密钥握手)
   - 5.2 [命令分发](#52-命令分发)
   - 5.3 [触摸注入（最复杂）](#53-触摸注入最复杂)
   - 5.4 [内存读写](#54-内存读写)
   - 5.5 [页表遍历](#55-页表遍历)
   - 5.6 [断点](#56-断点)
   - 5.7 [方案选择器](#57-方案选择器)
   - 5.8 [共享内存](#58-共享内存)
   - 5.9 [防格机](#59-防格机)
   - 5.10 [其余子系统](#510-其余子系统)
6. [命令全表](#6-命令全表)
7. [关键全局变量速查](#7-关键全局变量速查)
8. [历史修复时间线](#8-历史修复时间线)
9. [维护须知与红线](#9-维护须知与红线)

---

## 1. 模块总览

欢愉是一个基于 **KernelPatch (KP)** 的 ARM64 内核可加载模块（`.kpm`，本质是 `ET_REL` 可重定位目标文件），不依赖内核源码树，通过 KP 提供的导出符号访问内核。

**设计取向**：不硬编码任何内核结构体偏移。所有能力通过「多世代方案（scheme）自动降级 + 运行时观察」获得，命中失败就降一档换一种实现。

| 属性 | 值 |
|---|---|
| 版本 | 1.80.0 |
| 产物大小 | 1,269,264 字节 |
| md5 | `1b86d850214d0cfe703ee28e6b7b36f6` |
| ELF 类型 | `ET_REL` / AArch64 |
| KPM 段 | `.info` `.init` `.exit` `.ctl0`（四段齐全） |
| 源码规模 | 约 53,000 行（含 `hy_insn_prefix.c` 指令前缀表 32,804 行） |
| 实机内核 | 6.12.69（`kver 0x60c45`） |
| 目标平台 | Android / ARM64 / GKI |

---

## 2. 文件清单与职责

| 文件 | 行数 | 职责 |
|---|---:|---|
| `hy.h` | ~1900 | **总头文件**：版本、ABI、命令号、常量、全局声明、各模块接口原型 |
| `hy_insn_prefix.c` | 32804 | ARM64 指令前缀匹配表（自动生成，用于指令级断点/扫描） |
| `hy_input.c` | 3236 | **触摸子系统**：事件探测、设备识别、分辨率学习、虚拟手指注入 |
| `hy_ctl.c` | 2137 | **命令分发**：`/proc/HuanyuD` 写入入口 + 全部命令实现 |
| `hy_bp.c` | 1920 | 断点子系统：硬件/软件断点、DPT 影子页 |
| `hy_guard.c` | 930 | 防格机：拦截危险写入/格式化路径 |
| `hy_shm.c` | 911 | 共享内存：用户态↔内核态大块数据通道 |
| `hy_lsx.c` | 847 | 扩展扫描：段/区域枚举与特征搜索 |
| `hy_mem.c` | 719 | 内存读写：虚拟地址读取、解引用指针 |
| `hy_stress.c` | 704 | 原语压测：各功能面自检 |
| `hy_procfs.c` | 697 | `/proc/HuanyuD` 注册与读写回调 |
| `hy_pt.c` | 634 | 页表深度遍历与转换 |
| `hy_gate.c` | 595 | 权限闸门：解锁窗口、调用鉴权 |
| `hy_prctl.c` | 531 | prctl/supercall 通道（用户态主通道） |
| `hy_main.c` | 505 | 模块入口：`init` / `exit`、全局定义 |
| `hy_extra.c` | 489 | 杂项扩展命令 |
| `hy_gnss.c` | 482 | GNSS 虚拟定位（按需挂全局 ioctl hook） |
| `hy_dbgfs.c` | 478 | debugfs 诊断接口 |
| `hy_scheme.c` | 467 | **方案选择器**：多世代实现与降级逻辑 |
| `hy_kma.c` | 390 | 内核内存分配器封装（静态池优先） |
| `hy_pgtable.c` | 371 | 页表方案的具体世代实现 |
| `hy_sysmon.c` | 369 | 系统调用监控 |
| `hy_sym.c` | 328 | 符号解析：kallsyms 查询 |
| `hy_cntvct.c` | 313 | CNTVCT 时钟监控 |
| `hy_discover.c` | 292 | 设备/环境自动发现 |
| `hy_insn.c` | 265 | 指令解码辅助 |
| `hy_hide.c` | 255 | 隐藏：模块自身与 GPU 信息 |
| `hy_pm.c` | 244 | 电源/性能相关 |
| `hy_devinfo.c` | 243 | 设备信息表（可扩展 k=v） |
| `hy_net.c` | 217 | 网络相关辅助 |
| `hy_task.c` | 191 | 任务/进程查询 |
| `hy_trampoline.c` | 172 | 跳板：hook 中转 |
| `hy_shm.h` | 130 | 共享内存协议结构 |
| `hy_scheme.h` | 123 | 方案枚举与结构体 |
| `hy_insn.h` | 83 | 指令前缀表索引 |
| `module.lds` | 6 | 链接脚本（KPM 段布局） |

---

## 3. 编译与发布

### 3.1 两条工具链

```bash
# GCC 路线
bash build.sh

# Zig 路线（沙盒 gcc 不可用时）
bash build_zig.sh
```

两者选项存在细微差异，但产物均需满足：四段齐全、版本串唯一、UND 符号全部为 KP 标准导出。

### 3.2 发布校验（`release.sh`）

13 项强制校验，任一不过即拒绝发布：

| # | 校验项 | 说明 |
|---|---|---|
| 1 | 内核版本常量自洽 | `HY_VERSION_STRING` = `MAJOR.MINOR.PATCH` 拼接 |
| 2 | kpm 文件名 | 与版本号一致 |
| 3 | 二进制内含版本串 | `strings` 能且只能找到当前版本 |
| 4 | 旧版本残留 | 上一版本号出现次数必须为 0 |
| 5 | 两个 hpp 版本 | 与内核一致 |
| 6 | 五层密钥三处一致 | 内核 `hy.h` + 两个 hpp 逐字节 md5 相同 |
| 7 | 五层长度 | 6 / 64 / 64 / 64 / 256（L1 = `Huanyu` 固定） |
| 8 | ELF 类型 | `ET_REL` |
| 9 | KPM 四段 | `.info` `.init` `.exit` `.ctl0` |
| 10 | UND 符号 | 必须全为 KP 标准导出；`memcpy` = 0；`kf_` 前缀 = 0 |
| 11 | zip 内唯一 kpm | 包内不能混入旧版 |
| 12 | zip 复检 | 包内 kpm 与单独发出的**逐字节相同** |
| 13 | 用户态编译 | 两个 hpp + 工具 `-Wall -Wextra` 零警告（静态断言通过） |

> 第 13 项曾经救过一次：1.78.0 时 `HY_VERSION_STRING` 改了但 `HY_VER_MINOR` 漏改，头文件的静态断言直接拦下编译，避免发出一个握手必失败的头文件。

---

## 4. 分层架构

```
┌─────────────────────────────────────────────────────┐
│  用户态                                              │
│  huanyu.hpp（字符串命令） / huanyu_wanbai.hpp（二进制）│
└───────────────┬─────────────────────┬───────────────┘
                │ prctl / supercall   │ 写 /proc/HuanyuD
                ▼                     ▼
┌─────────────────────────────────────────────────────┐
│  内核态                                              │
│  hy_prctl.c  ──┐                                     │
│  hy_procfs.c ──┼──► hy_ctl.c （命令分发）             │
│  hy_gate.c   ──┘         │                           │
│                          ▼                           │
│      ┌──────────┬────────┼────────┬──────────┐       │
│      ▼          ▼        ▼        ▼          ▼       │
│  hy_input.c  hy_mem.c  hy_bp.c  hy_shm.c  hy_guard.c │
│      │          │        │                           │
│      └──────────┴────────┴────► hy_scheme.c          │
│                                 （多世代方案选择）     │
└─────────────────────────────────────────────────────┘
```

**两条命令通道等价**：`hy_prctl.c` 与 `hy_procfs.c` 最终都进 `hy_ctl.c` 的同一套分发逻辑，不依赖用户态守护进程 `HuanyuD`。

---

## 5. 核心子系统逐个拆解

### 5.1 版本与密钥握手

`hy.h` 第 730 行附近：

```c
#define HY_VERSION_STRING "1.80.0"
#define HY_VER_MAJOR 1
#define HY_VER_MINOR 80
#define HY_VER_PATCH 0
```

**五层密钥**：L1 固定为 `Huanyu`（6 字节），L2/L3/L4 各 64 字节，L5 为 256 字节。三处（内核 + 两个 hpp）必须逐字节一致。

> ⚠️ 每次改版本号，**两个 hpp 必须同步替换**。否则：
> - hpp 内静态断言 → 直接编译失败
> - 侥幸通过 → 握手版本比对失败，用户态调用全被拒

密钥轮换规则：新版本可轮换 L2~L5；命令行 `/proc/HuanyuD` 调试不受密钥影响。

### 5.2 命令分发

`hy_ctl.c` 是唯一的命令落地处。所有命令靠前缀匹配，**顺序敏感**：

```c
/* 第 1061 行注释原文：
 * 【顺序很重要】"touchstat" 必须以 9 字符先匹配，
 * 否则会被下面的 "tstat"（5 字符）抢先截断匹配 */
if (!hy_strncmp(cmd, "touchstat", 9)) ...
if (!hy_strncmp(cmd, "tstat", 5)) ...
```

**新增命令时的两个坑**：
1. 若新命令是某已有命令的**前缀扩展**（如 `tstat` vs `touchstat`），必须把长的放前面
2. 回复串写入缓冲区，长度需留余量；曾经因为回复串中间被并发覆写 8 字节出现乱码（`invalid (no acti|ve finger)`），1.79.0 改为短且无括号的 `no active finger`

### 5.3 触摸注入（最复杂）

这是整个模块投入最多的部分，`hy_input.c` 3236 行。

#### 5.3.1 两个观察点

```c
hits: iev=... ihe=...
```

- `iev` = `input_event` hook 命中数
- `ihe` = `input_handle_event` hook 命中数

> **为什么需要第二个点**：6.x GKI 开启 LTO，`input_event` 常被内联，kallsyms 查不到或 hook 不上。`input_handle_event` 是同层的备选观察点。5.10 以下 `input_event` 是导出符号，一个点就够。

#### 5.3.2 设备识别（不读结构体偏移）

不解析 `struct input_dev` 的内部布局，而是**观察真实驱动发过什么事件**：

| 观察项 | 判定 |
|---|---|
| 见过 `EV_ABS` | `abs=1` |
| 见过 `EV_KEY` | `btn=1` |
| 见过 `ABS_MT_*` | `mt=1` |
| 见过 `ABS_MT_SLOT` | **Protocol B** |
| 只见过 MT 坐标/TRACKING_ID | **Protocol A** |

`phys` 字段：`struct input_dev` 前两个成员固定是 `name`、`phys`，所以 phys 是 name 后面那个指针——与读 name **完全同级的取法**，不引入新偏移推算。

#### 5.3.3 分辨率学习

```c
learn resolv : 20324x43967
```

只采样 `ABS_X / ABS_Y / ABS_MT_POSITION_X / ABS_MT_POSITION_Y`，**排除注入自身产生的事件**。

**关键认知**：这是「摸到过的最大值」，不是驱动声明值。手指没滑到边缘就偏小。

真实值用 `getevent -lp /dev/input/eventN` 看 `ABS_MT_POSITION_X/Y` 的 `max`。

> 屏幕像素分辨率 ≠ 触摸面板坐标。本机实测面板 `20351×44351`，屏幕 `1080×2354`，倍率 **18.84**。注入用的是**面板坐标系**，源码里直接拿 x 与 `g_max_x` 比较，**没有任何换算**。

#### 5.3.4 手设优先（1.79.0 新增）

```c
static bool g_range_manual;
```

`trange` 设过之后，自学习**不再覆盖**手设值。此前每次重新加载都得重设一遍。

#### 5.3.5 槽位模型

```
槽位总数   = g_max_drv_slot + 1        （本机 10，即 0..9）
虚拟手指基址 = g_slot_base              （默认 5）
容量 cap   = ti_slot_limit() - 真手指占用
```

`ti_slot_limit()`（`hy_input.c:447`）是**唯一口径**：

```c
int lim = g_ti_max_slots;
if (g_max_drv_slot >= 0 && g_max_drv_slot + 1 < lim)
    lim = g_max_drv_slot + 1;      /* 以驱动真实上限为准 */
if (lim > TI_MAX_FINGERS) lim = TI_MAX_FINGERS;
```

> ⚠️ **1.80.0 修复**：`hy_emit` 里曾残留裸的 `g_ti_max_slots`，与容量/分配/让位三处的 `ti_slot_limit()` 口径不一致，导致 `hw_slot` 可被钳到 15 —— 仍然越过驱动的 9。越界的 `ABS_MT_SLOT` 被 input core 静默忽略，坐标写进「上一次选中的槽」，表现为手指乱跳或按了没反应。现在四处同源。

#### 5.3.6 协议 A / B 分流

| 协议 | 注入序列 |
|---|---|
| **B** | `SLOT` + `TRACKING_ID` + `X` + `Y`（+ 全局按键） |
| **A** | 每根手指后跟 `SYN_MT_REPORT`，**整帧重报全部活跃触点** |

> 为什么 A 必须整帧重报：协议 A 无槽位概念，靠 `SYN_MT_REPORT` 分隔手指。且 `ABS_MT_SLOT` 不在 A 设备的 `absbit` 里，`input_get_disposition()` 会整条判 `INPUT_IGNORE_EVENT` 丢掉。

#### 5.3.7 不断触的本质

```
tdown   → 分配 SLOT + TRACKING_ID
tmove×N → 只改坐标，TRACKING_ID 不变   ← 内核认为仍是同一根手指
tup     → TRACKING_ID = -1
```

**TRACKING_ID 按下时分配一次就一直有效**，槽位状态由内核维护。这是 Protocol B 的增量语义，不需要任何特殊机制。

> 曾误判「move 必须重发 TOUCH_MAJOR/WIDTH_MAJOR/PRESSURE」。协议上**不需要**——增量更新是合法语义，只发坐标完全符合规范。真实驱动全量上报只是厂商习惯。此结论已撤回。

#### 5.3.8 与物理驱动的对抗（保护计数器）

```
protect = 2202
```

物理驱动每帧 `input_mt_sync_frame()` 判定「这个槽本帧没出现过」，会补发 `TRACKING_ID = -1` 抹除我们的手指；随后 `input_mt_report_pointer_emulation()` 按它自己数的活跃槽发 `BTN_TOUCH = 0`。

**拦截点**（`hy_input.c:1243-1262`，两段）：

```c
/* 第一段：EV_ABS */
if (type == HY_EV_ABS && code == HY_ABS_MT_TRACKING_ID &&
    val == -1 && ti_finger_by_slot(g_ti_cur_slot) >= 0) {
    args->skip_origin = 1; g_ti_protects++;
}
/* 第二段：EV_KEY */
if (type == HY_EV_KEY && val == 0 &&
    (code == HY_BTN_TOUCH || code == HY_BTN_TOOL_FINGER || ...)) {
    args->skip_origin = 1; g_ti_protects++;
}
```

> **两段都不能删**。第一段是 `EV_ABS`（走 `absbit`），keybit 屏蔽够不着；删掉它虚拟手指一帧就被抹掉。
>
> 参考实现（lsdriver）用 `clear_bit(BTN_TOUCH, dev->keybit)` 从源头让物理驱动闭嘴——但那需要 `dev->keybit` 偏移，**KPM 拿不到**，硬猜就是历史上炸内核的老路。事件层拦截是唯一安全解。

#### 5.3.9 手指卡死的根因与 `tclear`

`hy_ti_up()` 靠位图判断「还有没有真手指」，只要位图有残留（为学坐标摸过屏就会置位）就不发 `BTN_TOUCH = 0`。而 `BTN_TOUCH = 0` 才是 Android InputReader 判定「触摸结束」的信号 —— 不发它，圆点永久留在屏上。

`tclear` **不看位图**，无条件发完整抬起序列并清空位图。它先把状态机置 IDLE 再发事件 —— 保护逻辑只在 ACTIVE 时拦 `BTN_TOUCH=0`，不清状态的话我们自己发的抬起会被自己拦掉。

#### 5.3.10 注入闸门

```
ti on / ti off
```

默认允许注入，但**虚拟手指只在显式 down 时才出现**。触摸探测（probe）默认开（1.76.0 起），它只读 hook、认设备、学参数，**不生成任何手指**。

### 5.4 内存读写

`hy_mem.c` + `hy_kma.c`。提供虚拟地址读取、解引用指针链路（多级 `*` 跟随）。

**安全约定**：常驻路径**零动态分配**，全部走静态对象池（`hy_bp.c` 注释明确「不碰 kmalloc」，`hy_shm.c` 用静态页数组）。

唯一的动态分配在 `hy_stress.c` 的 `load_mem()`：`__get_free_pages` → `free_pages` **成对**，循环内 `break` 前也已走完整释放路径。审计结论：**无泄漏**。

### 5.5 页表遍历

`hy_pgtable.c` + `hy_pt.c`。多世代方案：

```
pgtable : gen6 tcr-t1sz idx=0 demote=0
```

> **1.73.3 的关键修复**：input 事件路径**彻底不再走页表**。理由：`dev` 来自内核自己传的参数，`dev->name` 是内核维护的合法字符串，可信度极高，不需要页表验证；而 `input_event` 是极高频回调，可能在中断上下文，**本来就不该在里面遍历页表**。
>
> 当时的崩溃链：参数修对后 dev 变真实 → `hy_name_safe()` 第一次真正调用 `hy_kern_addr_mapped()` → 走 TTBR1 页表 → 第二级及更深的表地址 = 物理地址 + `g_physvirt_off`（本机该偏移不成立）→ 表中地址是垃圾 → 而 `hy_tbl_va_ok()` 只做纯范围检查验不了映射 → `ent = tbl[idx]` 解引用未映射地址 → oops。
>
> 修好之前为什么不崩？因为 dev 是被读坏的垃圾值，devname 校验早退，页表遍历**一次都没被调用过**。

### 5.6 断点

`hy_bp.c` 1920 行。支持硬件断点、软件断点、单步、DPT 主线程影子页。

- 方案：`bp : gen6 pte-shadow idx=0`
- 能力查询：`bpstat`
- 全部走静态对象池

### 5.7 方案选择器

`hy_scheme.c` + `hy_scheme.h`。**这是模块的容错核心**。

八个功能面，每个面有多世代实现（gen3 ~ gen6）：

```
[scheme] gen=6 (降级次数累计)
  physvirt  : gen5 memstart idx=1 demote=0
  pgtable   : gen6 tcr-t1sz idx=0 demote=0
  memread   : gen6 pt-way8  idx=0 demote=0
  kernrw    : gen5 linear   idx=1 demote=0
  bp        : gen6 pte-shadow idx=0 demote=0
  input     : gen6 handle_event idx=0 demote=0
  sym       : gen6 lk+each  idx=0 demote=0
```

手动干预：

```
scheme demote <域>              降一档
scheme force <域> <3|4|5|6>     强制指定世代（0 = 自动）
```

### 5.8 共享内存

`hy_shm.c` + `hy_shm.h`。静态页数组，无动态分配。

> **1.80.0 修复（常驻耗电）**：空闲时原本硬 `msleep(1)`，等于**一秒唤醒一千次**什么也不做。模块从开机一直加载，这是实打实的唤醒源。
>
> 改为自适应退避 **1 → 2 → 5 → 10 → 20ms**，有请求立刻清零回 1ms —— **响应延迟不变，空转降到 50 次/秒**。
>
> 另加纵深防御：`msleep` 缺失时**直接拒绝启动线程**，否则那个循环会变成满核忙等把机身烤热。

### 5.9 防格机

`hy_guard.c` 930 行。

```
guard on|off|status    防格机
unlock [seconds]       开解锁窗口（默认 300s）
lock                   立即结束窗口
```

> **刻意不 hook 全局 ioctl** —— binder 每秒上万次，挂上去性能灾难。只在 gnss 等按需场景临时挂载。

### 5.10 其余子系统

| 文件 | 要点 |
|---|---|
| `hy_gnss.c` | 虚拟定位。按需挂/卸全局 ioctl hook，不激活就不挂 |
| `hy_hide.c` | 模块自身隐藏 + GPU 信息隐藏 |
| `hy_sym.c` | kallsyms 符号解析，`sym : gen6 lk+each` |
| `hy_sysmon.c` | 系统调用监控 |
| `hy_cntvct.c` | CNTVCT 时钟监控（计时源） |
| `hy_lsx.c` | 段/区域枚举与特征搜索 |
| `hy_devinfo.c` | 可扩展设备信息表（`devinfo add k=v`） |
| `hy_discover.c` | 环境自动发现 |
| `hy_dbgfs.c` | debugfs 诊断接口 |
| `hy_insn.c` + `hy_insn_prefix.c` | ARM64 指令前缀匹配（3.2 万行生成表） |
| `hy_trampoline.c` | hook 跳板 |
| `hy_net.c` / `hy_task.c` / `hy_pm.c` | 网络 / 任务 / 电源辅助 |

---

## 6. 命令全表

通过 `echo '<命令>' > /proc/HuanyuD; cat /proc/HuanyuD` 调用。

### 6.1 通用

| 命令 | 说明 |
|---|---|
| `help` | 显示帮助 |
| `version` | 版本信息 |
| `handshake` | 版本/密钥握手状态 |

### 6.2 触摸

| 命令 | 说明 |
|---|---|
| `touch on\|off` | 触摸总开关（probe + tscan） |
| `probe on\|off` | 事件探测（安全，摸屏才识别）。**默认 on** |
| `tscan on\|off` | 主动枚举设备。**历史崩点，单独试** |
| `touchstat` | 触摸详细状态（含设备证据、协议、phys） |
| `tcap` | 触摸事件抓包（诊断用，**默认关闭**，需敲两次） |
| `tslock <n>` | 按索引锁定触摸屏（可靠兜底） |
| `tsname <名字>` | 按设备名锁定触摸屏 |
| `grab on\|off\|stat` | 槽位抢夺开关/统计 |
| `slotbase <n>` | 虚拟手指起始槽位（0..9） |
| `tdown <x> <y>` | 注入按下（自动挑空闲槽） |
| `tdown <id> <x> <y>` | 指定手指 id 按下 |
| `tmove <x> <y>` / `tmove <id> <x> <y>` | 注入移动 |
| `tup` / `tup <id>` | 注入抬起（不带 id = 抬全部） |
| `tstat` | 注入状态统计 |
| `tfinger` | 列出每根手指占的槽与当前容量 |
| `tclear` | **强制清除残留手指**（不看位图） |
| `ti on\|off` | 注入总闸（off 时自动清手指） |
| `tslots <n>` | 手动设定总槽位数（1..256） |
| `trange <x0 x1 y0 y1>` | 手动设定坐标范围（**设后自学习不再覆盖**） |

### 6.3 其他

| 命令 | 说明 |
|---|---|
| `scheme` | 各功能面当前方案与降级次数 |
| `scheme demote <域>` | 手动降一档 |
| `scheme force <域> <3\|4\|5\|6>` | 强制指定世代（0 = 自动） |
| `bpstat` | 断点能力与占用 |
| `devinfo reset\|add <k=v>\|show` | 设备信息表 |
| `guard on\|off\|status` | 防格机 |
| `unlock [seconds]` | 开解锁窗口（默认 300s） |
| `lock` | 立即结束窗口 |

### 6.4 `tstat` 输出解读

```
state=IDLE slot=-1 slots=10 down=1 move=1 up=1 busy=0 conflict=0 protect=2202 range=0..20351 x 0..44351
```

| 字段 | 含义 |
|---|---|
| `state` | `IDLE` / `ACTIVE` |
| `slot` | 当前手指槽位，`-1`（显示为 `18446744073709551615`）表示无手指 |
| `slots` | 槽位总数 |
| `down/move/up` | 累计注入次数 |
| `busy` | 忙碌计数 |
| `conflict` | 冲突计数 |
| `protect` | **保护计数器**：拦下物理驱动抹除的次数。> 0 说明保护生效 |
| `range` | 当前生效坐标范围 |

> `slot=18446744073709551615` 就是 -1 的无符号打印，**不是 bug**。

---

## 7. 关键全局变量速查

| 变量 | 位置 | 含义 |
|---|---|---|
| `g_max_x` / `g_max_y` | `hy_input.c:135-136` | 坐标上限。**默认硬编码 1080 / 2400，不是真实分辨率** |
| `g_range_manual` | `hy_input.c` | `trange` 是否手设过（手设后禁止自学习覆盖） |
| `g_slot_base` | — | 虚拟手指起始槽位 |
| `g_max_drv_slot` | — | 驱动真实最大槽位（本机 9） |
| `g_ti_max_slots` | — | 自学习得到的槽位上限（可被抬到 256） |
| `g_ti_state` | `hy_input.c:250` | 单指时代的状态机（已被多指结构取代） |
| `g_ti_protects` | — | 保护计数器 |
| `g_physvirt_off` | — | 物理↔虚拟偏移（本机不成立，故 input 路径不走页表） |
| `g_injecting` | — | 正在注入标志（用于排除自身事件） |

---

## 8. 历史修复时间线

| 版本 | 修复 |
|---|---|
| **1.73.2** | **input hook 参数取法**。普通函数 hook 误用 `syscall_argn()`——6.12 上 `has_syscall_wrapper` 必为 1，该函数把真正的 `input_dev *dev` 当 `struct pt_regs *`，而 `regs` 偏移为 0，导致 `args[n]` 实际等于 `(u64*)dev + n`，读的是 **input_dev 结构体自身的连续字段**。现象：`dev` 100% 未对齐、`type` 恒为 syn（403929 全占满）、`code` 恒为 0、`value` 恒为 655。改为 `args->args[n]`。只改 `hy_ie_common`；`prctl` / `sendto` 是真系统调用 hook，保留 `syscall_argn` |
| **1.73.3** | **input 路径不走页表**（详见 5.5）。修参数后才第一次走到这条从未走过的路，故必崩而非偶发（40 万次/几十秒，命中率 100%） |
| **1.74.0** | `touchstat` 增加 `phys` 字段，用于反查 `/dev/input/eventN` |
| **1.75.0** | 新增 `tclear`、`ti` 注入总闸；定位手指不消失根因 |
| **1.76.0** | 单指 → **多指动态容量**；probe 默认开 |
| **1.77.0** | 协议 A/B 分流；`tcap` 默认关闭（记满 8192 条自动停） |
| **1.78.0** | `ti_slot_limit()` 统一口径，修 cap=11 与槽位 10 的矛盾；补 `HY_VER_MINOR` 漏改 |
| **1.79.0** | 热路径早退；`trange` 手设防漂移；回复串乱码收尾 |
| **1.80.0** | `hy_emit` 槽位溢出（补 `ti_slot_limit`）；shm 线程自适应退避（1s 唤醒 1000 次 → 50 次） |

---

## 9. 维护须知与红线

### 9.1 绝对不能碰

1. **不要硬猜内核结构体偏移**。`dev->mt`、`dev->keybit` 这些都想要，但历史上炸内核就是这么来的。KPM 环境下拿不到可靠偏移，宁可走事件层等价方案。
2. **不要在 `input_event` 回调里遍历页表**。可能在中断上下文，且高频。
3. **不要删掉 `hy_ie_common` 里 EV_ABS 的那段拦截**。keybit 屏蔽够不着它，删了手指一帧就没。
4. **`tscan` 单独试**。帮助文本里标注了「历史崩点」。

### 9.2 改版本号时

必须同步改这三处，否则发布脚本第 5/6 项会拦：
- `hy.h` 的 `HY_VERSION_STRING` / `HY_VER_MAJOR` / `HY_VER_MINOR` / `HY_VER_PATCH`
- `huanyu.hpp`
- `huanyu_wanbai.hpp`

> 1.78.0 时漏改 `HY_VER_MINOR` 被静态断言拦下——那个断言就是为这种事准备的。

### 9.3 实测参数（本机）

```
触摸屏设备   : touchpanel = /dev/input/event7
面板坐标范围 : 0..20351 × 0..44351
槽位总数     : 10（ABS_MT_SLOT max = 9）
协议         : B（INPUT_PROP_DIRECT）
屏幕分辨率   : 1080 × 2354（FHD+ 高清档）
倍率         : 面板 = 屏幕像素 × 18.84
```

> ⚠️ 系统若设为「智能切换」，切到 1272×2772 档时倍率变为 **16.0**（20351÷1272 = 44351÷2772 ≈ 15.997），同一组面板坐标对应的屏幕位置会偏。**调试期间固定到 FHD+ 高清 1080×2354**。

### 9.4 验证清单（新版本加载后）

```bash
echo 'version'    > /proc/HuanyuD; cat /proc/HuanyuD   # 确认版本
echo 'trange 0 20351 0 44351' > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tslots 10'  > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tfinger'    > /proc/HuanyuD; cat /proc/HuanyuD   # cap 应 = 10
echo 'touchstat'  > /proc/HuanyuD; cat /proc/HuanyuD   # found=1, proto=B
echo 'tdown 10175 22175' > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tup'        > /proc/HuanyuD; cat /proc/HuanyuD
echo 'tstat'      > /proc/HuanyuD; cat /proc/HuanyuD   # protect > 0
```

开「开发者选项 → 指针位置」看落点是否在屏幕正中。

---

*文档对应版本 1.80.0 · 生成于最终交付*
