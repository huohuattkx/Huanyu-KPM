/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_scheme.h —— 统一方案选择器（多内核世代 + 自动降级）
 *
 * 【要解决的问题】
 *   同一件事在不同内核上"能跑的那套做法"不一样：
 *     - 物理地址换算：6.x 有 physvirt_offset，5.x 只有 memstart_addr，
 *       4.x 得靠页表反推，3.x 只能按固定偏移猜。
 *     - 触摸 hook：6.x GKI 开 LTO，input_event 常被内联，得挂
 *       input_handle_event；老内核挂 input_event 就行。
 *     - 读取后端：多路缓存 / 单路 / 无缓存，性能与"无痕"此消彼长。
 *   以前这些分支散落在各文件里，各自为政，没有统一的
 *   "这套不行换下一套"。
 *
 * 【统一模型】
 *   每个功能面（域）持有一张按**内核世代降序**排列的方案表：
 *       [0] 6 系方案  ← 最先试
 *       [1] 5 系方案
 *       [2] 4 系方案
 *       [3] 3 系方案  ← 最后兜底
 *   初始化时从 [0] 往下逐个 probe，第一个通过的就是当前方案。
 *   运行期若该方案失败（读不到、hook 不上、装不上），调 hy_scheme_fail()
 *   自动降到下一档并重新 apply，直到兜底档。
 *
 *   注意"6 系方案"指**面向 6 系内核设计的做法**，不是"只能在 6 上跑"。
 *   5 系内核上 6 系方案往往同样成立（很多机制 5.x 后期就有了），
 *   所以从高往低试恰好符合"先试高级的，不行再降级"的预期。
 *
 * 【屎山防线】
 *   1. probe 必须是真检测：只准读符号/寄存器/已有能力位，不准猜偏移。
 *   2. apply 只做"切开关/换参数"，不做初始化（初始化仍由各模块负责）。
 *   3. 域表是 const 静态数据，运行期只改 chosen 索引，不复制不重排。
 */
#ifndef HY_SCHEME_H
#define HY_SCHEME_H

#include <ktypes.h>

/* 内核世代：由 kver 推导，用作方案档位的命名与排序依据 */
#define HY_GEN_3 3
#define HY_GEN_4 4
#define HY_GEN_5 5
#define HY_GEN_6 6

/* 方案域。新增域：在 hy_scheme.c 的 g_sel / g_kind 里各加一项，枚举末尾追加。 */
enum hy_sc_dom {
    HY_SC_PHYSVIRT = 0,   /* 物理地址 <-> 内核虚拟地址换算 */
    HY_SC_PGTABLE,        /* 页表级数与虚拟地址位数的确定方式 */
    HY_SC_MEMREAD,        /* 进程内存读取后端 */
    HY_SC_KERNW,          /* 内核虚拟地址 / 物理地址读写后端 */
    HY_SC_BP,             /* 断点落地方案（用户未显式指定时的默认链） */
    HY_SC_INPUT,          /* 触摸事件观察点 */
    HY_SC_SYM,            /* 内核符号解析策略 */
    HY_SC_COUNT
};

typedef int (*hy_sc_probe_fn)(void);   /* 返回 0 = 该方案可用 */
typedef int (*hy_sc_apply_fn)(void);   /* 返回 0 = 切换成功 */

typedef struct {
    int              gen;    /* 面向的内核世代，仅用于排序与显示 */
    const char      *name;   /* 短名，打日志和显示用 */
    hy_sc_probe_fn   probe;  /* 可行性检测，必须真实 */
    hy_sc_apply_fn   apply;  /* 启用该方案（本表内保留，域级 apply 优先） */
} hy_scheme_t;

/* ---- 查询 ---- */
int  hy_scheme_gen(void);                  /* 当前内核世代（3/4/5/6） */
int  hy_scheme_chosen(int dom);            /* 当前选中索引，-1 = 无可用方案 */
int  hy_scheme_gen_of(int dom);            /* 当前方案所属世代 */
const char *hy_scheme_name(int dom);       /* 当前方案短名 */
const char *hy_scheme_dom_name(int dom);   /* 域名 */

/* ---- 控制 ---- */
void hy_scheme_init(void);                 /* init 早期：地址/符号/读取类域 */
void hy_scheme_init_late(void);            /* bp / input 等依赖子系统 init 的域 */
int  hy_scheme_demote(int dom);            /* 手动降一档，返回新索引或 -1 */
int  hy_scheme_fail(int dom);              /* 运行期失败：自动降档并重取 */
u32  hy_scheme_demotions(int dom);         /* 该域累计降级次数 */
int  hy_scheme_force(int dom, int gen);    /* 强制指定世代，0 = 恢复自动 */

/* ---- 各域"当前选中"的业务编号 ----
 * 不提供转发式 getter：各模块已有自己的 *_kind()/prefer_mode()，
 * 需要当前档位就调它们，或用上面的 hy_scheme_chosen/name 通用查询。
 */

/* PHYSVIRT 方案编号 */
#define HY_PV_PHYSVIRT_OFFSET 0  /* 6 系：直接读 physvirt_offset 符号 */
#define HY_PV_MEMSTART_ADDR   1  /* 5 系：PAGE_OFFSET - memstart_addr */
#define HY_PV_SWAPPER_PGD     2  /* 4 系：swapper_pg_dir 的 VA 减 TTBR1 物理地址（纯算术） */
#define HY_PV_FIXED_GUESS     3  /* 3 系：固定偏移假设，靠往返自测兜底 */

/* PGTABLE 方案编号 */
#define HY_PG_TCR_EL1    0  /* 6 系：读 TCR_EL1.T1SZ 得出 VA 位数 */
#define HY_PG_VABITS_SYM 1  /* 5 系：读 vabits_actual / va_bits 符号 */
#define HY_PG_PROBE_WALK 2  /* 4 系：先按 4 级走一遍内核页表，失败退 3 级 */
#define HY_PG_FIXED_39   3  /* 3 系：固定 39-bit / 3 级，最保守 */

/* MEMREAD 方案编号（进程内存读取） */
#define HY_MR_PT_WAY8    0  /* 6 系：页表遍历 + 8 路缓存 */
#define HY_MR_PT_WAY4    1  /* 5 系：页表遍历 + 4 路缓存 */
#define HY_MR_PT_WAY1    2  /* 4 系：页表遍历 + 单路缓存 */
#define HY_MR_PT_NOCACHE 3  /* 3 系：页表遍历，每次重走，不留任何缓存状态 */

/* KERNW 方案编号（内核/物理读写） */
#define HY_KW_KMA        0  /* 6 系：KMA 硬件级窗口，绕过线性映射 */
#define HY_KW_LINEAR     1  /* 5 系：线性映射直读 */
#define HY_KW_LINEAR_CHK 2  /* 4 系：线性映射 + 映射有效性校验 */
#define HY_KW_LINEAR_MIN 3  /* 3 系：线性映射最小实现，只做边界检查 */

/* INPUT 方案编号 */
#define HY_IN_HANDLE_EVENT 0  /* 6 系：挂 input_handle_event 抗 LTO 内联 */
#define HY_IN_EVENT        1  /* 5 系：挂 input_event，启用槽位自学习 */
#define HY_IN_EVENT_SIMPLE 2  /* 4 系：挂 input_event，不做自学习 */
#define HY_IN_COUNT_ONLY   3  /* 3 系：只计数不注入，最保守 */

/* SYM 方案编号 */
#define HY_SYM_LOOKUP_ON_EACH 0 /* 6 系：lookup_name + on_each_symbol 双路 */
#define HY_SYM_LOOKUP_ONLY    1 /* 5 系：只用 kallsyms_lookup_name */
#define HY_SYM_ON_EACH_ONLY   2 /* 4 系：只走 on_each_symbol 遍历 */
#define HY_SYM_PRESET_ONLY    3 /* 3 系：只用 KP 已导出符号，不额外解析 */

#endif /* HY_SCHEME_H */
