#!/usr/bin/env bash
set -u
KP=${KP_DIR:-/data/workspace/KP139/KernelPatch-0.13.9}
CC=${CC:-aarch64-linux-gnu-gcc}
INC="-I. -I$KP/kernel -I$KP/kernel/include -I$KP/kernel/patch/include \
     -I$KP/kernel/linux/include -I$KP/kernel/linux/arch/arm64/include \
     -I$KP/kernel/linux/tools/arch/arm64/include"
#
# 【v1.17.0 性能优先编译】
# 用户要求：大小无所谓，只要性能好。
#
# 说明每一项的取舍：
#   -O3                  基础（原本就有）
#   -fno-semantic-interposition  允许跨 TU 内联，KPM 是整体链接，安全
#   --param=inline-unit-growth=200  放宽内联膨胀上限，热路径更多被内联
#   --param=large-function-growth=500
#   -funroll-loops       展开循环：页表遍历、进程扫描这类定长循环收益明显
#   -fpeel-loops
#   -ftree-vectorize     -O3 已含，显式写出
#   -fomit-frame-pointer 多出一个通用寄存器
#   -fno-plt             减少间接跳转
#
# 【刻意不加的】：
#   -flto                与 -r 部分链接 + KPM 加载器冲突，会破坏 .kpm.* 段
#   -fprofile-*          需要采集数据，实机跑不了
#   -march=armv8.4-a+    目标机是 8.3（PACGA 需要），超配会在老核上非法指令
#   -funroll-all-loops   会让 .text 膨胀数倍，且 -O3 的启发式更准
#
BASE="-D__KERNEL__ -D__LINUX__ -D__USE_MISC -D_GNU_SOURCE \
  -D__LINUX_ARM_ARCH__=8 -D__aarch64__ \
  -Wall -fno-builtin -std=gnu11 -nostdinc -mgeneral-regs-only -ffixed-x18 \
  -fno-stack-protector -fno-tree-loop-distribute-patterns -fno-pie -fno-pic \
  -fno-asynchronous-unwind-tables -fno-unwind-tables -fno-ident \
  -march=armv8.3-a -O3 \
  -fno-semantic-interposition -funroll-loops -fpeel-loops \
  -ftree-vectorize -fomit-frame-pointer -fno-plt \
  --param=inline-unit-growth=200 --param=large-function-growth=500 \
  --param=max-inline-insns-auto=200 \
  -fno-math-errno -fno-trapping-math"
SRCS="hy_gate.c hy_scheme.c hy_main.c hy_sym.c hy_discover.c hy_pt.c hy_bp.c hy_mem.c hy_input.c hy_hide.c hy_guard.c hy_task.c hy_ctl.c hy_insn.c hy_insn_prefix.c hy_pgtable.c hy_trampoline.c hy_extra.c hy_procfs.c hy_dbgfs.c hy_prctl.c hy_shm.c hy_pm.c hy_sysmon.c hy_cntvct.c hy_gnss.c hy_lsx.c hy_devinfo.c hy_stress.c hy_kma.c hy_net.c"
OBJS=""
rm -f *.o huanyu.kpm
for s in $SRCS; do
  o="${s%.c}.o"
  echo ">>> $s"
  $CC $INC $BASE -Tmodule.lds -c -o "$o" "$s" 2>&1 | grep -E "error|warning" | head -10
  [ -f "$o" ] || { echo "   FAILED: $s"; exit 1; }
  OBJS="$OBJS $o"
done
$CC -r -o huanyu.kpm $OBJS
echo "OK huanyu.kpm=$(stat -c%s huanyu.kpm)"
rm -f *.o
