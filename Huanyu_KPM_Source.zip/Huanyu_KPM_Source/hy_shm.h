/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_shm.h —— 欢愉共享内存通道（内核 / 用户态共用）
 *
 * 【灵感来源：lsdriver】
 *   lsdriver 不用 ioctl、不用 prctl、不用 supercall，
 *   而是让内核把用户态的一块内存直接映射到内核地址空间，
 *   双方读写同一份物理页：
 *
 *     get_user_pages_remote(mm, 0x2025827000, nr, FOLL_WRITE, pages, NULL)
 *     vmap(pages, nr, VM_MAP, PAGE_KERNEL)
 *
 *   之后 req->op / req->kernel / req->user 全部是纯内存读写，
 *   零系统调用、零拷贝。
 *
 *   它靠两点建立连接：固定虚拟地址 + 进程名 "LS"。
 *
 * 【欢愉的改动】
 *   进程名匹配要求一个独立守护进程，而欢愉的用户态是注入在游戏里的，
 *   改进程名会影响宿主。所以改成：
 *     用户态 mmap 任意地址 -> 通过现有命令通道注册 -> 内核 GUP + vmap
 *   注册是一次性动作，用哪个通道都无所谓；之后就完全不走系统调用。
 *
 *   固定地址方案作为兜底保留（SHM_PROBE 用进程名扫描）。
 *
 * 【零拷贝的关键】
 *   命令 payload 里的指针字段（如 hy_request.buffer）如果指向共享区内部，
 *   内核可以直接 memcpy，无需 copy_to_user。
 *   判断方法：指针落在 [shm_va, shm_va + shm_size) 内。
 *   hy_shm_translate() 干这件事，hy_mem.c 的传输路径会先问它。
 */
#ifndef HY_SHM_H
#define HY_SHM_H

#include <stdint.h>

#define HY_SHM_MAGIC   0x48796e75u   /* "Hynu" */
#define HY_SHM_VERSION 1u

/* 数据区 128 KB。够放下绝大多数读写请求，超出时用户态分多次。 */
#define HY_SHM_PAYLOAD (128u * 1024u)
#define HY_SHM_SIZE    (sizeof(struct hy_shm_obj))


/* ==========================================================================
 * 【lsdriver 同款：固定地址 + 进程名扫描】
 *
 * lsdriver 的连接方式（lsdriver.c ConnectThreadFunction）：
 *   for_each_process(task) {
 *       if (strcmp(task->comm, "LS") != 0) continue;
 *       mm = get_task_mm(task);
 *       get_user_pages_remote(mm, 0x2025827000, nr, FOLL_WRITE, pages, NULL);
 *       vmap(pages, nr, VM_MAP, PAGE_KERNEL);
 *   }
 *
 * 完全由内核侧发起：用户态只需 mmap 到那个固定地址，
 * 不需要任何注册命令、不需要任何系统调用。
 * 双方靠地址 + 进程名握手。
 * ========================================================================== */

/* ls 原版用的固定虚拟地址 */
#define HY_SHM_FIXED_VA 0x2025827000ULL

/* 目标进程名：内核线程扫描匹配。可用加载参数覆盖。 */
#define HY_SHM_TARGET_NAME_MAX 16

/* 扫描周期（毫秒） */
#define HY_SHM_SCAN_MS 2000

/* 默认目标进程名。可用模块加载参数 shm_name=xxx 覆盖。 */
#ifndef HY_SHM_DEFAULT_NAME
#define HY_SHM_DEFAULT_NAME "Huanyu"
#endif

/* state 取值 */
#define HY_SHM_IDLE 0u   /* 空闲，用户可提交 */
#define HY_SHM_REQ  1u   /* 用户已提交，等待内核 */
#define HY_SHM_BUSY 2u   /* 内核处理中 */

/* flags */
#define HY_SHM_F_READY  (1u << 0)   /* 内核侧映射完成 */
#define HY_SHM_F_KVA    (1u << 1)   /* payload 指针需按共享区翻译 */

#pragma pack(1)

struct hy_shm_obj {
    volatile uint32_t magic;
    volatile uint32_t version;

    volatile uint32_t state;   /* 见 HY_SHM_* */
    volatile uint32_t seq;     /* 用户每次提交 +1 */
    volatile uint32_t ack;     /* 内核完成后回写 = seq */
    volatile int32_t  ret;     /* 命令返回值 */

    volatile uint32_t nr;      /* 命令号 */
    volatile uint32_t len;     /* payload 有效长度 */
    volatile uint32_t flags;
    volatile uint32_t reserved0;

    /* 共享区在用户态的地址与大小，用户填、内核校验 */
    volatile uint64_t shm_va;
    volatile uint64_t shm_size;

    /* 统计 */
    volatile uint64_t requests;
    volatile uint64_t errors;

    uint8_t payload[HY_SHM_PAYLOAD];
};

#pragma pack()

/* 注册命令的 payload：把共享区地址告诉内核 */
struct hy_shm_register {
    uint64_t va;
    uint64_t size;
    uint32_t pid;      /* 拥有该共享区的进程（通常为调用者自己） */
    uint32_t reserved;
};

/* 注册结果回写 */
struct hy_shm_status {
    uint32_t ready;      /* 1 = 已映射 */
    uint32_t nr_pages;
    uint64_t kva;        /* 内核虚拟地址（调试用，用户态不可访问） */
    uint64_t requests;
    uint64_t errors;
};

#endif /* HY_SHM_H */
