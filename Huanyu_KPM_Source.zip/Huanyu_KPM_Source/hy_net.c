/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_net.c —— 网络访问预留（内核侧）
 *
 * 【这个文件不做什么】
 *   不发一个包。没有 socket，没有 DNS，没有 TLS。
 *
 * 【那它为什么存在】
 *   把"以后要读网站、下东西"这件事的**接口**先焊死：命令号、参数结构、
 *   状态码语义、能力协商方式全部定下来，用户态对接文件可以立刻照着写，
 *   以后不需要返工改接口。
 *
 *   同时它承担一件内核**确实能做**的事：让 /proc/HuanyuD 能如实回答
 *   "现在能不能下载"。用户敲 `net cap` 得到的是确定的答案，而不是猜测。
 *
 * 【为什么内核不做真实收发】
 *   1. 符号问题：sock_create_kern / kernel_connect / kernel_recvmsg 全套
 *      都不在 KP 导出表里，只能 kallsyms 现解析 —— 这是本项目历史上
 *      反复炸内核的根因（防格机早期版本、devinfo 早期版本皆出于此）。
 *   2. 布局问题：struct socket / msghdr / iov_iter / skb 一个头文件都没有，
 *      靠猜偏移必炸。
 *   3. 代价问题：用户态网络栈崩了只死那个进程；内核里崩了是整机重启。
 *
 *   三条叠加，结论唯一：内核侧只做意图记录与能力声明，收发交用户态。
 *
 * 【内核侧实际提供的价值】
 *   - ABI 校验：拒绝超长 URL、非法 method，不让脏参数流到用户态
 *   - 意图记录：记住最近一次请求，供 /proc 观察与排错
 *   - 能力声明：明确回复 kernel_impl=0 / userland_required=1
 */

#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include "hy.h"

#define HY_NET_ABI_VERSION      1
#define HY_NET_DEFAULT_TIMEOUT  10000

/* 最近一次请求意图，仅用于观察 */
static char  g_last_url[HY_NET_URL_MAX];
static u32   g_last_method;
static u32   g_last_flags;
static u32   g_last_timeout;
static u64   g_fetch_calls;
static u64   g_rejected;
static int   g_last_err;

/* ==================== 对外接口 ==================== */

int hy_net_available(void)
{
    /*
     * "可用"在这里的准确含义是：ABI 已就绪，且用户态应承担收发。
     * 它不表示内核能自己下载 —— 内核永远不做这件事。
     */
    return 1;
}

void hy_net_cap_fill(struct hy_net_cap *c)
{
    if (!c) return;

    hy_memset(c, 0, sizeof(*c));
    c->kernel_impl       = 0;   /* 内核不做收发 */
    c->userland_required = 1;   /* 必须由用户态完成 */
    c->abi_version       = HY_NET_ABI_VERSION;
}

/*
 * 校验一次拉取请求。
 * 只做内核该做的：把明显非法的参数挡在这里，避免脏数据外流。
 * 返回值 0 表示参数合法；非 0 为 errno 正值。
 */
int hy_net_validate(const struct hy_net_req *r)
{
    unsigned long i;
    int seen_nul = 0;

    if (!r) return 22;                              /* EINVAL */

    if (r->method != HY_NET_METHOD_GET &&
        r->method != HY_NET_METHOD_HEAD &&
        r->method != HY_NET_METHOD_POST)
        return 22;

    if (r->timeout_ms > 120000u) return 22;         /* 上限 2 分钟 */

    /*
     * URL 必须 NUL 结尾且不含控制字符。
     * 逐字节扫描而不是 strlen —— 调用方可能传未清零的缓冲，
     * strlen 会一路读到越界处。
     */
    for (i = 0; i < HY_NET_URL_MAX; i++) {
        unsigned char ch = (unsigned char)r->url[i];
        if (ch == 0) { seen_nul = 1; break; }
        if (ch < 0x20 || ch == 0x7f) return 22;
    }
    if (!seen_nul) return 22;
    if (i == 0) return 22;                          /* 空 URL */

    return 0;
}

/*
 * 记录一次拉取意图。真实收发由用户态完成，这里只留痕。
 */
int hy_net_note(const struct hy_net_req *r)
{
    int rc = hy_net_validate(r);
    unsigned long n;

    g_fetch_calls++;

    if (rc != 0) {
        g_rejected++;
        g_last_err = -rc;
        return -rc;
    }

    n = hy_strlen(r->url);
    if (n >= HY_NET_URL_MAX) n = HY_NET_URL_MAX - 1;
    hy_memcpy(g_last_url, r->url, n);
    g_last_url[n] = 0;

    g_last_method  = r->method;
    g_last_flags   = r->flags;
    g_last_timeout = r->timeout_ms ? r->timeout_ms : HY_NET_DEFAULT_TIMEOUT;
    g_last_err     = 0;

    HY_LOG("net: noted url=%s method=%u timeout=%ums (userland does I/O)\n",
           g_last_url, g_last_method, g_last_timeout);

    return 0;
}

/*
 * 本文件不引入格式化函数：内核侧没有 snprintf 可用（KPM 不链接内核的
 * vsnprintf），因此用小工具手工拼。追加一律检查边界，绝不越界写。
 */
static void net_append(char *b, unsigned long cap, unsigned long *pos,
                       const char *s)
{
    while (*s) {
        if (*pos + 1 >= cap) return;
        b[(*pos)++] = *s++;
    }
    b[*pos] = 0;
}

static void net_append_u64(char *b, unsigned long cap, unsigned long *pos,
                           unsigned long long v)
{
    char tmp[24];
    int i = 0;

    if (!v) tmp[i++] = '0';
    while (v) { tmp[i++] = (char)('0' + (int)(v % 10)); v /= 10; }
    while (i > 0) {
        if (*pos + 1 >= cap) break;
        b[(*pos)++] = tmp[--i];
    }
    b[*pos] = 0;
}

/* 供 /proc/HuanyuD 与 procfs 打印 */
void hy_net_status_line(char *b, unsigned long cap)
{
    static const char *const names[] = { "GET", "HEAD", "POST" };
    unsigned long pos = 0;
    const char *mname;

    if (!b || cap == 0) return;

    mname = (g_last_method < 3) ? names[g_last_method] : "?";
    if (!g_last_url[0]) mname = "-";

    b[0] = 0;
    net_append(b, cap, &pos, "net: abi=");
    net_append_u64(b, cap, &pos, (unsigned long long)HY_NET_ABI_VERSION);
    net_append(b, cap, &pos, " kernel_impl=0 userland=1 calls=");
    net_append_u64(b, cap, &pos, g_fetch_calls);
    net_append(b, cap, &pos, " rejected=");
    net_append_u64(b, cap, &pos, g_rejected);
    net_append(b, cap, &pos, "\nnet: last=");
    net_append(b, cap, &pos, g_last_url[0] ? g_last_url : "(none)");
    net_append(b, cap, &pos, " method=");
    net_append(b, cap, &pos, mname);
    net_append(b, cap, &pos, " timeout=");
    net_append_u64(b, cap, &pos, (unsigned long long)g_last_timeout);
    net_append(b, cap, &pos, "ms err=");
    net_append_u64(b, cap, &pos,
                   (unsigned long long)(g_last_err < 0 ? -g_last_err : g_last_err));
}

/* ==================== 生命周期 ==================== */

int hy_net_init(void)
{
    hy_memset(g_last_url, 0, sizeof(g_last_url));
    g_last_method  = HY_NET_METHOD_GET;
    g_last_flags   = 0;
    g_last_timeout = HY_NET_DEFAULT_TIMEOUT;
    g_fetch_calls  = 0;
    g_rejected     = 0;
    g_last_err     = 0;

    HY_LOG("net: ABI v%d ready (kernel does no I/O; userland required)\n",
           HY_NET_ABI_VERSION);
    return 0;
}

void hy_net_exit(void)
{
    hy_memset(g_last_url, 0, sizeof(g_last_url));
    HY_LOG("net: exit\n");
}
