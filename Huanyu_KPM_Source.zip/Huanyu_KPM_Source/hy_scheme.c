/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_scheme.c —— 统一方案选择器实现
 *
 * 只做三件事，别的都不做：
 *   1. 按内核世代给每个域排一张候选表（const 静态数据，运行期不改动）
 *   2. 从表头往下 probe，第一个通过的就是当前方案
 *   3. 运行期被告知"当前方案失败"时，把 chosen 往后挪一档并重新 apply
 *
 * 各域"怎么算、怎么切"由对应模块自己提供 setter/getter，本文件不复制
 * 它们的算法 —— 那是屎山的主要来源（同一份逻辑被抄成两份后必然分叉）。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <kallsyms.h>
#include "hy.h"
#include "hy_scheme.h"

/* ==================== 内核世代 ==================== */

int hy_scheme_gen(void)
{
    int major = (int)(kver >> 16);
    if (major >= 6) return HY_GEN_6;
    if (major == 5) return HY_GEN_5;
    if (major == 4) return HY_GEN_4;
    return HY_GEN_3;
}

/* ==================== 各模块提供的 setter / getter ==================== */

/* hy_pt.c：物理地址换算与页表参数 */
extern int  hy_pt_try_physvirt(int kind, unsigned long *out_off);
extern int  hy_pt_apply_physvirt(int kind);
extern int  hy_pt_try_pgparams(int kind, int *levels, u64 *va_bits,
                               unsigned long *page_offset);
extern int  hy_pt_apply_pgparams(int kind);
extern int  hy_pt_pv_kind(void);
extern int  hy_pt_pg_kind(void);

/* hy_mem.c：进程内存读取后端 */
extern int  hy_mem_apply_backend(int kind);
extern int  hy_mem_backend_kind(void);

/* hy_bp.c：断点默认方案 */
extern int  hy_bp_apply_prefer(int mode);
extern int  hy_bp_prefer_mode(void);
extern u32  hy_bp_caps(void);

/* hy_input.c：触摸观察点 */
extern int  hy_input_observer_available(int kind);
extern int  hy_input_apply_observer(int kind);
extern int  hy_input_observer_kind(void);

/* hy_sym.c：符号解析策略 */
extern int  hy_sym_strategy_available(int kind);
extern int  hy_sym_apply_strategy(int kind);
extern int  hy_sym_strategy_kind(void);

/* hy_kma.c */
extern int  hy_kma_available(void);

/* hy_main.c 的加载开关（v1.65.0 二分定位） */
extern int hy_opt_noscheme;
extern int hy_opt_nopick;

/* ==================== 域 1：物理地址换算 ==================== */

static int pv_probe_physvirt_offset(void)
{
    return hy_pt_try_physvirt(HY_PV_PHYSVIRT_OFFSET, NULL);
}
static int pv_probe_memstart(void)
{
    return hy_pt_try_physvirt(HY_PV_MEMSTART_ADDR, NULL);
}
static int pv_probe_swapper_pgd(void)
{
    return hy_pt_try_physvirt(HY_PV_SWAPPER_PGD, NULL);
}
static int pv_probe_fixed_guess(void)
{
    return hy_pt_try_physvirt(HY_PV_FIXED_GUESS, NULL);
}

static int pv_apply(int kind) { return hy_pt_apply_physvirt(kind); }

static const hy_scheme_t pv_list[] = {
    { HY_GEN_6, "physvirt_off", pv_probe_physvirt_offset, NULL },
    { HY_GEN_5, "memstart",     pv_probe_memstart,        NULL },
    { HY_GEN_4, "swapper-pgd",  pv_probe_swapper_pgd,     NULL },
    { HY_GEN_3, "fixed-guess",  pv_probe_fixed_guess,     NULL },
};

/* ==================== 域 2：页表参数 ==================== */

static int pg_probe_tcr(void)
{
    return hy_pt_try_pgparams(HY_PG_TCR_EL1, NULL, NULL, NULL);
}
static int pg_probe_vabits(void)
{
    return hy_pt_try_pgparams(HY_PG_VABITS_SYM, NULL, NULL, NULL);
}
static int pg_probe_walk(void)
{
    return hy_pt_try_pgparams(HY_PG_PROBE_WALK, NULL, NULL, NULL);
}
static int pg_probe_fixed39(void)
{
    return hy_pt_try_pgparams(HY_PG_FIXED_39, NULL, NULL, NULL);
}

static const hy_scheme_t pg_list[] = {
    { HY_GEN_6, "tcr-t1sz",   pg_probe_tcr,     NULL },
    { HY_GEN_5, "vabits-sym", pg_probe_vabits,  NULL },
    { HY_GEN_4, "probe-walk", pg_probe_walk,    NULL },
    { HY_GEN_3, "fixed-39",   pg_probe_fixed39, NULL },
};

/* ==================== 域 3：进程内存读取后端 ==================== */

static int mr_apply(int kind) { return hy_mem_apply_backend(kind); }

static const hy_scheme_t mr_list[] = {
    { HY_GEN_6, "pt-way8",   NULL, NULL },
    { HY_GEN_5, "pt-way4",   NULL, NULL },
    { HY_GEN_4, "pt-way1",   NULL, NULL },
    { HY_GEN_3, "pt-nocache", NULL, NULL },
};

/* ==================== 域 4：内核/物理读取后端 ==================== */

static int kp_probe_kma(void) { return hy_kma_available() ? 0 : -1; }
static int kp_probe_linear(void) { return 0; }

static int kp_apply(int kind)
{
    /* 只有 6 系档走 KMA，其余一律线性映射直读 */
    hy_kma_set_mode(kind == HY_KW_KMA ? 1 : 0);
    return 0;
}

static const hy_scheme_t kp_list[] = {
    { HY_GEN_6, "kma-window", kp_probe_kma,    NULL },
    { HY_GEN_5, "linear",     kp_probe_linear, NULL },
    { HY_GEN_4, "linear-chk", kp_probe_linear, NULL },
    { HY_GEN_3, "linear-min", kp_probe_linear, NULL },
};

/* ==================== 域 5：断点落地方案 ==================== */

static int bp_probe_pte(void) { return (hy_bp_caps() & HY_BP_CAP_PTE) ? 0 : -1; }
static int bp_probe_hw(void)  { return (hy_bp_caps() & HY_BP_CAP_HW)  ? 0 : -1; }
static int bp_probe_sw(void)  { return (hy_bp_caps() & HY_BP_CAP_SW)  ? 0 : -1; }

static const hy_scheme_t bp_list[] = {
    { HY_GEN_6, "pte-shadow", bp_probe_pte, NULL },
    { HY_GEN_5, "hw-regs",    bp_probe_hw,  NULL },
    { HY_GEN_4, "sw-brk",     bp_probe_sw,  NULL },
    { HY_GEN_3, "sw-brk-safe", bp_probe_sw, NULL },
};

/* ==================== 域 6：触摸观察点 ==================== */

static int in_probe_handle_event(void)
{
    return hy_input_observer_available(HY_IN_HANDLE_EVENT);
}
static int in_probe_event(void)
{
    return hy_input_observer_available(HY_IN_EVENT);
}
static int in_probe_event_simple(void)
{
    return hy_input_observer_available(HY_IN_EVENT_SIMPLE);
}
static int in_probe_count_only(void) { return 0; }

static int in_apply(int kind) { return hy_input_apply_observer(kind); }

static const hy_scheme_t in_list[] = {
    { HY_GEN_6, "handle_event", in_probe_handle_event, NULL },
    { HY_GEN_5, "input_event",  in_probe_event,        NULL },
    { HY_GEN_4, "ie-simple",    in_probe_event_simple, NULL },
    { HY_GEN_3, "count-only",   in_probe_count_only,   NULL },
};

/* ==================== 域 7：符号解析策略 ==================== */

static int sy_probe_lookup_on_each(void)
{
    return hy_sym_strategy_available(HY_SYM_LOOKUP_ON_EACH);
}
static int sy_probe_lookup_only(void)
{
    return hy_sym_strategy_available(HY_SYM_LOOKUP_ONLY);
}
static int sy_probe_on_each_only(void)
{
    return hy_sym_strategy_available(HY_SYM_ON_EACH_ONLY);
}
static int sy_probe_preset_only(void) { return 0; }

static int sy_apply(int kind) { return hy_sym_apply_strategy(kind); }

static const hy_scheme_t sy_list[] = {
    { HY_GEN_6, "lk+each",  sy_probe_lookup_on_each, NULL },
    { HY_GEN_5, "lk-only",  sy_probe_lookup_only,    NULL },
    { HY_GEN_4, "each-only", sy_probe_on_each_only,  NULL },
    { HY_GEN_3, "preset",   sy_probe_preset_only,    NULL },
};

/* ==================== 域注册表 ==================== */

typedef struct {
    const char        *dom;
    const hy_scheme_t *list;
    int                n;
    int (*apply)(int);        /* 域级 apply，参数语义由各域自定 */
    int                stage; /* 0 = 早期（符号就绪即可） 1 = 后期（依赖子系统 init） */
    int                chosen;
    int                forced;
    u32                demotions;
} hy_sel_t;

/*
 * stage 为什么分两段：
 *   bp 域的 probe 要读 hy_bp_caps()，那得等 hy_bp_init() 跑完才有意义；
 *   input 域要读 hook 目标函数指针，那是 hy_input_init() 里才解析的。
 *   这两个域在早期 probe 只会得到"全部不可用"，然后被永久钉在兜底档，
 *   降级链形同虚设。所以放到 hy_scheme_init_late() 里选。
 */
/*
 * v1.65.0 旁路标志。
 * noscheme=1 / nopick=1 时框架只登记不 probe/apply，各模块保持自己
 * 内置的默认档（等同 v1.63 行为）。这样一旦怀疑框架是崩点，
 * 不用回退版本就能确认 —— 二分定位的关键一环。
 *
 * 两者区别：
 *   noscheme : 完全不碰框架，chosen 全 -1，demote/fail 全部失败。
 *   nopick   : 框架状态可用，只是 init 阶段不选档（保留运行期手动降档）。
 */
static int g_bypass;

static hy_sel_t g_sel[HY_SC_COUNT] = {
    { "physvirt", pv_list, (int)(sizeof(pv_list)/sizeof(pv_list[0])), pv_apply, 0, -1, 0, 0 },
    { "pgtable",  pg_list, (int)(sizeof(pg_list)/sizeof(pg_list[0])), NULL,     0, -1, 0, 0 },
    { "memread",  mr_list, (int)(sizeof(mr_list)/sizeof(mr_list[0])), mr_apply, 0, -1, 0, 0 },
    { "kernrw",   kp_list, (int)(sizeof(kp_list)/sizeof(kp_list[0])), kp_apply, 0, -1, 0, 0 },
    { "bp",       bp_list, (int)(sizeof(bp_list)/sizeof(bp_list[0])), NULL,     1, -1, 0, 0 },
    { "input",    in_list, (int)(sizeof(in_list)/sizeof(in_list[0])), in_apply, 1, -1, 0, 0 },
    { "sym",      sy_list, (int)(sizeof(sy_list)/sizeof(sy_list[0])), sy_apply, 0, -1, 0, 0 },
};

/* 每档的"业务编号"，供 apply 与对外查询使用。
 * 与 list 索引一一对应，单独放是为了避免把编号塞进 const 表后被误改。 */
static const int g_kind[HY_SC_COUNT][4] = {
    { HY_PV_PHYSVIRT_OFFSET, HY_PV_MEMSTART_ADDR, HY_PV_SWAPPER_PGD,    HY_PV_FIXED_GUESS },
    { HY_PG_TCR_EL1,         HY_PG_VABITS_SYM,    HY_PG_PROBE_WALK,     HY_PG_FIXED_39 },
    { HY_MR_PT_WAY8,         HY_MR_PT_WAY4,       HY_MR_PT_WAY1,        HY_MR_PT_NOCACHE },
    { HY_KW_KMA,             HY_KW_LINEAR,   HY_KW_LINEAR_CHK,  HY_KW_LINEAR_MIN },
    { HY_BP_MODE_PTE,        HY_BP_MODE_HW,       HY_BP_MODE_SW,        HY_BP_MODE_SW },
    { HY_IN_HANDLE_EVENT,    HY_IN_EVENT,         HY_IN_EVENT_SIMPLE,   HY_IN_COUNT_ONLY },
    { HY_SYM_LOOKUP_ON_EACH, HY_SYM_LOOKUP_ONLY,  HY_SYM_ON_EACH_ONLY,  HY_SYM_PRESET_ONLY },
};

/* 各域 apply 的实际执行：pgtable / bp 两域参数语义特殊，单独处理 */
static int sel_apply(hy_sel_t *s, int dom, int idx)
{
    if (idx < 0 || idx >= s->n) return -1;

    /* pgtable 与 bp 的参数语义由各自模块解释，其余走域级 apply */
    if (dom == HY_SC_PGTABLE)
        return hy_pt_apply_pgparams(g_kind[dom][idx]);
    if (dom == HY_SC_BP)
        return hy_bp_apply_prefer(g_kind[dom][idx]);
    if (s->apply)
        return s->apply(g_kind[dom][idx]);

    /* 无 apply 的域：选定即生效 */
    return 0;
}

/* 从 from 开始往下找第一个可用的档 */
static int sel_pick_from(hy_sel_t *s, int dom, int from)
{
    int i;
    for (i = (from < 0 ? 0 : from); i < s->n; i++) {
        if (s->forced && s->list[i].gen != s->forced) continue;
        if (s->list[i].probe && s->list[i].probe() != 0) continue;
        if (sel_apply(s, dom, i) != 0) continue;
        s->chosen = i;
        return i;
    }
    /*
     * 【v1.65.0 修】失败时不要把 chosen 污染成 -1。
     * 原来这里写 -1，而 demote 里 "chosen < 0 就从 0 重选"，
     * 于是降到底之后再 fail 会回到第 0 档重来 ——
     * 配合 pt 的 while(guard++<8) 就是原地打转 8 次，日志刷屏且
     * 反复 apply 同一套已经证明不可用的方案。
     * 保留 chosen 不动，下一次 demote 才真的会向前走。
     */
    return -1;
}

/* ==================== 对外接口 ==================== */

/*
 * 早期域的选取顺序：pgtable 必须排在 physvirt 之前。
 * physvirt 的 swapper-pgd 档要用 TTBR1 的页表物理基址，读的是系统寄存器，
 * 不依赖页表参数；但 fixed-guess 档需要由 va_bits 推出的 PAGE_OFFSET，
 * 所以页表参数还是得先定。
 */
static const int early_order[] = {
    HY_SC_PGTABLE, HY_SC_PHYSVIRT, HY_SC_SYM, HY_SC_MEMREAD, HY_SC_KERNW
};

static void scheme_pick_stage(int stage)
{
    int k;
    int n = (stage == 0)
          ? (int)(sizeof(early_order)/sizeof(early_order[0]))
          : HY_SC_COUNT;

    for (k = 0; k < n; k++) {
        int d = (stage == 0) ? early_order[k] : k;
        int i;
        if (d < 0 || d >= HY_SC_COUNT) continue;
        if (g_sel[d].stage != stage) continue;

        i = sel_pick_from(&g_sel[d], d, 0);
        if (i >= 0) {
            HY_LOG("scheme: %-9s -> gen%d %s\n", g_sel[d].dom,
                   g_sel[d].list[i].gen, g_sel[d].list[i].name);
        } else {
            HY_LOG("scheme: %-9s -> NO SCHEME AVAILABLE\n", g_sel[d].dom);
        }
    }
}

void hy_scheme_init(void)
{
    HY_LOG("scheme: kernel gen=%d (kver=0x%x)\n", hy_scheme_gen(), kver);

    if (hy_opt_noscheme || hy_opt_nopick) {
        int d;
        g_bypass = 1;
        for (d = 0; d < HY_SC_COUNT; d++) g_sel[d].chosen = -1;

        /*
         * 旁路不等于"什么参数都不设"—— 那样 hy_physvirt_off 会是 0，
         * 后续所有地址换算全错。这里显式套用各模块的**内置默认档**
         * （就是 v1.63 及之前硬编码的那套），保证行为与旧版一致：
         *   pgtable  : TCR_EL1
         *   physvirt : physvirt_offset
         *   memread  : 8 路缓存
         *   kernw    : 线性映射
         *   sym      : lookup + on_each
         * 顺序不能乱：physvirt 的 memstart / fixed-guess 两档要用
         * 由 va_bits 推出的 PAGE_OFFSET，必须先有页表参数。
         */
        hy_pt_apply_pgparams(HY_PG_TCR_EL1);
        hy_pt_apply_physvirt(HY_PV_PHYSVIRT_OFFSET);
        hy_mem_apply_backend(HY_MR_PT_WAY8);
        hy_kma_set_mode(0);
        hy_sym_apply_strategy(HY_SYM_LOOKUP_ON_EACH);

        HY_LOG("scheme: BYPASSED (noscheme=%d nopick=%d), builtin defaults "
               "applied\n", hy_opt_noscheme, hy_opt_nopick);
        return;
    }
    scheme_pick_stage(0);
}

/* 断点与触摸两个域要等各自子系统 init 完才有可判断的能力位/函数指针 */
void hy_scheme_init_late(void)
{
    if (g_bypass) return;
    scheme_pick_stage(1);
}

int hy_scheme_chosen(int dom)
{
    if (dom < 0 || dom >= HY_SC_COUNT) return -1;
    return g_sel[dom].chosen;
}

int hy_scheme_gen_of(int dom)
{
    int i;
    if (dom < 0 || dom >= HY_SC_COUNT) return 0;
    i = g_sel[dom].chosen;
    if (i < 0) return 0;
    return g_sel[dom].list[i].gen;
}

const char *hy_scheme_name(int dom)
{
    int i;
    if (dom < 0 || dom >= HY_SC_COUNT) return "?";
    i = g_sel[dom].chosen;
    if (i < 0) return "none";
    return g_sel[dom].list[i].name;
}

const char *hy_scheme_dom_name(int dom)
{
    if (dom < 0 || dom >= HY_SC_COUNT) return "?";
    return g_sel[dom].dom;
}

int hy_scheme_demote(int dom)
{
    hy_sel_t *s;
    int i;
    if (dom < 0 || dom >= HY_SC_COUNT) return -1;
    if (g_bypass) return -1;
    s = &g_sel[dom];
    if (s->chosen < 0) return sel_pick_from(s, dom, 0);
    if (s->chosen + 1 >= s->n) return -1;

    i = sel_pick_from(s, dom, s->chosen + 1);
    if (i >= 0) {
        s->demotions++;
        HY_LOG("scheme: %s demote -> gen%d %s\n", s->dom,
               s->list[i].gen, s->list[i].name);
    }
    return i;
}

int hy_scheme_fail(int dom)
{
    /*
     * 与 demote 的区别：这是"运行期当前方案真的失败了"的入口。
     * 目前行为一致，分开是为了让调用点语义清楚，也方便以后加"重试 N 次
     * 才降档"这类策略时不改动调用方。
     */
    return hy_scheme_demote(dom);
}

u32 hy_scheme_demotions(int dom)
{
    if (dom < 0 || dom >= HY_SC_COUNT) return 0;
    return g_sel[dom].demotions;
}

int hy_scheme_force(int dom, int gen)
{
    hy_sel_t *s;
    if (dom < 0 || dom >= HY_SC_COUNT) return -1;
    if (g_bypass) return -1;
    s = &g_sel[dom];
    s->forced = gen;
    return sel_pick_from(s, dom, 0);
}

/* ==================== 业务查询 ====================
 *
 * 这里刻意不提供 hy_sc_*_kind() 之类的转发函数。
 * 各模块本来就有自己的 getter（hy_pt_pv_kind / hy_mem_backend_kind /
 * hy_bp_prefer_mode / hy_input_observer_kind / hy_sym_strategy_kind），
 * 再包一层转发只会多出一组没人调用的空壳，改起来还容易漏同步。
 * 需要知道"当前落在哪档"直接调模块自己的 getter，或走
 * hy_scheme_chosen / hy_scheme_name 这对通用查询。
 */
