/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_guard.c —— Huanyu 顶级防格机（v1.51.0 从零重写）
 *
 * ============================================================================
 * 【三个目标】
 *   1. 有效：覆盖所有已知"变砖"路径，且每条都有"双保险"兜底
 *   2. 高效：常规路径开销 ≈ 0（热路径只做整数测试，绝不 copy_from_user）
 *   3. 安全：零结构体布局依赖、零不透明指针解引用、任何一步失败只降级
 *
 * ============================================================================
 * 【为什么旧版 hy_antiwipe.c 必须推翻重写】
 *
 *   A. 参数取错 —— 防护从未生效
 *      旧版 hook 的是 __arm64_sys_openat 等内核 wrapper 符号。
 *      而 arm64 自 4.17 起强制 CONFIG_ARCH_HAS_SYSCALL_WRAPPER，
 *      其签名是 long (*)(const struct pt_regs *regs)，
 *      真实参数在 regs->regs[0..2] 里，不在 args->arg0/arg1。
 *      旧版按老签名读 args->arg1 当路径指针 —— 拿到的是垃圾寄存器值。
 *      结论：路径永远取不到，"拦截块设备写入"这个核心功能从未真正工作。
 *
 *   B. 热路径无条件 copy_from_user —— 白白付出巨大开销
 *      旧版每次 openat 都拷路径字符串。openat 是全系统最频繁的
 *      syscall 之一（每秒数千次），而其中绝大多数是只读打开。
 *      更糟的是返回值没检查：copy_from_user 失败时缓冲区内容未定义，
 *      却照样当字符串用 —— 这是"加载后随机炸内核"的经典来源。
 *
 *   C. reboot 无条件拦截 —— 制造另一种砖
 *      旧版拦所有 reboot，意味着正常重启/关机都做不了。
 *      手机照样变废物，只是方式不同。
 *
 * ============================================================================
 * 【本版做法】
 *
 *   1. 一律用 hook_syscalln()（KP 已解包好的 syscall 参数），
 *      彻底绕开 pt_regs / syscall wrapper 的签名差异问题。
 *
 *   2. 每个回调第一行就是整数快速判断，不匹配立即返回。
 *      openat 只在"写打开"时才进入慢路径（拷字符串）。
 *      只读打开 —— 占 openat 调用的绝大多数 —— 开销是两次内存读加一次位测试。
 *
 *   3. 块设备 ioctl 改为 hook 内核函数 blkdev_ioctl。
 *      全局 ioctl(29) 被 binder 疯狂调用（BINDER_WRITE_READ 就是 ioctl），
 *      在上面加任何逻辑都是实打实的性能损失；
 *      而 blkdev_ioctl 只在真正的块设备上触发，冷到一天也没几次。
 *
 *   4. 【双保险】不依赖 skip_origin。
 *      syscall hook 的 skip_origin 有 can_skip 门槛（某些 KP 配置下不生效）。
 *      因此每条拦截都同时做两件事：
 *        - 设 skip_origin + ret = -EACCES   （能 skip 时生效）
 *        - 篡改某个参数让它必然失败        （不能 skip 时兜底）
 *      例如把 filename 指针改成内核地址 —— openat 的 copy_from_user
 *      对内核地址必然返回 -EFAULT，调用方拿不到任何可用的 fd。
 *      这样无论 skip_origin 是否生效，防护都成立。
 *
 * ============================================================================
 * 【覆盖的变砖路径】
 *   L1 块设备写打开        dd / mkfs / sgdisk / parted / fastbootd
 *   L2 块设备擦除 ioctl    blkdiscard / BLKSECDISCARD / BLKZEROOUT / BLKPG
 *   L3 危险重启            reboot bootloader|fastboot|recovery|edl|sideload
 *   L4 kexec 加载          直接跳新内核，绕过 L3
 *   L5 模块加载            恶意内核模块（比用户态破坏更彻底）
 *   L6 模块卸载            先卸掉保护再动手
 *   L7 杀 init             pid 1 死即 kernel panic
 *   L8 保护目录删除/移动    rm -rf /data/adb（APatch/Magisk/KP 的家）
 *
 * 【防不住的（必须说清楚）】
 *   - 已经进了 recovery / fastboot 之后点"清除数据"（内核已停止运行）
 *   - 物理按键进 EDL / 9008 线刷（不经过内核）
 *   - io_uring 发起的 openat（不走 el0_svc，hook_syscalln 看不到）
 *     这条可用 g_deep=1 补上，但依赖 struct filename 首成员是 name，
 *     属于结构体布局假设，故默认关闭。
 */

#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <hook.h>
#include <syscall.h>
#include <ksyms.h>
#include "hy.h"

/* hy_sym.c 里已长期验证的符号 */
extern long (*hy_f_copy_from_user)(void *dst, const void *src, unsigned long n);

/* ===================== 极小工具（不依赖 hy.h 的字符串函数） ===================== */
/*
 * 这里刻意自己实现而不复用 hy_memset / hy_strstr：
 * 那些函数在不同版本里时有时无，用错了就是隐式声明（arm64 上
 * 隐式声明按 int 返回值 + 通用寄存器传参处理，签名不符不会报错但结果是错的）。
 */

static void g_memset(void *d, int v, unsigned long n)
{
    unsigned char *p = (unsigned char *)d;
    while (n--) *p++ = (unsigned char)v;
}

/* 带上限的长度，绝不无限扫 */
static unsigned long g_strlen(const char *s, unsigned long cap)
{
    unsigned long i = 0;
    if (!s) return 0;
    while (i < cap && s[i]) i++;
    return i;
}

/* p 是否为 s 的前缀 */
static int g_prefix(const char *s, const char *p)
{
    unsigned long i = 0;
    if (!s || !p) return 0;
    while (p[i]) {
        if (s[i] != p[i]) return 0;
        i++;
        if (i > 255) return 0;
    }
    return 1;
}

/* s 是否包含子串 p */
static int g_sub(const char *s, const char *p)
{
    unsigned long i, j;
    if (!s || !p || !p[0]) return 0;
    for (i = 0; s[i] && i < 512; i++) {
        for (j = 0; p[j] && s[i + j] == p[j]; j++) ;
        if (!p[j]) return 1;
    }
    return 0;
}

static void g_copy(char *dst, const char *src, unsigned long cap)
{
    unsigned long i = 0;
    if (!dst) return;
    if (!src) { dst[0] = 0; return; }
    while (i < cap - 1 && src[i]) { dst[i] = src[i]; i++; }
    dst[i] = 0;
}

/* 简易十进制解析（内核态没有 strtol） */
static int g_atoi(const char *s)
{
    int v = 0;
    int neg = 0;
    if (!s) return -1;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') {
        if (v > 100000000) return neg ? -1 : -1;
        v = v * 10 + (*s - '0');
        s++;
    }
    return neg ? -v : v;
}

/* ================================= 常量 ================================= */

/* O_*（asm-generic，ABI 稳定） */
#define G_O_ACCMODE  0x0003u
#define G_O_TRUNC    0x0200u   /* 01000 */

/* 块设备擦除 ioctl（include/uapi/linux/fs.h，ABI 稳定） */
#define G_BLKDISCARD     0x1277u   /* _IO(0x12,119) */
#define G_BLKSECDISCARD  0x127du   /* _IO(0x12,125) */
#define G_BLKZEROOUT     0x127fu   /* _IO(0x12,127) */
#define G_BLKPG          0x1269u   /* _IO(0x12,105) —— 可删分区 */

/* 写打开时需要拦截的路径前缀 */
static const char *const g_dev_prefix[] = {
    "/dev/block/",      /* Android 统一入口（vold 也在下面） */
    "/dev/sd",          /* SCSI / UFS */
    "/dev/mmcblk",      /* eMMC */
    "/dev/mtd",         /* 裸 NAND */
    "/dev/ubi",
    "/dev/nvme",
    "/dev/loop",
    "/dev/dm-",         /* dm-crypt / dm-linear */
    "/dev/md",
    "/dev/ram",
    "/dev/zram",
    "/dev/mapper/",
    "/dev/by-name/",
    "/dev/raw",
    "/dev/mem",         /* 直接写物理内存 */
    "/dev/kmem",
    "/dev/ufs-bsg",
    "/dev/ufs",
    "/sys/block/",      /* sysfs 层面操作块设备 */
    "/proc/sysrq-trigger",  /* sysrq：可触发 emergency remount / 崩溃 */
};

/* 删除/移动操作的保护目录 */
static const char *const g_prot_dir[] = {
    "/data/adb",        /* APatch / Magisk / KernelPatch 的家 */
    "/system",
    "/vendor",
    "/product",
    "/system_ext",
    "/odm",
    "/boot",
    "/dev/block",
};

/* 危险重启命令（reboot 的 cmd 参数） */
static const char *const g_bad_reboot[] = {
    "bootloader",
    "fastboot",
    "recovery",
    "sideload",
    "sideload-auto-reboot",
    "download",
    "edl",
    "kexec",
    "hardreset",
    "wipe",
    "erase",
    "oem-",
};

/* ================================= 状态 ================================= */

static int  g_on;                /* 总开关 */
static int  g_hooks;             /* 已成功安装的 hook 数 */
static u64  g_blk_open;          /* L1 拦截计数 */
static u64  g_blk_ioctl;         /* L2 */
static u64  g_blk_reboot;        /* L3 */
static u64  g_blk_kexec;         /* L4 */
static u64  g_blk_mod;           /* L5 + L6 */
static u64  g_blk_kill;          /* L7 */
static u64  g_blk_del;           /* L8 */
static u64  g_total;             /* 合计 */
static char g_last[128];         /* 最近一次被拦的描述 */

/* 解锁窗口：窗口内全部放行，供自己刷机/恢复用 */
static u64 (*g_f_ktime)(void);   /* 秒级时钟，解析不到则退化为手动模式 */
static u64  g_unlock_until;      /* 窗口截止时刻（秒） */
static u64  g_unlock_cnt;        /* 开过几次窗口 */
static int  g_manual_unlock;     /* 无时钟时的手动开关 */

/* 细分开关 */
static int g_allow_mod;          /* 1 = 允许加载内核模块（默认禁） */
static int g_protect_del;        /* 1 = 保护目录删除拦截（默认开） */
static int g_deep;               /* 1 = 额外 hook do_filp_open 覆盖 io_uring */

/* blkdev_ioctl 的函数地址（hook_wrap 用） */
static void *g_blkdev_ioctl;
static void *g_do_filp_open;

/* 一个必然位于内核空间的字符串。
 * 把它当作用户态指针传给 syscall，copy_from_user 必然返回 -EFAULT，
 * 调用方就拿不到任何可用的 fd —— 这是不依赖 skip_origin 的兜底手段。 */
static const char g_fault_str[] = "\xef\xbf\xbdguard-denied";

static void *g_kva_fault;        /* 缓存 g_fault_str 的地址，避免每次取 */

/* ================================= 判定 ================================= */

static void g_note(const char *what, const char *detail, u64 *counter)
{
    /* 只在真正拦截时才走这里 —— 冷路径，可以慢一点 */
    if (counter) (*counter)++;
    g_total++;
    g_memset(g_last, 0, sizeof(g_last));
    g_copy(g_last, what, sizeof(g_last));
    {
        unsigned long n = g_strlen(g_last, sizeof(g_last) - 1);
        if (detail && n + 1 < sizeof(g_last) - 1) {
            g_last[n] = ' ';
            g_copy(g_last + n + 1, detail, sizeof(g_last) - n - 1);
        }
    }
    HY_LOG("guard: BLOCK %s %s\n", what, detail ? detail : "");
}

/* 解锁窗口内放行？ */
static int g_unlocked(void)
{
    if (!g_f_ktime) return g_manual_unlock ? 1 : 0;
    if (g_unlock_until == 0) return 0;
    return g_f_ktime() < g_unlock_until;
}

/* 路径是否为危险块设备 */
static int g_is_dev_path(const char *p)
{
    int i;
    if (!p || p[0] != '/') return 0;
    for (i = 0; i < (int)(sizeof(g_dev_prefix) / sizeof(g_dev_prefix[0])); i++) {
        if (g_prefix(p, g_dev_prefix[i])) return 1;
    }
    return 0;
}

/* 路径是否在保护目录内 */
static int g_is_prot_path(const char *p)
{
    int i;
    if (!p || p[0] != '/') return 0;
    for (i = 0; i < (int)(sizeof(g_prot_dir) / sizeof(g_prot_dir[0])); i++) {
        if (g_prefix(p, g_prot_dir[i])) return 1;
    }
    return 0;
}

/* reboot cmd 是否危险 */
static int g_is_bad_reboot(const char *c)
{
    int i;
    if (!c || !c[0]) return 0;   /* cmd 为空 = 普通重启，放行 */
    for (i = 0; i < (int)(sizeof(g_bad_reboot) / sizeof(g_bad_reboot[0])); i++) {
        if (g_sub(c, g_bad_reboot[i])) return 1;
    }
    return 0;
}

/*
 * 从用户态拷贝路径到内核栈缓冲。
 * 返回 0 表示成功且 buf 已 '\0' 结尾。
 * 【铁律】必须检查 copy_from_user 返回值 —— 旧版就是没检查才炸。
 */
static int g_fetch_path(const void __user *up, char *buf, unsigned long cap)
{
    if (!up || !hy_f_copy_from_user) return -1;
    g_memset(buf, 0, cap);
    if (hy_f_copy_from_user(buf, up, cap - 1) != 0) return -1;
    buf[cap - 1] = 0;
    /* 再确认一次可读：strlen 自带上限，不会无限扫 */
    if (g_strlen(buf, cap) == 0) return -1;
    return 0;
}

#define G_PATHSZ 384

/* ================================= L1: openat ================================= */
/*
 * 【零开销关键】
 * 第一行做完两次内存读 + 一次位测试就返回。
 * 只读打开（O_RDONLY = 0）占 openat 的绝大多数，
 * 这部分调用的额外成本是几纳秒，完全不可感知。
 */
static void g_openat_before(hook_fargs4_t *args, void *udata)
{
    unsigned long flags;
    char buf[G_PATHSZ];

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;

    /* --- 快路径：不是写打开就走 --- */
    flags = (unsigned long)args->arg2;
    if ((flags & G_O_ACCMODE) == 0 && !(flags & G_O_TRUNC)) return;

    /* --- 慢路径：写打开，才拷字符串 --- */
    if (g_fetch_path((const void __user *)args->arg1, buf, G_PATHSZ) != 0) return;
    if (!g_is_dev_path(buf)) return;

    /* 双保险：skip_origin（若生效）+ 把路径指针换成内核地址（必然 -EFAULT） */
    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg1 = (uint64_t)(uintptr_t)g_kva_fault;
    g_note("openat-w", buf, &g_blk_open);
}

/* openat2：flags 在 struct open_how 的首成员（u64 flags），偏移 0 */
static void g_openat2_before(hook_fargs4_t *args, void *udata)
{
    u64 how_flags = 0;
    char buf[G_PATHSZ];

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;
    if (!args->arg2 || !hy_f_copy_from_user) return;

    /* struct open_how { u64 flags; ... } —— 只读前 8 字节，不假设其余布局 */
    if (hy_f_copy_from_user(&how_flags, (const void __user *)args->arg2,
                            sizeof(how_flags)) != 0) return;

    if (((unsigned long)how_flags & G_O_ACCMODE) == 0 &&
        !(how_flags & G_O_TRUNC)) return;

    if (g_fetch_path((const void __user *)args->arg1, buf, G_PATHSZ) != 0) return;
    if (!g_is_dev_path(buf)) return;

    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg1 = (uint64_t)(uintptr_t)g_kva_fault;
    g_note("openat2-w", buf, &g_blk_open);
}

/* ================================= L2: blkdev_ioctl ================================= */
/*
 * 刻意不 hook 全局 ioctl(29)。
 * binder 的 BINDER_WRITE_READ 就是 ioctl，Android 上每秒成千上万次，
 * 在那上面加任何判断都是实打实的发热与耗电。
 *
 * blkdev_ioctl 只在"对块设备发 ioctl"时触发，一天也没几次。
 * 参数：blkdev_ioctl(struct block_device *bdev, fmode_t mode,
 *                    unsigned int cmd, unsigned long arg)
 * cmd 在 arg2 —— 完全是整数，不需要解引用任何结构体。
 */
static void g_blkioctl_before(hook_fargs4_t *args, void *udata)
{
    unsigned int cmd;

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;

    cmd = (unsigned int)args->arg2;
    /* 快路径：一次都不匹配就走（大多数块设备 ioctl 是查询类） */
    if (cmd != G_BLKDISCARD && cmd != G_BLKSECDISCARD &&
        cmd != G_BLKZEROOUT  && cmd != G_BLKPG) return;

    /* 双保险：skip_origin + 把 cmd 换成必然 -ENOTTY 的非法值 */
    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg2 = 0xffffffffu;
    g_note("blkioctl", cmd == G_BLKPG ? "BLKPG" : "discard/zero", &g_blk_ioctl);
}

/* ================================= L3: reboot ================================= */
/*
 * 注意：不能无脑拦所有 reboot —— 那等于把正常关机也禁掉，
 * 手机照样变废物。只拦会进刷机/擦除模式的那些 cmd。
 * reboot(magic1, magic2, cmd, arg)
 */
static void g_reboot_before(hook_fargs4_t *args, void *udata)
{
    char buf[128];

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;

    if (g_fetch_path((const void __user *)args->arg2, buf, sizeof(buf)) != 0) {
        /* cmd 取不到：保守放行（不因为自己读不到就让系统重启不了） */
        return;
    }
    if (!g_is_bad_reboot(buf)) return;

    /* 双保险：skip_origin + 破坏 magic1（LINUX_REBOOT_MAGIC1 = 0xfee1dead） */
    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg0 = 0;
    g_note("reboot", buf, &g_blk_reboot);
}

/* ================================= L4: kexec_load ================================= */
static void g_kexec_before(hook_fargs4_t *args, void *udata)
{
    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;

    /* 双保险：skip_origin + 把 nr_segments 撑爆（KEXEC_SEGMENT_MAX = 16） */
    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg1 = 0x10000u;
    g_note("kexec_load", NULL, &g_blk_kexec);
}

/* ================================= L5/L6: 模块 ================================= */

/* init_module(void *umod, unsigned long len, const char *uargs) */
static void g_initmod_before(hook_fargs4_t *args, void *udata)
{
    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;
    if (g_allow_mod) return;

    /* 双保险：skip_origin + 把模块映像指针换成内核地址（-EFAULT） */
    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg0 = (uint64_t)(uintptr_t)g_kva_fault;
    g_note("init_module", NULL, &g_blk_mod);
}

/* finit_module(int fd, const char *uargs, int flags) */
static void g_finitmod_before(hook_fargs4_t *args, void *udata)
{
    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;
    if (g_allow_mod) return;

    /* 双保险：skip_origin + fd = -1（-EBADF） */
    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg0 = (uint64_t)(long)-1;
    g_note("finit_module", NULL, &g_blk_mod);
}

/*
 * delete_module(const char *name, int flags)
 * 只拦卸载欢愉自己 —— 别的模块允许正常卸载。
 */
static void g_delmod_before(hook_fargs4_t *args, void *udata)
{
    char buf[64];

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;

    if (g_fetch_path((const void __user *)args->arg0, buf, sizeof(buf)) != 0) return;
    if (!g_sub(buf, "huanyu")) return;

    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg0 = (uint64_t)(uintptr_t)g_kva_fault;
    g_note("delete_module", buf, &g_blk_mod);
}

/* ================================= L7: kill pid1 ================================= */
/*
 * kill(pid, sig)
 * 只对 pid == 1 动手，且兜底手段是把 sig 改成 0 ——
 * sig == 0 是"检测进程是否存在"，不投递任何信号，完全无害。
 * 这样即便 skip_origin 不生效，也不会真的杀掉 init。
 */
static void g_kill_before(hook_fargs4_t *args, void *udata)
{
    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;

    if ((long)args->arg0 != 1) return;

    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg1 = 0;
    g_note("kill-init", NULL, &g_blk_kill);
}

/* ================================= L8: 删除/移动 ================================= */

/* unlinkat(dfd, path, flag) —— rm / rmdir 都走它 */
static void g_unlink_before(hook_fargs4_t *args, void *udata)
{
    char buf[G_PATHSZ];

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;
    if (!g_protect_del) return;

    if (g_fetch_path((const void __user *)args->arg1, buf, G_PATHSZ) != 0) return;
    if (!g_is_prot_path(buf)) return;

    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg1 = (uint64_t)(uintptr_t)g_kva_fault;
    g_note("unlinkat", buf, &g_blk_del);
}

/* renameat(olddfd, oldpath, newdfd, newpath) —— mv 走它 */
static void g_rename_before(hook_fargs4_t *args, void *udata)
{
    char buf[G_PATHSZ];

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;
    if (!g_protect_del) return;

    if (g_fetch_path((const void __user *)args->arg1, buf, G_PATHSZ) != 0) return;
    if (!g_is_prot_path(buf)) return;

    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg1 = (uint64_t)(uintptr_t)g_kva_fault;
    g_note("renameat", buf, &g_blk_del);
}

static void g_rename2_before(hook_fargs8_t *args, void *udata)
{
    char buf[G_PATHSZ];

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;
    if (!g_protect_del) return;

    if (g_fetch_path((const void __user *)args->arg1, buf, G_PATHSZ) != 0) return;
    if (!g_is_prot_path(buf)) return;

    args->skip_origin = 1;
    args->ret = (uint64_t)(long)-EACCES;
    args->arg1 = (uint64_t)(uintptr_t)g_kva_fault;
    g_note("renameat2", buf, &g_blk_del);
}

/* ================================= 可选：io_uring 覆盖 ================================= */
/*
 * g_deep=1 时才装。
 * do_filp_open(int dfd, struct filename *pathname, const struct open_flags *op)
 * 这里假设两件事（在 4.x ~ 6.x 都成立，但终究是假设）：
 *   struct filename    首成员是 const char *name
 *   struct open_flags  首成员是 int open_flag
 * 因为属于结构体布局假设，默认关闭。
 */
static void g_filpopen_before(hook_fargs4_t *args, void *udata)
{
    const char *name = NULL;
    int oflag = 0;

    (void)udata;
    if (!hy_ready || !g_on) return;
    if (g_unlocked()) return;
    if (!args->arg1 || !args->arg2) return;

    /* 内核态指针，直接读（参数来自内核，必然已映射） */
    name = *(const char *const *)args->arg1;
    oflag = *(const int *)args->arg2;

    if (!name) return;
    if (((unsigned long)oflag & G_O_ACCMODE) == 0 && !(oflag & G_O_TRUNC)) return;

    /* name 是内核态字符串，直接比，不需要 copy_from_user */
    if (!g_is_dev_path(name)) return;

    args->skip_origin = 1;
    args->ret = (uint64_t)(uintptr_t)-EACCES;
    g_note("filp_open-w", name, &g_blk_open);
}

/* ================================= 安装 / 卸载 ================================= */

#define G_TRY_SYSCALL(nr, narg, before)                                     \
    do {                                                                    \
        if (hook_syscalln((nr), (narg), (before), NULL, NULL) == 0) {       \
            g_hooks++;                                                      \
            g_inst_##before = 1;                                            \
        } else {                                                            \
            HY_LOG("guard: hook " #nr " failed (degraded)\n");              \
        }                                                                   \
    } while (0)

/* 每个 hook 是否装成功，卸载时才知道要不要摘 */
static int g_inst_g_openat_before;
static int g_inst_g_openat2_before;
static int g_inst_g_reboot_before;
static int g_inst_g_kexec_before;
static int g_inst_g_initmod_before;
static int g_inst_g_finitmod_before;
static int g_inst_g_delmod_before;
static int g_inst_g_kill_before;
static int g_inst_g_unlink_before;
static int g_inst_g_rename_before;
static int g_inst_g_rename2_before;
static int g_inst_g_blkioctl_before;
static int g_inst_g_filpopen_before;

int hy_guard_init(void)
{
    g_on = 1;
    g_hooks = 0;
    g_protect_del = 1;
    g_allow_mod = 0;
    g_manual_unlock = 0;
    g_unlock_until = 0;
    g_unlock_cnt = 0;
    g_memset(g_last, 0, sizeof(g_last));
    g_kva_fault = (void *)(uintptr_t)g_fault_str;

    /* 时钟：秒级，用于解锁窗口。缺失则退化为手动开关。 */
    g_f_ktime = (u64(*)(void))hy_lookup_generic("ktime_get_real_seconds");
    if (!g_f_ktime)
        g_f_ktime = (u64(*)(void))hy_lookup_generic("ktime_get_seconds");

    /* L2：块设备 ioctl（hook 内核函数，不是全局 ioctl） */
    g_blkdev_ioctl = (void *)hy_lookup_generic("blkdev_ioctl");
    if (g_blkdev_ioctl) {
        if (hook_wrap4(g_blkdev_ioctl, g_blkioctl_before, NULL, NULL) == 0) {
            g_hooks++;
            g_inst_g_blkioctl_before = 1;
        } else {
            HY_LOG("guard: blkdev_ioctl hook failed (degraded)\n");
        }
    } else {
        HY_LOG("guard: blkdev_ioctl missing, L2 disabled\n");
    }

    /* L1 */
    G_TRY_SYSCALL(__NR_openat, 4, g_openat_before);
    G_TRY_SYSCALL(__NR_openat2, 4, g_openat2_before);
    /* L3 / L4 */
    G_TRY_SYSCALL(__NR_reboot, 4, g_reboot_before);
    G_TRY_SYSCALL(__NR_kexec_load, 4, g_kexec_before);
    /* L5 / L6 */
    G_TRY_SYSCALL(__NR_init_module, 3, g_initmod_before);
    G_TRY_SYSCALL(__NR_finit_module, 3, g_finitmod_before);
    G_TRY_SYSCALL(__NR_delete_module, 2, g_delmod_before);
    /* L7 */
    G_TRY_SYSCALL(__NR_kill, 2, g_kill_before);
    /* L8 */
    G_TRY_SYSCALL(__NR_unlinkat, 3, g_unlink_before);
    G_TRY_SYSCALL(__NR_renameat, 4, g_rename_before);
    G_TRY_SYSCALL(__NR_renameat2, 5, g_rename2_before);

    /* 可选：覆盖 io_uring */
    if (g_deep) {
        g_do_filp_open = (void *)hy_lookup_generic("do_filp_open");
        if (g_do_filp_open) {
            if (hook_wrap4(g_do_filp_open, g_filpopen_before, NULL, NULL) == 0) {
                g_hooks++;
                g_inst_g_filpopen_before = 1;
            }
        }
    }

    HY_LOG("guard: init done hooks=%d clk=%s deep=%d\n",
           g_hooks, g_f_ktime ? "yes" : "no(manual)", g_deep);
    return 0;
}

void hy_guard_exit(void)
{
    /*
     * 卸载必须与安装严格配对。
     * 残留 hook 会跳进已释放的代码 —— 模块一卸载就必炸，
     * 而且发生在瞬间，来不及打日志。
     */
    g_on = 0;

    if (g_inst_g_openat_before) {
        unhook_syscalln(__NR_openat, g_openat_before, NULL);
        g_inst_g_openat_before = 0;
    }
    if (g_inst_g_openat2_before) {
        unhook_syscalln(__NR_openat2, g_openat2_before, NULL);
        g_inst_g_openat2_before = 0;
    }
    if (g_inst_g_reboot_before) {
        unhook_syscalln(__NR_reboot, g_reboot_before, NULL);
        g_inst_g_reboot_before = 0;
    }
    if (g_inst_g_kexec_before) {
        unhook_syscalln(__NR_kexec_load, g_kexec_before, NULL);
        g_inst_g_kexec_before = 0;
    }
    if (g_inst_g_initmod_before) {
        unhook_syscalln(__NR_init_module, g_initmod_before, NULL);
        g_inst_g_initmod_before = 0;
    }
    if (g_inst_g_finitmod_before) {
        unhook_syscalln(__NR_finit_module, g_finitmod_before, NULL);
        g_inst_g_finitmod_before = 0;
    }
    if (g_inst_g_delmod_before) {
        unhook_syscalln(__NR_delete_module, g_delmod_before, NULL);
        g_inst_g_delmod_before = 0;
    }
    if (g_inst_g_kill_before) {
        unhook_syscalln(__NR_kill, g_kill_before, NULL);
        g_inst_g_kill_before = 0;
    }
    if (g_inst_g_unlink_before) {
        unhook_syscalln(__NR_unlinkat, g_unlink_before, NULL);
        g_inst_g_unlink_before = 0;
    }
    if (g_inst_g_rename_before) {
        unhook_syscalln(__NR_renameat, g_rename_before, NULL);
        g_inst_g_rename_before = 0;
    }
    if (g_inst_g_rename2_before) {
        unhook_syscalln(__NR_renameat2, g_rename2_before, NULL);
        g_inst_g_rename2_before = 0;
    }
    if (g_inst_g_blkioctl_before && g_blkdev_ioctl) {
        hook_unwrap(g_blkdev_ioctl, g_blkioctl_before, NULL);
        g_inst_g_blkioctl_before = 0;
    }
    if (g_inst_g_filpopen_before && g_do_filp_open) {
        hook_unwrap(g_do_filp_open, g_filpopen_before, NULL);
        g_inst_g_filpopen_before = 0;
    }

    g_blkdev_ioctl = NULL;
    g_do_filp_open = NULL;
    HY_LOG("guard: exit done\n");
}

/* ================================= 对外 API ================================= */

int hy_guard_active(void)
{
    return (g_on && g_hooks > 0) ? 1 : 0;
}

int hy_guard_hooks(void)
{
    return g_hooks;
}

/* 解锁窗口剩余秒数；-1 = 无时钟；0 = 未解锁 */
int hy_guard_unlock_left(void)
{
    u64 now;
    if (!g_f_ktime) return g_manual_unlock ? -2 : 0;
    if (g_unlock_until == 0) return 0;
    now = g_f_ktime();
    if (now >= g_unlock_until) return 0;
    return (int)(g_unlock_until - now);
}

void hy_guard_stats(u64 *total, u64 *open, u64 *ioctl, u64 *reboot,
                    u64 *kexec, u64 *mod, u64 *kill, u64 *del,
                    u64 *unlocks, char *last, int last_len)
{
    if (total)   *total   = g_total;
    if (open)    *open    = g_blk_open;
    if (ioctl)   *ioctl   = g_blk_ioctl;
    if (reboot)  *reboot  = g_blk_reboot;
    if (kexec)   *kexec   = g_blk_kexec;
    if (mod)     *mod     = g_blk_mod;
    if (kill)    *kill    = g_blk_kill;
    if (del)     *del     = g_blk_del;
    if (unlocks) *unlocks = g_unlock_cnt;
    if (last)    g_copy(last, g_last, (unsigned long)(last_len > 0 ? last_len : 1));
}

/* 控制：on / off */
int hy_guard_set(int on)
{
    g_on = on ? 1 : 0;
    HY_LOG("guard: %s\n", g_on ? "ON" : "OFF");
    return 0;
}

/* 控制：开解锁窗口（秒）。<=0 表示无限（直到手动 lock） */
int hy_guard_unlock(int sec)
{
    g_unlock_cnt++;
    if (!g_f_ktime) {
        g_manual_unlock = 1;
        return 0;
    }
    if (sec <= 0) {
        /* 无时钟时无法表达"无限"，用一个足够长但不溢出的窗口：24 小时 */
        g_unlock_until = g_f_ktime() + 86400u;
    } else {
        if (sec > 86400) sec = 86400;
        g_unlock_until = g_f_ktime() + (u64)sec;
    }
    HY_LOG("guard: unlock window opened (%d s)\n", sec);
    return 0;
}

int hy_guard_lock(void)
{
    g_unlock_until = 0;
    g_manual_unlock = 0;
    HY_LOG("guard: locked\n");
    return 0;
}

int hy_guard_allow_mod(int on)
{
    g_allow_mod = on ? 1 : 0;
    return 0;
}

int hy_guard_set_deep(int on)
{
    g_deep = on ? 1 : 0;
    return 0;
}

/*
 * 文本命令（供 HuanyuD 通过 HY_NR_DBG_CMD 下发）
 *   guard on|off|status
 *   unlock [seconds]      开解锁窗口（默认 300 秒）
 *   lock                  立即结束窗口
 */
int hy_guard_cmd(const char *cmd, const char *arg, char *out, int out_len)
{
    if (!out || out_len <= 0) return -EINVAL;

    if (!cmd || cmd[0] == 0) {
        g_copy(out, "guard: need subcommand (on|off|status)", (unsigned long)out_len);
        return -EINVAL;
    }

    if (g_prefix(cmd, "unlock")) {
        int sec = 300;
        if (arg && arg[0]) {
            int v = g_atoi(arg);
            if (v < 0) {
                g_copy(out, "unlock: bad seconds", (unsigned long)out_len);
                return -EINVAL;
            }
            sec = v;
        }
        hy_guard_unlock(sec);
        g_copy(out, g_f_ktime ? "unlock window opened" : "unlocked (manual mode)",
               (unsigned long)out_len);
        return 0;
    }

    if (g_prefix(cmd, "lock")) {
        hy_guard_lock();
        g_copy(out, "locked", (unsigned long)out_len);
        return 0;
    }

    if (g_prefix(cmd, "on")) {
        hy_guard_set(1);
        g_copy(out, "guard=on", (unsigned long)out_len);
        return 0;
    }
    if (g_prefix(cmd, "off")) {
        hy_guard_set(0);
        g_copy(out, "guard=off", (unsigned long)out_len);
        return 0;
    }
    if (g_prefix(cmd, "status")) {
        g_copy(out, g_on ? (g_hooks ? "ARMED" : "on-but-no-hook")
                         : "disarmed", (unsigned long)out_len);
        return 0;
    }

    g_copy(out, "unknown: guard on|off|status | unlock [s] | lock",
           (unsigned long)out_len);
    return -EINVAL;
}
