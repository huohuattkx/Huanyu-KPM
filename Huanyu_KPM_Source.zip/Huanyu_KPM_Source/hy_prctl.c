/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_prctl.c —— prctl 免鉴权命令通道
 *
 * 【为什么需要它】
 *
 * 欢愉原本只走 KernelPatch 的 supercall（CTL0）。但 supercall 的鉴权
 * 在 root shell 下常常过不去。看 kernel/patch/common/supercall.c：
 *
 *   int is_authed = 0;
 *   int is_trusted_caller = 0;
 *
 *   if (has_preset_superkey()) {          // (1) 仅当"设了密钥"才校验
 *       is_authed = !auth_superkey(key);
 *       is_trusted_caller = is_authed;
 *   }
 *   if (is_trusted_manager_uid(uid)) {    // (2) APatch 管理器进程
 *       is_trusted_caller = 1;
 *       is_authed = 1;
 *   } else if (is_su_allow_uid(uid)) {    // (3) root shell
 *       is_trusted_caller = 1;
 *       // 注意：这里【不设】 is_authed
 *   }
 *   if (!is_trusted_caller) return;
 *   ...
 *   args->ret = supercall(is_authed, cmd, ...);
 *
 * 而 supercall() 内部第一件事就是：
 *   if (!is_authed) return -EPERM;
 *
 * 于是：
 *   - 走 (3) root shell 时，若 (1) 没有把 is_authed 置 1，
 *     is_authed 保持 0 -> 所有需要鉴权的命令一律 -EPERM。
 *   - 只有 APatch 管理器进程(2)或掌握真实 superkey 时才能用。
 *
 * 之前我判断"没设密钥时任何 key 都能过"是错的：
 * 没设密钥时 (1) 根本不进入，is_authed 仍然是 0。
 *
 * 【方案】
 *   欢愉本身已经是内核模块，没必要再走 supercall 的门禁。
 *   这里 hook prctl，用魔法数识别自己的调用，直接执行命令。
 *   与 supercall 完全独立，不需要任何 key。
 *
 * 【为什么用 prctl】
 *   - prctl 本来就常被这类驱动当通道用（原 wanbai 头文件里就有
 *     PRCTL_MEM_READ 0x63687501 / PRCTL_MEM_WRITE 0x63687502）
 *   - 参数够用（5 个），调用开销极小
 *   - 不依赖 proc_ops / misc_register 等 KP 未导出的设施
 *
 * 【安全约束】
 *   - 只有 arg0 完全等于魔法数才接管，其余一律放行给原 prctl
 *   - 用户态 payload 一律经 copy_from_user / copy_to_user，绝不直接解引用
 *   - payload 长度按命令号在白名单里查，绝不信任用户传入的长度
 *   - 模块卸载后 hook 撤销，通道消失
 */
#include <linux/printk.h>
#include <linux/string.h>
#include <kpmodule.h>
#include <syscall.h>
#include <hook.h>
#include "hy.h"

/* arm64: prctl = 167 */
#ifndef __NR_prctl
#define __NR_prctl 167
#endif

/*
 * 魔法数："Hyun"（0x48 0x79 0x75 0x6e）
 * 取 64 位是为了降低与普通 prctl option 冲突的概率
 * （prctl 的 option 都是小整数，不会撞上）。
 */
#define HY_PRCTL_MAGIC 0x4879756eULL

/* payload 最大 1024，与用户态帧上限一致 */
#define HY_PRCTL_PAYLOAD_MAX 1024


/* ==========================================================================
 * 用户内存访问兜底
 *
 * 万一 _copy_from_user / _copy_to_user 全都查不到（某些 GKI 配置会裁掉），
 * prctl 通道就不该整个瘫痪。
 *
 * 兜底原理：ARM64 上内核与用户共享同一套页表，
 * 内核上下文可以直接访问用户虚拟地址 —— 只要该页已映射且未被换出。
 * prctl 的 payload 是用户态【刚刚写入】的指针，页几乎必然 resident。
 *
 * 因此这里退化成 memcpy + 地址范围校验：
 *   - 地址必须在用户空间（0x0 ~ TASK_SIZE，arm64 通常 0x800000000000）
 *   - 长度不能跨越用户/内核边界
 * 两条都满足才访问，否则拒绝。
 * ========================================================================== */

/* arm64 用户空间上界（48 位 VA）：0x0000_8000_0000_0000 */
extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);

/* hook_syscalln_override：可选增强，运行时解析，缺失则回退 hook_syscalln */
typedef int (*hy_hook5_fn)(int nr, int narg, void *before, void *after, void *udata);
static hy_hook5_fn hy_f_hook_syscalln_override;
extern void *(*hy_f_memcpy)(void *, const void *, unsigned long);

#define HY_USER_ADDR_MAX 0x800000000000UL

int hy_uaddr_ok(unsigned long a, unsigned long n)
{
    if (a == 0) return 0;
    if (n == 0) return 1;
    if (a >= HY_USER_ADDR_MAX) return 0;
    if (n > HY_USER_ADDR_MAX) return 0;
    if (a + n > HY_USER_ADDR_MAX) return 0;   /* 越界到内核空间 */
    return 1;
}

/* 返回 0 表示成功（约定与 copy_*_user 一致：未拷贝字节数） */
static long hy_read_user(void *dst, const void *src, unsigned long n)
{
    if (!hy_uaddr_ok((unsigned long)src, n)) return n;
    if (hy_f_copy_from_user) return hy_f_copy_from_user(dst, src, n);
    if (hy_f_memcpy) { hy_f_memcpy(dst, src, n); return 0; }
    return n;
}

static long hy_write_user(void *dst, const void *src, unsigned long n)
{
    if (!hy_uaddr_ok((unsigned long)dst, n)) return n;
    if (hy_f_copy_to_user) return hy_f_copy_to_user(dst, src, n);
    if (hy_f_memcpy) { hy_f_memcpy(dst, src, n); return 0; }
    return n;
}

/* 必须先有 copy_to_user */

/*
 * 命令 -> payload 期望长度白名单。
 * 不在表里的命令：payload 视为 0 长度（不拷贝）。
 * 这是刻意的设计——绝不信任用户传进来的长度。
 */
struct hy_prctl_size {
    unsigned int nr;
    unsigned int size;
};

static const struct hy_prctl_size hy_prctl_sizes[] = {
    { HY_NR_GET_PID,           sizeof(struct hy_request) },
    { HY_NR_MODULE_BASE,       sizeof(struct hy_request) },
    { HY_NR_MODULE_BSS,        sizeof(struct hy_request) },
    { HY_NR_READ_MEM,          sizeof(struct hy_request) },
    { HY_NR_WRITE_MEM,         sizeof(struct hy_request) },
    { HY_NR_READ_MEM_V2,       sizeof(struct hy_request) },
    { HY_NR_TOUCH_INIT,        sizeof(struct hy_touch_event_base) },
    { HY_NR_TOUCH_DOWN,        sizeof(struct hy_touch_event_base) },
    { HY_NR_TOUCH_UP,          sizeof(struct hy_touch_event_base) },
    { HY_NR_GYRO_INIT,         sizeof(int) },
    { HY_NR_GYRO_CONFIG,       sizeof(struct hy_gyro_config) },
    { HY_NR_GET_THREAD_TLS,    sizeof(struct hy_tls_request) },
    { HY_NR_EXEC_PACGA,        sizeof(struct hy_pacga_request) },
    { HY_NR_BP_SET_MODE,       sizeof(struct hy_bp_mode_config) },
    { HY_NR_BP_GET_MODE,       sizeof(struct hy_bp_mode_config) },
    { HY_NR_BP_GET_CAPS,       sizeof(struct hy_bp_caps) },
    { HY_NR_BP_INST,           sizeof(struct hy_bp_inst_args) },
    { HY_NR_BP_UNINST,         sizeof(u64) },
    { HY_NR_BP_SUSPEND,        sizeof(u64) },
    { HY_NR_BP_RESUME,         sizeof(u64) },
    { HY_NR_BP_GET_HIT_COUNT,      sizeof(struct hy_bp_get_hit_count_arg) },
    { HY_NR_BP_MODIFY,         sizeof(struct hy_bp_modify_args) },
    { HY_NR_BP_GET_HIT_ITEMS,      sizeof(struct hy_bp_get_hit_items_args) },
    { HY_NR_BP_CHECK_INITED,   0 },
    { HY_NR_BP_INIT_CMD,       0 },
    { HY_NR_BP_GET_NUM_BRPS,   0 },
    { HY_NR_BP_GET_NUM_WRPS,   0 },
    { HY_NR_FILE_HIDE_INIT,    0 },
    { HY_NR_FILE_HIDE_SET,     sizeof(struct hy_file_hide_config) },
    { HY_NR_FILE_HIDE_CLEAR,   0 },
    { HY_NR_FILE_HIDE_STATUS,  sizeof(struct hy_file_hide_status) },
    { HY_NR_ENUM_MODULES,      sizeof(struct hy_enum_mods_req) },
    { HY_NR_ENUM_PROCESSES,    sizeof(struct hy_enum_procs_req) },
    { HY_NR_ENUM_THREADS,      sizeof(struct hy_enum_threads_req) },
    { HY_NR_KERNEL_RW,         sizeof(struct hy_kern_rw_req) },
    { HY_NR_PHYS_RW,           sizeof(struct hy_kern_rw_req) },
    { HY_NR_PROTECT,           sizeof(struct hy_protect_req) },
    { HY_NR_CACHE_FLUSH,       sizeof(struct hy_flush_req) },
    { HY_NR_BP_LIST,           sizeof(struct hy_bp_list_req) },
    { HY_NR_BP_CLEAR_HITS,     sizeof(u64) },
    { HY_NR_HWCAP,             sizeof(struct hy_hwcap) },
    { HY_NR_STATS,             sizeof(struct hy_stats) },
    { HY_NR_VERSION,           16 },
    { HY_NR_DBG_CMD,          sizeof(struct hy_dbg_req) },   /* v1.42.0 调试命令 */
    { HY_NR_HANDSHAKE,        sizeof(struct hy_handshake_req) }, /* v1.67.0 握手 */
    /* v1.73.0 触摸：secure touch inject */
    { HY_NR_TI_DOWN,           sizeof(struct hy_touch_event_base) },
    { HY_NR_TI_MOVE,           sizeof(struct hy_touch_event_base) },
    { HY_NR_TI_UP,             0 },
    { HY_NR_TI_STATUS,         sizeof(struct hy_ti_stat) },
    { HY_NR_TI_SET_SLOTS,      sizeof(struct hy_ti_range) },
    { HY_NR_TI_SET_RANGE,      sizeof(struct hy_ti_range) },
    { HY_NR_TI_CLEAR,          0 },                              /* v1.75.0 */
    { HY_NR_TI_INJECT_GATE,    sizeof(struct hy_ti_range) },     /* v1.75.0 */
    { HY_NR_TI_DOWN_ID,        sizeof(struct hy_ti_finger_op) },  /* v1.76.0 */
    { HY_NR_TI_MOVE_ID,        sizeof(struct hy_ti_finger_op) },  /* v1.76.0 */
    { HY_NR_TI_UP_ID,          sizeof(struct hy_ti_finger_op) },  /* v1.76.0 */
    { HY_NR_TI_UP_ALL,         0 },                               /* v1.76.0 */
    { HY_NR_TI_CAPACITY,       sizeof(struct hy_ti_cap) },        /* v1.76.0 */
};

static unsigned int hy_prctl_size_of(unsigned int nr, int *known)
{
    size_t i;
    for (i = 0; i < sizeof(hy_prctl_sizes) / sizeof(hy_prctl_sizes[0]); i++) {
        if (hy_prctl_sizes[i].nr == nr) {
            *known = 1;
            return hy_prctl_sizes[i].size;
        }
    }
    *known = 0;
    return 0;
}

/*
 * prctl(HY_PRCTL_MAGIC, nr, payload_ptr, 0, 0)
 *
 * 约定：
 *   arg0 = 魔法数
 *   arg1 = 命令号
 *   arg2 = 用户态 payload 指针（可为 NULL，当期望长度为 0）
 *
 * ==========================================================================
 * 【v1.16.0 重大修正：为什么以前"明明 hook 成功却永远连不上"】
 *
 * 1) hook_syscalln **不支持** skip_origin。
 *    看 KernelPatch kernel/patch/common/syscall.c：
 *
 *        hook_err_t hook_syscalln(...)
 *        {
 *            if (syscall_hook_global)
 *                return syscall_hook_add(nr, 0, before, after, udata, 0, 0);
 *                                                              // ↑ allow_skip=0
 *        }
 *
 *    而 dispatcher 里：
 *
 *        if (args->skip_origin && can_skip && syscall_hook_handler_granular)
 *            regs->regs[0] = args->ret;
 *        else
 *            args->skip_origin = 0;      (静默丢弃)
 *
 *    allow_skip=0 -> can_skip=0 -> 我们在 before 里设的 args->ret
 *    被**全部丢弃**。真实 prctl 照样执行，返回 -EINVAL（无效 option），
 *    覆盖掉我们的结果 -> 用户态永远探测失败。
 *
 *    这就是"hook 装了、日志显示 ready、但就是连不上"的真因。
 *
 * 2) 修法一：改用 hook_syscalln_override（allow_skip=1，且 bypass uid gate）。
 *
 * 3) 修法二（更关键）：**把命令执行整体移到 after 回调**。
 *
 *    查证 hook.c 的 _transit8 / syscall.c 的 dispatch_after：
 *    after 回调在 skip_origin 生效与否时**都必然执行**，
 *    且返回值最终取 fargs.ret / args->ret。
 *
 *        befores -> (if !skip_origin) origin -> afters -> return fargs.ret
 *
 *    所以 after 里设置 args->ret 一定能生效，**不依赖 skip_origin 是否
 *    被支持**。这样即便 override 也拿不到 allow_skip，通道依然可用。
 *
 *    同时保证：命令只在 after 执行**一次**，不会出现"before 执行 +
 *    after 再执行"的重复副作用。
 * ==========================================================================
 */


/* ==========================================================================
 * v1.26.0 关键修复：before/after 配对不再依赖 after 时的寄存器值
 * --------------------------------------------------------------------------
 * 现象：模块加载成功、prctl hook 装上了，但用户态调用永远失败，
 *       /proc/huanyu 里 cmd total 恒为 0（hy_ctl_switch 从未被调用）。
 *
 * 根因：plain hook_syscalln 的 allow_skip=0，所以 before 里设的
 *       skip_origin 被忽略，真实 prctl 照样执行并返回 -EINVAL。
 *       而 ARM64 上系统调用的返回值也走 x0 —— after 回调里再读
 *       syscall_argn(args, 0) 拿到的是**返回值(-EINVAL)**而不是
 *       原始的魔法数，于是 magic 判定恒为假，直接 return。
 *
 *       证据：hy_usage_set_channel(1) 在 magic 判定之后执行，
 *       而 [client] 段 by channel 的 prctl 计数一直是 0，
 *       说明 after 每次都在 magic 那一步就退出了。
 *
 * 修法：before 里识别成功就把 (pid, nr, payload, rc) 存进 pending 槽，
 *       after 里**按 pid 取回**，完全不读寄存器。
 * ========================================================================== */

#ifndef HY_PRCTL_PENDING_MAX
#define HY_PRCTL_PENDING_MAX 16
#endif

struct hy_prctl_pending {
    volatile int  busy;
    volatile int  pid;
    unsigned int  nr;
    void __user  *upayload;
    long          rc;
};

static struct hy_prctl_pending g_pend[HY_PRCTL_PENDING_MAX];

static int hy_cur_pid(void)
{
    void *cur = hy_current_task();
    int off = hy_pid_offset();
    if (!cur || off < 0) return -1;
    return *(int *)((unsigned long)cur + (unsigned long)off);
}

static struct hy_prctl_pending *hy_pend_alloc(int pid)
{
    int i;
    for (i = 0; i < HY_PRCTL_PENDING_MAX; i++) {
        if (!g_pend[i].busy) {
            g_pend[i].busy = 1;
            g_pend[i].pid  = pid;
            return &g_pend[i];
        }
    }
    return NULL;
}

static struct hy_prctl_pending *hy_pend_find(int pid)
{
    int i;
    for (i = 0; i < HY_PRCTL_PENDING_MAX; i++) {
        if (g_pend[i].busy && g_pend[i].pid == pid)
            return &g_pend[i];
    }
    return NULL;
}

/*
 * 执行一次命令：读 payload -> 分发 -> 回写。
 * 供 before 调用（v1.26.0 起执行时机提前）。
 */
static long hy_prctl_exec(unsigned int nr, void __user *upayload)
{
    char buf[HY_PRCTL_PAYLOAD_MAX];
    unsigned int need;
    int known;
    long rc;

    need = hy_prctl_size_of(nr, &known);
    if (!known) {
        hy_usage_set_channel(1);
        return -EINVAL;
    }

    hy_usage_set_channel(1);   /* prctl */

    if (need == 0)
        return hy_ctl_switch(nr, NULL);

    if (need > HY_PRCTL_PAYLOAD_MAX || !upayload)
        return -EINVAL;

    hy_memset(buf, 0, sizeof(buf));
    if (hy_read_user(buf, upayload, need) != 0)
        return -EFAULT;

    rc = hy_ctl_switch(nr, buf);

    /* 无论成功失败都回写：调用方需要看到被填充的字段 */
    if (hy_write_user(upayload, buf, need) != 0)
        return -EFAULT;

    return rc;
}

/*
 * before：只做识别 + 抑制真实 prctl。
 * 故意不执行命令 —— 执行统一放在 after，保证只执行一次。
 */
static void hy_prctl_before(hook_fargs8_t *args, void *udata)
{
    uint64_t magic;

    (void)udata;

    /* 卸载守卫：hook 撤销与内存释放之间的时间窗 */
    if (!hy_ready) return;

    magic = syscall_argn(args, 0);

    /* 不是我们的调用 —— 立即放行，零开销 */
    if (magic != HY_PRCTL_MAGIC) return;

    /*
     * 【v1.26.0】在 before 里就把命令执行完并存进 pending 槽。
     * 原因见上方注释：after 里读不到原始 arg0，靠寄存器配对不可靠。
     *
     * 真实 prctl 随后仍会执行并返回 -EINVAL（无副作用），
     * 但 after 会用 pending 里的 rc 覆盖返回值。
     */
    {
        struct hy_prctl_pending *pd;
        int pid = hy_cur_pid();

        pd = hy_pend_alloc(pid);
        if (!pd) return;      /* 槽位耗尽，本次放弃 */

        pd->nr       = (unsigned int)syscall_argn(args, 1);
        pd->upayload = (void __user *)syscall_argn(args, 2);
        pd->rc       = hy_prctl_exec(pd->nr, pd->upayload);
    }

    args->skip_origin = 1;
}

/*
 * after：真正执行命令并写入返回值。
 * 无论 skip_origin 是否被支持，这里都会执行且返回值一定生效。
 */
static void hy_prctl_after(hook_fargs8_t *args, void *udata)
{
    /*
     * 【v1.72.1】删掉了这里 7 个从未被读的局部变量。
     *   其中 char buf[HY_PRCTL_PAYLOAD_MAX] 是 1 KB —— after 回调每次
     *   被调用都要在内核栈上白占 1 KB，而 prctl 通道是高频路径。
     *   这些变量是 v1.26.0 改成"从 pending 槽取结果"后遗留的，无人引用。
     */
    (void)udata;

    if (!hy_ready) return;

    /*
     * 【v1.26.0】不再读 syscall_argn(args, 0) —— after 时它已是返回值。
     * 改为按 pid 从 pending 槽取回 before 的执行结果。
     */
    {
        struct hy_prctl_pending *pd;
        int pid = hy_cur_pid();

        pd = hy_pend_find(pid);
        if (!pd) return;               /* 不是我们发起的调用 */

        args->ret = (u64)pd->rc;
        pd->busy = 0;
        pd->pid  = -1;
    }
}

/* 通道是否可用（供 status 类命令查询） */
static int g_prctl_hooked;
static int g_prctl_mode;   /* 1=override 2=plain */

int hy_prctl_init(void)
{
    int ret;

    if (g_prctl_hooked) return 0;

    /*
     * 【这里之前是个假修复】
     * 注释写着"不再直接禁用"，代码却 return -ENOSYS —— 照样禁用。
     * 于是无论 copy 符号是否修好，通道都起不来。
     * 现在注释与行为一致：只告警，继续装 hook。
     */
    if (!hy_f_copy_from_user || !hy_f_copy_to_user)
        HY_LOG("prctl: WARN copy_*_user missing, using direct-access fallback\n");

    hy_f_hook_syscalln_override = (hy_hook5_fn)
        hy_lookup_generic("hook_syscalln_override");
    if (!hy_f_hook_syscalln_override)
        HY_LOG("prctl: hook_syscalln_override absent, will use plain hook\n");

    /*
     * 优先 hook_syscalln_override：
     *   - allow_skip = 1  -> skip_origin 可被支持
     *   - bypass_gate = 1 -> 不受 su_syscall_gate 的 uid 限制
     * 回退 hook_syscalln（allow_skip=0，但 after 兜底仍然有效）。
     *
     * 两种情况下 unhook 都用 unhook_syscalln —— 它内部按
     * syscall_hook_global 选择同一套移除逻辑，与上面两个接口匹配。
     *
     * 【v1.20.0 重要修复】hook_syscalln_override 改为**运行时 kallsyms 解析**。
     * 之前它是链接期未定义符号：一旦目标 KP 版本没有导出这个函数，
     * KPM 加载器解析符号失败会导致**整个模块加载失败**，
     * 而不只是 prctl 通道失效。可选增强绝不能绑架模块的可加载性。
     */
    ret = -1;
    if (hy_f_hook_syscalln_override) {
        ret = hy_f_hook_syscalln_override(__NR_prctl, 5,
                                          hy_prctl_before, hy_prctl_after, NULL);
    }
    if (ret == 0) {
        g_prctl_mode = 1;
        HY_LOG("prctl: channel ready via override"
               " (nr=%d magic=0x%llx skip_origin=allowed)\n",
               __NR_prctl, (unsigned long long)HY_PRCTL_MAGIC);
    } else {
        HY_LOG("prctl: override failed err=%d, falling back\n", ret);
        ret = hook_syscalln(__NR_prctl, 5,
                            hy_prctl_before, hy_prctl_after, NULL);
        if (ret != 0) {
            HY_LOG("prctl: hook failed err=%d\n", ret);
            return -ENODEV;
        }
        g_prctl_mode = 2;
        HY_LOG("prctl: channel ready via plain hook"
               " (nr=%d magic=0x%llx skip_origin=best-effort)\n",
               __NR_prctl, (unsigned long long)HY_PRCTL_MAGIC);
    }

    HY_LOG("prctl: NOTE command runs in AFTER callback, so the result is"
           " delivered even when skip_origin is unsupported\n");

    g_prctl_hooked = 1;
    return 0;
}

void hy_prctl_exit(void)
{
    if (!g_prctl_hooked) return;
    /* 必须与注册时的 before/after 完全一致，否则匹配不上、hook 残留 */
    unhook_syscalln(__NR_prctl, hy_prctl_before, hy_prctl_after);
    g_prctl_hooked = 0;
    g_prctl_mode = 0;
    HY_LOG("prctl: channel removed\n");
}

/* 供 /proc/huanyu 诊断显示 */
int hy_prctl_mode(void) { return g_prctl_mode; }

int hy_prctl_ready(void) { return g_prctl_hooked; }
