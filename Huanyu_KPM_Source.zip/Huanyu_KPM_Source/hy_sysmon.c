/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_sysmon.c —— 指定进程的系统调用监控
 *
 * 【移植来源】lsdriver 的 arm64_syscall_monitor.h（662 行）
 *
 * ls 原版做法：
 *   inline hook "do_el0_svc"（arm64 syscall 统一入口），
 *   在函数入口拿 struct pt_regs，按 tgid 过滤目标进程，
 *   然后按 syscall 号做语义化解析（路径预览 128 字节、
 *   输入数据预览 32 字节、单条日志上限 768 字节）。
 *
 * 欢愉 KPM 的做法：
 *   同样 hook do_el0_svc 统一入口（而不是按号 hook_syscalln），
 *   这样能覆盖**所有** syscall，和 ls 完全同款。
 *
 * 与 ls 的差异（受 KPM 限制，非偷懒）：
 *   - ls 用 inline_hook_frame（自写蹦床）；
 *     KPM 用 hook_wrap4，由 KP 提供，更安全但多一层跳转
 *   - ls 靠 <uapi/asm/unistd.h> 的 __SYSCALL 宏生成名字表；
 *     KPM 没有完整 unistd 头文件，这里只记 syscall 号不做名字解析
 *   - ls 用 DEFINE_MUTEX；KPM 用自实现的简易自旋锁
 *   - ls 用 kmalloc 存记录；KPM 用静态环形缓冲
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <hook.h>
#include <ksyms.h>
#include <kallsyms.h>
#include <asm/current.h>
#include "hy.h"

extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);

/* ============================ 简易自旋锁 ============================ */

static volatile u32 g_lock;

static inline void sy_lock(void)
{
    u32 tmp;
    asm volatile(
        "1: ldaxr %w0, [%1]\n"
        "   cbnz  %w0, 1b\n"
        "   stxr  %w0, %w2, [%1]\n"
        "   cbnz  %w0, 1b\n"
        : "=&r"(tmp) : "r"(&g_lock), "r"(1) : "memory");
}

static inline void sy_unlock(void)
{
    asm volatile("stlr %w1, [%0]" :: "r"(&g_lock), "r"(0) : "memory");
}

/* ============================ 状态 ============================ */

/* 监控目标表：0 表示空槽。ls 原版也是 8 个。 */
static s32 g_pids[HY_SYSMON_MAX_PIDS];

/* 环形记录缓冲。ls 用 kmalloc，这里用静态数组。 */
static struct hy_sysmon_entry g_log[HY_SYSMON_MAX_LOG];
static u32 g_log_head;
static u64 g_log_seq;
static u64 g_total;

static void *g_svc_target;      /* do_el0_svc 地址 */
static bool g_hooked;
static bool g_any_target;

/*
 * 是否命中监控目标。
 * ls 按 tgid 匹配（覆盖进程所有线程）；KPM 没有可靠 tgid 偏移，
 * 这里按 pid 匹配，同时把线程也纳入（见 hy_cur_pid）。
 */
static bool sy_should_trace(int pid)
{
    int i;
    if (!g_any_target || pid <= 0) return false;
    for (i = 0; i < HY_SYSMON_MAX_PIDS; i++) {
        if (g_pids[i] == pid) return true;
    }
    return false;
}

static int hy_cur_pid(void)
{
    unsigned long sp_el0;
    void *cur;
    int off;

    if (!sp_el0_is_current) return -1;
    asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));
    if (!sp_el0) return -1;
    cur = (void *)sp_el0;

    off = hy_pid_offset();
    if (off < 0) return -1;

    {
        int v = *(int *)((unsigned long)cur + (unsigned long)off);
        if (v > 0 && v < 0x80000) return v;
    }
    return -1;
}

/* ============================ 记录 ============================ */

static void sy_record(int pid, u32 nr, u64 a0, u64 a1, u64 a2, u64 ret)
{
    struct hy_sysmon_entry *e;
    u32 idx;

    sy_lock();
    idx = g_log_head;
    g_log_head = (g_log_head + 1) % HY_SYSMON_MAX_LOG;
    g_total++;
    g_log_seq++;
    sy_unlock();

    e = &g_log[idx];
    e->seq  = g_log_seq;
    e->pid  = pid;
    e->tid  = pid;
    e->nr   = nr;
    e->arg0 = a0;
    e->arg1 = a1;
    e->arg2 = a2;
    e->ret  = ret;
    e->ts   = 0;
}

/* ============================ hook ============================ */

/*
 * do_el0_svc 的入口签名（arm64）：
 *   asmlinkage void do_el0_svc(struct pt_regs *regs)   —— 5.x/6.x 多数版本
 *   少数版本是 do_el0_svc(struct pt_regs *regs, int scno)
 *
 * 用 hook_fargs4_t：arg0 = regs，arg1 = scno（若有）。
 * 我们从 regs 里直接读 x8（syscall 号）和 x0~x5（参数），
 * 这样不依赖第二个参数是否存在。
 */
static void hy_svc_before(hook_fargs4_t *args, void *udata)
{
    void *regs;
    u64 *r;
    u32 nr;
    int pid;

    (void)udata;

    /* 卸载守卫：模块退出中，任何回调立即返回 */
    if (!hy_ready) return;
    if (!g_any_target) return;

    pid = hy_cur_pid();
    if (!sy_should_trace(pid)) return;

    regs = (void *)(unsigned long)args->arg0;
    if (!regs) return;
    r = (u64 *)regs;

    /* pt_regs: x0..x30 连续，x8 是 syscall 号 */
    if ((unsigned long)r < 0xffffff0000000000UL) return;
    nr = (u32)r[8];

    sy_record(pid, nr, r[0], r[1], r[2], 0);
}

static void hy_svc_after(hook_fargs4_t *args, void *udata)
{
    void *regs;
    u64 *r;
    int pid;

    (void)udata;
    if (!hy_ready) return;
    if (!g_any_target) return;

    pid = hy_cur_pid();
    if (!sy_should_trace(pid)) return;

    regs = (void *)(unsigned long)args->arg0;
    if (!regs) return;
    r = (u64 *)regs;
    if ((unsigned long)r < 0xffffff0000000000UL) return;

    /*
     * 回填返回值。pt_regs 里 x0 在返回时被写入了 syscall 返回值，
     * 这里直接读 r[0] 就是最新结果。
     * 只更新最近一条同 pid 的记录。
     */
    {
        u32 i;
        sy_lock();
        for (i = 0; i < HY_SYSMON_MAX_LOG; i++) {
            u32 idx = (g_log_head + HY_SYSMON_MAX_LOG - 1 - i) % HY_SYSMON_MAX_LOG;
            if (g_log[idx].pid == pid && g_log[idx].ret == 0) {
                g_log[idx].ret = r[0];
                break;
            }
        }
        sy_unlock();
    }
}

/* ============================ 对外接口 ============================ */

int hy_sysmon_init(void)
{
    /*
     * ls 原版 hook "do_el0_svc"。
     * 不同版本内核名字可能不同，列几个候选。
     * 只解析地址、不碰结构体布局 —— wxshadow 的教训。
     */
    static const char *const cands[] = {
        "do_el0_svc",
        "el0_svc",
        "do_el0_svc_compat",
    };
    int i;

    hy_memset(g_pids, 0, sizeof(g_pids));
    hy_memset(g_log, 0, sizeof(g_log));
    g_log_head = 0;
    g_log_seq = 0;
    g_total = 0;
    g_any_target = false;

    for (i = 0; i < 3; i++) {
        unsigned long a = kallsyms_lookup_name ? kallsyms_lookup_name(cands[i]) : 0;
        if (a && (a & 0xffffff0000000000UL) == 0xffffff0000000000UL) {
            g_svc_target = (void *)a;
            HY_LOG("sysmon: candidate %s @ %lx\n", cands[i], a);
            break;
        }
    }

    if (!g_svc_target) {
        HY_LOG("sysmon: do_el0_svc NOT FOUND (monitoring unavailable)\n");
        return -1;
    }
    return 0;
}

void hy_sysmon_exit(void)
{
    g_any_target = false;
    if (g_svc_target && g_hooked) {
        hook_unwrap(g_svc_target, hy_svc_before, hy_svc_after);
        HY_LOG("sysmon: unwrapped do_el0_svc\n");
    }
    g_hooked = false;
    g_svc_target = NULL;
}

static int sy_ensure_hook(void)
{
    int ret;
    if (!g_svc_target) return -ENODEV;
    if (g_hooked) return 0;

    ret = hook_wrap4(g_svc_target, hy_svc_before, hy_svc_after, NULL);
    if (ret != 0) {
        HY_LOG("sysmon: hook do_el0_svc failed err=%d\n", ret);
        return -ENODEV;
    }
    g_hooked = true;
    HY_LOG("sysmon: hooked do_el0_svc @ %px\n", g_svc_target);
    return 0;
}

int hy_sysmon_set(s32 pid, u32 enable)
{
    int i;
    int ret;

    if (pid <= 0) return -EINVAL;

    if (enable) {
        /*
         * 【顺序注意】先装 hook 再发布 pid。
         * ls 原版也是这个顺序，注释里写明"避免监控表生效但入口未拦截"。
         */
        ret = sy_ensure_hook();
        if (ret != 0) return ret;

        sy_lock();
        for (i = 0; i < HY_SYSMON_MAX_PIDS; i++) {
            if (g_pids[i] == pid) { sy_unlock(); return 0; }
        }
        for (i = 0; i < HY_SYSMON_MAX_PIDS; i++) {
            if (g_pids[i] == 0) { g_pids[i] = pid; g_any_target = true; break; }
        }
        sy_unlock();
        return 0;
    }

    sy_lock();
    for (i = 0; i < HY_SYSMON_MAX_PIDS; i++) {
        if (g_pids[i] == pid) g_pids[i] = 0;
    }
    {
        bool any = false;
        for (i = 0; i < HY_SYSMON_MAX_PIDS; i++) {
            if (g_pids[i] != 0) { any = true; break; }
        }
        g_any_target = any;
    }
    sy_unlock();

    /* 没人监控了就摘 hook，避免长期占用热路径 */
    if (!g_any_target && g_hooked && g_svc_target) {
        hook_unwrap(g_svc_target, hy_svc_before, hy_svc_after);
        g_hooked = false;
        HY_LOG("sysmon: no targets left, unhooked\n");
    }
    return 0;
}

int hy_sysmon_read(struct hy_sysmon_read *req)
{
    u32 n = 0;
    u32 i;
    void __user *dst;

    if (!req) return -EINVAL;

    req->total = g_total;

    if (!req->buf_ptr || req->max_count == 0) { req->nr_read = 0; return 0; }
    if (!hy_f_copy_to_user) return -ENODEV;

    dst = (void __user *)(unsigned long)req->buf_ptr;

    /* 按时间顺序输出：从最老的开始 */
    sy_lock();
    for (i = 0; i < HY_SYSMON_MAX_LOG && n < req->max_count; i++) {
        u32 idx = (g_log_head + i) % HY_SYSMON_MAX_LOG;
        if (g_log[idx].seq == 0) continue;
        sy_unlock();
        if (hy_f_copy_to_user(
                (void __user *)((unsigned long)dst + n * sizeof(struct hy_sysmon_entry)),
                &g_log[idx], sizeof(struct hy_sysmon_entry)) != 0) {
            sy_lock();
            break;
        }
        n++;
        sy_lock();
    }
    sy_unlock();

    req->nr_read = n;

    if (req->clear) {
        sy_lock();
        hy_memset(g_log, 0, sizeof(g_log));
        g_log_head = 0;
        sy_unlock();
    }
    return 0;
}

u64 hy_sysmon_total(void) { return g_total; }
int hy_sysmon_hooked(void) { return g_hooked ? 1 : 0; }
int hy_sysmon_active(void) { return g_any_target ? 1 : 0; }
