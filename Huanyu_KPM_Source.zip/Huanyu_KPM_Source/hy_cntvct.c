/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_cntvct.c —— 监控指定进程读取 CNTVCT_EL0
 *
 * 【移植来源】lsdriver 的 arm64_cntvct_monitor.h（228 行）
 *
 * ls 原版做法（完全同款，这里照搬）：
 *   1) hook cpu_switch_to(__switch_to)：切到目标进程时
 *      clear CNTKCTL_EL1 的 ARCH_TIMER_USR_VCT_ACCESS_EN 位
 *   2) 于是 EL0 读 CNTVCT_EL0 会 trap 进 EL1
 *   3) hook cntvct_read_handler（内核里本就存在的模拟读取函数）来计数
 *
 * 为什么这招有效：CNTVCT_EL0 是很多反调试/反加速检测的常见手段
 * （比较两次读取的差值判断是否被加速），把它变成 trap 就能看见。
 *
 * 【关键安全约束】
 *   清除 EL0VCTEN 之后，如果内核**没有** cntvct_read_handler，
 *   目标进程读 CNTVCT 会走 do_undefinstr 拿到 SIGILL —— 直接崩溃。
 *   所以这里强制：只在 cntvct_read_handler 存在时才允许启用。
 *   这是 ls 源码里没显式写、但显然隐含的前提（它的 ko 有完整头文件，
 *   编译期就能确定该函数存在；KPM 只能运行时查）。
 *
 * 【为什么只在 hook 的进程上生效】
 *   CNTKCTL_EL1 是 per-CPU 的，且随上下文切换被内核保存/恢复。
 *   所以必须在 __switch_to 之后、切到目标进程时写，
 *   对其他进程无影响 —— 与 ls 完全一致。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <hook.h>
#include <ksyms.h>
#include <kallsyms.h>
#include <asm/current.h>
#include "hy.h"

/*
 * CNTKCTL_EL1 位定义（arch/arm64/include/asm/arch_timer.h）
 *   bit 0 : EL0PCTEN —— EL0 访问物理计数器 CNTPCT
 *   bit 1 : EL0VCTEN —— EL0 访问虚拟计数器 CNTVCT   ← 我们要清的是这个
 *   bit 2 : EVNTEN
 *   bit 3 : EVNDIR / EVT_STREAM_EN
 */
#define HY_CNTKCTL_EL0VCTEN  (1UL << 1)

/* ============================ 状态 ============================ */

static s32 g_pid;
static bool g_active;

static void *g_switch_fn;       /* __switch_to */
static void *g_handler_fn;      /* cntvct_read_handler */
static bool g_hooked_switch;
static bool g_hooked_handler;

static u64 g_count;             /* 被拦截的读取次数 */
static u64 g_last_pc;

static volatile u32 g_lock;

static inline void cv_lock(void)
{
    u32 tmp;
    asm volatile(
        "1: ldaxr %w0, [%1]\n"
        "   cbnz  %w0, 1b\n"
        "   stxr  %w0, %w2, [%1]\n"
        "   cbnz  %w0, 1b\n"
        : "=&r"(tmp) : "r"(&g_lock), "r"(1) : "memory");
}

static inline void cv_unlock(void)
{
    asm volatile("stlr %w1, [%0]" :: "r"(&g_lock), "r"(0) : "memory");
}

static int hy_cur_pid(void)
{
    unsigned long sp_el0;
    void *cur;
    int off;

    if (!sp_el0_is_current) return -1;
    asm volatile("mrs %0, sp_el0" : "=r"(sp_el0));
    if (!sp_el0) return -1;
    cur = (void *)sp_el0;

    off = hy_pid_offset();
    if (off < 0) return -1;

    {
        int v = *(int *)((unsigned long)cur + (unsigned long)off);
        if (v > 0 && v < 0x80000) return v;
    }
    return -1;
}

/* ============================ hook ============================ */

/*
 * __switch_to 之后：
 *   目标进程 -> 清 CNTKCTL 的 EL0VCTEN，使其读 CNTVCT 陷入 EL1
 *   其他进程 -> 置回该位（否则切出去后别的进程也被 trap）
 *
 * 【为什么要置回】
 *   CNTKCTL 是 per-CPU 的，切到别的进程时如果不恢复，
 *   下一个进程也会走 trap 路径。ls 原版在这里只做了清除，
 *   是因为它的 hook 只作用于特定进程集；
 *   欢愉这里显式恢复，避免"误伤"。
 */
static void hy_cntvct_switch_after(hook_fargs4_t *args, void *udata)
{
    u64 cntkctl;
    int pid;

    (void)args; (void)udata;
    if (!hy_ready) return;
    if (!g_active) return;

    pid = hy_cur_pid();

    asm volatile("mrs %0, cntkctl_el1" : "=r"(cntkctl));

    if (pid > 0 && pid == g_pid) {
        if (cntkctl & HY_CNTKCTL_EL0VCTEN) {
            cntkctl &= ~HY_CNTKCTL_EL0VCTEN;
            asm volatile("msr cntkctl_el1, %0" :: "r"(cntkctl));
        }
    } else {
        if (!(cntkctl & HY_CNTKCTL_EL0VCTEN)) {
            cntkctl |= HY_CNTKCTL_EL0VCTEN;
            asm volatile("msr cntkctl_el1, %0" :: "r"(cntkctl));
        }
    }
    asm volatile("isb" ::: "memory");
}

/*
 * cntvct_read_handler 被调用 = 目标进程读了一次 CNTVCT_EL0。
 * 这里只计数，不改返回值 —— 内核这个函数本来就会模拟出正确的值，
 * 所以目标进程行为不变，只是每次读取都会经过这里。
 */
static void hy_cntvct_handler_before(hook_fargs4_t *args, void *udata)
{
    unsigned long elr;

    (void)udata;
    if (!hy_ready) return;
    if (!g_active) return;
    if (g_pid <= 0 || hy_cur_pid() != g_pid) return;

    cv_lock();
    g_count++;
    cv_unlock();

    asm volatile("mrs %0, elr_el1" : "=r"(elr));
    g_last_pc = elr;
    (void)args;
}

/* ============================ 对外接口 ============================ */

int hy_cntvct_init(void)
{
    static const char *const sw_cands[] = {
        "__switch_to",
        "cpu_switch_to",
    };
    static const char *const hd_cands[] = {
        "cntvct_read_handler",
    };
    int i;

    g_pid = 0;
    g_active = false;
    g_count = 0;
    g_last_pc = 0;

    for (i = 0; i < 2; i++) {
        unsigned long a = kallsyms_lookup_name ? kallsyms_lookup_name(sw_cands[i]) : 0;
        if (a && (a & 0xffffff0000000000UL) == 0xffffff0000000000UL) {
            g_switch_fn = (void *)a;
            break;
        }
    }

    for (i = 0; i < 1; i++) {
        unsigned long a = kallsyms_lookup_name ? kallsyms_lookup_name(hd_cands[i]) : 0;
        if (a && (a & 0xffffff0000000000UL) == 0xffffff0000000000UL) {
            g_handler_fn = (void *)a;
            break;
        }
    }

    HY_LOG("cntvct: switch=%px handler=%px\n", g_switch_fn, g_handler_fn);

    if (!g_switch_fn) {
        HY_LOG("cntvct: __switch_to NOT FOUND, disabled\n");
        return -1;
    }
    if (!g_handler_fn) {
        /*
         * 【安全】没有模拟读取函数就绝不允许启用。
         * 否则清了 EL0VCTEN 之后目标进程读 CNTVCT 直接 SIGILL 崩溃。
         */
        HY_LOG("cntvct: cntvct_read_handler NOT FOUND -> refusing to enable"
               " (would SIGILL the target)\n");
        return -2;
    }
    return 0;
}

void hy_cntvct_exit(void)
{
    g_active = false;
    g_pid = 0;

    /*
     * 【卸载顺序】先摘 hook，再把 CNTKCTL 恢复原状。
     * 顺序反了会导致"模块已卸载但 CNTKCTL 还被清着"，
     * 目标进程读 CNTVCT 直接崩。
     */
    if (g_switch_fn && g_hooked_switch) {
        hook_unwrap(g_switch_fn, NULL, hy_cntvct_switch_after);
        g_hooked_switch = false;
    }
    if (g_handler_fn && g_hooked_handler) {
        hook_unwrap(g_handler_fn, hy_cntvct_handler_before, NULL);
        g_hooked_handler = false;
    }

    /* 恢复当前 CPU 的 CNTKCTL */
    {
        u64 v;
        asm volatile("mrs %0, cntkctl_el1" : "=r"(v));
        if (!(v & HY_CNTKCTL_EL0VCTEN)) {
            v |= HY_CNTKCTL_EL0VCTEN;
            asm volatile("msr cntkctl_el1, %0" :: "r"(v));
            asm volatile("isb" ::: "memory");
        }
    }

    HY_LOG("cntvct: exit done, restored CNTKCTL\n");
}

int hy_cntvct_set(s32 pid, u32 enable)
{
    int ret;

    if (!enable) {
        g_active = false;
        g_pid = 0;
        /* 恢复 CNTKCTL */
        {
            u64 v;
            asm volatile("mrs %0, cntkctl_el1" : "=r"(v));
            if (!(v & HY_CNTKCTL_EL0VCTEN)) {
                v |= HY_CNTKCTL_EL0VCTEN;
                asm volatile("msr cntkctl_el1, %0" :: "r"(v));
                asm volatile("isb" ::: "memory");
            }
        }
        if (g_switch_fn && g_hooked_switch) {
            hook_unwrap(g_switch_fn, NULL, hy_cntvct_switch_after);
            g_hooked_switch = false;
        }
        if (g_handler_fn && g_hooked_handler) {
            hook_unwrap(g_handler_fn, hy_cntvct_handler_before, NULL);
            g_hooked_handler = false;
        }
        return 0;
    }

    if (pid <= 0) return -EINVAL;
    if (!g_switch_fn || !g_handler_fn) return -ENODEV;

    if (!g_hooked_switch) {
        ret = hook_wrap4(g_switch_fn, NULL, hy_cntvct_switch_after, NULL);
        if (ret != 0) {
            HY_LOG("cntvct: hook __switch_to failed err=%d\n", ret);
            return -ENODEV;
        }
        g_hooked_switch = true;
    }

    if (!g_hooked_handler) {
        ret = hook_wrap4(g_handler_fn, hy_cntvct_handler_before, NULL, NULL);
        if (ret != 0) {
            HY_LOG("cntvct: hook cntvct_read_handler failed err=%d\n", ret);
            return -ENODEV;
        }
        g_hooked_handler = true;
    }

    g_pid = pid;
    g_active = true;
    HY_LOG("cntvct: monitoring pid=%d\n", pid);
    return 0;
}

int hy_cntvct_read(struct hy_cntvct_read *req)
{
    if (!req) return -EINVAL;
    req->count = g_count;
    req->last_pc = g_last_pc;
    if (req->clear) g_count = 0;
    return 0;
}

u64 hy_cntvct_total(void) { return g_count; }
int hy_cntvct_hooked(void) { return g_hooked_switch ? 1 : 0; }
int hy_cntvct_active(void) { return g_active ? 1 : 0; }
