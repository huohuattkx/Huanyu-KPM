/*
 * hy_pm.c —— 节能模式
 *
 * 需求：连续 HY_IDLE_SEC（默认 50）秒没有任何 KPM 功能被调用，
 *       则进入节能模式；一旦有命令进来立即唤醒。
 *
 * ==========================================================================
 * 设计约束（都是从前面几次炸内核里学到的事）
 * ==========================================================================
 *
 * 1) 不新增内核线程。
 *    前面 v1.13.0 刚修过 kthread use-after-free —— 线程只能由
 *    kthread_should_stop() 退出，早退会让 kthread_stop() 拿到已释放的
 *    task_struct。能不加线程就不加。
 *
 * 2) 不用 kmalloc。
 *    你 6.12 上 kmalloc 实测 NOT-FOUND，解析到 kmalloc_trace 会崩。
 *
 * 3) 时间源只用 KP 导出的符号，找不到就降级为"永不节能"。
 *    绝不自己猜符号地址。
 *
 * ==========================================================================
 * 如何实现"50 秒无活动"而不需要定时器
 * ==========================================================================
 *
 * 惰性原则：真正的活动入口只有 hy_ctl_switch()（prctl / supercall /
 * 共享内存三条通道最终都汇入它）。所以：
 *
 *   - hy_ctl_switch() 开头调用 hy_pm_touch() 记录最后活动时刻
 *   - 需要判断是否节能的地方（shm 扫描线程）调用 hy_pm_is_saving()
 *     惰性求值：拿当前时间与最后活动时刻比，超过阈值就是节能
 *
 * 不需要定时器、不需要 workqueue、不需要额外线程。
 * 空闲时只是"没人来判断"，本身就不消耗 CPU —— 这才叫节能。
 *
 * 效果：
 *   - shm 连接线程在节能期间不做进程扫描（这是最耗的部分）
 *   - 唤醒：任何一条命令进入 hy_ctl_switch() 立即恢复
 */
#include "hy.h"

/*
 * 时间源。
 *
 * 【注意】KernelPatch 的 173 个导出符号里**没有任何**时间函数
 * （我已核对：没有 ktime_get / sched_clock / jiffies）。
 * 所以只能通过 kallsyms_lookup_name 运行时解析 —— 这个项目一直在用
 * 这条路（find_vma、proc_create_single_data 等）。
 *
 * 解析不到就降级为"永不节能"，绝不猜地址。
 */
static unsigned long (*g_ktime_get_sec)(void);
static u64 (*g_sched_clock)(void);

/*
 * 实际使用的取秒函数指针。
 * 优先级：ktime_get_sec > sched_clock/1e9 > 不可用
 */
static unsigned long (*g_now_sec)(void);

static u64  g_last_activity;   /* 最后活动时刻（秒） */
static int  g_saving;          /* 当前是否节能（缓存，避免重复计算） */
static int  g_wakeups;         /* 唤醒次数，诊断用 */
static u64  g_last_wake;       /* 上次唤醒时刻（秒），诊断用：验证"有命令进来立即退出节能" */
static u64  g_sleep_ticks;     /* 累计节能轮数，诊断用 */

/* ------------------------------------------------------------------ */
/* 时间源                                                              */
/* ------------------------------------------------------------------ */

/*
 * 用 sched_clock 兜底：返回纳秒，转成秒。
 * 精度不重要，我们只关心 50 秒量级。
 */
static unsigned long now_via_sched_clock(void)
{
    if (!g_sched_clock) return 0;
    return (unsigned long)(g_sched_clock() / 1000000000ULL);
}

static unsigned long now_via_ktime(void)
{
    if (!g_ktime_get_sec) return 0;
    return (unsigned long)g_ktime_get_sec();
}

/* ------------------------------------------------------------------ */
/* 对外接口                                                            */
/* ------------------------------------------------------------------ */

void hy_pm_touch(void)
{
    if (!g_now_sec) return;

    g_last_activity = (u64)g_now_sec();

    if (g_saving) {
        g_saving = 0;
        g_wakeups++;
        g_last_wake = g_last_activity;
        HY_LOG("pm: wake (idle exceeded %ds)\n", HY_IDLE_SEC);
    }
}

int hy_pm_is_saving(void)
{
    unsigned long now, idle;

#if !HY_POWERSAVE_ENABLE
    return 0;
#endif

    if (!g_now_sec) return 0;          /* 时间源不可用 -> 永不节能 */

    now = g_now_sec();
    if (now == 0) return 0;

    /* 首次调用：把起点设成现在，避免上电后立刻被判为长时间空闲 */
    if (g_last_activity == 0) {
        g_last_activity = (u64)now;
        return 0;
    }

    /* 处理回绕（理论上不会，但保险） */
    if ((u64)now < g_last_activity) {
        g_last_activity = (u64)now;
        return 0;
    }

    idle = now - (unsigned long)g_last_activity;

    if (idle >= (unsigned long)HY_IDLE_SEC) {
        if (!g_saving) {
            g_saving = 1;
            HY_LOG("pm: enter powersave after %lu s idle\n", idle);
        }
        g_sleep_ticks++;
        return 1;
    }

    g_saving = 0;
    return 0;
}

u64 hy_pm_idle_sec(void)
{
    unsigned long now;

    if (!g_now_sec) return 0;
    now = g_now_sec();
    if (now == 0 || g_last_activity == 0) return 0;
    if ((u64)now < g_last_activity) return 0;
    return (u64)(now - (unsigned long)g_last_activity);
}

/*
 * 【v1.19.0】对外暴露当前秒数，供命中记录打时间戳。
 * 原来 hy_bp_record_hit 里 hit_time 恒为 0 ——
 * 用户拿到一堆命中却完全不知道先后顺序与间隔，
 * 无法判断"某次命中是不是刚刚发生的"。
 */
u64 hy_now_sec(void)
{
    if (!g_now_sec) return 0;
    return (u64)g_now_sec();
}

void hy_pm_init(void)
{
    g_last_activity = 0;
    g_saving = 0;
    g_wakeups = 0;
    g_sleep_ticks = 0;

    /*
     * 候选按签名一致原则排列：
     *   ktime_get_seconds  (void) -> time64_t   （5.x~6.x）
     *   __ktime_get_real_seconds (void) -> time64_t（老版本）
     *   sched_clock        (void) -> u64 纳秒   （几乎必然存在）
     */
    {
        static const char *kt[] = {
            "ktime_get_seconds",
            "__ktime_get_real_seconds",
            "ktime_get_sec",
        };
        int i;
        for (i = 0; i < 3; i++) {
            unsigned long a = hy_lookup_generic(kt[i]);
            if (a) {
                g_ktime_get_sec = (unsigned long (*)(void))a;
                HY_LOG("pm: clock = %s @ %px\n", kt[i], (void *)a);
                break;
            }
        }
    }
    {
        unsigned long a = hy_lookup_generic("sched_clock");
        if (a) g_sched_clock = (u64 (*)(void))a;
    }

    if (g_ktime_get_sec) {
        g_now_sec = now_via_ktime;
    } else if (g_sched_clock) {
        g_now_sec = now_via_sched_clock;
        HY_LOG("pm: clock = sched_clock (fallback)\n");
    } else {
        g_now_sec = NULL;
        HY_LOG("pm: no clock source, powersave DISABLED\n");
    }

    HY_LOG("pm: idle threshold = %d s (enable=%d)\n",
           HY_IDLE_SEC, HY_POWERSAVE_ENABLE);
}

void hy_pm_exit(void)
{
    HY_LOG("pm: exit (wakeups=%d sleep_ticks=%llu)\n",
           g_wakeups, (unsigned long long)g_sleep_ticks);
    g_now_sec = NULL;
    g_saving = 0;
}

/* 诊断信息给 /proc/huanyu */
void hy_pm_diag(u64 *idle, int *saving, u64 *wakeups, u64 *ticks)
{
    if (idle)    *idle    = hy_pm_idle_sec();
    if (saving)  *saving  = g_saving;
    if (wakeups) *wakeups = (u64)g_wakeups;
    if (ticks)   *ticks   = g_sleep_ticks;
}

/*
 * 【v1.35.0】距上次唤醒过了多少秒。
 * 用途：验证"节能期间一旦有连接/命令进来，是否立即退出节能"。
 *   进入节能 -> 发一条命令 -> 立刻 cat /proc/huanyu
 *   若 state 变回 active 且 last wake 是很小的数（0~几秒），即证明唤醒即时生效。
 * 从未唤醒过返回 (u64)-1，procfs 会打印 never。
 */
u64 hy_pm_secs_since_wake(void)
{
    if (!g_now_sec || !g_last_wake) return (u64)-1;
    return (u64)g_now_sec() - g_last_wake;
}
