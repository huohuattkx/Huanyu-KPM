/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_pt.c —— 地址换算与用户页表遍历
 *
 * 5.10 ~ 6.18 的差异处理：
 *   - 虚拟地址位数从 TCR_EL1.T1SZ 推算，据此决定 3 级（39-bit）还是
 *     4 级（48-bit）页表，避免按 6.1 布局硬编码导致越界。
 *   - PAGE_OFFSET 由 va_bits 计算，不依赖常量。
 *   - init 阶段做 phys<->virt 往返自测，不通过直接拒绝加载。
 *     这是 wxshadow 最危险的一点：偏移算错后拿着错地址写 PTE，
 *     等于往随机物理地址写数据。
 */
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/mm_types.h>
#include <kallsyms.h>
#include <ksyms.h>
#include "hy.h"
#include "hy_scheme.h"

extern void *(*hy_f_find_get_task_by_vpid)(int pid);
extern void *(*hy_f_get_task_mm)(void *task);
extern void (*hy_f_mmput)(void *mm);
extern void (*hy_f_put_task_struct)(void *task);
extern unsigned long (*hy_f___get_free_pages)(unsigned int gfp, unsigned int order);
extern void (*hy_f_free_pages)(unsigned long addr, unsigned int order);
extern long *hy_v_memstart_addr;
extern long *hy_v_physvirt_offset;
extern void (*hy_f_kick_all_cpus_sync)(void);

static u64 hy_va_bits;
static int hy_pt_levels;          /* 3 或 4 */
static unsigned long hy_page_offset;
static unsigned long hy_physvirt_off;

#define HY_PTRS_PER_TABLE 512

/* 每级页表项的索引位移 */
#define HY_PUD_SHIFT_4 30
#define HY_PMD_SHIFT_4 21
#define HY_PTE_SHIFT   12

#define HY_PGD_SHIFT_3 30   /* 39-bit VA：pgd -> pmd -> pte */
#define HY_PMD_SHIFT_3 21

static bool g_pt_ok;

/*
 * 【v1.40.0】内核页表基址（来自 TTBR1_EL1），用于"地址是否已映射"校验。
 *
 * 背景：hy_input.c 从 struct device* 反推 struct input_dev* 时要读
 * 候选指针并当作字符串解引用。hy_lkaddr_ok() 只能判断"落在内核地址
 * 范围"，不代表已映射 —— 读到落在该范围但未映射的垃圾值就会 oops。
 * v1.35~v1.39 的加载即炸的根因即在此。
 *
 * 有了内核页表基址，就能在解引用前真正走一遍页表确认映射有效。
 */
/*
 * 【v1.66.0】内核页表基址改成存 **VA**。
 *
 * 原来存的是 TTBR1 里抠出来的物理地址，调用方再拿线性映射偏移换回 VA
 * —— 而 swapper_pg_dir 住在内核镜像里，要用 kimage_voffset 才对。
 * 用错偏移换出来的 VA 是个垃圾地址，第一次解引用就 oops（v1.60 起秒炸）。
 *
 * 现在直接存 VA：它的来源有三条，都不需要任何偏移换算 ——
 *   1) swapper_pg_dir 符号地址（kallsyms 给的就是内核 VA）
 *   2) 都不行时，本模块任何静态变量的地址也在 TTBR1 覆盖范围内，
 *      但那不是页表，不能当基址用，所以这条路直接判失败。
 * 也就是说：拿不到 swapper_pg_dir 就如实报告内核页表不可用，
 * 绝不猜一个地址出来。
 */
static unsigned long g_kern_pgd_va;

int hy_pt_ready(void) { return g_pt_ok ? 1 : 0; }

/*
 * 【v1.40.0】内核虚拟地址是否已映射。
 *
 * 走一遍 TTBR1 页表：能走到有效表项（valid bit 置位）才算已映射。
 * 用途：解引用任何"来源不可信的内核指针"之前先过这一关，
 * 把"落在内核地址范围但未映射"的垃圾值挡在外面。
 *
 * 返回 0 表示不可读（未映射 / 页表参数无效 / 基址缺失），
 * 调用方必须当作"不可用"处理，绝不解引用。
 *
 * 注意：这是尽力而为的检查，不保证 100% 准确；
 * 它的价值是把绝大多数垃圾值挡掉，而不是替代正确性。
 */
int hy_kern_addr_mapped(unsigned long va)
{
    u64 ent;
    int lvl;
    u64 *ptep;

    if (!g_kern_pgd_va) return 0;
    if (!g_pt_ok) return 0;

    ptep = hy_walk_pgtable(g_kern_pgd_va, va, &lvl, NULL, NULL);
    if (!ptep) return 0;

    ent = *ptep;
    if (!(ent & 1UL)) return 0;      /* valid bit */

    return 1;
}

/* ==================== 方案选择支持（供 hy_scheme 调用） ====================
 *
 * 这些函数只回答两个问题："这套算法在这台机器上算得出结果吗"（try）
 * 和"那就用这套"（apply）。真正的初始化仍在 hy_pt_init() 里。
 */

static int g_pv_kind = HY_PV_PHYSVIRT_OFFSET;
static int g_pg_kind = HY_PG_TCR_EL1;

/*
 * 偏移是否已经过独立证据验证。
 * 只有它为 1 时才允许做"需要解引用"的校验（走页表交叉比对）。
 * 为 0 时一律只做纯算术校验 —— 这是 init 不炸的硬约束。
 */
static int g_off_verified;

#define HY_PT_ADDR_MASK 0x0000FFFFFFFFF000UL

/*
 * 走 TTBR1 内核页表把一个 VA 翻成物理地址。
 * 失败返回 0（0 不是合法的内核物理基址，调用方按失败处理）。
 */
static unsigned long pt_lookup_phys(unsigned long va)
{
    unsigned long mask;
    u64 *ptep;
    int lvl = 0;
    u64 path[8];
    int plen = 0;
    u64 ent;

    /*
     * 【v1.66.0】基址直接用 VA，不再从 TTBR1 抠物理地址再换算。
     * 见 g_kern_pgd_va 声明处的说明。
     *
     * 另外：偏移没定就绝不能碰页表（v1.64.2 加载即炸的旧根因）。
     * 选档发生在 hy_physvirt_off 定下来之前（hy_scheme_init 早于
     * hy_pt_init），真正的交叉校验放到 pt_validate()，那时偏移已就绪。
     */
    if (!hy_physvirt_off) return 0;
    if (!g_kern_pgd_va) return 0;

    ptep = hy_walk_pgtable(g_kern_pgd_va, va, &lvl, path, &plen);
    if (!ptep) return 0;

    ent = *ptep;
    if (!(ent & 1UL)) return 0;      /* valid bit */

    /* 块映射（2M / 1G）时表项指向块起始，页内偏移位数不同 */
    mask = (lvl == 1) ? (0x200000UL - 1)
         : (lvl == 2) ? (0x40000000UL - 1)
                      : (HY_PAGE_SIZE - 1);

    return (unsigned long)(ent & HY_PT_ADDR_MASK) + (va & mask);
}

static unsigned long pt_page_offset_of(u64 va_bits)
{
    /* PAGE_OFFSET = 0xffff... << (va_bits - 1) */
    return ~(0UL) << (va_bits - 1);
}

/*
 * 试算页表参数。levels / va_bits / page_offset 任一可为 NULL（只要探测）。
 * 返回 0 = 这套算法在本机算得出合理结果。
 */
int hy_pt_try_pgparams(int kind, int *levels, u64 *va_bits,
                       unsigned long *page_offset)
{
    u64 vb = 0;
    int lv;

    switch (kind) {
    case HY_PG_TCR_EL1: {
        /* 6 系首选：TCR_EL1.T1SZ 直接给出用户空间 VA 位数 */
        u64 tcr, t1sz;
        asm volatile("mrs %0, tcr_el1" : "=r"(tcr));
        t1sz = (tcr >> 16) & 0x3f;
        vb = 64 - t1sz;
        break;
    }
    case HY_PG_VABITS_SYM:
        /* 5 系：内核把探测结果存成了符号，直接读 */
        if (!hy_v_vabits_actual) return -1;
        vb = (u64)(*hy_v_vabits_actual);
        break;
    case HY_PG_PROBE_WALK: {
        /*
         * 4 系：不依赖任何符号/寄存器语义，直接按 4 级走一遍内核页表，
         * 走不通退 3 级。最慢但最不挑内核。
         */
        unsigned long probe_va = (unsigned long)&hy_va_bits;
        /*
         * 这一档要 walk 内核页表，而 walk 依赖偏移。
         * 光判"偏移非 0"不够 —— 偏移算错时同样会炸，
         * 必须等它被独立证据验证过才允许走。
         */
        if (!g_off_verified) return -1;
        hy_pgtable_set_params(4, 48, pt_page_offset_of(48));
        if (pt_lookup_phys(probe_va)) { vb = 48; break; }
        hy_pgtable_set_params(3, 39, pt_page_offset_of(39));
        if (pt_lookup_phys(probe_va)) { vb = 39; break; }
        return -1;
    }
    case HY_PG_FIXED_39:
        /* 3 系兜底：按 39-bit 硬假设 */
        vb = 39;
        break;
    default:
        return -1;
    }

    if (vb < 32 || vb > 52) return -1;

    /* 52-bit 需要 5 级，目前自实现遍历只做 3/4 级，超出就按 4 级走 */
    lv = (vb <= 39) ? 3 : 4;

    if (levels) *levels = lv;
    if (va_bits) *va_bits = vb;
    if (page_offset) *page_offset = pt_page_offset_of(vb);
    return 0;
}

int hy_pt_apply_pgparams(int kind)
{
    int lv;
    u64 vb;
    unsigned long po;

    if (hy_pt_try_pgparams(kind, &lv, &vb, &po) != 0) return -1;

    hy_va_bits    = vb;
    hy_pt_levels  = lv;
    hy_page_offset = po;
    hy_pgtable_set_params(lv, vb, po);
    g_pg_kind = kind;
    return 0;
}

int hy_pt_pg_kind(void) { return g_pg_kind; }

/*
 * 试算线性映射偏移。
 *
 * 【校验必须走独立信息源】
 *   不能用 v - off + off == v 这种自反式往返 —— 它对任何 off 都成立，
 *   等于没校验。这里拿**页表反推出来的物理地址**当基准：
 *   p_true + off 必须恰好等于 v，否则这套算法在本机是错的。
 *   3 系的固定猜测档正是靠这一关才不会把错偏移放出去。
 */
int hy_pt_try_physvirt(int kind, unsigned long *out_off)
{
    unsigned long off;

    switch (kind) {
    case HY_PV_PHYSVIRT_OFFSET:
        if (!hy_v_physvirt_offset || *hy_v_physvirt_offset == 0) return -1;
        off = (unsigned long)(*hy_v_physvirt_offset);
        break;
    case HY_PV_MEMSTART_ADDR:
        if (!hy_v_memstart_addr || !hy_page_offset) return -1;
        /* virt = phys - memstart_addr + PAGE_OFFSET */
        off = hy_page_offset - (unsigned long)(*hy_v_memstart_addr);
        break;
    case HY_PV_SWAPPER_PGD: {
        /*
         * 4 系：swapper_pg_dir 的内核地址减 TTBR1 里的页表物理基址。
         *
         * 【为什么不走页表反推】原 PGTABLE_DERIVE 档要 walk 内核页表，
         * 而 walk 的前提 hy_physvirt_off 正是这一步要算的东西 ——
         * 拿还没定的偏移去解引用页表物理地址，就是 v1.64.x 秒炸的根因。
         *
         * 这里改成纯算术：TTBR1 装的就是 swapper_pg_dir 的物理地址，
         * 符号查出的是它的内核地址，两者相减即线性映射偏移。
         * 全程零解引用，偏移对错都不会炸。
         */
        unsigned long sva, ttbr1, pgd_phys;
        if (!hy_v_swapper_pg_dir) return -1;
        sva = hy_v_swapper_pg_dir;
        asm volatile("mrs %0, ttbr1_el1" : "=r"(ttbr1));
        pgd_phys = ttbr1 & ((1UL << 48) - 1);
        pgd_phys &= ~((unsigned long)HY_PAGE_SIZE - 1);
        if (!pgd_phys) return -1;
        if (sva <= pgd_phys) return -1;
        off = sva - pgd_phys;
        break;
    }
    case HY_PV_FIXED_GUESS:
        if (!hy_page_offset) return -1;
        /* 假设物理内存从 0 开始 */
        off = hy_page_offset;
        break;
    default:
        return -1;
    }

    /*
     * 【v1.64.2】选档阶段只做廉价判据，绝不走页表。
     *
     * 原来这里用 pt_lookup_phys() 做交叉校验，而这一档正是在算
     * hy_physvirt_off —— 偏移此刻还是 0，等于拿 0 偏移走页表去求偏移，
     * 物理地址被当成虚拟地址解引用，加载即炸的根因就在这里。
     *
     * 真正有效的交叉校验移到 pt_validate()（hy_pt_init 调用，
     * 那时偏移已 apply）。那里失败会触发 hy_scheme_fail 换档重来，
     * 一样能达到"算错就换一套算法"的目的，而且不会炸。
     */
    if (!off || off == ~0UL) return -1;

    if (out_off) *out_off = off;
    return 0;
}

int hy_pt_apply_physvirt(int kind)
{
    unsigned long off;
    if (hy_pt_try_physvirt(kind, &off) != 0) return -1;
    hy_physvirt_off = off;
    g_pv_kind = kind;
    /*
     * 只有 swapper 档自带独立证据（TTBR1 是硬件给的，不看偏移脸色）；
     * 其余档的 off 都还是"算出来的"，要等 pt_validate() 判过才算数。
     */
    g_off_verified = (kind == HY_PV_SWAPPER_PGD) ? 1 : 0;
    return 0;
}

int hy_pt_pv_kind(void) { return g_pv_kind; }

/*
 * 校验当前选中的 physvirt + pgtable 组合在本机是否真的成立。
 * 三道关：参数自洽、与 memstart_addr 交叉比对、页表遍历自诊断。
 */
static int pt_validate(void)
{
    unsigned long v, p, v2;

    if (!hy_page_offset || !hy_pt_levels) return -1;

    /*
     * 【v1.66.0】这一条是**自反式**往返：v - off + off 恒等于 v，
     * 对任何 off 都成立，等于没校验。它唯一还能起的作用是挡住
     * "hy_physvirt_off 根本没被设置"这种极端情况，保留但不作为判据。
     */
    v  = (unsigned long)&hy_va_bits;
    p  = hy_virt_to_phys(v);
    v2 = (unsigned long)hy_phys_to_virt(p);
    HY_LOG("pt: roundtrip v=%lx p=%lx v2=%lx match=%d\n", v, p, v2, v == v2);
    if (v != v2) return -1;

    /*
     * 【v1.66.0】原来的 "swapper_pg_dir VA - TTBR1 物理地址 == 线性映射
     * 偏移" 这条判据是**错的**，必须删掉。
     *
     * swapper_pg_dir 住在内核镜像里，它减自己的物理地址得到的是
     * kimage_voffset，而不是线性映射偏移（PAGE_OFFSET - memstart_addr）。
     * arm64 上这两个值不相等是常态 —— KernelPatch 自己就有判据
     *     include/pgtable.h: has_vmalloc_area() { return kimage_voffset !=
     *                                                    linear_voffset; }
     * 所以那条校验在大多数机器上**永远判失败**，害得 pt_init 一路降级
     * 到底再放弃，白白让整个内存/断点能力不可用。
     *
     * 现在换成两条各自成立的判据：
     *   1) 与 memstart_addr 交叉比对（若该符号可用）——定义明确，零解引用
     *   2) 走一遍内核页表，看参数是否自洽 —— 需要偏移已可信才做
     */

    /* 记录内核页表基址 VA（供 hy_kern_addr_mapped / pt_lookup_phys 用） */
    if (hy_v_swapper_pg_dir && hy_v_swapper_pg_dir >= 0xfff0000000000000UL)
        g_kern_pgd_va = hy_v_swapper_pg_dir;
    else
        HY_LOG("pt: swapper_pg_dir unavailable, kernel pgd walks disabled\n");

    if (hy_v_memstart_addr) {
        unsigned long expect = hy_page_offset -
                               (unsigned long)(*hy_v_memstart_addr);
        if (expect && expect != hy_physvirt_off) {
            HY_LOG("pt: off mismatch memstart=%lx cur=%lx\n",
                   expect, hy_physvirt_off);
            return -1;
        }
        if (expect) {
            g_off_verified = 1;
            HY_LOG("pt: off verified via memstart_addr (off=%lx)\n",
                   hy_physvirt_off);
        }
    } else {
        HY_LOG("pt: memstart_addr unavailable, skip cross-check\n");
        /*
         * 拿不到 memstart_addr 时，"physvirt_offset 到底是不是线性偏移"
         * 无法用算术证明。此时**不要**因此判失败 —— 那就是 1.58 及之前
         * 一直在用的值，判失败等于凭空砍掉功能。照旧接受它，只是
         * 标记为"未经独立验证"，后续需要解引用的校验一律跳过。
         */
        g_off_verified = 0;
    }

    /*
     * 【次校验：走页表交叉比对】
     *
     * 【v1.66.0】测试地址必须是**线性映射区内的地址**。
     * 原来用的是模块自己的静态变量 &hy_va_bits —— 模块镜像由
     * kp_malloc_exec 分配，落在 module/vmalloc 区，压根不在线性映射里。
     * 对它做 virt_to_phys（线性偏移）再拿去和页表翻出来的物理地址比，
     * 在任何机器上都不可能相等 —— 又一条永远判失败的假校验。
     *
     * 只有页分配器可用时才能拿到真正的线性映射地址；拿不到就如实跳过，
     * 绝不拿一个必然不等的对照去判失败。
     */
    if (g_off_verified && g_kern_pgd_va &&
        hy_f___get_free_pages && hy_f_free_pages) {
        unsigned long dv = hy_f___get_free_pages(0xcc0, 0);
        if (dv) {
            unsigned long dp     = hy_virt_to_phys(dv);
            unsigned long p_tbl  = pt_lookup_phys(dv);

            HY_LOG("pt: xcheck(dyn) v=%lx linear=%lx tbl=%lx\n",
                   dv, dp, p_tbl);
            hy_f_free_pages(dv, 0);

            if (p_tbl && dp && p_tbl != dp) {
                HY_LOG("pt: FATAL phys mismatch tbl=%lx linear=%lx\n",
                       p_tbl, dp);
                return -1;
            }
        }
    } else if (g_off_verified) {
        HY_LOG("pt: xcheck skipped (no linear-map test address)\n");
    }

    /* 页表遍历自诊断：默认不开（要 ptcheck=1），只是排查用 */
    if (g_kern_pgd_va && hy_opt_ptcheck && g_off_verified) {
        int rc = hy_pgtable_selfcheck(g_kern_pgd_va);
        if (rc != 0) {
            HY_LOG("pt: selfcheck failed rc=%d\n", rc);
            return -1;
        }
    } else if (!hy_opt_ptcheck) {
        HY_LOG("pt: selfcheck skipped (add ptcheck=1 to enable)\n");
    } else {
        HY_LOG("pt: selfcheck skipped (offset not verified)\n");
    }

    /*
     * 兜底档是"假设物理内存从 0 开始"，本身没有任何证据。
     * 又拿不到 swapper_pg_dir 做独立校验时放它出去，等于拿一个
     * 大概率错误的偏移去做后续所有地址换算 —— 比直接不用更危险。
     * 这种情况如实判失败，让上层停用内存/断点能力，好过静默出错。
     */
    if (!g_off_verified && g_pv_kind == HY_PV_FIXED_GUESS) {
        HY_LOG("pt: FATAL fixed-guess unverifiable, refusing\n");
        return -1;
    }

    return 0;
}

int hy_pt_init(void)
{
    int guard = 0;

    g_pt_ok = false;

    /*
     * 页表参数与线性映射偏移已由 hy_scheme_init() 选好并 apply，
     * 这里只负责校验。不通过就降一档再来，直到没有更低的档。
     *
     * 这就是"多方案降级"真正落地的地方：以前算错就直接拒绝加载，
     * 现在先换一套算法再试，试遍了才放弃。
     */
    HY_LOG("pt: try levels=%d va_bits=%llu off=%lx pv=%s pg=%s\n",
           hy_pt_levels, hy_va_bits, hy_physvirt_off,
           hy_scheme_name(HY_SC_PHYSVIRT), hy_scheme_name(HY_SC_PGTABLE));

    while (guard++ < 8) {
        if (pt_validate() == 0) {
            g_pt_ok = true;
            break;
        }

        HY_LOG("pt: current scheme invalid, demoting\n");
        /*
         * pgtable 先降：它决定 va_bits，而 physvirt 里有两个档都依赖
         * 由 va_bits 推出的 PAGE_OFFSET，先降它收益最大。
         * 两个都降不动才是真的没救。
         */
        if (hy_scheme_fail(HY_SC_PGTABLE) < 0 &&
            hy_scheme_fail(HY_SC_PHYSVIRT) < 0) {
            HY_LOG("pt: FATAL no scheme left\n");
            return -1;
        }
    }

    if (!g_pt_ok) {
        HY_LOG("pt: FATAL all schemes failed\n");
        return -1;
    }

    g_pt_ok = true;
    HY_LOG("pt: init OK pv=%s pg=%s\n",
           hy_scheme_name(HY_SC_PHYSVIRT), hy_scheme_name(HY_SC_PGTABLE));
    return 0;
}

unsigned long hy_virt_to_phys(unsigned long vaddr)
{
    return vaddr - hy_physvirt_off;
}

void *hy_phys_to_virt(unsigned long paddr)
{
    return (void *)(paddr + hy_physvirt_off);
}

/*
 * 定位用户地址对应的 PTE 表项。
 * 【已改为走 hy_pgtable.c 的自实现遍历】
 *   原来这里自己写了一遍 3/4 级分支，与 hy_pgtable.c 重复且能力更弱
 *   （不支持 5 级、不支持块映射的粒度区分）。
 *   现在统一调用 hy_walk_pgtable，一处维护、一处校验。
 */
u64 *hy_find_user_pte(void *mm, unsigned long addr, int *level)
{
    u64 *pgdp;
    u64 *ent;
    int lvl = -1;
    u64 path[8];
    int plen = 0;

    if (!mm || level == NULL) return NULL;
    *level = 0;

    /* 拿 pgd：优先用自发现偏移，KP 的只作参考 */
    {
        int off = hy_pgd_offset();
        if (off < 0) off = mm_struct_offset.pgd_offset;
        if (off < 0) return NULL;
        pgdp = *(u64 **)((unsigned long)mm + off);
    }
    if (!pgdp) return NULL;

    /*
     * 【v1.66.0】直接把 mm->pgd 这个 VA 交给 walk。
     *
     * 旧实现先 hy_virt_to_phys(pgdp) 换回物理地址、walk 内部再换回来，
     * 一来一回纯属多余 —— 而且这两步用的是同一个偏移，一旦偏移不对
     * 就变成"换个错的再换回来"，中间还要拿那个错的物理地址去做
     * hy_phys_ok 判断。现在一步到位，少一次出错机会。
     */
    ent = hy_walk_pgtable((unsigned long)pgdp, addr, &lvl, path, &plen);
    if (!ent) return NULL;

    /*
     * level 语义转换：
     *   hy_walk_pgtable: 0=4K页 1=2M块 2=1G块
     *   本函数历史约定: 1=4K页 2=块
     */
    if (lvl == 0) *level = 1;
    else *level = 2;

    return ent;
}

/*
 * 【v1.19.0】返回 hy_walk_pgtable 的**原始** level（0=4K 1=2M 2=1G）。
 *
 * hy_find_user_pte 把 2M 和 1G 块合并成同一个 level=2，
 * 调用方因此无法知道块的实际粒度。
 * hy_mem.c 计算块内偏移时必须知道到底是 2M 还是 1G ——
 * 猜错就会读到错误的物理地址（见 hy_map_user_page 的修复说明）。
 */
u64 *hy_find_user_pte_lvl(void *mm, unsigned long addr, int *raw_lvl)
{
    /* 与 hy_find_user_pte 完全相同的流程，只是 level 不做转换 */
    u64 *pgdp;
    u64 *ent;
    int lvl = -1;
    u64 path[8];
    int plen = 0;
    int off;

    if (!mm || raw_lvl == NULL) return NULL;
    *raw_lvl = -1;

    off = hy_pgd_offset();
    if (off < 0) off = mm_struct_offset.pgd_offset;
    if (off < 0) return NULL;
    pgdp = *(u64 **)((unsigned long)mm + off);
    if (!pgdp) return NULL;

    ent = hy_walk_pgtable((unsigned long)pgdp, addr, &lvl, path, &plen);
    if (!ent) return NULL;

    *raw_lvl = lvl;
    return ent;
}

void hy_set_user_pte(void *mm, unsigned long addr, u64 *ptep, u64 pte)
{
    (void)mm; (void)addr;
    if (!ptep) return;
    *ptep = pte;
}

/*
 * TLB 刷新。优先用内核函数，拿不到就用内联汇编做本地 + 广播失效。
 * 内联汇编版本只依赖系统寄存器，5.10~6.18 通用。
 */
void hy_flush_tlb_range(void *mm, unsigned long start, unsigned long end)
{
    unsigned long addr;

    (void)mm;

    for (addr = start & HY_PAGE_MASK; addr < end; addr += HY_PAGE_SIZE) {
        asm volatile("dsb ishst" ::: "memory");
        asm volatile("tlbi vale1is, %0" :: "r"(addr >> 12));
    }
    asm volatile("dsb ish" ::: "memory");
    asm volatile("isb" ::: "memory");

    if (hy_f_kick_all_cpus_sync)
        hy_f_kick_all_cpus_sync();
}

/* 供 hy_extra.c 的 KERNEL_RW 边界校验使用 */
unsigned long hy_page_offset_base(void) { return hy_page_offset; }
