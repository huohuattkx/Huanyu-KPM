/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef HY_INSN_H
#define HY_INSN_H

#include <ktypes.h>

/* 指令类别 */
enum hy_insn_cls {
    HY_CLS_DP_IMM  = 0,
    HY_CLS_BRANCH  = 1,
    HY_CLS_LDST    = 2,
    HY_CLS_DP_REG  = 3,
    HY_CLS_SIMD    = 4,
    HY_CLS_SYS     = 5,
    HY_CLS_FP      = 6,
    HY_CLS_BARRIER = 7,
    HY_CLS_UNK     = 8,
};

/* 指令标志 */
#define HY_F_BRANCH   (1u << 0)  /* 分支/跳转 */
#define HY_F_PCREL    (1u << 1)  /* PC 相关，搬移后需修正 */
#define HY_F_MEM      (1u << 2)  /* 访问内存 */
#define HY_F_MEMW     (1u << 3)  /* 写内存 */
#define HY_F_SYS      (1u << 4)  /* 系统调用 / 异常 */
#define HY_F_SIMD     (1u << 5)  /* 使用 FP/SIMD 寄存器 */
#define HY_F_RELOC    (1u << 6)  /* 可安全搬移 */
#define HY_F_PRIV     (1u << 7)  /* 特权指令 */
#define HY_F_ATOMIC   (1u << 8)  /* 原子操作 */
#define HY_F_EXCL     (1u << 9)  /* 独占访问 */

/*
 * 表项压到 12 字节（原 16）。
 * 65536 项 × 12 = 786 KB，比原 1 MB 省 25%，
 * 且字段顺序按大小降序排列，无内部填充。
 *
 * cls / name_idx 各 1 字节够用：类别 0~8，助记符索引 < 256。
 */
struct hy_insn_entry {
    u32 mask;
    u32 value;
    u16 flags;
    u8  cls;
    u8  name_idx;
};

extern const struct hy_insn_entry hy_insn_prefix[65536];
extern const char *const hy_insn_names[];
extern const u32 hy_insn_names_size;

/* 解码结果 */
struct hy_insn_info {
    u32 insn;
    u16 cls;
    u16 flags;
    const char *name;
    u32 match_mask;
    u32 match_value;
    bool matched;
};

/* 前缀表查表：O(1)，索引 = insn >> 16 */
const struct hy_insn_entry *hy_insn_lookup_prefix(u32 insn);

/* 完整解码：前缀表 + mask/value 精确校验 + 逐层兜底 */
void hy_insn_decode(u32 insn, struct hy_insn_info *out);

/* 常用判定 */
bool hy_insn_is_branch(u32 insn);
bool hy_insn_is_pcrel(u32 insn);
bool hy_insn_is_syscall(u32 insn);
bool hy_insn_is_memory(u32 insn);
bool hy_insn_is_simd(u32 insn);
bool hy_insn_can_relocate(u32 insn);

/* 分支目标解码（B/BL/B.cond/CBZ/TBZ），非分支返回 0 */
u64 hy_insn_branch_target(u32 insn, u64 pc);

/* 指令重定位：把 src 处的指令搬到 dst_pc，修正 PC 相关字段。
 * 无法安全重定位（如 ADR/ADRP/B 超出范围）返回 false。 */
bool hy_insn_relocate(u32 insn, u64 src_pc, u64 dst_pc, u32 *out);

#endif
