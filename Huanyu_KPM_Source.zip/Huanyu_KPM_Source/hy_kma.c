/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_kma.c —— KMA（Kernel Memory Allocator）读取后端
 *
 * 【它到底是什么】
 *   所谓"硬件级读取"，落到这里就是一件事：**按物理地址读，不依赖
 *   目标地址当前的虚拟映射是否可用**。
 *
 *   做法是临时改我们自己的一页页表项，让它的物理目标指向要读的页：
 *
 *       1. 分配一页独占的内核页作为"观察窗口"
 *       2. 在内核页表里找到窗口 VA 的 PTE
 *       3. 把 PTE 的物理地址字段换成目标物理页
 *       4. 刷掉这条 VA 的 TLB
 *       5. 从窗口 VA 拷贝数据
 *       6. 还原 PTE、再刷一次 TLB
 *
 *   窗口页是 __get_free_pages 分出来的，分配器保证独占 —— 改它的 PTE
 *   不会影响任何别人。改完一定还原，且全程只有一个使用者。
 *
 * 【与内核级读取的分工（这是设计核心，不要随意改）】
 *   内核级路径（phys_to_virt 线性映射 / 直接解引用）快且稳，但有前提：
 *   目标必须在线性映射范围内、且线性映射本身没被改。
 *   KMA 路径绕开这个前提，代价是每次都要改页表 + 刷 TLB，慢得多。
 *
 *   因此按场景路由，而不是全局一刀切：
 *
 *       用户态进程内存   -> 永远内核级（KMA 在这里没有收益，自动回落）
 *       内核虚拟地址     -> mode=1 时走 KMA，失败回落内核级
 *       物理地址         -> mode=1 时走 KMA，失败回落内核级
 *
 *   默认 mode=0，全内核级 —— 与不加这个功能时行为完全一致。
 *
 * 【四条硬约束】
 *   1. 只做读，不做写。写内存一律走原内核路径。
 *   2. 只接受 4K 粒度的 PTE。窗口页若落在 2M/1G 块映射里，直接拒绝
 *      （拆块映射的风险不可控），调用方自动回落内核级。
 *   3. 任何一步失败都必须还原 PTE 后再返回，绝不留脏页表。
 *   4. 加载参数 nokma=1 可彻底关闭，一个符号都不解析。
 */

#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include "hy.h"

#ifndef EINVAL
#define EINVAL 22
#endif
#ifndef EFAULT
#define EFAULT 14
#endif
#ifndef ENOTSUP
#define ENOTSUP 524
#endif
#ifndef ENODEV
#define ENODEV 19
#endif

extern unsigned long (*hy_f___get_free_pages)(unsigned int gfp, unsigned int order);
extern void (*hy_f_free_pages)(unsigned long addr, unsigned int order);

/* 两参：flush_tlb_kernel_range(unsigned long start, unsigned long end) */
static void (*f_flush_range)(unsigned long, unsigned long);
/* 零参：flush_tlb_all(void) —— 兜底，代价大但不挑版本 */
static void (*f_flush_all)(void);

static void            *v_swapper_pg_dir;
static unsigned long    g_window_va;
static u64             *g_window_pte;
static u64              g_window_pte_saved;
static unsigned long    g_window_cur_phys;   /* 窗口当前指向的物理页，~0 = 未映射 */
static int              g_ready;
static int              g_mode;         /* 0 = 内核级（默认），1 = KMA */
static int              g_disabled;     /* nokma=1 */

/* 统计：用于判断这条路径到底有没有被真正用上 */
static unsigned long    g_kma_reads;
static unsigned long    g_kma_fallbacks;
static unsigned long    g_kma_errors;

static void hy_kma_flush(unsigned long va)
{
    if (f_flush_range) {
        f_flush_range(va & HY_PAGE_MASK, (va & HY_PAGE_MASK) + HY_PAGE_SIZE);
        return;
    }
    if (f_flush_all) f_flush_all();
}

/*
 * 窗口自旋锁。
 *
 * 为什么必须有：观察窗口是全局唯一的，改 PTE 是"保存 -> 改写 -> 拷贝 ->
 * 还原"四步，中间任何时刻被另一个 CPU 插进来都会出事：
 *
 *     CPU0: 保存原值 -> 写入 physA
 *     CPU1: 保存(读到的是 physA，不是原值) -> 写入 physB
 *     CPU0: 拷贝      -> 读到 physB 的数据（错）
 *     CPU0: 还原成 physA（错，原值被覆盖）
 *
 * 后果是"读错数据 + 页表被永久改坏"，所以这里必须串行化。
 *
 * 为什么自己写而不是用 spin_lock：KPM 没有内核头文件，拿不到 spinlock_t
 * 布局，也无法保证符号存在。arm64 的独占访问指令（ldaxr/stxr/stlr）是
 * 架构原生指令，零符号依赖、零结构体布局，在这里最稳。
 *
 * 取锁期间不休眠、不调度，因此不会与自身重入（调用方也不在中断上下文
 * 用这条路径）。
 */
extern int hy_mem_cache_enabled(void);

static unsigned int g_win_lock;

static void win_lock(void)
{
    unsigned int tmp, one = 1;

    __asm__ __volatile__(
        "1:  ldaxr  %w0, [%1]\n"
        "    cbnz   %w0, 1b\n"
        "    stxr   %w0, %w2, [%1]\n"
        "    cbnz   %w0, 1b\n"
        : "=&r" (tmp)
        : "r" (&g_win_lock), "r" (one)
        : "memory", "cc");
}

static void win_unlock(void)
{
    __asm__ __volatile__(
        "    stlr   wzr, [%0]\n"
        :
        : "r" (&g_win_lock)
        : "memory");
}

/*
 * 读一页内的连续区间。
 * len 不得超过从 off 到页尾的剩余长度 —— 跨页由调用方切分。
 */
/*
 * 读一页内的连续区间（调用者必须已持有 win_lock）。
 * len 不得超过从 off 到页尾的剩余长度 —— 跨页由调用方切分。
 *
 * 【v1.63.0 性能：每页只刷一次 TLB】
 *   原实现是"改 PTE -> 刷 -> 拷 -> 还原 -> 刷"，一页两次 flush。
 *   跨页读时中间的还原纯属浪费：下一页马上又要把它改成别的物理页。
 *   现在改成一条链上连续映射，只在**最后**统一还原并刷一次：
 *       N 页的 flush 次数从 2N 降到 N+1。
 *   窗口页是我们独占分配的，中间态不会被别人看到，所以这样是安全的。
 */
static int hy_kma_read_page_locked(unsigned long phys, void *dst, unsigned long len)
{
    u64 new_pte;
    unsigned long off, base_phys;

    if (!g_ready) return -ENODEV;
    if (!g_window_pte) return -ENODEV;

    off = phys & (HY_PAGE_SIZE - 1);
    if (len == 0 || off + len > HY_PAGE_SIZE) return -EINVAL;

    base_phys = phys & HY_PAGE_MASK;

    /*
     * 【同页短路】
     *   批量读常见"多段数据落在同一物理页"，此时窗口已经指向它，
     *   再改一次 PTE + 刷一次 TLB 纯属重复劳动。直接拷。
     */
    /*
     * 同页短路也受读取缓存开关控制：
     * 设成 OFF 就表示"每次都用最直白的路径，不复用任何上一次的结果"，
     * 这条短路属于复用，自然一并关掉 —— 让开关对**所有**读取路径语义一致。
     */
    if (g_window_cur_phys != base_phys || !hy_mem_cache_enabled()) {
        new_pte = hy_pte_replace_phys(g_window_pte_saved, base_phys);

        /*
         * 【必须显式置 AF —— 否则会在自旋锁里触发缺页】
         * arm64 上 PTE 的 AF(bit10) 为 0 时，处理器首次访问该页会抛
         * Access Flag 缺页异常。窗口页是刚分配的，AF 大概率还是 0；
         * 而我们接下来是在 **win_lock 自旋锁持有期间** 访问它 ——
         * 一旦进异常路径，就是在原子上下文里做缺页处理，后果不可控。
         *
         * 这里主动置 AF，让访问变成纯硬件行为，绝不进异常。
         * 还原时写回的是 g_window_pte_saved 原值，所以 AF 的原始状态
         * 一点都不会留在页表里，读完之后看不出这页被动过。
         */
        new_pte |= HY_PTE_AF;

        *g_window_pte = new_pte;
        hy_kma_flush(g_window_va);
        g_window_cur_phys = base_phys;
    }

    hy_memcpy(dst, (const void *)(g_window_va + off), len);
    return 0;
}

/*
 * 对外主入口：按物理地址读取。
 * 跨页自动切分，单页失败立即返回错误（调用方负责回落内核级）。
 */
int hy_kma_read_phys(unsigned long phys, void *dst, unsigned long len)
{
    unsigned long done = 0;
    int rc = 0;

    if (!g_ready || !dst) return -ENODEV;
    if (len == 0) return -EINVAL;

    /*
     * 【v1.63.0 性能：整批只取一次锁】
     *   原来每页各自 lock/unlock，跨页读 N 页就是 N 对原子指令。
     *   这两条指令本身不贵，但完全没必要 —— 整批映射本来就是
     *   一个不可分割的操作序列，锁提到循环外即可。
     */
    win_lock();
    g_window_pte_saved = *g_window_pte;
    g_window_cur_phys = ~0UL;   /* 未知，强制首页真正改写一次 */

    while (done < len) {
        unsigned long cur = phys + done;
        unsigned long room = HY_PAGE_SIZE - (cur & (HY_PAGE_SIZE - 1));
        unsigned long seg = len - done;

        if (seg > room) seg = room;

        rc = hy_kma_read_page_locked(cur, (u8 *)dst + done, seg);
        if (rc != 0) break;
        done += seg;
    }

    /* 无论中途是否出错，都必须还原 PTE 再放行 —— 绝不留脏页表 */
    *g_window_pte = g_window_pte_saved;
    hy_kma_flush(g_window_va);
    g_window_cur_phys = ~0UL;
    win_unlock();

    if (rc != 0) {
        g_kma_errors++;
        return rc;
    }

    g_kma_reads++;
    return 0;
}

int hy_kma_available(void)
{
    return (g_ready && !g_disabled) ? 1 : 0;
}

int hy_kma_mode(void) { return (g_mode && hy_kma_available()) ? 1 : 0; }

void hy_kma_set_mode(int mode)
{
    g_mode = (mode == 1) ? 1 : 0;
    HY_LOG("kma: mode=%d (avail=%d)\n", g_mode, hy_kma_available());
}

void hy_kma_note_fallback(void) { g_kma_fallbacks++; }

void hy_kma_stats(unsigned long *reads, unsigned long *fallbacks,
                  unsigned long *errors)
{
    if (reads)     *reads     = g_kma_reads;
    if (fallbacks) *fallbacks = g_kma_fallbacks;
    if (errors)    *errors    = g_kma_errors;
}

/* ==================== 生命周期 ==================== */

int hy_kma_init(void)
{
    /*
     * 【优先只刷本地 TLB —— 能不发 IPI 就不发】
     * 全局 flush 会向所有 CPU 广播 IPI，把其它核的 TLB 一起清掉。
     * 这既是明显的性能/时序痕迹（其它核上跑着的检测代码能感觉到
     * 这一下停顿），也白白拖慢读取。
     *
     * 而窗口页只在 win_lock 保护下被**当前这一颗 CPU**访问，
     * 其它核上根本不会有这条 VA 的 TLB 条目，刷本地就足够正确。
     * 本地符号不存在时才退回全局版本。
     */
    static const char *const range_cands[] = {
        "local_flush_tlb_kernel_range",
        "flush_tlb_kernel_range",
        "__flush_tlb_kernel_range",
    };
    static const char *const all_cands[] = {
        "local_flush_tlb_all",
        "flush_tlb_all",
        "__flush_tlb_all",
    };
    int i, level;
    unsigned long pgd_va;

    g_ready = 0;
    g_window_va = 0;
    g_window_pte = NULL;

    if (hy_opt_nokma) {
        g_disabled = 1;
        HY_LOG("kma: nokma=1 -> disabled\n");
        return 0;
    }

    if (!hy_f___get_free_pages || !hy_f_free_pages) {
        HY_LOG("kma: page allocator missing -> disabled\n");
        return 0;
    }

    for (i = 0; i < 3; i++) {
        unsigned long a = hy_lookup_generic(range_cands[i]);
        if (a) { f_flush_range = (void (*)(unsigned long, unsigned long))a; break; }
    }
    if (!f_flush_range) {
        for (i = 0; i < 3; i++) {
            unsigned long a = hy_lookup_generic(all_cands[i]);
            if (a) { f_flush_all = (void (*)(void))a; break; }
        }
    }
    if (!f_flush_range && !f_flush_all) {
        HY_LOG("kma: no TLB flush symbol -> disabled\n");
        return 0;
    }

    /*
     * 内核页表基址：**必须用 swapper_pg_dir 的 VA**。
     *
     * 【v1.66.0 加载即秒炸的真正根因就在这里】
     * 旧代码写的是 g_pgd_phys = hy_virt_to_phys(pgd_va)。
     * 而 swapper_pg_dir 住在**内核镜像**里，它到物理地址的换算要用
     * kimage_voffset，不是线性映射偏移 —— arm64 上这两个值不相等是常态
     * （KernelPatch 自己就有 has_vmalloc_area() 判这两个是否不同）。
     * 于是换出来的是一个凭空捏造的物理地址，紧接着 walk 就拿着它去
     * 解引用：第一次读表就是读垃圾地址，直接 oops。
     *
     * 现在直接把 VA 交给 walk，一次换算都不做。
     * TTBR1 只在拿不到 swapper_pg_dir 符号时用来记个数（不可当基址：
     * 它是物理地址，而我们没有可信的 kimage_voffset 能换回去）。
     */
    v_swapper_pg_dir = (void *)hy_lookup_generic("swapper_pg_dir");
    pgd_va = (unsigned long)v_swapper_pg_dir;
    if (!pgd_va || pgd_va < 0xfff0000000000000UL) {
        HY_LOG("kma: swapper_pg_dir unavailable/invalid -> disabled\n");
        return 0;
    }
    HY_LOG("kma: kernel pgd va=%lx\n", pgd_va);

    g_window_va = hy_f___get_free_pages(0xcc0u, 0);
    if (!g_window_va) {
        HY_LOG("kma: window page alloc failed -> disabled\n");
        return 0;
    }

    /*
     * 只接受 4K 粒度的 PTE。
     * 窗口页若被 2M/1G 块映射覆盖，改 PTE 等于拆块 —— 风险不可控，
     * 这里直接放弃，调用方会回落到内核级路径，功能不受影响。
     */
    g_window_pte = hy_walk_pgtable(pgd_va, g_window_va, &level, NULL, NULL);
    if (!g_window_pte || level != 0) {
        HY_LOG("kma: window pte level=%d (need 0) -> disabled\n", level);
        hy_f_free_pages(g_window_va, 0);
        g_window_va = 0;
        g_window_pte = NULL;
        return 0;
    }

    g_ready = 1;
    HY_LOG("kma: ready pgd_va=%lx window_va=%lx pte=%px flush=%s\n",
           pgd_va, g_window_va, (void *)g_window_pte,
           f_flush_range ? "range" : "all");
    return 0;
}

void hy_kma_exit(void)
{
    if (g_window_va && hy_f_free_pages) {
        hy_f_free_pages(g_window_va, 0);
        HY_LOG("kma: window released (reads=%lu fallback=%lu err=%lu)\n",
               g_kma_reads, g_kma_fallbacks, g_kma_errors);
    }
    g_window_va = 0;
    g_window_pte = NULL;
    g_ready = 0;
}
