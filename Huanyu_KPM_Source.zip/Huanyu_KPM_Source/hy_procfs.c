/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_procfs.c —— /proc/huanyu 真实文件接口
 *
 * 【这是真的文件，不是路径劫持】
 *
 *   旧方案把 /proc/huanyu 的路径偷换成 /proc/uptime，再在 read 里替换内容。
 *   那不是接口：ls /proc 看不到、stat 也失败，只是骗过了调用者。
 *
 *   现在直接用内核的 proc_create_single_data() 真正注册一个文件。
 *   之后：
 *     - ls /proc/huanyu      能看到
 *     - cat /proc/huanyu     读到 "你好"
 *     - stat /proc/huanyu    成功
 *   完全由内核 procfs 子系统维护，不依赖任何其他文件、不做任何路径替换。
 *
 * 【符号从哪来】
 *   KernelPatch 只导出了 173 个符号，proc_create 不在其中。
 *   但 kallsyms_lookup_name 在导出表里，而用户的内核开了
 *   CONFIG_KALLSYMS_ALL=y，所以能查到内核里任何符号。
 *   —— 这是本项目一直在用的机制（find_vma / input_register_device 都是）。
 *   之前误判成"KP 没导出就做不到"，是把"KP 导出表"当成了全部可用符号。
 *
 * 【为什么用 proc_create_single_data 而不是 proc_create】
 *   proc_create 需要 struct proc_ops，其成员布局随版本变化
 *   （proc_ioctl / proc_compat_ioctl 的有无、CONFIG_COMPAT 等），
 *   而我们没有内核头文件可以核对布局，硬编码风险高。
 *
 *   proc_create_single_data 从 4.17 到 6.x 签名稳定：
 *       struct proc_dir_entry *proc_create_single_data(
 *           const char *name, umode_t mode,
 *           struct proc_dir_entry *parent,
 *           int (*show)(struct seq_file *, void *),
 *           void *data);
 *   seq_file 的 open/read/lseek/release 全由内核提供，我们只写一个 show。
 *
 *   parent 传 NULL 时内核自动用 &proc_root（见 xlate_proc_name 的实现），
 *   所以连 proc_root 符号都不需要查。
 *
 * 【卸载即消失】
 *   exit 里调 proc_remove()。
 *   这一步绝不能省：否则 /proc/huanyu 会残留并指向已释放的模块内存，
 *   下次有人 cat 它就跳进野指针 —— 正是本项目之前踩过的坑。
 */
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <asm/current.h>
#include "hy.h"
#include "hy_scheme.h"
extern int hy_opt_grab;
#include "hy_shm.h"

/* KP 的 errno 头在不同版本路径不同，直接用数值常量最稳 */
#ifndef ENOENT
#define ENOENT 2
#endif
#ifndef ENOMEM
#define ENOMEM 12
#endif

/*
 * struct proc_dir_entry 对模块是不透明的：只存指针、只传给内核函数，
 * 从不访问其成员，因此不需要知道它的布局。
 */
struct hy_proc_dir_entry;

typedef struct hy_proc_dir_entry *(*hy_proc_create_single_data_t)(
    const char *name,
    unsigned short mode,                 /* umode_t */
    struct hy_proc_dir_entry *parent,
    int (*show)(void *seq, void *v),
    void *data);

typedef void (*hy_proc_remove_t)(struct hy_proc_dir_entry *entry);

typedef void (*hy_seq_printf_t)(void *seq, const char *fmt, ...);

static hy_proc_create_single_data_t hy_f_proc_create_single_data;
static hy_proc_remove_t             hy_f_proc_remove;
static hy_seq_printf_t              hy_f_seq_printf;

static struct hy_proc_dir_entry *g_hy_entry;
static struct hy_proc_dir_entry *g_hy_dbg_entry;
static int g_dbg_writable;

/* 权限 0444：只读 */
#define HY_PROC_MODE 0444

/*
 * show 回调。内核 seq_file 在每次 read 时调用它一次。
 * seq_file 本身对我们不透明，只透传指针给 seq_printf。
 */
/*
 * show 回调。
 *
 * 除了"你好"，还输出各通道的实时状态。
 * 这是刻意的设计：这个文件的读取完全不经过 supercall 鉴权，
 * 任何进程 cat 一下就能确认模块是否在跑、哪条通道可用 ——
 * 是排查"连不上"的第一手依据。
 */
static int hy_proc_show(void *seq, void *v)
{
    struct hy_shm_status st;
    int prctl_ok, shm_ok, symfail;

    (void)v;

    /* 卸载守卫：万一 proc_remove 与回调之间存在时间窗 */
    if (!hy_ready) return 0;
    if (!hy_f_seq_printf) return 0;

    /* 这里是Huanyu的日志页面 */
    hy_f_seq_printf(seq, "\xe8\xbf\x99\xe9\x87\x8c\xe6\x98\xaf"
                         "Huanyu"
                         "\xe7\x9a\x84\xe6\x97\xa5\xe5\xbf\x97"
                         "\xe9\xa1\xb5\xe9\x9d\xa2\n");

    prctl_ok = hy_prctl_ready();

    /* ==================================================================
     * [client] 当前有没有用户态连着
     * ================================================================== */
    {
        u64 total = 0, prctl_n = 0, ctl0_n = 0, shm_n = 0, errs = 0;
        unsigned int lnr = 0;
        int lpid = 0, pids[8], n = 0, i;
        u64 counts[8];

        hy_usage_diag(&total, &prctl_n, &ctl0_n, &shm_n, &errs,
                      &lnr, &lpid, pids, counts, 8, &n);

        hy_f_seq_printf(seq, "\n[client]\n");
        hy_f_seq_printf(seq, "  connected     : %s\n",
                        (total > 0) ? "YES (userland has used this module)" : "NO (never used yet)");
        hy_f_seq_printf(seq, "  cmd total     : %llu\n", (unsigned long long)total);
        hy_f_seq_printf(seq, "  by channel    : prctl=%llu ctl0=%llu shm=%llu\n",
                        (unsigned long long)prctl_n,
                        (unsigned long long)ctl0_n,
                        (unsigned long long)shm_n);
        hy_f_seq_printf(seq, "  errors        : %llu\n", (unsigned long long)errs);
        hy_f_seq_printf(seq, "  last cmd      : nr=%u from pid=%d\n", lnr, lpid);

        if (n > 0) {
            hy_f_seq_printf(seq, "  known pids    :");
            for (i = 0; i < n; i++)
                hy_f_seq_printf(seq, " %d(%llu)", pids[i],
                                (unsigned long long)counts[i]);
            hy_f_seq_printf(seq, "\n");
        } else {
            hy_f_seq_printf(seq, "  known pids    : (none)\n");
        }
    }

    /* ==================================================================
     * [handshake] 版本 / 挑战-响应握手闸门（v1.71.0）
     * 只显示状态与版本号，绝不显示密钥的任何字符。
     * ================================================================== */
    {
        char gt[256];
        hy_memset(gt, 0, sizeof(gt));
        hy_gate_text(gt, sizeof(gt));
        hy_f_seq_printf(seq, "\n[handshake]\n  %s\n", gt);
    }

    /* ==================================================================
     * [runtime] 运行时状态
     * ================================================================== */
    {
        struct hy_stats st;
        hy_memset(&st, 0, sizeof(st));
        hy_stats(&st);

        hy_f_seq_printf(seq, "\n[runtime]\n");
        hy_f_seq_printf(seq, "  bp active     : %llu / %u slots\n",
                        (unsigned long long)st.bp_active, (unsigned)HY_POOL_BP);
        hy_f_seq_printf(seq, "  bp hit total  : %llu\n",
                        (unsigned long long)st.hit_total);
        hy_f_seq_printf(seq, "  cache hit/miss: %llu / %llu\n",
                        (unsigned long long)st.cache_hits,
                        (unsigned long long)st.cache_miss);
        hy_f_seq_printf(seq, "  cache mode    : %s\n",
                        hy_mem_cache_enabled() ? "on" : "off");
        hy_f_seq_printf(seq, "  sym failures  : %llu\n",
                        (unsigned long long)st.sym_failures);
    }

    /* ==================================================================
     * [cpu features]
     * ================================================================== */
    {
        struct hy_hwcap cap;
        hy_memset(&cap, 0, sizeof(cap));
        if (hy_hwcap(&cap) == 0) {
            hy_f_seq_printf(seq, "\n[cpu features]\n");
            hy_f_seq_printf(seq, "  pac=%u bti=%u lse=%u mte=%u fp=%u\n",
                            cap.pac, cap.bti, cap.lse, cap.mte, cap.fp);
            hy_f_seq_printf(seq, "  brps=%u wrps=%u\n", cap.brps, cap.wrps);
        }
    }

    /* ==================================================================
     * [layout] 内核布局自发现结果
     * ================================================================== */
    {
        hy_f_seq_printf(seq, "\n[layout]\n");
        hy_f_seq_printf(seq, "  comm  off=%d\n", hy_comm_offset());
        hy_f_seq_printf(seq, "  pid   off=%d\n", hy_pid_offset());
        hy_f_seq_printf(seq, "  tasks off=%d\n", hy_tasks_offset());
        hy_f_seq_printf(seq, "  pgd   off=%d\n", hy_pgd_offset());
        hy_f_seq_printf(seq, "  (src: -1 = unavailable)\n");
    }

    /* ==================================================================
     * [device] 设备信息（v1.43.0）
     *
     * 内核侧只解码 kver；其余字段由用户态 HuanyuD 采集后写入：
     *   HuanyuD devinfo add manufacturer=XXX
     *   HuanyuD devinfo add model=YYY
     * 没采集过的字段一律不显示（不伪造 unknown 之外的东西）。
     * ================================================================== */
    {
        char kverstr[48];
        const char *t;

        hy_devinfo_kernel_ver(kverstr, sizeof(kverstr));
        hy_f_seq_printf(seq, "\n[device]\n");
        hy_f_seq_printf(seq, "  kernel        : %s\n", kverstr);

        t = hy_devinfo_text();
        if (t && t[0]) {
            /* 逐行原样输出，前面加两个空格缩进 */
            const char *p = t;
            while (*p) {
                char line[160];
                int n = 0;
                while (*p && *p != '\n' && n < (int)sizeof(line) - 1) {
                    line[n++] = *p++;
                }
                if (*p == '\n') p++;
                line[n] = 0;
                if (n) {
                    /*
                     * v1.55.0：devinfo 行统一是 key=value，
                     * 这里拆开对齐成 "  key            : value"，
                     * 不再原样吐 "cpus           =8" 这种参差的东西。
                     * 没有 '=' 的行（用户自定义备注）保持原样输出。
                     */
                    int eq = -1, i2;
                    for (i2 = 0; i2 < n; i2++)
                        if (line[i2] == '=') { eq = i2; break; }
                    if (eq > 0 && eq <= 20) {
                        char out[176];
                        int o2 = 0, k2;
                        out[o2++] = ' '; out[o2++] = ' ';
                        for (k2 = 0; k2 < eq && o2 < 160; k2++)
                            out[o2++] = line[k2];
                        while (o2 < 16 && o2 < 160) out[o2++] = ' ';
                        if (o2 < 170) out[o2++] = ':';
                        if (o2 < 170) out[o2++] = ' ';
                        for (k2 = eq + 1; k2 < n && o2 < 172; k2++)
                            out[o2++] = line[k2];
                        out[o2] = 0;
                        hy_f_seq_printf(seq, "%s\n", out);
                    } else {
                        hy_f_seq_printf(seq, "  %s\n", line);
                    }
                }
            }
        } else {
            hy_f_seq_printf(seq, "  (no info yet -- run: HuanyuD devinfo add <k>=<v>)\n");
        }
    }

    /* ==================================================================
     * [features] 各子模块启用情况
     * ================================================================== */
        /* ==================================================================
     * [compat] 兼容性自检（v1.45.0）
     *
     * 换内核版本时一眼看出「哪些功能因符号缺失/能力不足而不可用」，
     * 不用再去 dmesg 里翻。OK = 可用，NO = 不可用（会静默降级）。
     * ================================================================== */
    {
        int sf = hy_sym_failures();

        hy_f_seq_printf(seq, "\n[compat]\n");
        hy_f_seq_printf(seq, "  page table    : %s\n",
                        hy_pt_ready() ? "OK" : "NO (addr translate off)");
        hy_f_seq_printf(seq, "  breakpoints   : %s (caps=0x%x)\n",
                        hy_bp_caps() ? "OK" : "NO", hy_bp_caps());
        hy_f_seq_printf(seq, "  prctl channel : %s\n",
                        hy_prctl_ready() ? "OK" : "NO (use supercall)");
        hy_f_seq_printf(seq, "  file hide     : %s\n",
                        hy_hide_active() ? "ACTIVE" : "OK (idle)");
        hy_f_seq_printf(seq, "  trampoline    : %s\n",
                        hy_tramp_ready() ? "OK" : "NO");
        hy_f_seq_printf(seq, "  sym failures  : %d%s\n", sf,
                        sf ? "  <- see dmesg | grep huanyu" : "");
    }

    /*
     * [guard] v1.51.0 顶级防格机
     *
     * 这里显示的是「装了几个 hook / 拦了几次」，
     * 是判断防格机是否真的在工作（而不只是声称在工作）的唯一依据。
     */
    {
        u64 total = 0, op = 0, io = 0, rb = 0, kx = 0, md = 0, kl = 0, dl = 0, ul = 0;
        char last[128];
        int left = hy_guard_unlock_left();

        hy_guard_stats(&total, &op, &io, &rb, &kx, &md, &kl, &dl, &ul,
                       last, sizeof(last));

        hy_f_seq_printf(seq, "\n[guard]\n");
        hy_f_seq_printf(seq, "  state         : %s (%d hooks)\n",
                        hy_guard_active() ? "ARMED" : "off", hy_guard_hooks());
        if (left > 0)
            hy_f_seq_printf(seq, "  unlock window : OPEN (%d s left)\n", left);
        else if (left == -2)
            hy_f_seq_printf(seq, "  unlock window : OPEN (manual, no clock)\n");
        else
            hy_f_seq_printf(seq, "  unlock window : closed\n");
        hy_f_seq_printf(seq, "  blocked total : %llu\n", (unsigned long long)total);
        hy_f_seq_printf(seq, "  blk open      : %llu   (dd/mkfs/sgdisk)\n",
                        (unsigned long long)op);
        hy_f_seq_printf(seq, "  blk ioctl     : %llu   (discard/zeroout)\n",
                        (unsigned long long)io);
        hy_f_seq_printf(seq, "  reboot        : %llu   (fastboot/ recovery)\n",
                        (unsigned long long)rb);
        hy_f_seq_printf(seq, "  kexec         : %llu\n", (unsigned long long)kx);
        hy_f_seq_printf(seq, "  module        : %llu   (init/delete)\n",
                        (unsigned long long)md);
        hy_f_seq_printf(seq, "  kill init     : %llu\n", (unsigned long long)kl);
        hy_f_seq_printf(seq, "  rm prot dir   : %llu\n", (unsigned long long)dl);
        hy_f_seq_printf(seq, "  unlocks       : %llu\n", (unsigned long long)ul);
        hy_f_seq_printf(seq, "  last blocked  : %s\n", last[0] ? last : "(none)");
    }

    /*
     * [scheme] v1.64.0：各功能面当前落在哪一档方案。
     *
     * 之前"为什么用的这套做法"完全不可见 —— 只知道结果不对，看不出
     * 是选错了算法还是算法本身算错。现在把档位摊开，出问题先看这里。
     */
    hy_f_seq_printf(seq, "\n[scheme] 内核世代=%d（每域从高往低试，失败自动降档）\n",
                    hy_scheme_gen());
    {
        int d;
        for (d = 0; d < HY_SC_COUNT; d++) {
            hy_f_seq_printf(seq, "  %-9s : gen%d %-11s 降级=%u\n",
                            hy_scheme_dom_name(d),
                            hy_scheme_gen_of(d),
                            hy_scheme_name(d),
                            (unsigned int)hy_scheme_demotions(d));
        }
    }

hy_f_seq_printf(seq, "\n[features]\n");
    hy_f_seq_printf(seq, "  procfs file   : %s\n",
                    hy_procfs_created() ? "created" : "no");
    hy_f_seq_printf(seq, "  file hide     : %s\n",
                    hy_hide_active() ? "ACTIVE" : "off");
    hy_f_seq_printf(seq, "  trampoline    : %s\n",
                    hy_tramp_ready() ? "ready" : "no");

    /*
     * [input] v1.20.0：把 hy_input_status / hy_gyro_status 真正接进来。
     * 这两个函数上一版写了却没人调用（死代码），导致触摸到底走的是
     * 真实触摸屏还是降级自建设备，完全看不出来。
     */
    {
        int real_found = 0, own_ok = 0, down = 0, probe_on = 0;
        int mx = 0, my = 0;
        int gact = 0, ghk = 0;
        u64 gpat = 0;

        hy_input_status(&real_found, &own_ok, &down, &probe_on, &mx, &my);
        hy_gyro_status(&gact, &ghk, &gpat);

        hy_f_seq_printf(seq, "\n[input]\n");
        hy_f_seq_printf(seq, "  touchscreen   : %s\n",
                        real_found ? "HIJACKED (real dev)"
                                   : (own_ok ? "own dev (single-touch)"
                                             : "NOT AVAILABLE"));
        hy_f_seq_printf(seq, "  probe hook    : %s\n", probe_on ? "on" : "off");
        hy_f_seq_printf(seq, "  screen        : %dx%d\n", mx, my);
        hy_f_seq_printf(seq, "  fingers down  : %d\n", down);
        {
            int dropped = 0, lx = 0, ly = 0;
            hy_input_grab_status(&dropped, &lx, &ly);
            hy_f_seq_printf(seq, "  slot grab     : %s\n",
                            hy_opt_grab ? "ON (需 touch=1)" : "off (grab=1 开启)");
            hy_f_seq_printf(seq, "  slot base     : %d (虚拟手指起始槽)\n", hy_input_slot_base());
            hy_f_seq_printf(seq, "  grabbed/drop  : %d\n", dropped);
            hy_f_seq_printf(seq, "  learned max   : %dx%d (自学习坐标上限)\n", lx, ly);
        }
        hy_f_seq_printf(seq, "  gyro sendto   : %s\n", ghk ? "hooked" : "NOT hooked");
        hy_f_seq_printf(seq, "  gyro active   : %s (patched=%llu)\n",
                        gact ? "ON" : "off", (unsigned long long)gpat);
        hy_f_seq_printf(seq, "  active dev    : %s\n", hy_input_active_name());
        hy_f_seq_printf(seq, "  input_event#  : %lu\n", hy_input_ie_events());
        if (!real_found)
            hy_f_seq_printf(seq, "  hint          : not hijacked yet.\n"
                                 "                  pick a name below and call\n"
                                 "                  touch_set_name(\"<name>\")\n");

        /* v1.27.0：列出登记到的输入设备 */
        {
            char dbuf[24 * 56];
            int n = hy_input_seen_dump(dbuf, (int)sizeof(dbuf));
            if (n > 0) {
                hy_f_seq_printf(seq, "  devices seen  : %d\n",
                                hy_input_seen_count());
                dbuf[(n < (int)sizeof(dbuf)) ? n : (int)sizeof(dbuf) - 1] = 0;
                hy_f_seq_printf(seq, "%s", dbuf);
            }
        }
    }

    {
        u64 idle = 0, wakeups = 0, ticks = 0;
        int saving = 0;
        hy_pm_diag(&idle, &saving, &wakeups, &ticks);
        hy_f_seq_printf(seq, "\n[power save]\n");
        hy_f_seq_printf(seq, "  state         : %s\n", saving ? "SAVING" : "active");
        hy_f_seq_printf(seq, "  idle          : %llu s (threshold %d s)\n",
                        (unsigned long long)idle, HY_IDLE_SEC);
        hy_f_seq_printf(seq, "  wakeups       : %llu\n", (unsigned long long)wakeups);
        {
            u64 sw = hy_pm_secs_since_wake();
            if (sw == (u64)-1)
                hy_f_seq_printf(seq, "  last wake     : never\n");
            else
                hy_f_seq_printf(seq, "  last wake     : %llu s ago\n",
                                (unsigned long long)sw);
        }
        hy_f_seq_printf(seq, "  saved scans   : %llu\n", (unsigned long long)ticks);
    }

    {
        const char *s = "?";
        switch ((int)HY_DEFAULT_BP_SCHEME) {
        case 1: s = "hardware (1)"; break;
        case 2: s = "PTE (2)"; break;
        case 3: s = "software (3)"; break;
        default: s = "hardware (fallback)"; break;
        }
        hy_f_seq_printf(seq, "\n[breakpoint]\n");
        hy_f_seq_printf(seq, "  default scheme: %s\n", s);
        hy_f_seq_printf(seq, "  fallback chain: hardware -> PTE -> software\n");
        /*
         * 【v1.19.0】补充运行时信息：
         *   编译期默认 / 运行时默认 / 实际可用能力 / 单步是否可用。
         * 排查"为什么没用硬件断点"时，这几行能一眼看出是
         * 用户态改过默认、还是硬件槽位耗尽、还是单步不可用。
         */
        {
            const char *rs = "?";
            u32 caps = hy_bp_caps();

            switch ((int)hy_default_mode) {
            case HY_BP_MODE_AUTO: rs = "auto(builtin chain)"; break;
            case HY_BP_MODE_HW:   rs = "hardware(1)"; break;
            case HY_BP_MODE_PTE:  rs = "PTE(2)"; break;
            case HY_BP_MODE_SW:   rs = "software(3)"; break;
            default: rs = "?"; break;
            }
            hy_f_seq_printf(seq, "  runtime default: %s\n", rs);
            hy_f_seq_printf(seq, "  caps           : 0x%x (SW=%d PTE=%d HW=%d)\n",
                            caps,
                            !!(caps & HY_BP_CAP_SW),
                            !!(caps & HY_BP_CAP_PTE),
                            !!(caps & HY_BP_CAP_HW));
            hy_f_seq_printf(seq, "  hw slots       : brps=%u wrps=%u\n",
                            hy_bp_num_brps(), hy_bp_num_wrps());
            hy_f_seq_printf(seq, "  single step    : %s\n",
                            hy_bp_step_supported() ? "yes" : "NO (SW/PTE hit once only)");
        }

    /* v1.18.0 ls 移植能力 */
    {
        struct hy_ls_status st;

        if (hy_ls_status(&st) == 0) {
            hy_f_seq_printf(seq, "\n[ls-port v1.18.0]\n");
            hy_f_seq_printf(seq, "  syscall monitor : %s (hooked=%u total=%llu)\n",
                            st.sysmon_active ? "ON" : "off", st.sysmon_hooked,
                            (unsigned long long)st.sysmon_total);
            hy_f_seq_printf(seq, "  cntvct monitor  : %s (hooked=%u hits=%llu)\n",
                            st.cntvct_active ? "ON" : "off", st.cntvct_hooked,
                            (unsigned long long)st.cntvct_total);
            hy_f_seq_printf(seq, "  gnss spoof      : %s (hooked=%u patched=%llu)\n",
                            st.gnss_active ? "ON" : "off", st.gnss_hooked,
                            (unsigned long long)st.gnss_patches);
            hy_f_seq_printf(seq, "  dpt main-thread : %s (hooked=%u)\n",
                            st.dpt_active ? "ON" : "off", st.dpt_hooked);
            hy_f_seq_printf(seq, "  kgsl hide       : %s (hooked=%u)\n",
                            st.kgsl_active ? "ON" : "off", st.kgsl_hooked);
            hy_f_seq_printf(seq, "  step breakpoint : %s\n",
                            st.stepbp_active ? "ON" : "off");
        }
    }
    }   /* 关闭断点段块 */

    shm_ok   = hy_shm_ready();
    symfail  = hy_sym_failures();

    hy_memset(&st, 0, sizeof(st));
    hy_shm_status(&st);

        /*
     * version 直接打印 HY_VERSION_STRING —— 与 KPM_VERSION() 同一个宏。
     * 之前这里写死 1.0，导致模块升到 1.16.0 而 procfs 还显示 1.0。
     */
    hy_f_seq_printf(seq, "version    : %s\n", HY_VERSION_STRING);
    hy_f_seq_printf(seq, "  (KPM_VERSION is the same source)\n");

    hy_f_seq_printf(seq, "sym miss   : %d\n", symfail);
    hy_f_seq_printf(seq, "bp caps    : 0x%x  brps=%d wrps=%d\n",
                    hy_bp_caps(), hy_bp_num_brps(), hy_bp_num_wrps());
    hy_f_seq_printf(seq, "\n");
    hy_f_seq_printf(seq, "[channels]\n");
    hy_f_seq_printf(seq, "  ctl0(supercall) : always (needs superkey)\n");
    {
        const char *m = "?";
        switch (hy_prctl_mode()) {
        case 1: m = "override(skip_origin supported)"; break;
        case 2: m = "plain(after-callback fallback)"; break;
        default: m = "not hooked"; break;
        }
        hy_f_seq_printf(seq, "  prctl           : %s [%s]\n",
                        prctl_ok ? "READY" : "down", m);
    }
    hy_f_seq_printf(seq, "  shm (zero-copy) : %s\n", shm_ok ? "READY" : "down");
    hy_f_seq_printf(seq, "    shm pages     : %u\n", st.nr_pages);
    hy_f_seq_printf(seq, "    shm requests  : %llu\n",
                    (unsigned long long)st.requests);
    hy_f_seq_printf(seq, "    shm errors    : %llu\n",
                    (unsigned long long)st.errors);

    if (!prctl_ok && !shm_ok) {
        hy_f_seq_printf(seq, "\n");
        hy_f_seq_printf(seq, "[hint]\n");
        hy_f_seq_printf(seq, "  两条免鉴权通道都没起来。可能原因：\n");
        hy_f_seq_printf(seq, "   1) prctl: hook 未生效（看 dmesg prctl 行）\n");
        hy_f_seq_printf(seq, "   2) shm  : 需要用户态主动调 shm_init()\n");
        hy_f_seq_printf(seq, "  此时只能用 supercall，而它要求 superkey。\n");
    }
    return 0;
}

/*
 * /proc/HuanyuD —— 调试接口说明页（只读）
 *
 * 用户需要"可写"的调试入口，但 proc_create_single_data 只能给只读文件，
 * 而 proc_create + struct proc_ops 的布局随内核版本变化，KPM 下不能碰。
 *
 * 因此这里做成只读的"命令清单 + 当前状态"页：
 *   cat /proc/HuanyuD   等价于 HuanyuD help
 * 真正的命令执行走用户态程序 HuanyuD（经 prctl 通道下发），
 * 既满足终端操作习惯，又不引入任何结构体布局风险。
 */
static int hy_proc_show_dbg(void *seq, void *v)
{
    (void)v;
    if (!hy_ready) return 0;
    if (!hy_f_seq_printf) return 0;

    hy_f_seq_printf(seq,
        "\x48\x75\x61\x6e\x79\x75\x20"
        "\xe5\x86\x85\xe6\xa0\xb8\xe8\xb0\x83\xe8\xaf\x95"
        "\xe6\x8e\xa5\xe5\x8f\xa3\n");

    hy_f_seq_printf(seq, "\n[status]\n");
    hy_f_seq_printf(seq, "  touch         : %d\n", hy_opt_touch ? 1 : 0);
    hy_f_seq_printf(seq, "  grab          : %d\n", hy_opt_grab ? 1 : 0);

    hy_f_seq_printf(seq, "\n[commands] 用法: HuanyuD <command> [args]\n");
    hy_f_seq_printf(seq, "  help                 显示本帮助\n");
    hy_f_seq_printf(seq, "  version              版本信息\n");
    hy_f_seq_printf(seq, "  touch on|off         触摸自动识别开关\n");
    hy_f_seq_printf(seq, "  grab on|off|stat     触摸槽位抢夺开关/统计\n");
    hy_f_seq_printf(seq, "  slotbase <n>         虚拟手指起始槽位(0..9)\n");
    hy_f_seq_printf(seq, "  bpstat               断点能力与当前占用\n");
    hy_f_seq_printf(seq, "  devinfo reset|add <k=v>|show   设备信息\n");

    hy_f_seq_printf(seq, "\n[note]\n");
    hy_f_seq_printf(seq, "  本文件只读（可写实现不可用），命令需走 prctl 通道。\n");
    return 0;
}

int hy_procfs_init(void)
{
    if (g_hy_entry) return 0;   /* 已创建，避免重复 */

    /*
     * 符号解析。名字必须在所有候选里签名严格一致：
     * 这里只有一个候选，不做任何"看起来像"的回退
     * （历史教训：把 kmalloc_trace 当 kzalloc 用会直接 panic）。
     */
    hy_f_proc_create_single_data =
        (hy_proc_create_single_data_t)hy_lookup_generic("proc_create_single_data");
    hy_f_proc_remove =
        (hy_proc_remove_t)hy_lookup_generic("proc_remove");
    hy_f_seq_printf =
        (hy_seq_printf_t)hy_lookup_generic("seq_printf");

    if (!hy_f_proc_create_single_data) {
        HY_LOG("procfs: proc_create_single_data NOT FOUND\n");
        return -ENOENT;
    }
    if (!hy_f_proc_remove) {
        HY_LOG("procfs: proc_remove NOT FOUND (refuse: would leak entry)\n");
        return -ENOENT;
    }
    /*
     * 【v1.39.0】seq_printf 拿不到就【拒绝创建】文件。
     *
     * hy_proc_show() 里有几十处 hy_f_seq_printf(seq, ...) 调用。
     * 之前这里只打 WARN 然后照样创建文件 —— 一旦 seq_printf 解析
     * 失败，用户 cat /proc/huanyu 时 show 会调用 NULL 函数指针，
     * 直接 oops。这是"看着加载成功、一读文件就炸"的典型来源。
     *
     * 拒绝创建的代价只是没有诊断文件，任何功能都不受影响。
     */
    if (!hy_f_seq_printf) {
        HY_LOG("procfs: seq_printf NOT FOUND -> refuse to create "
               "(would oops on read)\n");
        return -ENOENT;
    }

    /*
     * 真正创建。parent = NULL -> /proc 根目录。
     */
    g_hy_entry = hy_f_proc_create_single_data("Huanyu", HY_PROC_MODE,
                                              NULL, hy_proc_show, NULL);
    if (!g_hy_entry) {
        HY_LOG("procfs: proc_create_single_data returned NULL\n");
        return -ENOMEM;
    }
    HY_LOG("procfs: /proc/Huanyu created (entry=%px mode=0%o)\n",
           (void *)g_hy_entry, HY_PROC_MODE);

    /*
     * 【v1.53.0】调试接口页优先走可写实现（hy_dbgfs.c 手工构造 proc_ops）。
     * 拿不到可写就回退到只读说明页 —— 调试口少一个不要紧，
     * 绝不能因为填错 proc_ops 槽位把内核写崩。
     */
    g_hy_dbg_entry = (struct hy_proc_dir_entry *)hy_dbgfs_create();
    if (g_hy_dbg_entry) {
        g_dbg_writable = 1;
        HY_LOG("procfs: /proc/HuanyuD created WRITABLE (entry=%px)\n",
               (void *)g_hy_dbg_entry);
        return 0;
    }

    HY_LOG("procfs: /proc/HuanyuD writable unavailable -> read-only fallback\n");
    g_hy_dbg_entry = hy_f_proc_create_single_data("HuanyuD", HY_PROC_MODE,
                                                  NULL, hy_proc_show_dbg, NULL);
    if (g_hy_dbg_entry)
        HY_LOG("procfs: /proc/HuanyuD created read-only (entry=%px)\n",
               (void *)g_hy_dbg_entry);
    else
        HY_LOG("procfs: /proc/HuanyuD create failed (non-fatal)\n");
    return 0;
}

void hy_procfs_exit(void)
{
    if (!g_hy_entry) return;

    if (hy_f_proc_remove || g_dbg_writable) {
        if (g_hy_dbg_entry) {
            if (g_dbg_writable)
                hy_dbgfs_remove((void *)g_hy_dbg_entry);
            else
                hy_f_proc_remove(g_hy_dbg_entry);
            g_hy_dbg_entry = NULL;
            HY_LOG("procfs: /proc/HuanyuD removed\n");
        }
        hy_f_proc_remove(g_hy_entry);
        HY_LOG("procfs: /proc/Huanyu removed\n");
    } else {
        /* 拿不到 proc_remove 时绝不创建过，这里理论上到不了 */
        HY_LOG("procfs: WARN cannot remove, proc_remove missing\n");
    }

    g_hy_entry = NULL;
    hy_f_proc_create_single_data = NULL;
    hy_f_proc_remove = NULL;
    hy_f_seq_printf = NULL;
}

/* 供 CTL0 文本命令 status/proc 查询 */
bool hy_procfs_created(void) { return g_hy_entry != NULL; }
