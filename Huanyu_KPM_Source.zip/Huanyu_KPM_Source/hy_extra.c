/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_extra.c —— 扩展能力
 *
 *   35 ENUM_MODULES    枚举目标进程的内存区域（VMA 级别）
 *   36 ENUM_PROCESSES  枚举系统所有进程
 *   37 ENUM_THREADS    枚举指定进程的线程
 *   38 KERNEL_RW       读写内核虚拟地址
 *   39 PHYS_RW         读写物理地址
 *   40 PROTECT         修改目标进程某段内存的 r/w/x 权限
 *   41 CACHE_FLUSH     刷新指定范围的 dcache / icache
 *   42 BP_LIST         列出已安装的断点
 *   43 BP_CLEAR_HITS   清空命中记录
 *   44 HWCAP           查询 CPU 特性
 *   45 STATS           运行时统计
 *   46 VERSION         版本与能力位
 *
 * 【安全约束】
 *   - 内核地址读写只在"地址落在内核线性映射区"时才做，越界直接拒绝
 *   - 权限修改只改用户态可执行位与只读位，不动其它属性位
 *   - 所有对用户态缓冲的写入一律走 copy_to_user
 */
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <asm/current.h>
#include "hy.h"

extern void *(*hy_f_find_get_task_by_vpid)(int pid);
extern void *(*hy_f_get_task_mm)(void *task);
extern void (*hy_f_mmput)(void *mm);
extern void (*hy_f_put_task_struct)(void *task);
extern void *(*hy_f_find_vma)(void *mm, unsigned long addr);
extern long (*hy_f_copy_to_user)(void __user *dst, const void *src, unsigned long n);
extern long (*hy_f_copy_from_user)(void *dst, const void __user *src, unsigned long n);
extern unsigned long hy_lookup_generic(const char *name);

extern void hy_cache_invalidate(void);
extern u64 hy_cache_hits_cnt(void);
extern u64 hy_cache_miss_cnt(void);
extern int hy_sym_failures(void);
extern u64 hy_bp_hit_total(void);
extern u32 hy_bp_active_count(void);

static void *g_init_task;

int hy_extra_init(void)
{
    g_init_task = (void *)hy_lookup_generic("init_task");
    return 0;
}

/* ============================ 36 ENUM_PROCESSES ============================ */

int hy_enum_processes(struct hy_enum_procs_req *req)
{
    struct hy_proc_info info;
    void *task;
    u32 n = 0;
    u32 max;

    if (!req || !req->buf_ptr || req->max_count == 0) return -EINVAL;
    if (!g_init_task || hy_tasks_offset() < 0) return -ENOTSUPP;
    if (!hy_f_copy_to_user) return -ENODEV;

    max = req->max_count > 512 ? 512 : req->max_count;
    task = g_init_task;

    /*
     * 【修复 v1.17.0】遍历进程链表没有上限。
     * 若遍历期间有进程退出，链表被并发修改可能形成环或断链，
     * 这里就会变成死循环（内核卡死，看门狗重启）。
     * 加 guard 上限，最多扫 65536 个就收手。
     */
    {
        int guard = 0;
    do {
        char *comm;
        s32 *pidp;

        comm = (char *)((unsigned long)task + hy_comm_offset());
        pidp = (s32 *)((unsigned long)task + hy_pid_offset());

        hy_memset(&info, 0, sizeof(info));
        info.pid = *pidp;
        hy_strscpy(info.comm, comm, sizeof(info.comm));

        if (hy_f_copy_to_user((void __user *)(unsigned long)(req->buf_ptr + n * sizeof(info)),
                              &info, sizeof(info)) != 0)
            break;
        n++;
        if (n >= max) break;

        {
            struct list_head *tasks =
                (struct list_head *)((unsigned long)task + hy_tasks_offset());
            task = (void *)((unsigned long)tasks->next - hy_tasks_offset());
        }
    } while (task && task != g_init_task && ++guard < 65536);
    }

    return (int)n;
}

/* ============================ 37 ENUM_THREADS ============================ */
/*
 * 线程与主进程共享 comm，据此从全进程表里筛出同名的 task。
 * 不依赖 tgid 偏移（KP 未提供，硬编码风险高）。
 */
int hy_enum_threads(struct hy_enum_threads_req *req)
{
    struct hy_proc_info info;
    void *task;
    char target_comm[16];
    bool found_target = false;
    u32 n = 0;
    u32 max;

    if (!req || req->pid <= 0 || !req->buf_ptr || req->max_count == 0) return -EINVAL;
    if (!g_init_task || hy_tasks_offset() < 0) return -ENOTSUPP;
    if (!hy_f_copy_to_user) return -ENODEV;

    max = req->max_count > 512 ? 512 : req->max_count;

    /* 先取主线程的 comm */
    {
        void *t = g_init_task;
        int guard = 0;
        do {
            s32 *pidp = (s32 *)((unsigned long)t + hy_pid_offset());
            if (*pidp == req->pid) {
                hy_strscpy(target_comm, (char *)((unsigned long)t + hy_comm_offset()),
                        sizeof(target_comm));
                found_target = true;
                break;
            }
            {
                struct list_head *tasks =
                    (struct list_head *)((unsigned long)t + hy_tasks_offset());
                t = (void *)((unsigned long)tasks->next - hy_tasks_offset());
            }
        } while (t && t != g_init_task && ++guard < 65536);
    }
    if (!found_target) return -ESRCH;

    task = g_init_task;
    {
        int guard = 0;
    do {
        char *comm = (char *)((unsigned long)task + hy_comm_offset());
        s32 *pidp = (s32 *)((unsigned long)task + hy_pid_offset());

        if (hy_strcmp(comm, target_comm) == 0) {
            hy_memset(&info, 0, sizeof(info));
            info.pid = *pidp;
            hy_strscpy(info.comm, comm, sizeof(info.comm));
            if (hy_f_copy_to_user(
                    (void __user *)(unsigned long)(req->buf_ptr + n * sizeof(info)),
                    &info, sizeof(info)) != 0)
                break;
            n++;
            if (n >= max) break;
        }
        {
            struct list_head *tasks =
                (struct list_head *)((unsigned long)task + hy_tasks_offset());
            task = (void *)((unsigned long)tasks->next - hy_tasks_offset());
        }
    } while (task && task != g_init_task && ++guard < 65536);
    }

    return (int)n;
}

/* ============================ 35 ENUM_MODULES ============================ */

int hy_enum_modules(struct hy_enum_mods_req *req)
{
    struct hy_mod_info mi;
    void *task, *mm = NULL;
    unsigned long probe = 0x1000;
    u32 n = 0;
    u32 max;
    int iter;

    if (!req || req->pid <= 0 || !req->buf_ptr || req->max_count == 0) return -EINVAL;
    if (!hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;
    if (!hy_f_copy_to_user || !hy_f_find_vma) return -ENODEV;

    max = req->max_count > 512 ? 512 : req->max_count;

    task = hy_f_find_get_task_by_vpid(req->pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    for (iter = 0; iter < 4096 && n < max; iter++) {
        void *vma = hy_f_find_vma(mm, probe);
        unsigned long vs, ve;
        u64 *ptep;
        int lvl = 0;

        if (!vma) break;
        vs = *(unsigned long *)((unsigned long)vma + 0);
        ve = *(unsigned long *)((unsigned long)vma + 8);
        if (ve <= vs) break;

        hy_memset(&mi, 0, sizeof(mi));
        mi.start = vs;
        mi.end = ve;

        ptep = hy_find_user_pte(mm, vs, &lvl);
        if (ptep) {
            u64 pte = *ptep;
            mi.exec  = ((pte & (1UL << 54)) == 0) ? 1 : 0;   /* UXN */
            mi.write = ((pte & (1UL << 7)) == 0) ? 1 : 0;    /* AP[2] */
        }

        if (hy_f_copy_to_user(
                (void __user *)(unsigned long)(req->buf_ptr + n * sizeof(mi)),
                &mi, sizeof(mi)) != 0)
            break;
        n++;

        probe = ve;
        if (probe == 0) break;
    }

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);
    return (int)n;
}

/* ============================ 38 KERNEL_RW ============================ */

int hy_kernel_rw(struct hy_kern_rw_req *req)
{
    unsigned long addr;
    u64 size;

    if (!req || !req->buf_ptr || req->size == 0) return -EINVAL;
    if (!hy_f_copy_to_user || !hy_f_copy_from_user) return -ENODEV;

    addr = (unsigned long)req->addr;
    size = req->size;

    /*
     * 严格边界校验：必须落在内核线性映射区（PAGE_OFFSET 及以上）。
     * 越界一律拒绝 —— 宁可功能受限，也不能让内核地址被随意改写。
     */
    if (addr < hy_page_offset_base()) return -EFAULT;
    if (size > 4096) return -EINVAL;
    if (addr + size < addr) return -EFAULT;

    /*
     * 【v1.60.0】mode=1 时读内核虚拟地址走 KMA。
     *
     * 走法：先把内核 VA 换算成物理地址，再让 KMA 按物理页读。
     * 这样读出来的内容与直接解引用一致，但绕开了"线性映射是否有效"
     * 这个前提 —— 页表被动过、或映射属性异常时这条路径仍然成立。
     *
     * 写一律不走 KMA：写入内存没有这个需求，且改页表去写风险更高。
     *
     * 任何一步失败都落到下面的内核级路径，绝不静默返回错误。
     */
    if (!req->is_write && hy_kma_mode() == 1) {
        unsigned long phys = hy_virt_to_phys(addr);
        if (phys) {
            u8 tmp[4096];
            if (hy_kma_read_phys(phys, tmp, size) == 0) {
                if (hy_f_copy_to_user((void __user *)(unsigned long)req->buf_ptr,
                                      tmp, size) == 0)
                    return (int)size;
            }
            hy_kma_note_fallback();
        } else {
            hy_kma_note_fallback();
        }
    }

    if (req->is_write) {
        u8 tmp[4096];
        if (hy_f_copy_from_user(tmp, (void __user *)(unsigned long)req->buf_ptr, size) != 0)
            return -EFAULT;
        hy_memcpy((void *)addr, tmp, size);
    } else {
        if (hy_f_copy_to_user((void __user *)(unsigned long)req->buf_ptr,
                              (const void *)addr, size) != 0)
            return -EFAULT;
    }
    return (int)size;
}

/* ============================ 39 PHYS_RW ============================ */

int hy_phys_rw(struct hy_kern_rw_req *req)
{
    unsigned long phys, kva;

    if (!req || !req->buf_ptr || req->size == 0) return -EINVAL;
    if (req->size > 4096) return -EINVAL;

    phys = (unsigned long)req->addr;
    kva = (unsigned long)hy_phys_to_virt(phys);

    /*
     * kva 为 0 不再提前返回。
     * 目标物理页没有被线性映射覆盖时 phys_to_virt 就是拿不到地址，
     * 而这恰好是 KMA 能救的场景 —— 先让 KMA 试，它失败再回落到 -EFAULT。
     */
    if (!kva && hy_kma_mode() != 1) return -EFAULT;

    /*
     * 【修复 v1.21.0】原来是：
     *     if (hy_f_copy_from_user && hy_f_copy_from_user(...) != 0)
     *         return -EFAULT;
     *
     * 当 copy 符号【缺失】时（6.12 上 copy_from_user 是宏，kallsyms 里
     * 查不到，dmesg 可见 "sym: MISS copy_from_user"），短路求值让整个
     * 判断为假 —— 于是【不返回错误】，继续往下用【未初始化的 tmp】
     * 做 memcpy 写入物理地址。等价于往随机物理内存写 4KB 栈垃圾。
     *
     * 读路径同样：copy 失败不报错，返回 size 假装成功，调用方拿到的是
     * 没被填充的缓冲。
     *
     * 现在：copy 缺失时明确失败（-ENODEV），宁可功能不可用也不静默破坏。
     */
    if (!hy_f_copy_from_user || !hy_f_copy_to_user) {
        HY_LOG("extra: phys_rw needs copy_*_user, unavailable\n");
        return -ENODEV;
    }

    /*
     * 【v1.60.0】mode=1 时按物理地址走 KMA。
     *
     * 这正是 KMA 最有价值的场景：phys_to_virt 只对线性映射覆盖到的
     * 物理内存有效，高端内存 / 设备内存 / 未被线性映射的页会拿到野指针。
     * KMA 改的是我们自己的窗口页 PTE，不依赖目标页有没有线性映射。
     *
     * 写依然不走 KMA。失败一律回落到下面的线性映射路径。
     */
    if (!req->is_write && hy_kma_mode() == 1) {
        u8 tmp[4096];
        if (hy_kma_read_phys(phys, tmp, req->size) == 0) {
            if (hy_f_copy_to_user((void __user *)(unsigned long)req->buf_ptr,
                                  tmp, req->size) == 0)
                return (int)req->size;
        }
        hy_kma_note_fallback();
    }

    if (req->is_write) {
        u8 tmp[4096];
        if (hy_f_copy_from_user(
                tmp, (void __user *)(unsigned long)req->buf_ptr, req->size) != 0)
            return -EFAULT;
        hy_memcpy((void *)kva, tmp, req->size);
    } else {
        if (hy_f_copy_to_user(
                (void __user *)(unsigned long)req->buf_ptr,
                (const void *)kva, req->size) != 0)
            return -EFAULT;
    }
    return (int)req->size;
}

/* ============================ 40 PROTECT ============================ */

int hy_protect(struct hy_protect_req *req)
{
    void *task, *mm = NULL;
    unsigned long addr, end;
    int n = 0;

    if (!req || req->pid <= 0 || req->size == 0) return -EINVAL;
    if (!hy_f_find_get_task_by_vpid || !hy_f_get_task_mm) return -ENODEV;

    task = hy_f_find_get_task_by_vpid(req->pid);
    if (!task) return -ESRCH;
    mm = hy_f_get_task_mm(task);
    if (!mm) {
        if (hy_f_put_task_struct) hy_f_put_task_struct(task);
        return -EINVAL;
    }

    addr = req->addr & HY_PAGE_MASK;
    end  = (req->addr + req->size + HY_PAGE_SIZE - 1) & HY_PAGE_MASK;

    while (addr < end && n < 4096) {
        u64 *ptep = hy_find_user_pte(mm, addr, &(int){0});
        if (ptep) {
            /*
             * 【修复 v1.21.0】原来这里手写字面量位操作（1<<54 / 1<<7）。
             * hy_pgtable.c 里本来就有 hy_pte_set_exec / hy_pte_clear_exec /
             * hy_pte_set_readonly / hy_pte_clear_readonly 四个封装，
             * 但它们全文零调用点 —— 于是各处各自手写，位定义散落。
             *
             * 说明：hy_pte_set_exec() 同时清 UXN 和 PXN，比原来只清 UXN
             * 更完整（PXN 不清的话 EL0 仍不可执行，改权限会静默无效）。
             */
            u64 pte = *ptep;
            if (req->prot & 4) pte = hy_pte_set_exec(pte);
            else               pte = hy_pte_clear_exec(pte);
            if (req->prot & 2) pte = hy_pte_set_readonly(pte);
            else               pte = hy_pte_clear_readonly(pte);
            hy_set_user_pte(mm, addr, ptep, pte);
            n++;
        }
        addr += HY_PAGE_SIZE;
    }

    hy_flush_tlb_range(mm, req->addr & HY_PAGE_MASK, end);
    hy_cache_invalidate();

    if (hy_f_mmput) hy_f_mmput(mm);
    if (hy_f_put_task_struct) hy_f_put_task_struct(task);
    return n;
}

/* ============================ 41 CACHE_FLUSH ============================ */

/*
 * 刷新指定范围的 dcache（cisw 会刷整组，这里按 cacheline 逐个 civac）
 * 再刷 icache。用于修改代码后让改动对指令流生效。
 */
int hy_cache_flush(struct hy_flush_req *req)
{
    unsigned long addr, end;

    if (!req || req->size == 0) return -EINVAL;
    if (req->size > (1UL << 24)) return -EINVAL;   /* 16MB 上限 */

    addr = req->addr & ~(64UL - 1);
    end  = req->addr + req->size;

    for (; addr < end; addr += 64) {
        asm volatile("dc civac, %0" :: "r"(addr) : "memory");
    }
    asm volatile("dsb sy" ::: "memory");

    addr = req->addr & ~(64UL - 1);
    for (; addr < end; addr += 64) {
        asm volatile("ic ivau, %0" :: "r"(addr) : "memory");
    }
    asm volatile("dsb sy" ::: "memory");
    asm volatile("isb" ::: "memory");

    return 0;
}

/* ============================ 44 HWCAP ============================ */

int hy_hwcap(struct hy_hwcap *cap)
{
    u64 isar1, isar2, pfr0;

    if (!cap) return -EINVAL;
    hy_memset(cap, 0, sizeof(*cap));

    asm volatile("mrs %0, ID_AA64ISAR1_EL1" : "=r"(isar1));
    asm volatile("mrs %0, ID_AA64ISAR2_EL1" : "=r"(isar2));
    asm volatile("mrs %0, ID_AA64PFR0_EL1"  : "=r"(pfr0));

    cap->pac = (((isar1 >> 4) & 0xf) != 0) ? 1 : 0;
    cap->bti = (((pfr0 >> 32) & 0xf) >= 1) ? 1 : 0;
    cap->lse = (((isar1 >> 20) & 0xf) >= 2) ? 1 : 0;
    cap->mte = (((isar1 >> 8) & 0xf) >= 1) ? 1 : 0;
    cap->fp  = (((pfr0 >> 16) & 0xf) != 0xf) ? 1 : 0;
    cap->brps = hy_bp_num_brps();
    cap->wrps = hy_bp_num_wrps();
    return (int)sizeof(*cap);
}

/* ============================ 45 STATS ============================ */

int hy_stats(struct hy_stats *st)
{
    if (!st) return -EINVAL;
    hy_memset(st, 0, sizeof(*st));
    st->cache_hits   = hy_cache_hits_cnt();
    st->cache_miss   = hy_cache_miss_cnt();
    st->bp_active    = hy_bp_active_count();
    st->hit_total    = hy_bp_hit_total();
    st->sym_failures = (u64)(hy_sym_failures() < 0 ? 0 : hy_sym_failures());
    return (int)sizeof(*st);
}
