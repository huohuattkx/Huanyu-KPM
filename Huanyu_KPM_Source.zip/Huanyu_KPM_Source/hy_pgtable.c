/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * hy_pgtable.c —— 完全自实现的 ARM64 页表遍历
 *
 * 【为什么要自己实现】
 *   KernelPatch 只给了 mm_struct_offset.pgd_offset 一项，其余全靠自己：
 *     - 页表级数（3 级 39-bit / 4 级 48-bit / 5 级 52-bit）
 *     - 每级的索引位移
 *     - 块映射（1G/2M）与页映射的区分
 *     - contiguous bit、D-bit（脏）、AF（访问标志）
 *     - PTE 各权限位的语义
 *   这些在 5.10 ~ 6.18 之间变过（尤其 5.4 引入 52-bit VA、
 *   6.x 对 cont bit 与 AF 的处理），靠 KP 一项偏移远远不够。
 *
 *   本文件全部自己算，只在"拿 pgd 指针"这一步接受 KP 的偏移作为**参考**，
 *   并且自带校验（见 hy_discover.c）。
 *
 * 【安全边界】
 *   - 每级解引用前都校验地址落在内核线性映射区
 *   - 绝不写不确定的 PTE（写之前先做 roundtrip 自测，见 hy_pt.c）
 */
#include <linux/printk.h>
#include <linux/string.h>
#include <linux/mm_types.h>
#include "hy.h"
#include "hy_insn.h"

/* ============================ 页表参数 ============================ */

#define HY_PTRS_PER 512

/* 由 hy_pt.c 探测并写入 */
static int  g_levels = 4;          /* 3 / 4 / 5 */
static u64  g_va_bits = 48;
static unsigned long g_page_offset;

/* 每级位移表：[0]=PGD, [1]=PUD, [2]=PMD, [3]=PTE */
static int g_shift[5];

/* PTE 位定义（ARM64 4K 粒度，5.10~6.18 稳定） */
#define HY_PTE_VALID      (1UL << 0)
#define HY_PTE_TYPE_MASK  (3UL << 0)
#define HY_PTE_TYPE_BLOCK (1UL << 0)
#define HY_PTE_TYPE_TABLE (3UL << 0)
#define HY_PTE_TYPE_PAGE  (3UL << 0)
#define HY_PTE_AF         (1UL << 10)
#define HY_PTE_NG         (1UL << 11)
#define HY_PTE_DBM        (1UL << 51)
#define HY_PTE_CONT       (1UL << 52)
#define HY_PTE_PXN        (1UL << 53)
#define HY_PTE_UXN        (1UL << 54)
#define HY_PTE_ADDR_MASK  0x0000FFFFFFFFF000UL

void hy_pgtable_set_params(int levels, u64 va_bits, unsigned long page_offset)
{
    g_levels = levels;
    g_va_bits = va_bits;
    g_page_offset = page_offset;

    /*
     * 计算每级位移。
     * 总 VA 位数 = 各级索引位数之和 + 12（页内偏移）
     * 4 级：9(pgd) + 9(pud) + 9(pmd) + 9(pte) + 12 = 48
     * 3 级：9(pgd) + 9(pmd) + 9(pte) + 12 = 39
     */
    switch (levels) {
    case 5:
        g_shift[0] = 48; g_shift[1] = 39;
        g_shift[2] = 30; g_shift[3] = 21; g_shift[4] = 12;
        break;
    case 4:
        g_shift[0] = 39; g_shift[1] = 30;
        g_shift[2] = 21; g_shift[3] = 12; g_shift[4] = -1;
        break;
    case 3:
    default:
        g_shift[0] = 30; g_shift[1] = 21;
        g_shift[2] = 12; g_shift[3] = -1; g_shift[4] = -1;
        break;
    }

    HY_LOG("pgtable: levels=%d va_bits=%llu shifts=%d/%d/%d/%d\n",
           g_levels, g_va_bits, g_shift[0], g_shift[1], g_shift[2], g_shift[3]);
}

static inline bool hy_phys_ok(unsigned long p)
{
    /* 物理地址必须合理：非 0 且高位不全 1 */
    if (p == 0) return false;
    if ((p & 0xFFFF000000000000UL) == 0xFFFF000000000000UL) return false;
    return true;
}

/*
 * 【v1.64.3 加载即炸的真正根因】解引用前的最后一道闸。
 *
 * 本文件开头一直写着"每级解引用前都校验地址落在内核线性映射区"，
 * 但循环里从来没这一行 —— 注释和实现对不上，出事只是时间问题。
 *
 * v1.64.0 第一次把"走内核页表"放进了 init 路径（pt_lookup_phys 做
 * 交叉校验）。而走页表的前提 hy_physvirt_off 恰恰是这一步要算的东西：
 * 偏移还没定或算错时，hy_phys_to_virt(pgd_phys) 出来的是个垃圾地址，
 * TTBR1 物理基址常是 0x80000000 一类，加错偏移后落在用户区/未映射区，
 * 一读就是 oops —— 表现就是"加载即秒炸"。
 *
 * 下界怎么取：三种 VA 配置下内核空间的最低起点是 52-bit 的
 * 0xfff0000000000000，取它当统一判据，48/39-bit 同样成立，
 * 且能挡掉绝大多数"物理地址 + 错误偏移"落进用户区的情形。
 *
 * 注意这只是兜底网：它挡不住"偏移错得刚好也落在内核区间"的情况。
 * 真正让 init 不炸的是 pt_validate() 改用纯算术的 swapper 交叉校验
 * （见 hy_pt.c），根本不再依赖走页表。两道防线缺一不可。
 */
static inline bool hy_tbl_va_ok(unsigned long va)
{
    return va >= 0xfff0000000000000UL;
}

/* ============================ 遍历 ============================ */

/*
 * 走页表，返回最后一级表项的地址（内核 VA）。
 * out_level: 0=页(4K) 1=块(2M PMD) 2=块(1G PUD)，-1 表示未命中
 * 同时回填每级的表项值，便于调试与后续改写。
 *
 * 【v1.66.0 签名变更：第一参数从"pgd 物理地址"改为"pgd 虚拟地址"】
 *
 * 这是"加载即秒炸"的真正根因所在，必须把道理说清楚。
 *
 * arm64 上有**两个**完全不同的 VA<->PA 偏移：
 *
 *   kimage_voffset   = 内核镜像(含 swapper_pg_dir)的 VA - PA
 *   linear_voffset   = PAGE_OFFSET - memstart_addr，即线性映射偏移
 *
 * 两者不相等是常态 —— KernelPatch 自己就专门留了判据：
 *     kernel/patch/include/pgtable.h:  has_vmalloc_area()
 *         return kimage_voffset != linear_voffset;
 *     kernel/patch/base/map.c:258:     pgd_va = pgd_pa + data->kimage_voffset;
 *         注释还写着 "the top-level table must live inside the kernel
 *         image (.bss)"
 *
 * 而 swapper_pg_dir 恰恰**住在内核镜像里**，不在线性映射区。
 * 旧实现用 hy_virt_to_phys(swapper_pg_dir_va) 去换它的物理地址，
 * 用的却是线性映射偏移 —— 换出来的是一个凭空捏造的物理地址。
 * 再交给本函数，第一次解引用就是读垃圾地址：直接 oops，
 * 表现就是"加载秒炸"。v1.60 起新增的 hy_kma.c 正是第一个这么用的
 * 调用方，所以它一进来就炸。
 *
 * 改成传 VA 之后，这个换算根本不存在了：
 *   - 内核页表：调用方直接传 swapper_pg_dir 的 VA（kallsyms 给的）
 *   - 用户页表：调用方直接传 mm->pgd（内核里本来存的就是 VA）
 * 两条路径都不再做任何 VA<->PA 换算，偏移算错也不会走到这条路上来。
 *
 * 更深一层的表怎么办？那些页是普通 RAM（内核页表由 memblock/页分配器
 * 分出，用户页表由 pgd_alloc/pte_alloc_one 分出），落在线性映射区，
 * 所以循环内部继续用 hy_phys_to_virt（线性偏移）是正确的。
 * 需要特殊对待的只有**顶层表**这一个，而它现在由调用方直接给 VA。
 */
u64 *hy_walk_pgtable(unsigned long pgd_va, unsigned long addr,
                     int *out_level, u64 *path, int *path_len)
{
    unsigned long cur_phys = 0;
    int lvl;
    int depth = 0;
    u64 *tbl;
    u64 ent;
    unsigned long idx;

    if (out_level) *out_level = -1;
    if (path_len) *path_len = 0;
    if (!hy_tbl_va_ok(pgd_va)) return NULL;

    /*
     * 遍历深度 = levels - 1（最后一级是 PTE 表）
     * 4 级：pgd -> pud -> pmd -> pte  共 4 层表，最后 pte 表项即页
     */
    for (lvl = 0; lvl < g_levels; lvl++) {
        unsigned long tbl_ul;

        if (lvl == 0) {
            /* 顶层表：调用方直接给 VA，不做任何换算 */
            tbl_ul = pgd_va;
        } else {
            tbl_ul = (unsigned long)hy_phys_to_virt(cur_phys);
        }
        if (!hy_tbl_va_ok(tbl_ul)) return NULL;

        tbl = (u64 *)tbl_ul;
        if (g_shift[lvl] < 0) return NULL;
        idx = (addr >> g_shift[lvl]) & (HY_PTRS_PER - 1);

        ent = tbl[idx];
        if (path) path[depth] = ent;
        depth++;
        if (path_len) *path_len = depth;

        /* 无效表项 */
        if (!(ent & HY_PTE_VALID)) return NULL;

        /* 是表还是块？ */
        if ((ent & HY_PTE_TYPE_MASK) == HY_PTE_TYPE_TABLE && lvl < g_levels - 1) {
            /* 指向下一级表 */
            unsigned long nxt = ent & HY_PTE_ADDR_MASK;
            if (!hy_phys_ok(nxt)) return NULL;
            cur_phys = nxt;
            continue;
        }

        /* 块映射（在 pud 层是 1G，pmd 层是 2M）或最后的页 */
        if (lvl == g_levels - 1) {
            /* 最后一级：4K 页 */
            if (out_level) *out_level = 0;
        } else {
            /* 中间层提前终止 = 块映射 */
            if (out_level) {
                if (lvl == g_levels - 2) *out_level = 1;      /* 2M */
                else *out_level = 2;                           /* 1G */
            }
        }
        return &tbl[idx];
    }

    return NULL;
}

/* ============================ 权限判定 ============================ */

bool hy_pte_user_readable(u64 pte)
{
    return (pte & HY_PTE_VALID) && ((pte & (1UL << 6)) != 0);   /* AP[1] */
}

bool hy_pte_user_writable(u64 pte)
{
    /* AP = 0b01 (bit6=1, bit7=0) 表示 EL0 可写 */
    return (pte & HY_PTE_VALID) &&
           ((pte & (1UL << 6)) != 0) &&
           ((pte & (1UL << 7)) == 0);
}

bool hy_pte_user_exec(u64 pte)
{
    /* UXN(54)=0 且 PXN(53)=0 时 EL0 可执行 */
    return (pte & HY_PTE_VALID) &&
           ((pte & HY_PTE_UXN) == 0) &&
           ((pte & HY_PTE_PXN) == 0);
}

bool hy_pte_priv_exec(u64 pte)
{
    return (pte & HY_PTE_VALID) && ((pte & HY_PTE_PXN) == 0);
}

/* ============================ 权限改写 ============================ */

/* 去掉 EL0 执行权限（PTE 影子页断点用） */
u64 hy_pte_clear_exec(u64 pte)
{
    return pte | HY_PTE_UXN;
}

/* 加上 EL0 执行权限（切到影子页时用） */
u64 hy_pte_set_exec(u64 pte)
{
    return pte & ~HY_PTE_UXN & ~HY_PTE_PXN;
}

/* 改为只读（写观察点用） */
u64 hy_pte_set_readonly(u64 pte)
{
    return pte | (1UL << 7);
}

/* 清除只读（恢复） */
u64 hy_pte_clear_readonly(u64 pte)
{
    return pte & ~(1UL << 7);
}

/* 替换物理地址，保留属性位 */
u64 hy_pte_replace_phys(u64 pte, unsigned long new_phys)
{
    return (pte & ~HY_PTE_ADDR_MASK) | (new_phys & HY_PTE_ADDR_MASK);
}

/* ============================ 物理地址提取 ============================ */

/*
 * 从表项取物理地址，自动处理块对齐。
 * 块映射（2M/1G）的偏移位数与页不同，必须按 level 屏蔽。
 */
unsigned long hy_pte_to_phys(u64 pte, int level)
{
    unsigned long mask;

    switch (level) {
    case 0:  mask = HY_PTE_ADDR_MASK;              break;  /* 4K */
    case 1:  mask = 0x0000FFFFFFE00000UL;          break;  /* 2M */
    case 2:  mask = 0x0000FFFFC0000000UL;          break;  /* 1G */
    default: mask = HY_PTE_ADDR_MASK;              break;
    }
    return pte & mask;
}

/* 给定地址与 level，返回该映射的粒度 */
unsigned long hy_map_granularity(int level)
{
    switch (level) {
    case 0:  return 0x1000UL;
    case 1:  return 0x200000UL;
    case 2:  return 0x40000000UL;
    default: return 0x1000UL;
    }
}

/* ============================ 自诊断 ============================ */

/*
 * 用当前内核地址做一次完整遍历，验证参数正确。
 * 失败说明 levels / shifts / pgd_offset 有错 —— 必须拒绝加载，
 * 否则后面写 PTE 就是往随机物理地址写。
 */
int hy_pgtable_selfcheck(unsigned long pgd_va)
{
    unsigned long test_va = (unsigned long)&g_levels;
    int level = -1;
    u64 path[8];
    int plen = 0;
    u64 *ent;

    ent = hy_walk_pgtable(pgd_va, test_va, &level, path, &plen);
    if (!ent) {
        HY_LOG("pgtable: selfcheck FAILED (no entry for %lx)\n", test_va);
        return -1;
    }

    HY_LOG("pgtable: selfcheck va=%lx level=%d depth=%d ent=%llx\n",
           test_va, level, plen, (unsigned long long)*ent);

    /* 页表项必须 valid */
    if (!(*ent & HY_PTE_VALID)) {
        HY_LOG("pgtable: selfcheck FAILED (entry invalid)\n");
        return -2;
    }

    /*
     * 【v1.66.0】不再拿 hy_virt_to_phys(test_va) 当期望值。
     *
     * test_va 是**模块自己的静态变量**，模块镜像由 kp_malloc_exec 分配，
     * 落在 module/vmalloc 区，根本不在线性映射区。对它用线性映射偏移
     * 做 VA->PA 换算是没有意义的，换出来的"期望值"必然对不上，
     * 于是这条自诊断在任何机器上都会判失败 —— 假失败。
     *
     * 这里改成检查翻出来的物理地址本身是否像个物理地址：
     * 非 0、不是全 1、且页/块对齐。这足以证明"页表参数（levels 与各级
     * 位移）能在这台机器上走通"，而走不通才是要拒绝加载的理由。
     */
    {
        unsigned long phys = hy_pte_to_phys(*ent, level);
        unsigned long gran = hy_map_granularity(level);

        HY_LOG("pgtable: selfcheck phys=%lx gran=%lx\n", phys, gran);
        if (!hy_phys_ok(phys) || (phys & (gran - 1))) {
            HY_LOG("pgtable: selfcheck FAILED (phys implausible)\n");
            return -3;
        }
    }

    HY_LOG("pgtable: selfcheck OK\n");
    return 0;
}
